package grpc

import (
	pb "kratos-stream-server/api"
	"kratos-stream-server/internal/service"
	"github.com/bilibili/kratos/pkg/net/rpc/warden"
)

// New new a grpc server.
func New(svc *service.Service) *warden.Server {

	ws := warden.NewServer(svc.AppConfig.Grpc)
	pb.RegisterUploadServer(ws.Server(),svc)
	pb.RegisterTokenServer(ws.Server(),svc)
	ws, err := ws.Start()
	if err != nil {
		panic(err)
	}
	return ws
}
