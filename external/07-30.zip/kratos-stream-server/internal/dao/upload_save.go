package dao

import (
	"crypto/md5"
	"fmt"
	fp "github.com/bilibili/kratos/pkg/database/sftp"
	"github.com/bilibili/kratos/pkg/ecode"
	"github.com/bilibili/kratos/pkg/log"
	"github.com/satori/go.uuid"
	"io/ioutil"
	pb "kratos-stream-server/api"
	"os"
	"path"
	"strings"
	"time"
	"context"
)

//获取上传的文件
func (d *dao) getUploadFile(key string, c context.Context, req *pb.UploadFileReq) (mUploadFileResp *pb.UploadFileResp, err error) {

	//文件名
	saveFile := req.Filename


	//创建文件
	newFile, err := os.Create(saveFile)
	if err != nil {
		err = ecode.ReqParamErr
		return
	}
	defer newFile.Close()

	//将获取到的文件到本地
	_, err = newFile.Write([]byte(req.WmText))
	if err != nil {
		log.Warn("file write failure err=%", err)
		err = ecode.UploadUploadErr
		return
	}

	//验证文件md5
	var hash string
	hash, err = d.Md5SumFile(saveFile)
	if err != nil {
		log.Info("file md5 Sum file=%s err=%s", saveFile, err)
		return
	}
	//获取redis是否存在md5,存在表明该文件已经被上传过
	hashKey := d.GetFileMd5RedisKey(hash)
	var value []byte
	value, err = d.GET(c, hashKey)
	if err != nil {
		log.Info("GetFileMd5RedisKey get redis save md5 file  error=%s", err.Error())
		return
	}

	//获取redis的视频名称，名称=vid+视频格式
	newFileNameFormat := string(value)
	vid := newFileNameFormat
	if newFileNameFormat != "" {
		//截取视频id
		splitNo := strings.Split(vid, ".")
		vid = splitNo[0]
		//删除文件
		os.Remove(saveFile)
	} else {
		//获取文件名后追
		fileExt := path.Ext(saveFile)
		//修改文件名为vid
		newFileName := d.GetUuid()
		vid = newFileName
		newFileNameFormat = fmt.Sprintf("%s%s", newFileName, fileExt)
		os.Rename(saveFile, newFileNameFormat)

		//文件保存到sftp
		err = fp.NewUploadSftpFile(d.Kftp, fp.REMOTE_SFTP_VODIE, newFileNameFormat)
		if err != nil {
			err = ecode.UploadUploadErr
			return
		} else {
			//删除本地的图片，只保留sftp图片
			os.Remove(newFileNameFormat)
		}
	}

	//组建参数
	mUploadFileResp = &pb.UploadFileResp{}
	mUploadFileResp.Filename = newFileNameFormat
	mUploadFileResp.Vid = vid
	mUploadFileResp.Createat = time.Now().String()
	mUploadFileResp.Createip = LOCALIP
	mUploadFileResp.Idno = req.Idno
	mUploadFileResp.Tag = req.Tag
	if req.Dir == "" {
		mUploadFileResp.Dir = fp.REMOTE_SFTP_VODIE
	} else {
		mUploadFileResp.Dir = req.Dir
	}
	mUploadFileResp.Hash = hash

	return
}

/**
获取文件的md5
*/
func (d *dao) Md5SumFile(file string) (hash string, err error) {
	var data []byte
	data, err = ioutil.ReadFile(file)
	if err != nil {
		return
	}
	value := md5.Sum(data)

	for _, v := range value {
		hash += fmt.Sprintf("%x", v)
	}
	return
}

/**
获取唯一id
*/
func (d *dao) GetUuid() (id string) {

	return uuid.NewV4().String()
}
