package main

import (
	"github.com/sony/sonyflake"
	"fmt"
	"github.com/bilibili/kratos/pkg/ecode"
	"errors"
	"strings"
	"path"
	"regexp"
	"time"
)

func genSonyflake() {
	flake := sonyflake.NewSonyflake(sonyflake.Settings{})
	id, err := flake.NextID()
	if err != nil {
		fmt.Println("flake.NextID() failed with %s\n", err)
	}
	// Note: this is base16, could shorten by encoding as base62 string
	fmt.Printf("github.com/sony/sonyflake:   %x\n", id)
}

func main() {
	//genSonyflake()

	err:=errors.New("err code !!!")
	bcode := ecode.Cause(err)
	//bcode :=ecode.New(200)
	fmt.Println(bcode.Code())
	fmt.Println(bcode.Message())
	fmt.Println(bcode.Details())

	_ratingScoreSQL := "INSERT INTO up_rating_%02d(mid,tag_id,cdate,creativity_score,influence_score,credit_score,meta_creativity_score,meta_influence_score, magnetic_score) VALUES %s ON DUPLICATE KEY UPDATE tag_id=VALUES(tag_id), cdate=VALUES(cdate), creativity_score=VALUES(creativity_score),influence_score=VALUES(influence_score),credit_score=VALUES(credit_score),meta_creativity_score=VALUES(meta_creativity_score),meta_influence_score=VALUES(meta_influence_score),magnetic_score=VALUES(magnetic_score)"

	k:=fmt.Sprintf(_ratingScoreSQL,1, "woshi")
	fmt.Println(k)

	var params string ="我似乎,我是,sww,qqq"
	arr:=strings.Split(params,",")
	for i:=0;i<len(arr) ;i++  {

		fmt.Println(string(arr[i]))
	}

	fmt.Println(arr)
	//Getenv()


	fullFilename := "/Users/a747/go/src/user-account-server/README.md"

	filenameWithSuffix :=path.Ext(fullFilename)

	fmt.Println(filenameWithSuffix)

	httpMethod :="POST"
	if matches, err := regexp.MatchString("^[A-Z]+$", httpMethod); !matches || err != nil {
		panic("http method " + httpMethod + " is not valid")
	}

	fmt.Println(time.Duration(time.Second*5))

	fmt.Println(time.Unix(0, 0))

	s:="select id,name,id_no,mobile,address,create_at,create_ip,create_by from user where mobile=%s or name=%s limit 1"
	sql:=fmt.Sprintf(s,"18017471860","陈美芳")
	fmt.Println(sql)


	r:=int(( 8 * time.Second)/time.Millisecond)
	fmt.Println(r)



	aa:=&AA{}
	aa.C=100

	bb:=&B{}
	bb.Age = aa.C
	fmt.Println(bb)
	aa.C=101

	fmt.Println(aa)


}

type AA struct {
	C int64
}

type B struct {

	Age int64
}