package service

import (
	"context"
	"encoding/json"
	"errors"
	"github.com/bilibili/kratos/pkg/conf/paladin"
	fp "github.com/bilibili/kratos/pkg/database/sftp"
	"github.com/bilibili/kratos/pkg/log"
	"github.com/golang/protobuf/ptypes/empty"
	pb "kratos-user-account-server/api"
	"kratos-user-account-server/internal/dao"
	"kratos-user-account-server/internal/model/user"
	"strings"
)

// Service service.
type Service struct {
	ac   *paladin.Map
	dao  dao.Dao
	Kftp *fp.FtpConfigs
	AppConfig *dao.Config

}

// New new a service and return.
func New() (s *Service) {
	//var ac = new(paladin.TOML)
	//if err := paladin.Watch("application.toml", ac); err != nil {
	//	panic(err)
	//}

	appConf:=dao.BuildConfig()

	s = &Service{
		//ac:   appConf,
		dao:  dao.New(),
		Kftp: appConf.Ftp,
		AppConfig:appConf,
	}
	return s
}

// SayHello grpc demo func.
func (s *Service) SayHello(ctx context.Context, req *pb.HelloReq) (reply *empty.Empty, err error) {
	reply = new(empty.Empty)
	return
}

// SayHelloURL bm demo func.
func (s *Service) SayHelloURL(ctx context.Context, req *pb.HelloReq) (reply *pb.HelloResp, err error) {
	reply = &pb.HelloResp{
		Content: "hello " + req.Name,
	}

	err = errors.New("SayHelloURL is null !!")
	return nil, err
}

/**
查询用户是否存在
 */
func(s *Service)FindUserIsExistDao(ctx context.Context,mobile string ,name string )(reply *account_service.UserReply,err error){
	//验证登录
	//bmc := ctx.(*blademaster.Context)
	//code:=auth.IsLogin(bmc)
	//if code.Code() != ecode.OK.Code(){
	//	err =errors.New(code.Message())
	//	return
	//}

	if reply, err = s.dao.FindUserIsExistDao(ctx, name,mobile); err != nil {
		log.Info("FindUserIsExistDao  mobile=%s name =%s  errors=%s", mobile,name, err)
	}
	return
}


//查询单个用户
func (s *Service) FindUser(ctx context.Context, in *account_service.FindUserReq) (reply *account_service.UserReply, err error) {
	//验证登录
	//bmc := ctx.(*blademaster.Context)
	//code:=auth.IsLogin(bmc)
	//if code.Code() != ecode.OK.Code(){
	//	err =errors.New(code.Message())
	//	return
	//}

	log.Info("FindUser params in = %s",in.IdNo)

	id_no := in.IdNo
	if reply, err = s.dao.FindUserDao(ctx, id_no); err != nil {
		log.Info("adduser save data id_no=%s  err=%s", id_no, err)
	}
	return
}

//查询多个用户
func (s *Service) FindUserList(ctx context.Context, in *account_service.FindUserReq) (reply *account_service.UserListReply, err error) {

	////验证登录
	//bmc := ctx.(*blademaster.Context)
	//code:=auth.IsLogin(bmc)
	//if code.Code() != ecode.OK.Code(){
	//	err =errors.New(code.Message())
	//	return
	//}
	
	//获取参数
	params := in.IdNo
	arrayIdNo := strings.Split(params, ",")
	if reply, err = s.dao.FindUserListDao(ctx, arrayIdNo); err != nil {
		log.Info("adduser save data id_no=%s  err=%s", arrayIdNo, err)
	}
	return
}

//AddUserReq function is  add user
func (s *Service) AddUser(ctx context.Context, req *account_service.AddUserReq) (reply *account_service.UserReply, err error) {
	//验证登录
	//bmc := ctx.(*blademaster.Context)
	//code:=auth.IsLogin(bmc)
	//if code.Code() != ecode.OK.Code(){
	//	err =errors.New(code.Message())
	//	return
	//}
	//
	name := req.Name
	mobile := req.Mobile
	if reply, err = s.dao.AddUserDao(ctx, name, mobile); err != nil {
		log.Info("adduser save data mobile=%s  err=%s", mobile, err)
		return nil, err
	}
	return
}

//update user of id_no
func (s *Service) UpdateUser(ctx context.Context, req *account_service.UpdateUserReq) (reply *account_service.UserReply, err error) {
	//验证登录
	//bmc := ctx.(*blademaster.Context)
	//code:=auth.IsLogin(bmc)
	//if code.Code() != ecode.OK.Code(){
	//	err =errors.New(code.Message())
	//	return
	//}


	mobile := req.Mobile
	address := req.Address
	idNo := req.IdNo
	if reply, err = s.dao.UpdateUserDao(ctx, idNo, mobile, address); err != nil {
		log.Error("update user  id_no=%s  ", idNo)
		return
	}
	return
}

//function delete user of id_no and name
func (s *Service) DeleteUser(ctx context.Context, req *account_service.DeleteUserReq) (reply *account_service.UserReply, err error) {

	//验证登录
	//bmc := ctx.(*blademaster.Context)
	//code:=auth.IsLogin(bmc)
	//if code.Code() != ecode.OK.Code(){
	//	err =errors.New(code.Message())
	//	return
	//}


	id_no := req.IdNo
	content := req.Content

	if reply, err = s.dao.DeleteUserDao(ctx, id_no, content); err != nil {
		log.Error("delete user  id_no=%s  ", id_no)
		return
	}

	return
}

//查询用户详细信息
func (s *Service) FindUserCommon(ctx context.Context, in *account_service.UserCommonReq) (reply *account_service.UserCommon, err error) {
	//验证登录
	//bmc := ctx.(*blademaster.Context)
	//code:=auth.IsLogin(bmc)
	//if code.Code() != ecode.OK.Code(){
	//	err =errors.New(code.Message())
	//	return
	//}

	if reply, err = s.dao.FindUserCommonDao(ctx, in); err != nil {
		return
	}

	return
}

//更新用户详细信息
//user_common表的更新只能通过user去更新用户的name mobile address
func (s *Service) UpdateUserCommon(ctx context.Context, in *account_service.UserCommon) (reply *account_service.UserCommon, err error) {
	//验证登录
	//bmc := ctx.(*blademaster.Context)
	//code:=auth.IsLogin(bmc)
	//if code.Code() != ecode.OK.Code(){
	//	err =errors.New(code.Message())
	//	return
	//}
	if reply, err = s.dao.VerifiedIdNoUser(ctx, in); err != nil {
		return
	}
	return

}


/*
检测token是否有效
*/
func (s *Service) Token(ctx context.Context, in *account_service.TokenReq) (reply *account_service.UserReply, err error) {

	var rediserr error
	var loginInfo []byte
	loginKey:=s.GetLoginToRedisKey(ctx,in.Token)
	loginInfo,rediserr=s.dao.FindRedisString(ctx,loginKey)
	if  rediserr!=nil{
		err =rediserr
		return
	}

	reply =&account_service.UserReply{}
	err=json.Unmarshal(loginInfo,reply)

	return
}

// Ping ping the resource.
func (s *Service) Ping(ctx context.Context) (err error) {
	return s.dao.Ping(ctx)
}

// Close close the resource.
func (s *Service) Close() {
	s.dao.Close()
}
