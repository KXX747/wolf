#!/usr/bin/env bash

export GO111MODULE=on
go mod download
