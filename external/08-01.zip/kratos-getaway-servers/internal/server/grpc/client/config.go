package client

const (
	DisectUserAppId="kratos-user-account-server"
	DisectUserHttpAppId="kratos-user-account-server/http"
	DisectStreamAppId="kratos-stream-server"
)



