package client

import (
	"context"
	"github.com/bilibili/kratos/pkg/log"
	"github.com/bilibili/kratos/pkg/net/rpc/warden"
	"github.com/bilibili/kratos/pkg/net/rpc/warden/resolver/livezk"
	"google.golang.org/grpc"
	"kratos-getaway-servers/api/account_service"
	"kratos-getaway-servers/internal/dao"
)

func init() {

}

/**
连接grpc的服务
 */
type UserServer struct {
	cfg *dao.Config
	userRPCClient account_service.UsersClient
	userDetailCommonClient account_service.UserDetailCommonClient

}

//user rpc client
func NewRPCUserServers(cfg *dao.Config) (mUserServer *UserServer){

	//user rpc
	userR:=livezk.Discovery(cfg.Livezk,DisectUserAppId)

	client:= warden.NewClient(cfg.RPCClient2.User) //连接grpc的初始化
	opts:=client.GetOPts()
	connUser,err:=grpc.Dial(userR.Scheme()+"://author/"+DisectUserAppId,opts...)
	if err != nil {
		panic(err)
	}
	mUsersRPCClient:=account_service.NewUsersClient(connUser)

	//usercommon rpc
	userCommonR:=livezk.Discovery(cfg.Livezk,DisectUserAppId)
	clientUserCommon:= warden.NewClient(cfg.RPCClient2.User) //连接grpc的初始化
	optsUserCommon:=clientUserCommon.GetOPts()
	connUserCommon, err := grpc.Dial(userCommonR.Scheme()+"://author/"+DisectUserAppId,optsUserCommon...)
	if err != nil {
		panic(err)
	}
	mUserDetailCommonClient:=account_service.NewUserDetailCommonClient(connUserCommon)

	//save rpc client
	mUserServer = &UserServer{
		cfg:cfg,
	}
	mUserServer.userRPCClient = mUsersRPCClient
	mUserServer.userDetailCommonClient = mUserDetailCommonClient

	return
}


//用户注册
func(service *UserServer)AddUserDao(ctx context.Context,mAddUserReq *account_service.AddUserReq)(reply *account_service.UserReply,err error){

	if reply,err =service.userRPCClient.AddUser(ctx,mAddUserReq);err!=nil {
		log.Info("userRPCClient AddUserDao err=%s mAddUserReq=%s",err,mAddUserReq)

		return nil,err
	}
	return
}

//修改用户
func(service *UserServer)UpdateUserDao(ctx context.Context,mUpdateUserReq *account_service.UpdateUserReq) (reply *account_service.UserReply,err error){

	if reply,err =service.userRPCClient.UpdateUser(ctx,mUpdateUserReq);err!=nil  {
		log.Info("userRPCClient UpdateUserDao err=%s mUpdateUserReq=%s",err,mUpdateUserReq)

		return nil,err
	}

	return
}

//删除
func(service *UserServer)DeleteUserDao(ctx context.Context,mDeleteUserReq *account_service.DeleteUserReq) (reply *account_service.UserReply,err error){
	if reply,err =service.userRPCClient.DeleteUser(ctx,mDeleteUserReq);err!=nil  {
		log.Info("userRPCClient DeleteUserDao err=%s mDeleteUserReq=%s",err,mDeleteUserReq)

		return nil,err
	}


	return
}

//查询用户
func(service *UserServer)FindUserDao(ctx context.Context,mFindUserReq *account_service.FindUserReq)(reply *account_service.UserReply,err error){
	if reply,err =service.userRPCClient.FindUser(ctx,mFindUserReq);err!=nil {
		log.Info("userRPCClient FindUserDao err=%s IdNo=%s",err,mFindUserReq.IdNo)
		return nil,err
	}
	return
}

//查询多个用户信息
func(service *UserServer)FindUserListDao(ctx context.Context,mFindUserReq *account_service.FindUserReq)(reply *account_service.UserListReply,err error){

	if reply,err =service.userRPCClient.FindUserList(ctx,mFindUserReq);err!=nil {
		log.Info("userRPCClient FindUserListDao err=%s IdNo=%s",err,mFindUserReq.IdNo)
		return nil,err
	}

	return
}

////查询用户是否存在
//func(service *UserServer)FindUserIsExistDao(ctx context.Context,name string ,mobile string )(reply *account_service.UserReply,err error){
//
//	return
//}


//验证用户登录查询用户
func(service *UserServer)VerifiedIdNoUser(ctx context.Context, in *account_service.UserCommon) (reply *account_service.UserCommon,err error){

	return
}

//更新用户信息
func(service *UserServer) UpdateUserCommon(ctx context.Context, in *account_service.UserCommon) (reply *account_service.UserCommon,err error) {

	if reply,err =service.userDetailCommonClient.UpdateUserCommon(ctx,in);err!=nil {
		log.Info("userDetailCommonClient UpdateUserCommon err=%s idNo=%s",err,in)
		return nil,err
	}
	return
}

//更新用户信息
func(service *UserServer) FindUserCommon(ctx context.Context, in *account_service.UserCommonReq) (reply *account_service.UserCommon,err error) {

	if reply,err =service.userDetailCommonClient.FindUserCommon(ctx,in);err!=nil {
		log.Info("userDetailCommonClient FindUserCommon err=%s in=%s",err,in)
		return nil,err
	}

	return
}









