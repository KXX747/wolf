package http

import (
	"fmt"
	"github.com/bilibili/kratos/pkg/ecode"
	"github.com/bilibili/kratos/pkg/log"
	"github.com/bilibili/kratos/pkg/net/http/blademaster"
	"github.com/bilibili/kratos/pkg/net/rpc/warden/resolver/livezk"
	"kratos-getaway-servers/internal/model"
	"kratos-getaway-servers/internal/server/grpc/client"
	"kratos-getaway-servers/internal/service"
	"net/url"
)

const (
	//LOGIN_URL="http://127.0.0.1:38888/app/v1/common/login"
	_LOGIN_URL = "http://%s/app/v1/common/login"
	//LOGIN_OUT_URL="http://127.0.0.1:38888/app/v1/common/loginout"
	_LOGIN_OUT_URL = "http://%s/app/v1/common/loginout"
	//USER_UPLOAD_RUL="http://127.0.0.1:38888/user-account-server/upload/image"
	_USER_UPLOAD_RUL = "http://%s/app/v1/common/loginout"
)

var (
	LOGIN_URL = _LOGIN_URL
	LOGIN_OUT_URL = _LOGIN_OUT_URL
	USER_UPLOAD_RUL =_USER_UPLOAD_RUL
	resultChan = make(chan map[string]struct{})
)

//reset url
func resetUrl()  {
	LOGIN_URL = _LOGIN_URL
	LOGIN_OUT_URL = _LOGIN_OUT_URL
	USER_UPLOAD_RUL =_USER_UPLOAD_RUL
}


//discovery http server url
func discoveryHttpUserServer(svc *service.Service) {

	go livezk.DiscoveryHttp(svc.AppConfig.Livezk, client.DisectUserHttpAppId,resultChan)
	for {
		select {
		case ch :=<-resultChan:
			fmt.Println("ch=",ch)
				for value := range ch {
					resetUrl()
					LOGIN_URL = fmt.Sprintf(LOGIN_URL, value)
					LOGIN_OUT_URL = fmt.Sprintf(LOGIN_OUT_URL, value)
					USER_UPLOAD_RUL = fmt.Sprintf(USER_UPLOAD_RUL, value)
					log.Info("http请求url使用发现组建，LOGIN_URL=%s LOGIN_OUT_URL=%s USER_UPLOAD_RUL=%s", LOGIN_URL, LOGIN_OUT_URL, USER_UPLOAD_RUL)
				}


		}
		
	}
}
/**
用户登录
*/
func LoginSys(c *blademaster.Context) {

	loginInParams := new(model.LoginInSystem)
	if err := c.Bind(loginInParams); err != nil {
		c.JSON(nil, ecode.ReqParamErr)
		return
	}
	params := url.Values{}
	params.Set("name", loginInParams.Name)
	params.Set("mobile", loginInParams.Mobile)
	if req, err := userHttpClient.NewRequest("POST", LOGIN_URL, "", params); err != nil {
		log.Warn("getaway login fial err=%s", err)
		c.JSON(nil, ecode.RequestErr)
		return
	} else {
		req.Header.Set("x-seesion-token", c.Request.Header.Get("x-seesion-token"))
		var resp interface{}
		if err := userHttpClient.JSON(c, req, &resp); err != nil {
			log.Warn("getaway login JSON fial err=%s", err)
			c.JSON(nil, ecode.RequestErr)
			return
		} else {
			c.JSON(resp, nil)
		}

	}

}

/**
退出用户
*/
func LoginOut(c *blademaster.Context) {
	mLoginOutSystem := new(model.LoginOutSystem)
	if err := c.Bind(mLoginOutSystem); err != nil {
		c.JSON(nil, ecode.ReqParamErr)
		return
	}

	params := url.Values{}
	params.Set("name", mLoginOutSystem.Name)
	params.Set("mobile", mLoginOutSystem.Mobile)
	params.Set("token", mLoginOutSystem.Token)
	if req, err := userHttpClient.NewRequest("POST", LOGIN_OUT_URL, "", params); err != nil {
		log.Warn("getaway login fial  ")
		c.JSON(nil, ecode.RequestErr)
		return
	} else {
		req.Header.Set("x-seesion-token", c.Request.Header.Get("x-seesion-token"))
		var resp interface{}
		if err := userHttpClient.JSON(c, req, &resp); err != nil {
			log.Warn("getaway login JSON fial err=%s", err)
			c.JSON(nil, ecode.RequestErr)
			return
		}
		c.JSON(resp, nil)

	}
}

/**
一是 Request Body 就是整个文件内容，通过请求头（即 Header ）中的 Content-Type 字段来指定文件类型。
二是用 multipart 表单方式来上传
*/
//上传信息照片
func updatecard(ctx *blademaster.Context) {

	p := new(model.ParamUpload)
	if err := ctx.Bind(p); err != nil {
		ctx.JSON(nil, ecode.ReqParamErr)
		return
	}

	ctx.Request.ParseMultipartForm(32 << 10)
	fileOne, handlerOne, err := ctx.Request.FormFile(model.CRAD_ONE)
	if err != nil {
		log.Warn("getaway ctx.Request.FormFile err=%s", err)
		ctx.JSON(nil, ecode.RequestErr)
		return
	}
	defer fileOne.Close()

	fileTwo, handlerTwo, err := ctx.Request.FormFile(model.CRAD_TWO)
	if err != nil {
		log.Warn("getaway ctx.Request.FormFile err=%s", err)
		ctx.JSON(nil, ecode.RequestErr)
		return
	}
	defer fileTwo.Close()

	contentOne := make([]byte, handlerOne.Size)
	contentTwo := make([]byte, handlerTwo.Size)

	params := url.Values{}
	params.Set("id_no", p.IdNo)
	params.Set("user_real_name", p.UserRealName)
	params.Set("card_id", p.CradId)
	params.Set("age", p.Age)
	params.Set("sex", p.Sex)
	params.Set(model.CRAD_ONE, string(contentOne[:]))
	params.Set(model.CRAD_TWO, string(contentTwo[:]))
	if req, err := userHttpClient.NewRequest("POST", USER_UPLOAD_RUL, "", params); err != nil {
		log.Warn("getaway login fial  ")
		ctx.JSON(nil, ecode.RequestErr)
		return
	} else {
		//req.Header.Set("Content-Type", binding.MIMEMultipartPOSTForm)
		req.Header.Set("x-seesion-token", ctx.Request.Header.Get("x-seesion-token"))
		resp := &model.LoginResponse{}
		if err := userHttpClient.JSON(ctx, req, resp); err != nil {
			log.Warn("getaway login JSON fial err=%s", err)
			ctx.JSON(nil, ecode.RequestErr)
			return
		} else {
			ctx.JSON(resp, nil)
		}

	}

}
