package dao

import (
	"context"
	"database/sql"
	"github.com/bilibili/kratos/pkg/log"
	pb "kratos-stream-server/api"
	"time"
)

const (
	FILEUP  = "file_up"
	LOCALIP = "127.0.0.1"

	//视频添加查询
	_tbVedioNewAddSQL = "INSERT into tb_video(id,id_no,filename,vid,dir,create_at,create_ip,tag,hash)  VALUES(0,?,?,?,?,?,?,?,?);"

	//查询视频
	_tbVedioAchieveSQL = "select id,id_no,filename,vid,dir,create_at,create_ip,tag from tb_video where vid=? limit 1"

	//添加评价
	_tbEvaluationNewAddSQL = "INSERT into tb_evaluation(id,id_no,vid,e_idno,e_name,eid,e_content,create_at,create_ip,n_eid)  VALUES(0,?,?,?,?,?,?,?,?,?);"
	//查询评价
	_tbEvaluationAchieveSQL = "select id,id_no,vid,e_idno,e_name,eid,e_content,create_at,create_ip,n_eid from tb_evaluation where eid = ? limit"
)

/**
upload文件
视频文件
*/
func (d *dao) File(ctx context.Context, req *pb.UploadFileReq) (mUploadFileResp *pb.UploadFileResp, err error) {

	//保存数据到sftp
	mUploadFileResp, err = d.getUploadFile(FILEUP, ctx, req)
	if err!=nil {
		log.Info(" d.getUploadFile fail error=%s mUploadFileResp=%s",err.Error(),mUploadFileResp)
		return
	}

	//将数据保存到mysql
	var result sql.Result
	//id_no,filename,vid,dir,create_at,create_ip,tag,url
	result, err = d.db.Exec(ctx, _tbVedioNewAddSQL, mUploadFileResp.Idno, mUploadFileResp.Filename, mUploadFileResp.Vid, mUploadFileResp.Dir, mUploadFileResp.Createat, mUploadFileResp.Createip, mUploadFileResp.Tag,mUploadFileResp.Hash)
	if err!=nil {
		log.Info("d.db.Exec _tbVedioNewAddSQL=%s ,mUploadFileResp =%s  error=%s",_tbVedioNewAddSQL,mUploadFileResp,err.Error())
		return
	}
	result.RowsAffected()

	//保存redis
	err =d.SaveUpdateVedioByRedis(ctx,mUploadFileResp)
	if err!=nil {
		return
	}

	return
}

/**
获取视频图片服务器的token和上传位置
*/
func (d *dao) New(ctx context.Context, in *pb.NewTokenReq) (mNewTokenResp *pb.NewTokenResp, err error) {

	return
}

//添加视频评价
func (d *dao) Addevaluation(ctx context.Context, req *pb.EvaluationVodieReq) (mVodieResp *pb.EvaluationVodieResp, err error) {

	mVodieResp =&pb.EvaluationVodieResp{}
	mVodieResp.Idno = req.Idno
	mVodieResp.Vid =req.Vid
	mVodieResp.Eidno = req.Eidno
	mVodieResp.Ename =req.Ename
	mVodieResp.Econtent = req.Econtent
	mVodieResp.Createip =LOCALIP
	mVodieResp.Neid = req.Neid
	mVodieResp.Createat =time.Now().String()
	mVodieResp.Eid=d.GetUuid() //评价内容唯一eid

	var result sql.Result
	//id_no,vid,e_idno,e_name,eid,e_content,create_at,create_ip,n_eid
	result, err = d.db.Exec(ctx, _tbEvaluationNewAddSQL, mVodieResp.Idno, mVodieResp.Vid, mVodieResp.Eidno, mVodieResp.Ename, mVodieResp.Eid,mVodieResp.Econtent, mVodieResp.Createat, mVodieResp.Createip, mVodieResp.Neid)
	if err!=nil {
		log.Info(" d.db.Exec  _tbEvaluationNewAddSQL=%s req=%s error=%s ",_tbEvaluationNewAddSQL,req,err)
		return
	}
	result.LastInsertId()
	//
	//保存到redis
	err=d.SaveUpdateVedioEvalByRedis(ctx,mVodieResp)
	if err!=nil {
		return
	}
	return
}


//根据评价eid获取评价内容和子评价
//直接在redis中获取
func (d *dao) Fileallevalby(ctx context.Context, req *pb.EvaluationGetReq) (mVodieResp *pb.EvaluationListByVodieResp, err error) {
	//_tbVedioAchieveSQL
	//id_no,vid,e_idno,e_name,eid,e_content,create_at,create_ip,n_eid
	mVodieResp,err=d.QueryVedioEvalByRedis(ctx,req)
	if err!=nil {
		return
	}

	return
}

/**
获取用户的所有视频列表
 */
func (d *dao) Listfile(ctx context.Context, req *pb.FileListReq) (mFileListResp *pb.FileListResp, err error) {
	mFileListResp,err=d.QueryUserFile(ctx,req)
	if err!=nil {
		return
	}
	return
}
