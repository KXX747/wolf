package dao

import (
	"context"
	"github.com/bilibili/kratos/pkg/log"
	"fmt"
	pb "kratos-stream-server/api"
	"github.com/bilibili/kratos/pkg/cache/redis"
)

const  (
	_FILE_MD5 ="stream:file:md5:%s" //文件的md5值
	_USER_FILE_LIST="stream:user:file:list:%s" //用户的所有视频列表
	_FILE_EVAL_LIST="stream:file:eval:%s" //对视频id所有评价,neid全部为空，存储评价
	_FILE_EVAL_LIST_EVAL="stream:eval:file:eval:%s:%s" //当视频的评价neid为空时，表示这是第一条评价，这里存储的是对该评价的回复
)


//添加数据list
func(d *dao)Lpush(ctx context.Context)(err error){

	conn := d.redis.Get(ctx)
	defer conn.Close()

	return
}

//获取数据list
func(d *dao)Lrange(ctx context.Context)(err error){
	conn := d.redis.Get(ctx)
	defer conn.Close()

	return
}


//添加数据string
func(d *dao)SET(ctx context.Context,key, value string)(err error){
	conn := d.redis.Get(ctx)
	defer conn.Close()

	if _, err = conn.Do("SET", key, value); err != nil {
		log.Error("conn.Set(PING) error(%v)", err)
	}
	return
}


//获取数据string
func(d *dao)GET(ctx context.Context,key string)(reply []byte,err error){
	conn := d.redis.Get(ctx)
	defer conn.Close()
	r, e := conn.Do("GET", key);
	if  e != nil {
		log.Error("redis: conn.Do(GET, %s) error(%v)", key, e)
		err =e;
		return
	}

	//get data return []byte 。
	if r!=nil {
		reply = r.([]byte)
	}
	return
}

//添加数据hash
func(d *dao)Hset(ctx context.Context)(err error){

	conn := d.redis.Get(ctx)
	defer conn.Close()


	return
}


//获取数据hash
func(d *dao)Hget(ctx context.Context)(err error){
	conn := d.redis.Get(ctx)
	defer conn.Close()

	return
}

//添加更新redis用户视频
func(d *dao)SaveUpdateVedioByRedis(ctx context.Context,mUploadFileResp *pb.UploadFileResp)(err error){
	conn := d.redis.Get(ctx)
	defer conn.Close()
	//redis记录文件已经上传，无需重复上传的业务处理
	hashKey:=d.GetFileMd5RedisKey(mUploadFileResp.Hash)
	if err=conn.Send("SET",hashKey,mUploadFileResp.Filename);err != nil {
		log.Error("redis: conn.Send(SET, %s, %s) error(%v)", hashKey, mUploadFileResp.Filename, err)
		return
	}

	//get user file redis key
	idNoFileList:=d.GetUserFileListRedisKey(mUploadFileResp.Idno)
	var content []byte
	content,err=mUploadFileResp.Marshal()
	if err!=nil {
		log.Info("mEvaluationVodieReq  Marshal error =%s",err.Error())
		return
	}
	if err=conn.Send("lpush",idNoFileList,string(content));err != nil {
		log.Error("redis: conn.Send(lpush, %s, %s) error(%v)", idNoFileList,content, err)
		return
	}
	if err := conn.Flush(); err != nil {
		log.Error("redis: conn.Flush error(%v)", err)
	}
	for i := 0; i < 2; i++ {
		if _, err = conn.Receive(); err != nil {
			log.Error("redis: conn.Receive error(%v)", err)
			return
		}
	}

	return
}

//[idno:"5f69fcc0-6cf4-46e6-a763-0bba633b816e"
//	dir:"/SFTP/vedio" filename:"140f75a2-e7ba-4187-9448-763385f26595.mp4"
//	tag:"redis\347\211\271\346\200\247\347\233\256\345\275\225 ,mp4"
//	vid:"140f75a2-e7ba-4187-9448-763385f26595"
//	createat:"2019-07-08 16:58:52.14583 +0800 CST m=+28.945019661"
//	createip:"127.0.0.1" hash:"b9fb3a93e0126ee1f4b3d843ef2bed93"
//
//idno:"5f69fcc0-6cf4-46e6-a763-0bba633b816e"
//dir:"/SFTP/vedio" filename:"140f75a2-e7ba-4187-9448-763385f26595.mp4"
//tag:"redis\347\211\271\346\200\247\347\233\256\345\275\225 ,mp4"
//vid:"140f75a2-e7ba-4187-9448-763385f26595"
//createat:"2019-07-08 14:57:39.474389 +0800 CST m=+54.032261684"
//createip:"127.0.0.1" hash:"b9fb3a93e0126ee1f4b3d843ef2bed93"
//
//idno:"5f69fcc0-6cf4-46e6-a763-0bba633b816e" dir:"/SFTP/vedio"
//filename:"140f75a2-e7ba-4187-9448-763385f26595.mp4"
//tag:"redis\347\211\271\346\200\247\347\233\256\345\275\225 ,mp4"
//vid:"140f75a2-e7ba-4187-9448-763385f26595"
//createat:"2019-07-08 14:56:51.649703 +0800 CST m=+6.206263044"
//createip:"127.0.0.1" hash:"b9fb3a93e0126ee1f4b3d843ef2bed93" ]


/**

获取视频列表
idno 用户id获取
startPos 开始位置
endPos 结束位置
 */
func(d *dao) QueryUserFile(ctx context.Context,req *pb.FileListReq)(mFileListResp *pb.FileListResp, err error){
	conn := d.redis.Get(ctx)
	defer conn.Close()

	mFileListResp = &pb.FileListResp{}
	var reply []interface{}

	//获取指定评价的所有回复
	hashKey :=d.GetUserFileListRedisKey(req.Idno)

	//获取数据
	reply,err=redis.Values(conn.Do("lrange",hashKey,req.Startpos,req.Endpos))
	if err != nil {
		log.Error("redis: conn.Send(lpush, %s, %s) error(%v)", hashKey, err)
		return
	}

	for _, value := range reply {
		vbyte :=value.([]byte)
		pbEval :=&pb.UploadFileResp{}
		//json.Unmarshal(vbyte,pbEval)
		err =pbEval.Unmarshal(vbyte)
		if err != nil {
			log.Error("pbEval.Unmarshal error=%s", err)
			return
		}
		mFileListResp.Results =append(mFileListResp.Results,pbEval)
	}
	return
}



//添加更新redis用户对视频的评价，评价分为两种一种是评价 第二种为用户回复
func(d *dao)SaveUpdateVedioEvalByRedis(ctx context.Context,mEvaluationVodieReq *pb.EvaluationVodieResp)(err error){
	conn := d.redis.Get(ctx)
	defer conn.Close()

	var hashKey string


	//视频评价
	if mEvaluationVodieReq.Neid ==""{
		//评价的neidu不存在表示该评价不是回复
		hashKey=d.GetUserEvalListRedisKey(mEvaluationVodieReq.Vid)
	}else {
		//视频回复
		hashKey =d.GetUserEvalReplyRedisKey(mEvaluationVodieReq.Vid,mEvaluationVodieReq.Neid)
	}

	log.Info("SaveUpdateVedioEvalByRedis  mEvaluationVodieReq=%s hashKey=%s",mEvaluationVodieReq,hashKey)

	var content []byte
	content,err=mEvaluationVodieReq.Marshal()
	if err!=nil {
		log.Info("mEvaluationVodieReq  Marshal error =%s",err.Error())
		return
	}
	if err=conn.Send("lpush",hashKey,string(content));err != nil {
		log.Error("redis: conn.Send(lpush, %s, %s) error(%v)", hashKey,string(content), err)
		return
	}


	if err := conn.Flush(); err != nil {
		log.Error("redis: conn.Flush error(%v)", err)
	}
	if _, err = conn.Receive(); err != nil {
		log.Error("redis: conn.Receive error(%v)", err)
		return
	}
	return
}

/**

获取视频列表数据
vid 视频评价列表
neid 视频为评价还是回复
startPos 开始位置
endPos 结束位置
 */
func(d *dao) QueryVedioEvalByRedis(ctx context.Context,req *pb.EvaluationGetReq)(mVodieResp *pb.EvaluationListByVodieResp, err error){
	conn := d.redis.Get(ctx)
	defer conn.Close()

	mVodieResp = &pb.EvaluationListByVodieResp{}

	var reply []interface{}
	var hashKey string

	//根据neid判断在redis中获取的key
	if req.Neid ==""{
		//获取评价列表
		hashKey=d.GetUserEvalListRedisKey(req.Vid)
	}else {
		//获取指定评价的所有回复
		hashKey=d.GetUserEvalReplyRedisKey(req.Vid,req.Neid )
	}

	log.Info("QueryVedioEvalByRedis  req=%s hashKey=%s",req,hashKey)

	//获取数据
	reply,err=redis.Values(conn.Do("lrange",hashKey,req.StartPos,req.EndPos))
	if err != nil {
		log.Error("redis: conn.Send(lpush, %s, %s) error(%v)", hashKey, err)
		return
	}
	for _, value := range reply {
		vbyte :=value.([]byte)
		pbEval :=&pb.EvaluationVodieResp{}
		err=pbEval.Unmarshal(vbyte)
		if err!=nil {
			log.Error("pbEval.Unmarshal error=%s", err)
			return
		}
		mVodieResp.Results =append(mVodieResp.Results,pbEval)
	}
	return
}




//文件在redis中的key
func(d *dao)GetFileMd5RedisKey(key string)(redisKey string) {
	redisKey = fmt.Sprintf(_FILE_MD5,key)
	return
}

//用户视频文件在redis中的key
func(d *dao)GetUserFileListRedisKey(key string)(redisKey string) {
	redisKey = fmt.Sprintf(_USER_FILE_LIST,key)
	return
}

//视频的所有评价在redis中的key
func(d *dao)GetUserEvalListRedisKey(key string)(redisKey string) {
	redisKey = fmt.Sprintf(_FILE_EVAL_LIST,key)
	return
}

//视频评价的回复,vid视频唯一id，eid评价唯一id
func(d *dao)GetUserEvalReplyRedisKey(vid,eid string)(redisKey string) {
	redisKey = fmt.Sprintf(_FILE_EVAL_LIST_EVAL,vid,eid)
	return
}


