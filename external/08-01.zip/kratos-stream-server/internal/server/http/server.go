package http

import (
	"net/http"

	pb "kratos-stream-server/api"
	"kratos-stream-server/internal/model"
	"kratos-stream-server/internal/service"

	"github.com/bilibili/kratos/pkg/log"
	bm "github.com/bilibili/kratos/pkg/net/http/blademaster"
)

var (
	svc *service.Service
)

// New new a bm server.
func New(s *service.Service) (engine *bm.Engine) {

	svc = s
	engine = bm.DefaultServer(svc.AppConfig.Http)
	pb.RegisterUploadBMServer(engine,svc)
	pb.RegisterTokenBMServer(engine,svc)
	initRouter(engine)
	if err := engine.Start(); err != nil {
		panic(err)
	}
	return
}

func initRouter(e *bm.Engine) {
	e.Ping(ping)
	g := e.Group("/kratos-stream-server")
	{
		g.GET("/start", howToStart)
	}
}

func ping(ctx *bm.Context) {
	if err := svc.Ping(ctx); err != nil {
		log.Error("ping error(%v)", err)
		ctx.AbortWithStatus(http.StatusServiceUnavailable)
	}
}

// example for http request handler.
func howToStart(c *bm.Context) {
	k := &model.Kratos{
		Hello: "Golang 大法好 !!! docker",
	}
	c.JSON(k, nil)
}

