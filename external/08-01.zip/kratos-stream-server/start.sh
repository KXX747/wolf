#!/usr/bin/env bash


#export GO111MODULE=on
#go mod download
#go mod vendor

#创建项目
#kratos new kratos-stream-server -o liuhui -d /Users/a747/go/src/ --proto
echo "启动中"

#生成proto
cd $GOPATH/kratos-stream-server
cd api
#./pd-st.sh
echo "proto 完成"

#启动服务
cd ..
cd cmd
go build
#启动服务 修改pref的端口
./cmd -conf ../configs/ -http.perf=tcp://0.0.0.0:39002
echo "启动 完成"