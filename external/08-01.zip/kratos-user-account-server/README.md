# user-account-server

## 项目简介
1.用户信息

 redis实现分布式锁
 
 export GO111MODULE=on
 go mod vendor
 
 
 #!/usr/bin/env bash
 
 echo "启动中"
 
 #path="$GOPATH/kratos-user-account-server/configs/"
 #pref="-http.perf=tcp://0.0.0.0:38887"
 
 
 #生成proto
 cd $GOPATH/kratos-user-account-server
 cd internal/model/user
 ./pd-st.sh
 echo "proto 完成"
 
 #启动服务
 cd ../../../cmd
 go build -o cmd main.go
 #启动服务 修改pref的端口
 
 #echo $path $pref
 ./cmd -conf  /Users/a747/go/kratos-user-account-server/configs/ -http.perf=tcp://0.0.0.0:38887
 
