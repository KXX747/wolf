package grpc

import (
	"github.com/bilibili/kratos/pkg/net/rpc/warden"
	pb "kratos-user-account-server/api"
	"kratos-user-account-server/internal/model/user"
	"kratos-user-account-server/internal/service"
)


// New new a grpc server.
func New(svc *service.Service) *warden.Server {

	ws := warden.NewServer(svc.AppConfig.Grpc)
	//注册demo的rpc
	pb.RegisterDemoServer(ws.Server(), svc)
	//注册rpc
	account_service.RegisterUsersServer(ws.Server(), svc)
	//用户信息
	account_service.RegisterUserDetailCommonServer(ws.Server(), svc)

	ws, err := ws.Start()
	if err != nil {
		panic(err)
	}

	return ws
}


////
//
//const target = "direct://default/127.0.0.1:9000,127.0.0.1:9091" // NOTE: example
//
//// NewClient new member grpc client
//func NewClient(cfg *warden.ClientConfig, opts ...grpc.DialOption) (account_service.UsersClient, error) {
//	client := warden.NewClient(cfg, opts...)
//	conn, err := client.Dial(context.Background(), target)
//	if err != nil {
//		return nil, err
//	}
//	// 注意替换这里：
//	// NewDemoClient方法是在"api"目录下代码生成的
//	// 对应proto文件内自定义的service名字，请使用正确方法名替换
//	return account_service.NewUsersClient(conn), nil
//}
//













