#!/usr/bin/env bash

echo "启动中"

#生成proto
cd $GOPATH/kratos-user-account-server
cd internal/model/user
#./pd-st.sh
echo "proto 完成"

#启动服务
cd ../../../cmd
go build -o cmd main.go
#启动服务 修改pref的端口
#-conf $GOPATH/kratos-user-account-server/configs/
./cmd -conf ../configs/ -http.perf=tcp://0.0.0.0:38887
echo "启动 完成。。。"
