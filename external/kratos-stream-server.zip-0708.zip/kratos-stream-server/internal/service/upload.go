package service

import (
	"context"
	pb "kratos-stream-server/api"
	"fmt"
	"github.com/bilibili/kratos/pkg/net/http/blademaster"
	"errors"
	"github.com/bilibili/kratos/pkg/ecode"
	"github.com/bilibili/kratos/pkg/net/http/blademaster/middleware/auth"

)


/**
upload文件
视频文件
 */
func (s *Service)File(ctx context.Context, req *pb.UploadFileReq) (mUploadFileResp *pb.UploadFileResp, err error) {
	fmt.Println(req)

	bmc := ctx.(*blademaster.Context)
	code:=auth.IsLogin(bmc)
	if code.Code() != ecode.OK.Code(){
		err =errors.New(code.Message())
		bmc.Abort()
		return
	}
	if mUploadFileResp,err=s.dao.File(ctx,req);err!=nil {
		return
	}

	return
}

/**
	获取视频图片服务器的token和上传位置
 */
func (s *Service) New(ctx context.Context, req *pb.NewTokenReq) (mNewTokenResp *pb.NewTokenResp, err error) {
	bmc := ctx.(*blademaster.Context)
	code:=auth.IsLogin(bmc)
	if code.Code() != ecode.OK.Code(){
		err =errors.New(code.Message())
		bmc.Abort()
		return
	}

	if mNewTokenResp,err=s.dao.New(ctx,req);err!=nil {
		return
	}

	return
}
//添加视频评价
func (s *Service)  Addevaluation(ctx context.Context, req *pb.EvaluationVodieReq)(mVodieResp *pb.EvaluationVodieResp, err error){
	bmc := ctx.(*blademaster.Context)
	code:=auth.IsLogin(bmc)
	if code.Code() != ecode.OK.Code(){
		err =errors.New(code.Message())
		bmc.Abort()
		return
	}

	if mVodieResp,err=s.dao.Addevaluation(ctx,req);err!=nil {
		return
	}

	return
}

//根据评价eid获取评价内容和子评价
func (s *Service) Fileallevalby(ctx context.Context, req *pb.EvaluationGetReq) (mVodieResp *pb.EvaluationListByVodieResp, err error){
	bmc := ctx.(*blademaster.Context)
	code:=auth.IsLogin(bmc)
	if code.Code() != ecode.OK.Code(){
		err =errors.New(code.Message())
		bmc.Abort()
		return
	}
	if mVodieResp,err=s.dao.Fileallevalby(ctx,req);err!=nil {
		return
	}

	return
}


//视频和评价列表
func (s *Service)Listfile(ctx context.Context, req *pb.FileListReq) (mFileListResp *pb.FileListResp, err error){

	bmc := ctx.(*blademaster.Context)
	code:=auth.IsLogin(bmc)
	if code.Code() != ecode.OK.Code(){
		err =errors.New(code.Message())
		bmc.Abort()
		return
	}
	if mFileListResp,err=s.dao.Listfile(ctx,req);err!=nil {
		return
	}

	return
}


