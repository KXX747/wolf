package http

import (
	"net/http"

	pb "kratos-user-account-server/api"
	"kratos-user-account-server/internal/service"

	"github.com/bilibili/kratos/pkg/conf/paladin"
	"github.com/bilibili/kratos/pkg/log"
	bm "github.com/bilibili/kratos/pkg/net/http/blademaster"
	"kratos-user-account-server/internal/model/user"
)

var (
	svc *service.Service
)

// New new a bm server.
func New(s *service.Service) (engine *bm.Engine) {
	var (
		hc struct {
			Server *bm.ServerConfig
		}
	)
	if err := paladin.Get("http.toml").UnmarshalTOML(&hc); err != nil {
		if err != paladin.ErrNotExist {
			panic(err)
		}
	}
	svc = s
	engine = bm.DefaultServer(hc.Server)

	pb.RegisterDemoBMServer(engine, svc)
	account_service.RegisterUsersBMServer(engine, svc)
	account_service.RegisterUserDetailCommonBMServer(engine, svc)
	initRouter(engine)
	if err := engine.Start(); err != nil {
		panic(err)
	}
	return
}

func initRouter(e *bm.Engine) {
	//限流中间件
	limiter := bm.NewRateLimiter(nil)
	e.Use(limiter.Limit())
	//获取ping
	e.Ping(ping)
	//添加路由组
	g := e.Group("/user-account-server")
	{
		g.GET("/start", howToStart)
		g.POST("upload/image", updatecard)

	}

}


func ping(ctx *bm.Context) {
	if err := svc.Ping(ctx); err != nil {
		log.Error("ping error(%v)", err)
		ctx.AbortWithStatus(http.StatusServiceUnavailable)
	}
}
