package model

// Kratos hello kratos.
type Kratos struct {
	Hello string
}