The `Google Assistant API` allows developers to embed the Google Assistant into
their devices. It provides an audio-in (spoken user query) and
audio-out (Assistant spoken response).
