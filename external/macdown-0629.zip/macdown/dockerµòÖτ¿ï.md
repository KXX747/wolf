# docker教程

基础用法教程 https://blog.csdn.net/fgf00/article/details/51893771
docker入门之镜像管理基础 https://cloud.tencent.com/info/1e5ce1f06ec4f8845d7c9fb980481fea.html
docker网络模型 https://www.jianshu.com/p/a14ebdc37386

## 基础用法
	

	### Docker 包括三个基本概念
		镜像（Image）
		容器（Container）
		仓库（Repository）

	### Search images 搜索镜像
		docker search ubuntu
	
	###pull images 下载景象
		docker pull ubuntu
	
	###运行镜像
		docker run -i -t ubuntu:14.04 /bin/bash
	
		docker run - 运行一个容器
		-t - 分配一个（伪）tty (link is external)
		-i - 交互模式 (so we can interact with it)
		ubuntu:14.04 - 使用 ubuntu 基础镜像 14.04
		/bin/bash - 运行命令 bash shell
		
		注: ubuntu 会有多个版本，通过指定 tag 来启动特定的版本 [image]:[tag]
		$ sudo docker ps # 查看当前运行的容器, ps -a 列出当前系统所有的容器 CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS              PORTS               NAMES
		6c9129e9df10        ubuntu:14.04        /bin/bash 6 minutes ago       Up 6 minutes                            cranky_babbage	
	### 查看docker信息
		docker info 	
	
	### 镜像腿用到仓库
		 sudo docker push 192.168.0.100:5000/ubuntu # 推送镜像库到私有源[可注册   
		 docker 官方账户，推送到官方自有账户] $ sudo docker push 192.168.0.100:5000/ubuntu:14.04 # 推送指定镜像到私有源。
	
	 ###docker image 镜像的使用
		# 搜索镜像
		docker search <image> # 在docker index中搜索image
		# 下载镜像
		docker pull <image>  # 从docker registry server 中下拉image
		# 查看镜像 
	    docker images： # 列出images
	    docker images -a # 列出所有的images（包含历史）
	    docker rmi  <image ID>： # 删除一个或多个imag
	    docker image rm REPOSITY:TAG #多个相同的镜像时，删除需要指定REPOSITY:TAG

	 
	 ### docker container容器使用
	 
	 	# 使用镜像创建容器
		docker run -i -t sauloal/ubuntu14.04
		docker run -i -t sauloal/ubuntu14.04 /bin/bash # 创建一个容器，让其中运行 bash 应用，退出后容器关闭
		docker run -itd --name centos_aways --restart=always centos #创建一个名称centos_aways的容器，自动重启
		# --restart参数：always始终重启；on-failure退出状态非0时重启；默认为，no不重启
		
		# 查看容器
		    docker ps ：列出当前所有正在运行的container
		    docker ps -l ：列出最近一次启动的container
		    docker ps -a ：列出所有的container（包含历史，即运行过的container）
		    docker ps -q ：列出最近一次运行的container ID
		# 再次启动容器
		    docker start/stop/restart <container> #：开启/停止/重启container
		    docker start [container_id] #：再次运行某个container （包括历史container）
		#进入正在运行的docker容器
		    docker exec -it [container_id] /bin/bash
		    docker run -i -t -p <host_port:contain_port> #：映射 HOST 端口到容器，方便外部访问容器内服务，host_port 可以省略，省略表示把 container_port 映射到一个动态端口。
		
		# 删除容器
		    docker rm <container...> #：删除一个或多个container
		    docker rm `docker ps -a -q` #：删除所有的container
		    docker ps -a -q | xargs docker rm #：同上, 删除所有的container

	 	
	 	###docker run和create的区别
		 	docker run 和 docker create 参数基本一样，run是创建容器并后台启动，create是只创建容器。 
			docker run 相当于docker create 和 docker start
			
			run创建容器：docker run -itd
			create创建： docker create -it
			    -t, --tty                       Allocate a pseudo-TTY
			    -i, --interactive               Keep STDIN open even if not attached
			    -d, --detach                    Run container in background and print container ID #run的参数
			    
###3、持久化容器与镜像

	3.1 通过容器生成新的镜像
	
	运行中的镜像称为容器。你可以修改容器（比如删除一个文件），但这些修改不会影响到镜像。不过，你使用docker commit 命令可以把一个正在运行的容器变成一个新的镜像。
	
	docker commit <container> [repo:tag] # 将一个container固化为一个新的image，后面的repo:tag可选。
	3.2 持久化容器
	export命令用于持久化容器
	docker export <CONTAINER ID> > /tmp/export.tar
	
	3.3 持久化镜像
	Save命令用于持久化镜像
	docker save 镜像ID > /tmp/save.tar

	3.4 导入持久化container
	删除container 2161509ff65e
	docker rm 2161509ff65e
	
	导入export.tar文件
	cat /tmp/export.tar | docker import - export:latest
	
	3.5 导入持久化image
	删除image daa11948e23d
	docker rmi daa11948e23d
	
	导入save.tar文件
	docker load < /tmp/save.tar

	对image打tag
	docker tag daa11948e23d load:tag
	
	3.6 export-import与save-load的区别
	导出后再导入(export-import)的镜像会丢失所有的历史，而保存后再加载（save-load）的镜像没有丢失历史和层(layer)。这意味着使用导出后再导入的方式，你将无法回滚到之前的层(layer)，同时，使用保存后再加载的方式持久化整个镜像，就可以做到层回滚。（可以执行docker tag 来回滚之前的层）。
	
	3.7 一些其它命令
	 docker logs $CONTAINER_ID #查看docker实例运行日志，确保正常运行
	    docker inspect $CONTAINER_ID #docker inspect <image|container> 查看image或container的底层信息
	    docker build <path> 寻找path路径下名为的Dockerfile的配置文件，使用此配置生成新的image
	    docker build -t repo[:tag] 同上，可以指定repo和可选的tag
	    docker build - < <dockerfile> 使用指定的dockerfile配置文件，docker以stdin方式获取内容，使用此配置生成新的image
	    docker port <container> <container port> 查看本地哪个端口映射到container的指定端口，其实用docker ps 也可以看到

			
			    
	 	
## 镜像管理基础
	
### 镜像生成方式：Dockerfile,container commmit,docker hub automated builds

### 制作镜像上传到docker hub网站
	根据busybox制作镜像
	
	1,运行busybox镜像
		docker run --name b1 -it  docker.io/busybox   
		
	2，使用commit根据运行的container，busybox制作新镜像
		docker commit 84a252affb12 docker747/test:v0.01
	3，将docker747/test:v0.01镜像推送push到dockerhub
		登录dockerhub
		   docker login -u docker747
			Password: 
			Login Succeeded
			
		推送镜像
		docker push docker747/test 
		The push refers to a repository [docker.io/docker747/test]
		9cd5552bed74: Pushed 
		0b97b1c81a32: Mounted from library/busybox 
		v0.01: digest: sha256:9ce4208255f166ff3226e8d488ffa23bc36e38568b0b13a71e58a6607fe5b598 size: 734
	
	4，拉去pull镜像docker747/test:v0.01
		
		docker pull docker747/test
	
	5,运行镜像
		docker run --name b1 -it  docker.io/docker747/test:v0.01
			

## 容器虚拟化网络概述

###Linux内核支持的namespace类型
#### 目前，Linux内核里面实现了7种不同类型的namespace。  
名称        宏定义             隔离内容  
Cgroup      CLONE_NEWCGROUP   Cgroup root directory (since Linux 4.6)  
IPC         CLONE_NEWIPC      System V IPC, POSIX message queues (since Linux   2.6.19)  
Network     CLONE_NEWNET      Network devices, stacks, ports, etc. (since Linux 2.6.24)  
Mount       CLONE_NEWNS       Mount points (since Linux 2.4.19)  
PID         CLONE_NEWPID      Process IDs (since Linux 2.6.24)  
User        CLONE_NEWUSER     User and group IDs (started in Linux 2.6.23 and completed in Linux 3.8)  
UTS         CLONE_NEWUTS      Hostname and NIS domain name (since Linux 2.6.19)  

#### 下面简要介绍一个以上不同类型的命名空间的作用：  
IPC：用于隔离进程间通讯所需的资源（ System V IPC, POSIX message queues），PID命名空间和IPC命名空间可以组合起来用，同一个IPC名字空间内的进程可以彼此看见，允许进行交互，不同空间进程无法交互  
Network：Network Namespace为进程提供了一个完全独立的网络协议栈的视图。包括网络设备接口，IPv4和IPv6协议栈，IP路由表，防火墙规则，sockets等等。一个Network Namespace提供了一份独立的网络环境，就跟一个独立的系统一样。  
Mount：每个进程都存在于一个mount Namespace里面，mount Namespace为进程提供了一个文件层次视图。如果不设定这个flag，子进程和父进程将共享一个mount Namespace，其后子进程调用mount或umount将会影响到所有该Namespace内的进程。如果子进程在一个独立的mount Namespace里面，就可以调用mount或umount建立一份新的文件层次视图。  
PID：：linux通过命名空间管理进程号，同一个进程，在不同的命名空间进程号不同！进程命名空间是一个父子结构，子空间对于父空间可见。  
User：用于隔离用户  
UTS：用于隔离主机名  


#### docker网络模型

	查看docker的网络模型
	docker network ls
	NETWORK ID          NAME                DRIVER              SCOPE
	52fa4ba790c3        bridge              bridge              local
	40274efa1f18        host                host                local
	74bb789db86f        none                null                local

	docker网络详解
	基于对net namespace的控制，docker可以为在容器创建隔离的网络环境，在隔离的网络环境下，容器具有完全独立的网络栈，与宿主机隔离，也可以使容器共享主机或者其他容器的网络命名空间，基本可以满足开发者在各种场景下的需要。按docker官方的说法，docker容器的网络有五种模式：
	
	bridge：docker默认的网络模式，为容器创建独立的网络命名空间，容器具有独立的网卡等所有单独的网络栈，是最常用的使用方式。
	host：直接使用容器宿主机的网络命名空间。
	none：为容器创建独立网络命名空间，但不为它做任何网络配置，容器中只有lo，用户可以在此基础上，对容器网络做任意定制。
	其他容器：与host模式类似，只是容器将与指定的容器共享网络命名空间。
	用户自定义：docker 1.9版本以后新增的特性，允许容器使用第三方的网络实现或者创建单独的bridge网络，提供网络隔离能力。
	
	
	

## docker容器网络

	
	docker网络详解 http://www.cnblogs.com/sammyliu/p/5894191.html
	


## docker存储卷

	//创建存储卷存储
	docker run --name voluma1 -it -v /data  docker.io/docker747/test:v0.01  
	
	//查看详细信息
	docker  inspect 84a252affb12 
	
	
	多个容器可以共享同一个存储卷
	


## Dockerfile详解
	
1，基于容器自定义镜像
	
	
	

## dokcer私有registy





## docker系统资源限制及验证





## docker conpose详解

docker-compose up -d nginx                     构建建启动nignx容器

docker-compose exec nginx bash            登录到nginx容器中

docker-compose down                              删除所有nginx容器,镜像

docker-compose ps                                   显示所有容器

docker-compose restart nginx                   重新启动nginx容器

docker-compose run --no-deps --rm php-fpm php -v  在php-fpm中不启动关联容器，并容器执行php -v 执行完成后删除容器

docker-compose build nginx                     构建镜像 。        

docker-compose build --no-cache nginx   不带缓存的构建。

docker-compose logs  nginx                     查看nginx的日志 

docker-compose logs -f nginx                   查看nginx的实时日志

 

docker-compose config  -q                        验证（docker-compose.yml）文件配置，当配置正确时，不输出任何内容，当文件配置错误，输出错误信息。 

docker-compose events --json nginx       以json的形式输出nginx的docker日志

docker-compose pause nginx                 暂停nignx容器

docker-compose unpause nginx             恢复ningx容器

docker-compose rm nginx                       删除容器（删除前必须关闭容器）

docker-compose stop nginx                    停止nignx容器

docker-compose start nginx                    启动nignx容器





# dockerfile优秀示例

示例一：

	FROM ubuntu:14.04.2
	MAINTAINER minimum@cepave.com
	ENV GOLANG_VERSION=1.4.1 \ 
	    GOLANG_OS=linux \
	    GOLANG_ARCH=amd64 \
	    GOROOT=/home/go \
	    GOPATH=/home/workspace \
	    PATH=$GOROOT/bin:$GOPATH/bin:$PATH
	WORKDIR /home
	RUN \ 
	  apt-get update && \
	  apt-get install -y wget vim git && \
	  wget https://storage.googleapis.com/golang/go$GOLANG_VERSION.$GOLANG_OS-$GOLANG_ARCH.tar.gz && \
	  tar -xzf go$GOLANG_VERSION.$GOLANG_OS-$GOLANG_ARCH.tar.gz && \
	  mkdir -p workspace/src && \
	  apt-get remove -y wget && \
	  apt-get clean && \
	  rm -rf /var/lib/apt/lists/* /tmp/* /var/tmp/* go$GOLANG_VERSION.$GOLANG_OS-$GOLANG_ARCH.tar.gz
	
示例二：

	FROM buildpack-deps 
	MAINTAINER Peter Martini <PeterCMartini@GMail.com> 
	RUN apt-get update \ 
	&& apt-get install -y curl procps \ 
	&& rm -fr /var/lib/apt/lists/* 
	RUN mkdir /usr/src/perl COPY *.patch /usr/src/perl/ 
	WORKDIR /usr/src/perl 
	RUN curl -SL https://cpan.metacpan.org/authors/id/S/SH/SHAY/perl-5.22.2.tar.bz2 -o perl-5.22.2.tar.bz2 \ 
	&& echo 'e2f465446dcd45a7fa3da696037f9ebe73e78e55 *perl-5.22.2.tar.bz2' | sha1sum -c - \ 
	&& tar --strip-components=1 -xjf perl-5.22.2.tar.bz2 -C /usr/src/perl \ 
	&& rm perl-5.22.2.tar.bz2 \ 
	&& cat *.patch | patch -p1 \ 
	&& ./Configure -Dusethreads -Duse64bitall -Duseshrplib -des \ 
	&& make -j$(nproc) \ && TEST_JOBS=$(nproc) make test_harness \ 
	&& make install \ 
	&& cd /usr/src \ 
	&& curl -LO https://raw.githubusercontent.com/miyagawa/cpanminus/master/cpanm \ 
	&& chmod +x cpanm \ && ./cpanm App::cpanminus \ 
	&& rm -fr ./cpanm /root/.cpanm /usr/src/perl /tmp/* 
	WORKDIR /root 
	CMD ["perl5.22.2","-de0"]
	
	作者：老菜_misa
	链接：https://www.jianshu.com/p/afa2b0c12e5e
	来源：简书
	简书著作权归作者所有，任何形式的转载都请联系作者获得授权并注明出处。
	
	
# 你可能不知道的 docker 命令的奇淫怪巧
	Intro
	介绍并收录一些可能会用到的一些简单实用却很少有人用的 docker 命令
	
	dangling images
	build 自己的 docker 镜像的时候，有时会遇到用一个甚至多个中间层镜像，这会一定程度上减少最终打包出来 docker 镜像的大小，但是会产生一些tag 为 none 的无用镜像，也称为悬挂镜像 (dangling images)
	
	列出所有的 dangling images:
	
	docker images -f "dangling=true"
	删除所有的 dangling images：
	
	docker rmi $(docker images -f "dangling=true" -q)
	批量操作
	当服务器重启或者因故关机时，docker 容器可能需要全部重新启动，启动所有 docker 容器
	
	注：如果有依赖关系，如 link 等，应该先启动这些被依赖的容器
	
	docker start $(docker ps -aq)
	停止所有 docker 容器
	
	docker stop $(docker ps -aq)
	删除所有 docker 容器
	
	docker rm $(docker ps -aq)
	删除所有 docker 镜像
	
	docker rmi $(docker images -q)
	docker 资源清理
	docker container prune # 删除所有退出状态的容器
	docker volume prune # 删除未被使用的数据卷
	docker image prune # 删除 dangling 或所有未被使用的镜像
	
	docker system prune #删除已停止的容器、dangling 镜像、未被容器引用的 network 和构建过程中的 cache
		# 安全起见，这个命令默认不会删除那些未被任何容器引用的数据卷，如果需要同时删除这些数据卷，你需要显式的指定 --volumns 参数
	docker system prune --all --force --volumns #这次不仅会删除数据卷，而且连确认的过程都没有了！注意，使用 --all 参数后会删除所有未被引用的镜像而不仅仅是 dangling 镜像