docker start mongos0
docker start mongos1
docker start mongos2
