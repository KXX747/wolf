cp -rf conf.noauth.example /home/mongodb/conf
cp -rf log.example /home/mongodb/log
