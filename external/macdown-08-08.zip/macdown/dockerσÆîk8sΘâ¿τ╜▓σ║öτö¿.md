
#一，三台centos组成keepalived虚拟IP
#### 部署机器
	110,111,112三台机器

####安装keepalived
 
    yum -y install keepalived
    
####修改配置文件keepalived.conf
 	
 	cd /etc/keepalived/keepalived.conf
 	
 	bal_defs {
   		router_id LVS_DEVEL_BACKUP
	}
	
	vrrp_instance VI_1 {
	    state BACKUP
	    interface ens33
	    virtual_router_id 51
	    priority 90
	    advert_int 1
	   # mcast_src_ip 192.168.57.111 
	    authentication {
	        auth_type PASS
	        auth_pass 1111
	    }
	    virtual_ipaddress {
	        192.168.57.180
	    }
	}
	
	virtual_server 192.168.57.180 80 {
	    # 健康检查时间间隔
	    delay_loop 6
	    lb_algo lc
	    lb_kind NAT
	    persistence_timeout 50
	    protocol TCP
	    # 通过调度算法把Master切换到真实的负载均衡服务器上
	    # 真实的主机会定期确定进行健康检查，如果MASTER不可用，则切换到备机上
	    real_server 192.168.57.110 80 {
        weight 1
        TCP_CHECK {
            # 连接超端口
            connect_port 80
            # 连接超时时间
            connect_timeout 3
        }
    }
    real_server 192.168.57.111 80 {
          weight 1
          TCP_CHECK {
              connect_port 80
              connect_timeout 3
          }
    }
    real_server 192.168.57.112 80 {
          weight 1
          TCP_CHECK {
              connect_port 80
              connect_timeout 3
          }
    }
	}


#### 配置完成后重新启动keepalived
	
		systemctl restart keepalived 
		
		ip a查看虚拟ip

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***



#二，docker 部署openresty
#### 部署机器
	110,111,112三台机器

#### 拉取openresty镜像
	
		docker pull openresty/openresty
		
####	在主机上创建openresty的配置文件，nginx.conf,logs日志目录,lua脚本目录,html目录。
		
	   cd /usr/local/openresty
	   
	   mkdir logs
	   mkdir lua
	   mkdir html
	   vi nginx.conf


#### 运行dokcer并挂载主机上的文件

	docker run  --name="pc-openresty-keepalived" -p 80:80  -v /usr/local/openresty/nginx/conf/nginx.conf:/usr/local/openresty/nginx/conf/nginx.conf -v /usr/local/openresty/nginx/logs/:/usr/local/openresrty/logs/ -v /usr/local/openresty/nginx/lua/:/usr/local/openresty/nginx/lua/ -v /usr/local/openresty/nginx/html/:/usr/local/openresty/nginx/html/ -d openresty/openresty
	
	//配置图片，视频，其他文件 的挂载路径-v /SFTP:/SFTP
	docker run  --name="pc-openresty-keepalived-sftp" -p 80:80  -v /usr/local/openresty/nginx/conf/nginx.conf:/usr/local/openresty/nginx/conf/nginx.conf -v /usr/local/openresty/nginx/logs/:/usr/local/openresrty/logs/ -v /usr/local/openresty/nginx/lua/:/usr/local/openresty/nginx/lua/ -v /usr/local/openresty/nginx/html/:/usr/local/openresty/nginx/html/ -v /SFTP:/SFTP -d openresty/openresty
	

####docker命令

	进入nginx容器	
	docker exec -it pc-openresty-keepalived  /bin/sh
	
	//重启nginx
	nginx -s reload
	//查看日志
	docker logs pc-openresty-keepalived
	
	终止Docker
	docker kill pc-openresty-keepalived && docker rm pc-openresty-keepalived
	
	//copy到其它机器指定位置
	scp -r openresrty-docker/ root@192.168.57.111:/usr/local/


#### nginx的挂载权限

	[root@dev-server ~]# getenforce
	Disabled
	[root@dev-server ~]# /usr/sbin/sestatus -v
	SELinux status:                 disabled
	
	临时关闭
	设置SELinux 成为permissive模式
	setenforce 1 设置SELinux 成为enforcing模式
	setenforce 0
	永久关闭
	
	vi /etc/selinux/config
	
	将SELINUX=enforcing改为SELINUX=disabled 
	设置后需要重启才能生效


####错误解决： docker: Error response from daemon: driver failed programming external connectivity on endpoint peaceful_sammet (0ffcb446e5de6905d872c4e20080243fce8f9928d68b857f6b4a23eadc38f2f3): iptables failed: iptables --wait -t nat -A DOCKER -p tcp -d 0/0 --dport 8080 -j DNAT --to-destination 172.17.0.2:8080 ! -i docker0: iptables: No chain/target/match by that name.


	pkill docker                         #终止进程
	iptables -t nat -F                 #清空nat表的所有链
	ifconfig docker0 down        #停止docker默认网桥
	brctl delbr docker0             #删除网桥
	systemctl restart docker       #重启docker
	
	
	

	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***

#三，k8s搭建pxc和replications集群
#### 部署机器
	110,111,112三台机器，每台机器是一个独立的集群，一个集群三个pxc

a,安装参考资源
	https://www.jianshu.com/p/8ae3da4969ed?from=timeline
	https://www.cnblogs.com/dowi/p/10220166.html
	
	https://www.percona.com/doc/kubernetes-operator-for-pxc/kubernetes.html
	https://github.com/percona/percona-xtradb-cluster-operator/tree/master
	https://my.oschina.net/u/2329318/blog/1550423



b,k8s部署pxc集群
	
	1，下载pxc的k8s资源
	git clone-brelease-0.3.0 https://github.com/percona/percona-xtradb-cluster-operator
	cd percona-xtradb-cluster-operator
	
	2，安装自定义资源
	CRDkubectl apply -f deploy/crd.yaml
	创建pxc namespacekubectl 
	kubectl create namespace pxc
	kubectl config set-context $(kubectl config current-context) --namespace=pxc
	3,创建k8s用户和权限
	kubectl apply-fdeploy/rbac.yaml
	
	4,部署operator
	kubectl apply-f deploy/operator.yaml

c,k8s配置初始密码

	配置初始密码生成加密字符串
	echo -n 'plain-text-password' | base64
	vi deploy/secrets.yaml
	
	apiVersion: v1
	kind: Secret
	metadata:  
	   name: my-cluster-secrets 
	   type: Opaque
	   data:  
	      root: 加密字符 
	      xtrabackup: 加密字符 
	      monitor: 加密字符  
	      clustercheck: 加密字符 
	      proxyuser: 加密字符 
	      proxyadmin: 加密字符 
	      pmmserver: 加密字符
	      
	部署
	kubectl apply-fdeploy/secrets.yaml


d,k8s部署pxc集群
		
		kubectl apply -f deploy/cr.yaml
		
		
		 #crontab计划
		 schedule:
      - name: "sat-night-backup"
        schedule: "0 0 * * 6"
        keep: 3       #保存几份备份
        storageName: s3-us-west
      - name: "daily-backup"
        schedule: "0 0 * * *"
        keep: 5
        storageName: fs-pvc




kubectl run -i --rm --tty percona-client --image=percona:5.7 --restart=Never -- bash -il percona-client:/$ mysql -h cluster1-proxysql -uroot -proot_password





dokcer 部署pxc集群
	
1、拉取镜像

https://github.com/vpc123/K8sZookeeper

	docker pull percona/percona-xtradb-cluster
	

2,创建docker内部网络

	docker network create --subnet=172.18.0.0/24 pxc-net
	
	查看创建网络
	docker network inspect pxc-net
	
3，创建docker卷

	docker volume create --name pxc-v1
	docker volume create --name pxc-v2
	docker volume create --name pxc-v3
	
	查看docker卷信息
	docker volume inspect pxc-v1
	docker volume inspect pxc-v2
	docker volume inspect pxc-v3
	
4,创建容器	

	容器一：
	
	docker run -di -p 3306:3306 -v v1:/var/lib/mysql -e MYSQL_ROOT_PASSWORD=rootfabric -e CLUSTER_NAME=PXC -e XTRABACKUP_PASSWORD=rootfabric --privileged=true --name=pxc-node-1 --net=pxc-net --ip 172.18.0.2 docker.io/percona/percona-xtradb-cluster
	
	容器二：	
	docker run -di -p 3307:3306 -v v2:/var/lib/mysql -e MYSQL_ROOT_PASSWORD=rootfabric -e CLUSTER_NAME=PXC -e XTRABACKUP_PASSWORD=rootfabric -e CLUSTER_JOIN=pxc-node-1 --privileged=true --name=pxc-node-2 --net=pxc-net --ip 172.18.0.3 docker.io/percona/percona-xtradb-cluster
	
	容器三：
	docker run -di -p 3308:3306 -v v3:/var/lib/mysql -e MYSQL_ROOT_PASSWORD=rootfabric -e CLUSTER_NAME=PXC -e XTRABACKUP_PASSWORD=rootfabric -e CLUSTER_JOIN=pxc-node-1 --privileged=true --name=pxc-node-3 --net=pxc-net --ip 172.18.0.4 docker.io/percona/percona-xtradb-cluster
	
	
	
grastate.dat(/var/lib/docker/volumes/mariadb/_data/grastate.dat)文件，设置
safe_to_bootstrap=1，可以尝试使用find（find / -name grastate.dat）命令查找该文件；




***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***

#四，Haproxy负载均衡
#### 部署机器
	110,111,112三台机器


 #### 拉取镜像
  
  	docker pull haproxy
  	
  在主机上创建haproxy的配置文件，haproxy.cfg
	 cd /usr/local/haproxy
	 
	 vi haproxy.cfg
	 
	 
####  运行配置
  docker run -d -it --name pc-keepalived-haproxy -v /usr/local/haproxy/haproxy.cfg:/usr/local/etc/haproxy/haproxy.cfg:ro haproxy


	采用安装 yum install -y haproxy
	
####	cd /etc/haproxy/
	vi haproxy.cfg
		
	global
    # to have these messages end up in /var/log/haproxy.log you will
    # need to:
    #
    # 1) configure syslog to accept network log events.  This is done
    #    by adding the '-r' option to the SYSLOGD_OPTIONS in
    #    /etc/sysconfig/syslog
    #
    # 2) configure local2 events to go to the /var/log/haproxy.log
    #   file. A line like the following can be added to
    #   /etc/sysconfig/syslog
    #
    #    local2.*                       /var/log/haproxy.log
    #
    log         127.0.0.1 local2

    chroot      /var/lib/haproxy
    pidfile     /var/run/haproxy.pid
    maxconn     4000
    user        haproxy
    group       haproxy
    daemon

    # turn on stats unix socket
    stats socket /var/lib/haproxy/stats

	#---------------------------------------------------------------------
	# common defaults that all the 'listen' and 'backend' sections will
	# use if not designated in their block
	#---------------------------------------------------------------------
	defaults
	    mode                    http
	    log                     global
	    option                  httplog
	    option                  dontlognull
	    option http-server-close
	    option forwardfor       except 127.0.0.0/8
	    option                  redispatch
	    retries                 3
	    timeout http-request    10s
	    timeout queue           1m
	    timeout connect         10s
	    timeout client          1m
	    timeout server          1m
	    timeout http-keep-alive 10s
	    timeout check           10s
	    maxconn                 3000
	
	#---------------------------------------------------------------------
	# main frontend which proxys to the backends
	#---------------------------------------------------------------------
	frontend  main *:21880
	    acl url_static       path_beg       -i /static /images /javascript /stylesheets
	    acl url_static       path_end       -i .jpg .gif .png .css .js
	
	    use_backend static          if url_static
	    default_backend             app
	
	#---------------------------------------------------------------------
	# static backend for serving up images, stylesheets and such
	#---------------------------------------------------------------------
	backend static
	    balance     roundrobin
	    server      static 127.0.0.1:4331 check
	
	#---------------------------------------------------------------------
	# round robin balancing between the various backends
	#---------------------------------------------------------------------
	backend app
	    balance     roundrobin
	    server  app1 192.168.57.110:80 check
	    server  app2 192.168.57.111:80 check
	    server  app3 192.168.57.112:80 check
	    server  app4 192.168.57.180:80 check
	
	
	listen  admin_stats
	        bind 0.0.0.0:21888 
	        mode  http 
	        stats uri   /haproxy
	        stats realm     Global\ statistics 
	        stats auth  admin:admin

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
#五，docker-mycat搭建

#### 部署机器
	110,111,112三台机器
		
####a,到Mycat官网下载Mycat最新版(1.6)。

####b,编写mycat的dockerfile


	FROM openjdk:8-jdk-stretch
	ADD http://dl.mycat.io/1.6.6.1/Mycat-server-1.6.6.1-release-20181031195535-linux.tar.gz /usr/local
	RUN cd /usr/local && tar -zxvf Mycat-server-1.6.6.1-release-20181031195535-linux.tar.gz && ls -lna
	
	VOLUME /usr/local/mycat/conf
	VOLUME /usr/local/mycat/logs
	EXPOSE 8066 9066
	CMD ["/usr/local/mycat/bin/mycat", "console"]
	


  docker build -t  mycat:1.6 . 
	
	
####c,构建Mycat容器		
		
	docker run --name="pc-keepalived-mycat" -p 18066:8066 -p 19066:9066 -v /usr/local/mycat/conf:/usr/local/mycat/conf -v /usr/local/mycat/logs:/usr/local/mycat/logs -d  mycat:1.6
	
	
	
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***

	

#六 canal数据同步搭建
	
			
			

CREATE USER canal IDENTIFIED BY 'canal';    
GRANT SELECT, REPLICATION SLAVE, REPLICATION CLIENT ON *.* TO 'canal'@'%';  
-- GRANT ALL PRIVILEGES ON *.* TO 'canal'@'%' ;  
FLUSH PRIVILEGES; 
--------------------- 
作者：boonya 
来源：CSDN 
原文：https://blog.csdn.net/boonya/article/details/89406067 
版权声明：本文为博主原创文章，转载请附上博文链接！

	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***



#7，docker-zookeeper集群搭建
####, 部署机器
	134,135,136三台机器
	
####1，拉取镜像

	docker pull zookeeper 
		
####2, 创建网络，此处不需要，三台机器组成zookeeper集群
	创建网络
	docker network create --subnet=172.18.0.0/24 zookeeper-net
	//查看网络
	docker network inspect zookeeper-net
	//删除网络
	docker network rm zookeeper-net
	
####3, github下载zookeeper资源在主机上，使用挂载的方式部署到docker
		
	下载到 /usr/local/
	
	修改myid
	mkdir -p /home/zk_data     #创建zk数据存放目录	echo 101 > /home/zk_data/myid   # 创建myid文件，三台机器上不可相同
		
	
####4,修改本地的配置文件zoo.cfg	
	
	cd /usr/local/zookeeper/conf
	
	# The number of milliseconds of each tick
	tickTime=2000
	# The number of ticks that the initial 
	# synchronization phase can take
	initLimit=10
	# The number of ticks that can pass between 
	# sending a request and getting an acknowledgement
	syncLimit=5
	# the directory where the snapshot is stored.
	# do not use /tmp for storage, /tmp here is just 
	# example sakes.
	dataDir=/home/zk_data
	# the port at which the clients will connect
	clientPort=2181
	# the maximum number of client connections.
	# increase this if you need to handle more clients
	#maxClientCnxns=60
	#
	# Be sure to read the maintenance section of the 
	# administrator guide before turning on autopurge.
	#
	# http://zookeeper.apache.org/doc/current/zookeeperAdmin.html#sc_maintenance
	#
	# The number of snapshots to retain in dataDir
	#autopurge.snapRetainCount=3
	# Purge task interval in hours
	# Set to "0" to disable auto purge feature
	#autopurge.purgeInterval=1
	server.101=192.168.57.134:2888:3888
	server.102=192.168.57.135:2888:3888
	server.103=192.168.57.136:2888:3888


***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***

####5,docker挂载zookeeper	
	
	134机器：
	docker run  --network host -v /home/zk_data:/data -v /usr/local/zookeeper/conf:/conf --name pc-zookeeper-1  -d docker.io/zookeeper
	
	135机器：
	docker run  --network host -v /home/zk_data:/data -v /usr/local/zookeeper/conf:/conf --name pc-zookeeper-2  -d docker.io/zookeeper
	
	136机器：
	docker run  --network host -v /home/zk_data:/data -v /usr/local/zookeeper/conf:/conf --name pc-zookeeper-3  -d docker.io/zookeeper
	

	docker exec -it pc-zookeeper-1 /bin/sh
	
	./bin/zkServer.sh status
	

	命令说明：	
	--network host: 使用主机上的网络配置，如果不用这种模式，而用默认的bridge模式，会导致容器跨主机间通信失败
	-v /data/zookeeper_data/data:/data：主机的数据目录挂载到容器/data下
	-v /data/zookeeper_data/conf:/conf： 主机的配置目录挂载到容器的/conf下，容器内的zkServer.sh默认会读取/conf/zoo.cfg下的配置
	都启动完成后，每台主机的2181/2888/3888端口都会开放出来了
	
	

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***

			

#8，docker-kafka集群搭建
	
	kafka学习参考
	https://www.cnblogs.com/cyfonly/p/5954614.html

#### 部署机器,三台机器组成kafka集群
	134,135,136三台机器
	
####1，拉取镜像

	docker pull wurstmeister/kafka
	
####2, github下载kafka资源在主机上，使用挂载的方式部署到docker
	
	下载到 /usr/local/
	
	cd /usr/local/kafka-2.2.1/config 
	
	修改 server.properties
	
	#broker.id=0  每台服务器的broker.id都不能相同
	#hostname	host.name=192.168.7.100
	#在log.retention.hours=168 下面新增下面三项	message.max.byte=5242880	default.replication.factor=2	replica.fetch.max.bytes=5242880
	#设置zookeeper的连接端口	zookeeper.connect=192.168.57.134:2181,192.168.57.135:2181,192.168.57.136:2181


	mkdir /home/kafka-logs
	
	
	
####3，制作kafka镜像 Dockfile
		
	vi Dockerfile
	FROM openjdk:8-jdk-stretch
	RUN cd /usr/local
	RUN  wget http://mirror.bit.edu.cn/apache/kafka/2.2.1/kafka_2.11-2.2.1.tgz && tar -xzf kafka_2.11-2.2.1.tgz 
	RUN cd kafka_2.11-2.2.1
	RUN ls -lna
	VOLUME /usr/local/kafka/bin
	VOLUME /usr/local/kafka/config
	VOLUME /home/kafka-logs
	EXPOSE 9092
	CMD ["/kafka_2.11-2.2.1/bin/kafka-server-start.sh", "/kafka_2.11-2.2.1/config/server.properties"]
	
	
	echo pwd
	构建镜像
	docker build -t kafka:2.2.1  .
	
	 运行kafka
	docker run  --net=host  --name="pc-kafka-1" -p 9092:9092 -v /home/kafka-logs:/home/kafka-logs -v /usr/local/kafka/config:/kafka_2.11-2.2.1/config -v /usr/local/kafka/bin:/kafka_2.11-2.2.1/bin -d  kafka:2.2.1
	
	docker run  --net=host  --name="pc-kafka-2" -p 9092:9092 -v /home/kafka-logs:/home/kafka-logs -v /usr/local/kafka/config:/kafka_2.11-2.2.1/config -v /usr/local/kafka/bin:/kafka_2.11-2.2.1/bin -d  kafka:2.2.1
	
	docker run  --net=host  --name="pc-kafka-3" -p 9092:9092 -v /home/kafka-logs:/home/kafka-logs -v /usr/local/kafka/config:/kafka_2.11-2.2.1/config -v /usr/local/kafka/bin:/kafka_2.11-2.2.1/bin -d  kafka:2.2.1
	
	配置hosts文件

	重启容器并查看配置
	docker restart 254e15b08f9a
	docker exec -it 254e15b08f9a /bin/sh 
	cd kafka_2.11-2.2.1/config
	cat server.properties
	
	查看容器的日志
	docker logs 254e15b08f9a
	
	scp -r kafka/ root@192.168.57.135:/usr/local/
	
	容器测试kafka
	创建topic
		./kafka-topics.sh --create --zookeeper 192.168.57.134:2181 --replication-factor 3 --partitions 1 --topic all-test-nihao
	
		./kafka-console-producer.sh --broker-list 192.168.57.135:9092 --topic test-nihao
		
		./kafka-console-consumer.sh --bootstrap-server 192.168.57.134:9092 --topic test-nihao --from-beginning
		
		./kafka-topics.sh --delete --zookeeper 192.168.57.34:2181 --topic test-nihao
		
		 如果还不能删除, 可以到zookeeper中去干掉它		# cd /usr/local/zookeeper-3.4.10/		# bin/zkCli.sh		# ls /brokers/topics            # 查看topic		# rmr /brokers/topics/topics_name     # 删除topic
		
	
	kafka配置文件：server.properties
	
		# The id of the broker. This must be set to a unique integer for each broker.
		broker.id=2
		
		############################# Socket Server Settings #############################
		
		# The address the socket server listens on. It will get the value returned from 
		# java.net.InetAddress.getCanonicalHostName() if not configured.
		#   FORMAT:
		#     listeners = listener_name://host_name:port
		#   EXAMPLE:
		#     listeners = PLAINTEXT://your.host.name:9092
		#listeners=PLAINTEXT://127.0.0.1:9092
		#listeners=PLAINTEXT://192.168.57.135:9092
		#host.name=192.168.57.135
		#port=9092
		# Hostname and port the broker will advertise to producers and consumers. If not set, 
		# it uses the value for "listeners" if configured.  Otherwise, it will use the value
		# returned from java.net.InetAddress.getCanonicalHostName().
		advertised.listeners=PLAINTEXT://192.168.57.135:9092
		
		# Maps listener names to security protocols, the default is for them to be the same. See the config documentation for more details
		#listener.security.protocol.map=PLAINTEXT:PLAINTEXT,SSL:SSL,SASL_PLAINTEXT:SASL_PLAINTEXT,SASL_SSL:SASL_SSL
		# The number of threads that the server uses for receiving requests from the network and sending responses to the network
		num.network.threads=3
		
		# The number of threads that the server uses for processing requests, which may include disk I/O
		num.io.threads=8
		
		# The send buffer (SO_SNDBUF) used by the socket server
		socket.send.buffer.bytes=102400
		
		# The receive buffer (SO_RCVBUF) used by the socket server
		socket.receive.buffer.bytes=102400
		
		# The maximum size of a request that the socket server will accept (protection against OOM)
		socket.request.max.bytes=104857600
		
		
		############################# Log Basics #############################
		
		# A comma separated list of directories under which to store log files
		log.dirs=/home/kafka-logs
		
		# The default number of log partitions per topic. More partitions allow greater
		# parallelism for consumption, but this will also result in more files across
		# the brokers.
		num.partitions=1
		
		# The number of threads per data directory to be used for log recovery at startup and flushing at shutdown.
		# This value is recommended to be increased for installations with data dirs located in RAID array.
		num.recovery.threads.per.data.dir=1
		
		############################# Internal Topic Settings  #############################
		# The replication factor for the group metadata internal topics "__consumer_offsets" and "__transaction_state"
		# For anything other than development testing, a value greater than 1 is recommended for to ensure availability such as 3.
		offsets.topic.replication.factor=1
		transaction.state.log.replication.factor=1
		transaction.state.log.min.isr=1
		
		############################# Log Flush Policy #############################
		
		# Messages are immediately written to the filesystem but by default we only fsync() to sync
		# the OS cache lazily. The following configurations control the flush of data to disk.
		# There are a few important trade-offs here:
		#    1. Durability: Unflushed data may be lost if you are not using replication.
		#    2. Latency: Very large flush intervals may lead to latency spikes when the flush does occur as there will be a lot of data to flush.
		#    3. Throughput: The flush is generally the most expensive operation, and a small flush interval may lead to excessive seeks.
		# The settings below allow one to configure the flush policy to flush data after a period of time or
		# every N messages (or both). This can be done globally and overridden on a per-topic basis.
		
		# The number of messages to accept before forcing a flush of data to disk
		#log.flush.interval.messages=10000
		
		# The maximum amount of time a message can sit in a log before we force a flush
		#log.flush.interval.ms=1000
		
		############################# Log Retention Policy #############################
		
		# The following configurations control the disposal of log segments. The policy can
		# be set to delete segments after a period of time, or after a given size has accumulated.
		# A segment will be deleted whenever *either* of these criteria are met. Deletion always happens
		# from the end of the log.
		
		# The minimum age of a log file to be eligible for deletion due to age
		log.retention.hours=168
		message.max.byte=5242880
		default.replication.factor=2
		replica.fetch.max.bytes=5242880
		
		# A size-based retention policy for logs. Segments are pruned from the log unless the remaining
		# segments drop below log.retention.bytes. Functions independently of log.retention.hours.
		#log.retention.bytes=1073741824
		
		# The maximum size of a log segment file. When this size is reached a new log segment will be created.
		log.segment.bytes=1073741824
		
		# The interval at which log segments are checked to see if they can be deleted according
		# to the retention policies
		log.retention.check.interval.ms=300000
		
		############################# Zookeeper #############################
		
		# Zookeeper connection string (see zookeeper docs for details).
		# This is a comma separated host:port pairs, each corresponding to a zk
		# server. e.g. "127.0.0.1:3000,127.0.0.1:3001,127.0.0.1:3002".
		# You can also append an optional chroot string to the urls to specify the
		# root directory for all kafka znodes.
		zookeeper.connect=192.168.57.134:2181,192.168.57.135:2181,192.168.57.136:2181
		
		# Timeout in ms for connecting to zookeeper
		zookeeper.connection.timeout.ms=6000
		
		
		############################# Group Coordinator Settings #############################
		
		# The following configuration specifies the time, in milliseconds, that the GroupCoordinator will delay the initial consumer rebalance.
		# The rebalance will be further delayed by the value of group.initial.rebalance.delay.ms as new members join the group, up to a maximum of max.poll.interval.ms.
		# The default value for this is 3 seconds.
		# We override this to 0 here as it makes for a better out-of-the-box experience for development and testing.
		# However, in production environments the default value of 3 seconds is more suitable as this will help to avoid unnecessary, and potentially expensive, rebalances during application startup.
		group.initial.rebalance.delay.ms=0

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***



#9,docker-搭建codis集群

#### 部署机器,三台机器组成kafka集群

	134,135,136三台机器

####github下载codis3.2.2资源在主机上，使用挂载的方式部署到docker

	https://www.jianshu.com/p/2b2bc2818243
	
	cd /usr/local
	
	//分发到135机器
	scp -r codis3.2.2 root@192.168.57.135:/usr/local
	
	cd codis3.2.2
	
	
	vi Dockerfile
	
		FROM golang:1.8
		RUN printf "deb http://archive.debian.org/debian/ jessie main\ndeb-src http://archive.debian.org/debian/ jessie main\ndeb http://security.debian.org jessie/updates main\ndeb-src http://security.debian.org jessie/updates main" > /etc/apt/sources.list
		
		RUN mv /etc/apt/sources.list /etc/apt/sources.list.bak && \
    echo "deb http://mirrors.163.com/debian/ jessie main non-free contrib" >/etc/apt/sources.list && \
    echo "deb http://mirrors.163.com/debian/ jessie-proposed-updates main non-free contrib" >>/etc/apt/sources.list && \
    echo "deb-src http://mirrors.163.com/debian/ jessie main non-free contrib" >>/etc/apt/sources.list && \
    echo "deb-src http://mirrors.163.com/debian/ jessie-proposed-updates main non-free contrib" >>/etc/apt/sources.list


		RUN apt-get update
		RUN apt-get install -y autoconf
		RUN apt-get install --assume-yes apt-utils
		
		ENV GOPATH /gopath
		ENV CODIS  ${GOPATH}/src/github.com/CodisLabs/codis
		ENV PATH   ${GOPATH}/bin:${PATH}:${CODIS}/bin
		COPY . ${CODIS}
		
		RUN make -C ${CODIS} distclean
		RUN make -C ${CODIS} build-all
		
		WORKDIR /codis
	
	
	
	构建镜像
	docker build -f Dockerfile  -t codis-image .
	
	

启动配置参考：
	https://www.jianshu.com/p/2b2bc2818243
	https://blog.csdn.net/wyc_cs/article/details/77074421 
	
docker安装后无法访问，改为裸机安装
	
	
***
***
***
***
***
***
***
	
###二；codis裸机安装依赖编译

  安装编译依赖：
  
	yum install autoconf automake libtool -y
	yum install -y gcc glibc gcc-c++ make git
	
	 make
	 
	 make gotest
	 
	
 修改配置文件：config下的配置文件修改
 
 	目录配置
 		
 		mkdir -p /usr/local/codis/{bin,logs,data}/
  		cp -rf /root/go/src/github.com/CodisLabs/codis/bin/* /usr/local/codis/bin
  		cp -rf /root/go/src/github.com/CodisLabs/codis/config /usr/local/codis/config
  
  		
  （1）Codis Dashboard （192.168.57.134 主机）
  

		dashboard是仪表盘，可以把其他服务绑定到监控仪表盘来进行服务管理及监控。
		
		编辑配置文件/usr/local/codis/config/dashboard.toml
		
		#coordinator_name = "filesystem"
		#coordinator_addr = "/tmp/codis"
		coordinator_name = "zookeeper"
		coordinator_addr = "192.168.57.134:2181,192.168.57.135:2181,192.168.57.136:2181"
		#coordinator_auth = ""
		
		# Set Codis Product Name/Auth.
		product_name = "codis-mysql-proxy"
		product_auth = ""
		
		# Set bind address for admin(rpc), tcp only.
		admin_addr = "0.0.0.0:18080"
		
		启动dashboard
		
	
		nohup /usr/local/codis/bin/codis-dashboard --ncpu=4 --config=/usr/local/codis/config/dashboard.toml --log=/usr/local/codis/logs/dashboard.log --log-level=WARN &		
		停止dashboard
		必须使用命令来停止dashboard，不然会报错。原因是已经在zk中注册了，但是没有正常关闭的话，zk中的信息就不能删除，再次启动会报错。
		
		/usr/local/codis/bin/codis-admin --dashboard=192.168.57.134:18080 --shutdown
	
	
	
(2）Codis Proxy

	   proxy是对外提供redis服务的入口。
		
		编辑配置文件/usr/local/codis/config/proxy.toml
	
 #主机192.168.57.134
		
		product_name = "codis-mysql-proxy"
		
		product_auth = ""
		
		session_auth = ""
		
		admin_addr = "0.0.0.0:11080"
		
		proto_type = "tcp4"
		
		proxy_addr = "0.0.0.0:19000"
		
		jodis_name = "zookeeper"
		
		jodis_addr = "192.168.57.134:2181,192.168.57.135:2181,192.168.57.136:2181"
		
		jodis_auth = ""
		
		jodis_timeout = "20s"
		
		jodis_compatible = true
		
		
 #主机192.168.57.135
 
		product_name = "codis-mysql-proxy"
		
		product_auth = ""
		
		session_auth = ""
		
		admin_addr = "0.0.0.0:11080"
		
		proto_type = "tcp4"
		
		proxy_addr = "0.0.0.0:19000"
		
		jodis_name = "zookeeper"
		
		jodis_addr = "192.168.57.134:2181,192.168.57.135:2181,192.168.57.136:2181"
		
		jodis_auth = ""
		
		jodis_timeout = "20s"
		
		jodis_compatible = true
	

 #主机192.168.57.136

		product_name = "codis-mysql-proxy"
		
		product_auth = ""
		
		session_auth = ""
		
		admin_addr = "0.0.0.0:11080"
		
		proto_type = "tcp4"
		
		proxy_addr = "0.0.0.0:19000"
		
		jodis_name = "zookeeper"
		
		jodis_addr = "192.168.57.134:2181,192.168.57.135:2181,192.168.57.136:2181"
		
		jodis_auth = ""
		
		jodis_timeout = "20s"
		
		jodis_compatible = true



启动codis-proxy
		
	nohup /usr/local/codis/bin/codis-proxy --ncpu=4 --config=/usr/local/codis/config/proxy.toml --log=/usr/local/codis/logs/proxy.log --log-level=WARN &
	
	
（3）Codis-admin

	关联proxy到dashboard
	
	#主机192.168.209.131
	
	/usr/local/codis/bin/codis-admin --dashboard=192.168.57.134:18080 --create-proxy -x 192.168.57.134:11080
	
	
	
（4）Codis-Server

	即创建redis实例,每台主机都创建2个redis实例

	mkdir -p /usr/local/codis/redis/6379
	mkdir -p /usr/local/codis/redis/6380
	
	
cp /root/go/src/github.com/CodisLabs/codis/config/redis.conf /usr/local/codis/redis/6379
cp /root/go/src/github.com/CodisLabs/codis/config/redis.conf /usr/local/codis/redis/6380

	
	
	修改/usr/local/codis/redis/6379/redis.conf配置文件

（maxmemory一定要设置最大内存，否则后面的codis无法使用）


	pidfile "/usr/local/codis/redis/6379/redis.pid"
	
	daemonize no
	
	protected-mode yes
	
	port 6379
	
	dbfilename "dump_6379.rdb"
	
	dir "/usr/local/codis/redis/6379/"
	
	logfile "/usr/local/codis/redis/6379/redis.log"
	
	requirepass ""
	
	maxmemory 1gb

 

修改/usr/local/codis/redis/6380/redis.conf配置文件

（maxmemory一定要设置最大内存，否则后面的codis无法使用）


	pidfile "/usr/local/codis/redis/6380/redis.pid"
	
	daemonize no
	
	protected-mode yes
	
	port 6380
	
	dbfilename "dump_6380.rdb"
	
	dir "/usr/local/codis/redis/6380/"
	
	logfile "/usr/local/codis/redis/6380/redis.log"
	
	requirepass ""
	
	maxmemory 1gb
	
	
	启动codis-server
	
	后面需要使用 Codis-fe或者Codis-admin 添加到集群
	
	nohup /usr/local/codis/bin/codis-server /usr/local/codis/redis/6379/redis.conf &
	nohup /usr/local/codis/bin/codis-server /usr/local/codis/redis/6380/redis.conf &

	
（5）Codis-FE

	# 启动 codis-fe
	nohup /usr/local/codis/bin/codis-fe --ncpu=4 --log=/usr/local/codis/logs/fe.log --log-level=WARN --zookeeper=192.168.57.134:2181 --listen=192.168.57.134:8888 &

	
（6）修复异常退出的 Codis-dashboard和修复异常退出的 Codis-proxy

dashboard 非正常退出，或者 kill -9 时使用

    需要正确连接到zookeeper集群
	/usr/local/codis/bin/codis-admin --remove-lock --product=codis-shanghai-south --zookeeper=192.168.57.134:2181

修复异常退出的 Codis-proxy

	proxy 非正常退出，或者 kill -9 时使用
	/usr/local/codis/bin/codis-admin --dashboard=192.168.57.136:18080 --remove-proxy --addr=192.168.57.136:11080 –force

（7）codis集群启动

  主机暂停codis-dashboard
  
   /usr/local/codis/bin/codis-admin --dashboard=192.168.57.134:18080 --shutdown

	a,主机启动codis-dashboard 134节点启动
	nohup /usr/local/codis/bin/codis-dashboard --ncpu=4 --config=/usr/local/codis/config/dashboard.toml --log=/usr/local/codis/logs/dashboard.log --log-level=WARN &
			
	b,创建proxy
	nohup /usr/local/codis/bin/codis-proxy --ncpu=4 --config=/usr/local/codis/config/proxy.toml --log=/usr/local/codis/logs/proxy.log --log-level=WARN &
	
	c,主机proxy和dashboard关联
	/usr/local/codis/bin/codis-admin --dashboard=192.168.57.134:18080 --create-proxy -x 192.168.57.134:11080
	
	d,启动redis
	nohup /usr/local/codis/bin/codis-server /usr/local/codis/redis/6379/redis.conf &
	nohup /usr/local/codis/bin/codis-server /usr/local/codis/redis/6380/redis.conf &
	
	//e,主机机器启动fe
	nohup /usr/local/codis/bin/codis-fe --ncpu=4 --log=/usr/local/codis/logs/fe.log --log-level=WARN --zookeeper=192.168.57.134:2181,192.168.57.135:2181,192.168.57.136:2181 --listen=192.168.57.134:8888 &
	
	f,codis集群启动成功 无法提供服务，需要redis进行分组和slots
		


 (8),在fe界面查看、添加proxy代理服务，在添加的时候proxy需要启动
 
 	proxy启动默认会自动注册到dashboard中，也可以在fe中手动添加,

	“Proxy Admin Address”选项中分别填写如下内容，然后点击“New Proxy”按钮添加
	
	192.168.57.134:11080
	
	192.168.57.135:11080
	
	192.168.57.136:11080
	
	备注：主机的codis-proxy服务需要启动，11080端口是互通的，才能添加成功，结果如下：
	
![codis-proxy启动成功](https://img-blog.csdnimg.cn/20190318170625919.png)


(9),部署codis-server加入集群
	
添加group

	Group栏为空，因为我们启动的codis-server并未加入到集群，启动所有主机codis-server服务，
	
	“NEW GROUP”选项分别输入输入1，2，3，点击NEW GROUP添加3个Group。

添加实例（按照部署规划，添加redis服务）

	“Data Center” 选项填 空
	
	“Codis Server Address” 选项填192.168.57.134:6379
	
	“Group”选项填1
	
	“Data Center” 选项填 空
	
	“Codis Server Address” 选项填192.168.57.134:6380
	
	“Group”选项填1

 

	“Data Center” 选项填 空
	
	“Codis Server Address” 选项填192.168.57.135:6379
	
	“Group”选项填2
	
	“Data Center” 选项填 空
	
	“Codis Server Address” 选项填192.168.57.135:6380
	
	“Group”选项填2

 

	“Data Center” 选项填 空
	
	“Codis Server Address” 选项填192.168.57.136:6379
	
	“Group”选项填3
	
	“Data Center” 选项填 空
	
	“Codis Server Address” 选项填192.168.57.136:6380
	
	“Group”选项填3

 
 配置结果如下，图中按钮误乱操作，否则会导致服务切换，若要删除Group，需要先删除Group对应的slots
 	
 ![配置结果](https://img-blog.csdnimg.cn/20190318170625958.png)


(10),对slots进行分组
	
Migrate Range选项中，输入所要分组的slots的起和止的范围，然后输入组ID，点击后面按钮即可。也可以直接点击按钮“Rebalance All Slots”，让系统自动分配slots。

	
	




(11),codis集群并发测试

	
10000请求，200并发

	/usr/local/codis/bin/redis-benchmark -h 192.168.57.134 -p 19000 -n 10000 -c 200 -q
	
	/usr/local/codis/bin/redis-benchmark -h 192.168.57.135 -p 19000 -n 10000 -c 200 -q
	
	/usr/local/codis/bin/redis-benchmark -h 192.168.57.136 -p 19000 -n 10000 -c 200 –q


redis单机性能测试：

10000请求，200并发

	/usr/local/codis/bin/redis-benchmark -h 192.168.57.134 -p 6379 -n 10000 -c 200 –q
	
	/usr/local/codis/bin/redis-benchmark -h 192.168.57.134 -p 6380 -n 10000 -c 200 -q

 

设置10万随机key连续SET 100万次测试：

	/usr/local/codis/bin/redis-benchmark -h 192.168.57.134 -p 19000 -t set -r 100000 -n 1000000
	
	/usr/local/codis/bin/redis-benchmark -h 192.168.57.135 -p 19000 -t set -r 100000 -n 1000000
	
	/usr/local/codis/bin/redis-benchmark -h 192.168.57.136 -p 19000 -t set -r 100000 -n 1000000





参考部署
https://blog.csdn.net/guoyanliang1985/article/details/88578226

	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***


#10,consul集群搭建
	
####a, 部署机器
		
	192.168.57.136
	
####b, docker拉取镜像
	
	docker pull consul
	
	 mkdir -p /data/consul/{config,data}
	 
	 //端口观测
	 netstat -tlnp|grep consul

####c, 部署consul

主机一的命令为：
	
	docker run  --net=host --name pxc-consul-1 -v /app/consul/data:/consul/data -v /app/consul/conf:/consul/config -d docker.io/consul consul agent -server -bind=192.168.57.134 -client 0.0.0.0 -ui -bootstrap-expect=3 -data-dir /consul/data -config-dir /consul/config

主机二的命令为：
	
	docker run  --net=host --name pxc-consul-2 -v /app/consul/data:/consul/data -v /app/consul/conf:/consul/config -d docker.io/consul consul agent -server -bind=192.168.57.135 -client 0.0.0.0 -ui -bootstrap-expect=3 -data-dir /consul/data -config-dir /consul/config -join 192.168.57.134

主机三的命令为：
	
	docker run  --net=host --name pxc-consul-3 -v /data/consul/data:/consul/data -v /data/consul/config:/consul/config -d docker.io/consul consul agent -server -bind=192.168.57.136 -client 0.0.0.0 -ui -bootstrap-expect=3 -data-dir /consul/data -config-dir /consul/config -join 192.168.57.134
	

命令说明：

	--net=host：采用主机网络配置，若采用默认的bridge模式，则会存在容器跨主机间通信失败的问题
	-v /data/consul_data/data:/consul/data：主机的数据目录挂载到容器的/consul/data下，因为该容器默认的数据写入位置即是/consul/data-
	v /data/consul_data/conf:/consul/config：主机的配置目录挂载到容器的/consul/conf下，因为该容器默认的数据写入位置即是/consul/conf
	consul agent -server：consul的server启动模式consul agent -bind=192.168.0.3：consul绑定到主机的ip上consul agent  -bootstrap-expect=3：server要想启动，需要至少3个serverconsul agent -data-dir /consul/data：consul的数据目录consul agent -config-dir /consul/config：consul的配置目录consul agent -join 192.168.0.1：对于主机二、三来说，需要加入到这个集群里
	-client 0.0.0.0 -ui ： 启动ui界面


####e,启动客户端
docker exec -it 9542d5a02850 /bin/sh
consul members
//
http://192.168.57.134:8500/ui/dc1/services/consul


在配置目录下分配客户端使用的端口，避免与服务端的端口冲突：
cd /app/consul_cli/conftouch basic.jsonvi basic.json#内容如下：
{        "ports": {                "http":18501,                "dns":18601,                "rpc":18401,                "serf_lan":18301,                "serf_wan":18302,                "server":18300        
}}

最后，启动客户端：


docker run  --net=host --name pxc-consul-client -v /data/consul/data:/consul/data -v /data/consul/config:/consul/config -d docker.io/consul  consul agent -bind=192.168.57.136 -client 0.0.0.0 -ui -bootstrap-expect=3 -data-dir /consul/data -config-dir /consul/config -join 192.168.57.134

参考地址
https://www.jianshu.com/p/565a1f24d730


***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***




#11 分布式追踪系统搭建(Jaeger)
	
	搭建参考：
	https://www.lizenghai.com/archives/6130.html
	
####机器

	192.168.57.134

#### docker搭建
	
	docker pull jaegertracing/all-in-one
	
#### 启动镜像
	
	docker run -d --name jaeger -e COLLECTOR_ZIPKIN_HTTP_PORT=9411 -p 5775:5775/udp -p 6831:6831/udp -p 6832:6832/udp -p 5778:5778 -p 16686:16686 -p 14268:14268 -p 9411:9411 jaegertracing/all-in-one
	
	访问 http://192.168.57.134:16686
		
doc
https://www.jaegertracing.io/docs/1.6/getting-started/
https://www.jaegertracing.io/docs/1.13/features/


***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***


#12,elasticsearch集群搭建和Kibana可视化

####机器

	192.168.57.135

####dokcer搭建

	docker pull elasticsearch
	docker pull kibana
	
	http://www.imooc.com/article/49888?block_id=tuijian_wz
	
####

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***

	
#13,分布式服务治理系统

istio

	1.基于版本号的服务管理，可以用于灰度发布。

　　2.请求的复制回放，用于模拟真实的流量进行压测。

　　3.给请求打标签用于实时的在线压测。

　　4.更灵活的负载均衡和路由策略。

　　5.内置的熔断机制，避免整个分布式系统产生雪崩效应。

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***


#14,mongodb集群搭建
搭建机器 	config集群			shard分片集群一        shard分片集群二      mongos连接集群 		

134			configsvr0 		shardsvr00           shardsvr10          mongos0

135			configsvr1		shardsvr01	        shardsvr11          mongos1

136			configsvr2		shardsvr02	        shardsvr12          mongos2
	

####a,机器
	192.168.57.134
	192.168.57.135 
	192.168.57.136
	
	参考搭建 
	https://blog.csdn.net/yekoufeng/article/details/83412431
	
	# key生成和预拷贝
	- openssl rand -base64 745 > /home/mongodb/key.file
	- chmod 600 /home/mongodb/key.file
	- 拷贝所有.example结尾的文件到/home/mongodb目录，去掉.example后缀(注：key.file,根据每套集群环境不一样而不同，需要自己重新生成)

	
####b,dokcer搭建

	docker pull mongo
	
<!--####c,单节点启动
	docker run -d -p 27017:27017 -v mongo_configdb:/data/configdb -v mongo_db:/data/db --name mongo docker.io/mongo	
####d,mongo启动启动
	https://www.cnblogs.com/jinrain/p/8427765.html
-->
	
####c,mongodb配置服务复制集和初始化
	
	//机器配置
	192.168.57.134 configsvr0
	192.168.57.135 configsvr1
	192.168.57.136 configsvr2

	 mkdir -p /home/mongodb/data/cs/configsvr0
	 mkdir -p /home/mongodb/data/cs/configsvr1
	 mkdir -p /home/mongodb/data/cs/configsvr2
	 
	 依赖配置文件 mongod_config.confs

   //启动配置mongod_config.conf,replSetName为rs_configsvr
	 
	 
	 docker run --network host -d --name configsvr0  -v /home/mongodb/conf/mongod_config.conf:/data/configdb/mongod.conf -v /home/mongodb/testKeyFile.file:/data/configdb/key.file -v /home/mongodb/log/cs/configsvr2/config.log:/data/configdb/log/config.log -v /home/mongodb/data/cs/configsvr2:/data/configdb mongo --config /data/configdb/mongod.conf --profile=1 --slowms=10
	 
	 
	docker run --network host -d --name configsvr1  -v /home/mongodb/conf/mongod_config.conf:/data/configdb/mongod.conf -v /home/mongodb/testKeyFile.file:/data/configdb/key.file -v /home/mongodb/log/cs/configsvr1/config.log:/data/configdb/log/config.log -v /home/mongodb/data/cs/configsvr1:/data/configdb mongo --config /data/configdb/mongod.conf --profile=1 --slowms=10
	
	docker run --network host -d --name configsvr2  -v /home/mongodb/conf/mongod_config.conf:/data/configdb/mongod.conf -v /home/mongodb/testKeyFile.file:/data/configdb/key.file -v /home/mongodb/log/cs/configsvr2/config.log:/data/configdb/log/config.log -v /home/mongodb/data/cs/configsvr2:/data/configdb mongo --config /data/configdb/mongod.conf --profile=1 --slowms=10	
	
	//configsvr地址
	192.168.57.134:27019
	192.168.57.135:27019
	192.168.57.136:27019
	
	
	初始化配置服务的配置集群 ，在136机器进入config中
	
	docker exec -it 36f966a98efb /bin/sh
	mongo --host 192.168.57.134 --port 27019
	
	rs.initiate({"_id":"rs_configsvr","configsvr":true,"members":[{"_id":0,"host":"192.168.57.134:27019" },{ "_id":1,"host":"192.168.57.135:27019" },{ "_id":2,"host":"192.168.57.136:27019" }]})
	
	其中configsvr:true指明这是一个用于分片集群的Config副本集。
	rs_configsvr 集群标示 replSetName: rs_configsvr 
	
	运行结果：
	"ok" : 1
	rs_configsvr:SECONDARY> 

	
####d,创建分片复制集群和初始化

		
	//机器配置
	#134机器
	mkdir -p /home/mongodb/data/sh/shardsvr00
	mkdir -p /home/mongodb/data/sh/shardsvr10
	
	#135机器
	mkdir -p /home/mongodb/data/sh/shardsvr01
	mkdir -p /home/mongodb/data/sh/shardsvr11
	
	#136机器
	mkdir -p /home/mongodb/data/sh/shardsvr02
	mkdir -p /home/mongodb/data/sh/shardsvr12
		
	依赖配置文件 mongod_shard0.conf和mongod_shard1.conf
		
	//134机器
	docker run  -p 27018:27018 --name shardsvr00 -d -v /home/mongodb/conf/mongod_shard0.conf:/data/db/mongod.conf -v /home/mongodb/testKeyFile.file:/data/db/key.file -v /home/mongodb/log/sh/shardsvr00/shards.log:/data/db/log/shards.log -v /home/mongodb/data/sh/shardsvr00:/data/db mongo  --config /data/db/mongod.conf --profile=1 --slowms=10
	
	docker run  -p 27015:27018 --name shardsvr10 -d -v /home/mongodb/conf/mongod_shard1.conf:/data/db/mongod.conf -v /home/mongodb/testKeyFile.file:/data/db/key.file -v /home/mongodb/log/sh/shardsvr10/shards.log:/data/db/log/shards.log -v /home/mongodb/data/sh/shardsvr10:/data/db mongo  --config /data/db/mongod.conf --profile=1 --slowms=10

	//135机器
	docker run -p 27018:27018 --name shardsvr01 -d -v /home/mongodb/conf/mongod_shard0.conf:/data/db/mongod.conf -v /home/mongodb/testKeyFile.file:/data/db/key.file -v /home/mongodb/log/sh/shardsvr01/shards.log:/data/db/log/shards.log -v /home/mongodb/data/sh/shardsvr01:/data/db mongo  --config /data/db/mongod.conf --profile=1 --slowms=10
	docker run -p 27015:27018 --name shardsvr11 -d -v /home/mongodb/conf/mongod_shard1.conf:/data/db/mongod.conf -v /home/mongodb/testKeyFile.file:/data/db/key.file -v /home/mongodb/log/sh/shardsvr11/shards.log:/data/db/log/shards.log -v /home/mongodb/data/sh/shardsvr11:/data/db mongo  --config /data/db/mongod.conf --profile=1 --slowms=10
	
	//136机器
	docker run  -p 27018:27018 --name shardsvr02 -d -v /home/mongodb/conf/mongod_shard0.conf:/data/db/mongod.conf -v /home/mongodb/testKeyFile.file:/data/db/key.file -v /home/mongodb/log/sh/shardsvr02/shards.log:/data/db/log/shards.log -v /home/mongodb/data/sh/shardsvr02:/data/db mongo  --config /data/db/mongod.conf --profile=1 --slowms=10
	docker run -p 27015:27018 --name shardsvr12 -d -v /home/mongodb/conf/mongod_shard1.conf:/data/db/mongod.conf -v /home/mongodb/testKeyFile.file:/data/db/key.file -v /home/mongodb/log/sh/shardsvr12/shards.log:/data/db/log/shards.log -v /home/mongodb/data/sh/shardsvr12:/data/db mongo  --config /data/db/mongod.conf --profile=1 --slowms=10


	//shard分片的地址
	由于–shardsvr 的默认端口为 27018。所以地址为
	•shardsvr00: 192.168.57.134:27018
	•shardsvr10: 192.168.57.134:27015
	•shardsvr01: 192.168.57.135:27018
	•shardsvr11: 192.168.57.135:27015
	•shardsvr02: 192.168.57.136:27018
	•shardsvr12: 192.168.57.136:27015
	
	
	
	//分片集群rs_shardsvr0初始化依赖mongod_shard0.conf
	
	 docker exec -it 8494a9e5ee5b /bin/sh
	 mongo --host 192.168.57.136 --port 27018
	
	rs.initiate({"_id":"rs_shardsvr0","members":[{"_id":0,"host":"192.168.57.134:27018" },{ "_id":1,"host":"192.168.57.135:27018" },{ "_id":2,"host":"192.168.57.136:27018" }]})
	
	运行结果：
	 "ok" : 1
	rs_shardsvr0:SECONDARY> 
	
		
	
	//分片集群rs_shardsvr1初始化依赖mongod_shard1.conf
	
	 docker exec -it 2af7ba4276a3 /bin/sh
	 mongo --host 192.168.57.136 --port 27015
	 
	rs.initiate({"_id":"rs_shardsvr1","members":[{"_id":0,"host":"192.168.57.134:27015" },{ "_id":1,"host":"192.168.57.135:27015" },{ "_id":2,"host":"192.168.57.136:27015" }]})
		
	运行结果：
	 "ok" : 1
	rs_shardsvr0:SECONDARY> 	
	
	


####e,创建mongos，连接mongos到分片集群
	
	//机器配置
	192.168.57.134:27017
	192.168.57.135:27017
	192.168.57.136:27017
	
	依赖配置文件mongos.conf,配置了连接configsvr的集群地址
		
	
	//创建134机器的mongos
	docker run --name mongos0  -d -p 27017:27017  -v /home/mongodb/conf/mongos.conf:/data/configdb/mongos.conf -v /home/mongodb/testKeyFile.file:/data/configdb/key.file -v /home/mongodb/log/mg/mongos.log:/data/configdb/log/mongos.log --entrypoint "mongos" mongo --config /data/configdb/mongos.conf
	
	//创建135机器的mongos
	docker run --name mongos1  -d -p 27017:27017  -v /home/mongodb/conf/mongos.conf:/data/configdb/mongos.conf -v /home/mongodb/testKeyFile.file:/data/configdb/key.file -v /home/mongodb/log/mg/mongos.log:/data/configdb/log/mongos.log --entrypoint "mongos" mongo --config /data/configdb/mongos.conf
	
	//创建136机器的mongos
	docker run --name mongos2  -d -p 27017:27017  -v /home/mongodb/conf/mongos.conf:/data/configdb/mongos.conf -v /home/mongodb/testKeyFile.file:/data/configdb/key.file -v /home/mongodb/log/mg/mongos.log:/data/configdb/log/mongos.log --entrypoint "mongos" mongo --config /data/configdb/mongos.conf

	
	//初始化mongos连接到分片到集群
	
	//134为例子，135和136需要重复以下操作
	docker exec -it mongos0 /bin/sh
	mongo --host 192.168.57.134 --port 27017
	
	//初始化分片rs_shardsvr0
	sh.addShard("rs_shardsvr0/192.168.57.134:27018,192.168.57.134:27018,192.168.57.134:27018")
	运行结果：
		{
	        "shardAdded" : "rs_shardsvr0",
	        "ok" : 1,
	        "operationTime" : Timestamp(1565263929, 8),
	        "$clusterTime" : {
	                "clusterTime" : Timestamp(1565263929, 8),
	                "signature" : {
	                        "hash" : BinData(0,"AAAAAAAAAAAAAAAAAAAAAAAAAAA="),
	                        "keyId" : NumberLong(0)
	                }
	        }
		}
	
	//初始化分片rs_shardsvr1
	sh.addShard("rs_shardsvr1/192.168.57.134:27015,192.168.57.134:27015,192.168.57.134:27015")
    运行结果：
    	同上

	
####f,分片使用
	
	//数据库 启用 分片
	sh.enableSharding(“test”)
	//分片集合
	sh.shardCollection(“test.order”, {"_id": “hashed” })
	
	//插入数据
	use test
	for (i = 1; i <= 1001; i=i+1){
	db.order.insert({‘price’: 1})
	}
	
	//查看数据每个集群的分布,
	db.order.find().count()	
	
		进入 shardsvr0
		docker exec -it shardsvr00 bash

		    db.order.find().count()
		    484

		进入 shardsvr1
		docker exec -it shardsvr10 bash

		    db.order.find().count()
		    517

####g,配置集群，分片集群，mongos集群常用的shell脚本
	
	//打开关闭配置集群docker
	docker start configsvr0
	docker start configsvr1
	docker start configsvr2	
	
	docker stop configsvr0
	docker stop configsvr1
	docker stop configsvr2	
	
	//打开关闭mongos集群docker
	docker start mongos0
	docker start mongos1
	docker start mongos2
	
	docker stop mongos0
	docker stop mongos1
	docker stop mongos2
	
	//打开分片集群的docker
	docker start shardsvr00
	docker start shardsvr10
	
	docker start shardsvr01
	docker start shardsvr11
	
	docker start shardsvr02
	docker start shardsvr12
	
	//打开分片集群的docker
	docker stop shardsvr00
	docker stop shardsvr10
	
	docker stop shardsvr01
	docker stop shardsvr11
	
	docker stop shardsvr02
	docker stop shardsvr12

	

	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***

	

#15, prometheus和grafana服务监控
		
####1，机器
	192.168.57.136
	
####a,获取镜像

	docker pull prom/node-exporter
	docker pull prom/prometheus
	docker pull grafana/grafana

####b,启动node-exporter
	
	docker run -d --name px-node-exporter -p 9100:9100 -v /proc:/host/proc:ro -v /sys:/host/sys:ro -v /:/rootfs:ro --net=host prom/node-exporter 

	查看端口是否正常启动	
		
	netstat -anpt
	
	访问 http://192.168.57.136:9100/metrics


###2,启动prometheus
	
####a,新建目录prometheus，编辑配置文件prometheus.yml

	mkdir /opt/prometheus
	cd /opt/prometheus/
	vi prometheus.yml

	global:
	  scrape_interval:     60s
	  evaluation_interval: 60s
	 
	scrape_configs:
	  - job_name: prometheus
	    static_configs:
	      - targets: ['192.168.57.136:9090']
	        labels:
	          instance: prometheus
	 
	  - job_name: linux
	    static_configs:
	      - targets: ['192.168.57.136:9100']
	        labels:
	          instance: localhost


####b,启动prometheus的镜像

	docker run  -d --name px-prometheus -p 9090:9090 -v /opt/prometheus/prometheus.yml:/etc/prometheus/prometheus.yml prom/prometheus

####c,查看端口是否启动

	netstat -anpt
	
####d,访问url

	http://192.168.57.136:9090/graph
	
	
	
###3,启动grafana	

####a,新建空文件夹grafana-storage，用来存储数据

	mkdir /opt/grafana-storage
	
####b,设置权限

	chmod 777 -R /opt/grafana-storage

####c,启动grafana镜像
	
docker run -d -p 3000:3000 --name=px-grafana -v /opt/grafana-storage:/var/lib/grafana grafana/grafana

####d,权限问题 重复步骤b可解决

 GF_PATHS_DATA='/var/lib/grafana' is not writable.
You may have issues with file permissions, more information here: http://docs.grafana.org/installation/docker/#migration-from-a-previous-version-of-the-docker-container-to-5-1-or-later
mkdir: cannot create directory '/var/lib/grafana/plugins': Permission denied

####e,查看端口
	
	netstat -anpt
	
####f,访问url

	http://192.168.57.136:3000/
	
	
	admin/admin
	
	
	
###4,grafana安装Dashboards

####a,添加数据源与自带模板

	Add data source --> http://192.168.20.135:9090 --> Dashboards --> prometheus2.0 --> save&test
	
####b,在grafana所在server安装饼图插件，并重启grafana

	docker exec -it f83f046ac8f6 /bin/sh
	./grafana-cli plugins install grafana-piechart-panel
	killall grafana-server
	./grafana-server restart &
	
	
	docker exec -it px-grafana sh
	grafana-cli plugins install grafana-piechart-panel
	grafana-server restart

	
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***

	

#16,hbase	搭建

####1，机器
	192.168.57.135

https://blog.csdn.net/baifanwudi/article/details/78498325


docker pull harisekhon/hbase

docker run -d  --name px-hbase -h myhbase -p 12181:12181 -p 18080:18080 -p 18085:18085 -p 19090:19090 -p 19095:19095 -p 16000:16000 -p 16010:16010 -p 16201:16201 -p 16301:16301  harisekhon/hbase

-d表示后台
-h 定义容器host
-p表示端口映射
–name 表示容器别名 (我这里命名hbase1.3)
harisekhon/hbase是image镜像

访问页面http://localhost:16010/master-status




修改本地开发环境的hosts,

vim /etc/hosts
#添加
127.0.0.1 myhbase


https://www.jianshu.com/p/4812db0a429d


































第一阶段
kratos+mysql +codis +openresty + zookeeper
golang(log-agent , Trace ,jaeger ，bbr，，tcc，分布式锁，微服务治理，api管理权限鉴权，配置中心，pb)

任务安排

	分布式锁=redis+lua+锁，api管理权限和鉴权，配置中心,openresty搭建图片视频访问  7月9号到14号
	
	log-agent , Trace ,jaeger和opentracing标准 7月15号到21号
	
	bbr,事务,微服务治理,网关  7月22到30号


第二阶段（8月份）
mongodb + kafka +es +分布式调度系统

	第一周和第二周将mongo和kafka集成到服务中去
	
	es 第三周
	es中即成微服务的log 第四周
	
	hbase 利用晚上十点之后(8-9月底接入)
	
第三阶段（9月份）
Go框架，库和软件的精选列表
https://github.com/valyala/awesome-go
Go面试题
https://www.zhihu.com/question/60952598
go框架喝语法分析
https://blog.csdn.net/u013272009/article/category/7277910/3?
go 分词
https://github.com/go-ego/riot/blob/master/README_zh.md
go语法分析
https://blog.csdn.net/gongpulin/article/category/7337678/2?
go算法和数据结构，设计模式
https://github.com/LSivan/go_codes
go数据结构与算法
https://github.com/csunny/argo
go设计模式
https://github.com/senghoo/golang-design-pattern
后端架构集合学习：
https://github.com/xingshaocheng/architect-awesome/blob/master/README.md#hbase

第四阶段（10月份 ，工作搞定）
目标 35*15



 
 
 
 
 
 

