#一，hbase使用

创建表,第一个参数是表名，第二个参数是列簇名

	create 'table1' , 'cf1'
	
1）查看有哪些表	

	hbase(main)> list
	
2）创建表

	语法：create <table>, {NAME => <family>, VERSIONS => <VERSIONS>}
	例如：创建表t1，有两个family name：f1，f2，且版本数均为2
	hbase(main)> create 't1',{NAME => 'f1', VERSIONS => 2},{NAME => 'f2', VERSIONS => 2}
	
3）删除表

	分两步：首先disable，然后drop
	例如：删除表t1
	hbase(main)> disable 't1'
	hbase(main)> drop 't1'
	
4）查看表的结构

	语法：describe <table>
	例如：查看表t1的结构
	hbase(main)> describe 't1'
	
5）修改表结构

	修改表结构必须先disable
	语法：alter 't1', {NAME => 'f1'}, {NAME => 'f2', METHOD => 'delete'}
	例如：修改表test1的cf的TTL为180天
	hbase(main)> disable 'test1'
	hbase(main)> alter 'test1',{NAME=>'body',TTL=>'15552000'},{NAME=>'meta', TTL=>'15552000'}
	hbase(main)> enable 'test1'

作者：编程老司机
链接：https://www.jianshu.com/p/4812db0a429d
来源：简书
简书著作权归作者所有，任何形式的转载都请联系作者获得授权并注明出处。