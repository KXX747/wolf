
https://www.jianshu.com/u/bf295670d0af k8s参考
https://blog.csdn.net/u010039418/article/details/86515007
https://blog.csdn.net/kozazyh/article/category/7468753/3?
https://jimmysong.io/kubernetes-handbook/concepts/label.html
https://blog.csdn.net/cloudvtech/column/info/22605
https://o-my-chenjian.com/2016/12/08/Deploy-K8s-by-Kubeadm-on-Linux/ 搭建集群  
https://zhuanlan.zhihu.com/p/48782859 k8s网络原理

#K8s详解
Cluster:集群是指由k8s使用一些列的物理机,虚拟机和其他基础资源来运行你的应用程序.
Node:一个node就是一个运行着k8s的物理机或虚拟机,平切pod可以在其上面被调度.
Pod:一个pod对应一个由相关容器和卷组成的容器组.
Label:一个label是一个被附加到资源上的键/值对,譬如附加到一个pod上,为他传递一个用户自定义并且可是别的属性.Label还可以被应用来组织和选择子网中的资源
Selector是一个通过匹配labels来定义资源之间关系的表达式,例如为一个负载均衡的service指定pod.
Replication Controller:RC是为了保证一定数量被指定的Pod的复制品在任何时间都能正常工作.它不仅允许复制的系统易于扩展,还会处理当pod在机器重启或发生故障的时候再次创建一个.
Service:一个service定义了访问pod的方式,就像单个固定的IP地址和与其相对应的DNS之间的关系.
Volume:一个volume是一个目录,k8s volume构建在docker volumes之上,并且支持添加和配置volume目录或者其他存储设备.
Secret:secret存储了敏感数据,例如能允许容器接受请求的权限令牌.


sudo vi  /Library/Preferences/VMware\ Fusion/vmnet8/dhcpd.conf

host CentOS 7 64-haproxy {

        hardware ethernet 00:0c:29:73:00:64;
        fixed-address 192.168.57.129;
}



##k8s集群搭建

1,创建kubernetes.repo资源文件

	vi /etc/yum.repos.d/kubernetes.repo

[kubernetes]
name=Kubernetes
baseurl=https://mirrors.aliyun.com/kubernetes/yum/repos/kubernetes-el7-x86_64/
enabled=1
gpgcheck=1
repo_gpgcheck=1
gpgkey=https://mirrors.aliyun.com/kubernetes/yum/doc/yum-key.gpg https://mirrors.aliyun.com/kubernetes/yum/doc/rpm-package-key.gpg


2，yum安装

	yum install -y kubelet kubeadm kubectl
	kubelet 运行在 Cluster 所有节点上，负责启动 Pod 和容器。
	kubeadm 用于初始化 Cluster。
	kubectl 是 Kubernetes 命令行工具。通过 kubectl 可以部署和管理应用，查看各种资源，创建、删除和更新各种组件。

3,配置kubelet
	
	默认情况下，Kubelet不允许所在的主机存在交换分区，后期规划的时候，可以考虑在系统安装的时候不创建交换分区，针对已经存在交换分区的可以设置忽略禁止使用Swap的限制，不然无法启动Kubelet。
	
	[root@linux-node1 ~]# vi /etc/sysconfig/kubelet
	
	KUBELET_EXTRA_ARGS="--fail-swap-on=false"
	

4,设置内核参数

	[root@linux-node1 ~]# cat <<EOF > /etc/sysctl.d/k8s.conf
	
	net.bridge.bridge-nf-call-ip6tables = 1
	
	net.bridge.bridge-nf-call-iptables = 1
	
	net.ipv4.ip_forward = 1
	
	EOF
	
	使配置生效
	sysctl --system

5,启动kubelet并设置开机启动

	注意，此时kubelet是无法正常启动的，可以查看/var/log/messages有报错信息，等待执行初始化之后即可正常，为正常现象。
	
	systemctl enable kubelet && systemctl start kubelet
	systemctl enable docker  && systemctl start docker
	
	 mkdir -p $HOME/.kube
  	 sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
    sudo chown $(id -u):$(id -g) $HOME/.kube/config



6，kubeadm启动master集群	

	//重新定义pod-network-cidr
	 kubeadm init --apiserver-advertise-address=192.168.57.131 --image-repository registry.aliyuncs.com/google_containers --kubernetes-version v1.14.2  --pod-network-cidr=192.168.0.0/16 --service-dns-domain=cluster.local --ignore-preflight-errors=Swap --ignore-preflight-errors=NumCPU
	 
	
	启动报错
		[root@localhost ~]# kubeadm init --kubernetes-version=v1.13.1  --pod-network-cidr=172.17.0.1/16    
	[init] Using Kubernetes version: v1.13.1
	[preflight] Running pre-flight checks
	        [WARNING Service-Docker]: docker service is not enabled, please run 'systemctl enable docker.service'
	error execution phase preflight: [preflight] Some fatal errors occurred:
	        [ERROR NumCPU]: the number of available CPUs 1 is less than the required 2
	        [ERROR FileContent--proc-sys-net-bridge-bridge-nf-call-iptables]: /proc/sys/net/bridge/bridge-nf-call-iptables contents are not set to 1
	        [ERROR Swap]: running with swap on is not supported. Please disable swap
	        [ERROR KubeletVersion]: the kubelet version is higher than the control plane version. This is not a supported version skew and may lead to a malfunctional cluster. Kubelet version: "1.14.1" Control plane version: "1.13.1"
	[preflight] If you know what you are doing, you can make a check non-fatal with `--ignore-preflight-errors=...`
	
	解决：
	vi /etc/sysconfig/kubelet添加下面
	KUBELET_EXTRA_ARGS="--fail-swap-on=false"
	
	kubeadm init --kubernetes-version=v1.0.1  --pod-network-cidr=172.17.0.1/16  
	
7,master节点输出增加节点的命令

	kubeadm token create --print-join-command
	结果：
	
	kubeadm join 192.168.57.131:6443 --token lay6wi.j3xmm4rnchmss9nr     --discovery-token-ca-cert-hash sha256:04b2fbec456924d8d3eb7ba15ddc5b9197b903240a2c8ef9d5d6d8c9cbf6ef0f --ignore-preflight-errors=Swap
	
	kubeadm join 192.168.57.131:6443 --token ld5l0e.2j84weor7bcoer3m --discovery-token-ca-cert-hash sha256:00b917f2a4a9acf59eb627ed1f46905fc137f4e4cf7f35debea0d348ca866234 --ignore-preflight-errors=Swap

	[preflight] Running pre-flight checks
	[preflight] Reading configuration from the cluster...
	[preflight] FYI: You can look at this config file with 'kubectl -n kube-system get cm kubeadm-config -oyaml'
	[kubelet-start] Downloading configuration for the kubelet from the "kubelet-config-1.14" ConfigMap in the kube-system namespace
	[kubelet-start] Writing kubelet configuration to file "/var/lib/kubelet/config.yaml"
	[kubelet-start] Writing kubelet environment file with flags to file "/var/lib/kubelet/kubeadm-flags.env"
	[kubelet-start] Activating the kubelet service
	[kubelet-start] Waiting for the kubelet to perform the TLS Bootstrap...
	
	This node has joined the cluster:
	* Certificate signing request was sent to apiserver and a response was received.
	* The Kubelet was informed of the new secure connection details.
	
	Run 'kubectl get nodes' on the control-plane to see this node join the cluster.
	
8，kubeadm启动node加入master集群
			
	kubeadm join 192.168.57.131:6443 --token s91o2z.5hwsqhi0px0323s4 --discovery-token-ca-cert-hash sha256:f891a6c3356ffdc170de238fa924290e59edcb7f946d96dee9e08c0be3260aa4 --ignore-preflight-errors=Swap

	
9,在master部署flannel

	kubectl apply -f https://raw.githubusercontent.com/coreos/flannel/master/Documentation/kube-flannel.yml
	
	wget https://raw.githubusercontent.com/coreos/flannel/v0.10.0/Documentation/kube-flannel.yml

	docker pull registry.cn-hangzhou.aliyuncs.com/kubernetes1112images/flannel:v0.10.0-amd64
	docker tag registry.cn-hangzhou.aliyuncs.com/kubernetes_containers/flannel:v0.10.0-amd64 quay.io/coreos/flannel:v0.10.0-amd64
	[root@master ~]# vim kube-flannel.yml
	      containers:
	      - name: kube-flannel
	        image: quay.io/coreos/flannel:v0.10.0-amd64
	        command:
	        - /opt/bin/flanneld
	        args:
	        - --ip-masq
	        - --kube-subnet-mgr
	        - --iface=ens33   #指定网卡
	
	[root@master ~]# kubectl apply -f kube-flannel.yml

	
10，重新安装

	kubeadm reset 
	
	vi /etc/hosts
192.168.57.131 k8s-docker-node-1
192.168.57.132 k8s-docker-node-2
192.168.57.133 k8s-docker-node-3
192.168.57.134 k8s-docker-node-4
192.168.57.135 k8s-docker-node-5
192.168.57.136 k8s-docker-node-6
		

##k8s快速入门（部署openresty为例子）

手动部署一个应用包含如下操作
 
    手动创建一个控制器deployment  
    部署一个service  
    动态扩缩容Pod副本  
    滚动更新  
    动态回滚  
    配置从集群外部访问myapp  
    
 
获取node资源

	kubectl get nodes

安装openresty的pod和deployment

	kubectl run openresty-deploy --image=openresty/openresty:alpine  --replicas=1 --port=80
	
	kubectl run --generator=deployment/apps.v1 is DEPRECATED and will be removed in a future version. Use kubectl run --generator=run-pod/v1 or kubectl create instead.
	
查看安装的pod

	kubectl get pod
	NAME                                READY   STATUS              RESTARTS   AGE
	openresty-deploy-5f57f9f57b-mc6fd   0/1     ContainerCreating   0          55s
	
查看deploy部署

	kubectl get deployments
	NAME               READY   UP-TO-DATE   AVAILABLE   AGE
	openresty-deploy   0/1     1            0           2m56s
	
kubectl delete删除指定的pod

	kubectl delete pods openresty-deploy-5f57f9f57b-mc6fd
	
kubectl delete删除指定的deployment

	kubectl delete deployment openresty-deploy
	
	
查看部署的pod详细信息

	kubectl describe pod openresty-deploy-5f57f9f57b-mc6fd 
	

node节点pod无法启动/节点删除网络重置

	node1之前反复添加过,添加之前需要清除下网络
	root@master1:/var/lib/kubelet# kubectl get po -o wide
	NAME                   READY     STATUS              RESTARTS   AGE       IP           NODE
	nginx-8586cf59-6zw9k   1/1       Running             0          9m        10.244.3.3   node2
	nginx-8586cf59-jk5pc   0/1       ContainerCreating   0          9m        <none>       node1
	nginx-8586cf59-vm9h4   0/1       ContainerCreating   0          9m        <none>       node1
	nginx-8586cf59-zjb84   1/1       Running             0          9m        10.244.3.2   node2
	root@node1:~# journalctl -u kubelet
	 failed: rpc error: code = Unknown desc = NetworkPlugin cni failed to set up pod "nginx-8586cf59-rm4sh_default" network: failed to set bridge addr: "cni0" already has an IP address different from 10.244.2.1/24
	12252 cni.go:227] Error while adding to cni network: failed to set bridge addr: "cni0" already
	重置kubernetes服务，重置网络。删除网络配置，link
	kubeadm reset
	systemctl stop kubelet
	systemctl stop docker
	rm -rf /var/lib/cni/
	rm -rf /var/lib/kubelet/*
	rm -rf /etc/cni/
	ifconfig cni0 down
	ifconfig flannel.1 down
	ifconfig docker0 down
	ip link delete cni0
	ip link delete flannel.1
	systemctl start docker
	加入节点
	systemctl start docker
	kubeadm join --token 55c2c6.2a4bde1bc73a6562 192.168.1.144:6443 --discovery-token-ca-cert-hash sha256:0fdf8cfc6fecc18fded38649a4d9a81d043bf0e4bf57341239250dcc62d2c832


kubectl service为pod提供一个固定访问端点，可以提供外部访问

	Usage:
	  kubectl expose (-f FILENAME | TYPE NAME) [--port=port] [--protocol=TCP|UDP] [--target-port=number-or-name]
	[--name=name] [--external-ip=external-ip-of-service] [--type=type] [options]
	
	//为openresty创建service
	kubectl expose deployment openresty-deploy --port=18080 --target-port=80 --protocol=TCP --type=ClusterIP
	kubectl expose deployment openresty-deploy --port=80 --target-port=80 --protocol=TCP --type=ClusterIP
	
	//查看创建的openresty-deploy service
	kubectl get svc -o wide
	
	修改openresty-deploy service信息
	kubectl edit svc openresty-deploy
	
	deployment：暴露的资源类型为控制器deployment；

	nginx-deploy:  deployment的名称
	
	--port=80: service的端口
	
	--target-port=80 : Pod的端口
	
	--type="":  service类型有ClusterIP, NodePort, LoadBalancer, or ExternalName. Default is 'ClusterIP'.
	-- ClusterIP：表示这个service只能在群集内部访问，不能在集群外部访问；
	-- NodePort：表示可以在集群外部访问到；
	
	
Kubernetes主机间curl cluster ip时不通  

	在node1（或者node2）上curl 10.254.132.190（cluster ip），只有当负载到本地pod时正常，curl <本地pod ip和另一个主机pod ip>是正常的。	
	
	--service-cidr string  10.96.0.0/12
	
	ip route add 10.254.0.0/16 dev flannel.1
	主机间可以通信，但是本地pod不正常了。
	
	删除上述路由信息，添加路由如下路由解决。
	
	ip route add 10.254.0.0/16 dev docker0
	
	ip route del 10.254.0.0/16 dev docker0
	
k8s搭建busybox 

	kubectl run client -it --image=busybox --replicas=1 --restart=Never	

k8s动态扩容

	再到客户端Pod中使用service名称myapp去访问
	while true ;do wget -O - -q myapp/hostname.html;sleep 1;done

	先创建一个新应用，叫myapp
	kubectl run myapp --image=ikubernetes/myapp:v1 --replicas=2
	myapp创建一个service
	kubectl expose deployment myapp --name=myapp --port=2880
	将myapp扩容至5个
	kubectl scale deployment myapp --replicas=5
	
	
	
	

	
	
##k8s资源清单自定义入门

	一、K8S中常见的资源  
	二、创建资源清单  
	    2.1 创建资源的方法：  
	    2.2 常用资源的配置清单  
	    2.3 利用资源清单创建Pod  
	    2.4 kubectl命令管理资源有三种用法  

###查看清单文件
	    
	[root@localhost ~]# kubectl get pod  
	NAME                               READY   STATUS    RESTARTS   AGE  
	myapp-5bc569c47d-dsksl             1/1     Running   0          45m  
	openresty-deploy-b545dfd6f-fw87z   1/1     Running   0          172m  
	[root@localhost ~]# kubectl get pod myapp-5bc569c47d-dsksl -o yaml      
	
	kubectl api-versions可以查看所有API 群组/版本
  
###K8S中常见的资源	  
 
	Kubernetes中把资源实例化以后称之为对象，这里先介绍K8S中常见的核心资源有哪些：
	工作负载型资源（workload）：Pod、ReplicaSet、Deployment、StatefulSet、DaemonSet、Job、CronJob。（ReplicationController在v1.11版本被废弃）
	
	服务发现及负载均衡型资源（ServiceDiscovery、LoadBalance） :  Service 、Ingress， ...
	配置与存储型资源： Volume（存储卷）、CSI（容器存储接口，可以扩展各种各样的第三方存储卷）
	特殊类型的存储卷：ConfigMap（当配置中心来使用的资源类型）、Secret（保存敏感数据）、DownwardAPI（把外部环境中的信息输出给容器）
	
	以上这些资源都是配置在名称空间级别。
	集群级资源（都是配置在名）： Namespace、Node、Role、ClusterRole、RoleBinding（角色绑定）、ClusterRoleBinding（集群角色绑定）、元数据型资源：HPA、PodTemplate（Pod模板，用于让控制器创建Pod时使用的模板。）、LimitRange（用来定义硬件资源限制的）
	 
###k8s自定义清单说明

	1，查看清单文件结构
	kubectl explain  pods
	KIND:     Pod
	VERSION:  v1
	
	DESCRIPTION:
	     Pod is a collection of containers that can run on a host. This resource is
	     created by clients and scheduled onto hosts.
	
	FIELDS:
	   apiVersion   <string>
	     APIVersion defines the versioned schema of this representation of an
	     object. Servers should convert recognized schemas to the latest internal
	     value, and may reject unrecognized values. More info:
	     https://git.k8s.io/community/contributors/devel/api-conventions.md#resources
	
	   kind <string>
	     Kind is a string value representing the REST resource this object
	     represents. Servers may infer this from the endpoint the client submits
	     requests to. Cannot be updated. In CamelCase. More info:
	     https://git.k8s.io/community/contributors/devel/api-conventions.md#types-kinds
	
	   metadata     <Object>
	     Standard object's metadata. More info:
	     https://git.k8s.io/community/contributors/devel/api-conventions.md#metadata
	
	   spec <Object>
	     Specification of the desired behavior of the pod. More info:
	     https://git.k8s.io/community/contributors/devel/api-conventions.md#spec-and-status
	
	   status       <Object>
	     Most recently observed status of the pod. This data may not be up to date.
	     Populated by the system. Read-only. More info:
	     https://git.k8s.io/community   
	    
	  2，查看具体清单属性结构如spec
	  	kubectl explain  pods.spec
	    
	  3,常用资源的配置清单
		apiVersion: group/version
	   kubectl api-versions
		kind: 资源类别
		metadata: 元数据
		    name: 资源名称
		    namespace: 名称空间
		    labels: 标签，键值数据。数据大小有限制。
		    annotations: 注解，也是键值数据，但是它的数据没有大小限制。
		spec: 期望的状态，disired state，由用户定义，最重要。每种资源支持的字段不一样。
		status: 当前状态，current state, 本字段由K8S集群维护。 
		
		4，yaml部署自定义  
		剩下的一些命令需要事前作一些准备，我们还是用上篇文章所用的yaml文件创建mysql和sonarqube的Deployment和pod。

			yaml文件准备
			
			[root@ku8-1 tmp]# ls yamls
			mysql.yaml  sonar.yaml
			[root@ku8-1 tmp]# cat yamls/mysql.yaml 
			---
			kind: Deployment
			apiVersion: extensions/v1beta1
			metadata:
			  name: mysql
			spec:
			  replicas: 1
			  template:
			    metadata:
			      labels:
			        name: mysql
			    spec:
			      containers:
			      - name: mysql
			        image: 192.168.32.131:5000/mysql:5.7.16
			        ports:
			        - containerPort: 3306
			          protocol: TCP
			        env:
			          - name: MYSQL_ROOT_PASSWORD
			            value: "hello123"
			            
			[root@ku8-1 tmp]# cat yamls/sonar.yaml 
			---
			kind: Deployment
			apiVersion: extensions/v1beta1
			metadata:
			  name: sonarqube
			spec:
			  replicas: 1
			  template:
			    metadata:
			      labels:
			        name: sonarqube
			    spec:
			      containers:
			      - name: sonarqube
			        image: 192.168.32.131:5000/sonarqube:5.6.5
			        ports:
			        - containerPort: 9000
			          protocol: TCP 
			          
			 
			 启动：
			 kubectl create -f yamls/
			 
			 删除：
			 kubectl delete -f yamls/
			  
 
## Kubernetes Pod详解
	
###Pod的生命周期:
	
	状态：Pending,Runing,Failed,Successed,Unkown
	创建Pod:
	Pod生命周期的重要行为
		初始化容器
		容器探测
		  liveness
		  readiness

	restartPolicy
	 Restart policy for all containers within the pod. One of Always, OnFailure,
     Never. Default to Always. More info:
     https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/#restart-policy
	
###imagePullPolicy拉取策略

	Always
	默认值,总是拉取 pull
	imagePullPolicy: Always
	
	IfNotPresent
	本地有则使用本地镜像,不拉取
	imagePullPolicy: IfNotPresent
	
	Never
	只使用本地镜像，从不拉取
	imagePullPolicy: Never
	
	
	
###K8S的应用程序健康检查分为livenessProbe和readinessProbe，两者相似，但两者存在着一些区别。

		livenessProbe在服务运行过程中检查应用程序是否运行正常，不正常将杀掉进程；而readness Probe是用于检测应用程序启动完成后是否准备好对外提供服务，不正常继续检测，直到返回成功为止。
		
		livenessProbe
		许多应用程序经过长时间运行，最终过渡到无法运行的状态，除了重启，无法恢复。通常情况下，K8S会发现应用程序已经终止，然后重启应用程序/pod。
		
		有时应用程序可能因为某些原因（后端服务故障等）导致暂时无法对外提供服务，但应用软件没有终止，导致K8S无法隔离有故障的pod，调用者可能会访问到有故障的pod，导致业务不稳定。K8S提供livenessProbe来检测应用程序是否正常运行，并且对相应状况进行相应的补救措施。
		
		readinessProbe
		在没有配置readinessProbe的资源对象中，pod中的容器启动完成后，就认为pod中的应用程序可以对外提供服务，该pod就会加入相对应的service，对外提供服务。但有时一些应用程序启动后，需要较长时间的加载才能对外服务，如果这时对外提供服务，执行结果必然无法达到预期效果，影响用于体验。
		
		比如使用tomcat的应用程序来说，并不是简单地说tomcat启动成功就可以对外提供服务的，还需要等待spring容器初始化，数据库连接没连上等等。对于spring boot应用，默认的actuator带有/health接口，可以用来进行启动成功的判断。
		
		检测方式
		exec-命令
		在用户容器内执行一次命令，如果命令执行的退出码为0，则认为应用程序正常运行，其他任务应用程序运行不正常。
		
		……
		  livenessProbe:
		    exec:
		      command:
		      - cat
		      - /home/laizy/test/hostpath/healthy
		……
		TCPSocket
		将会尝试打开一个用户容器的Socket连接（就是IP地址：端口）。如果能够建立这条连接，则认为应用程序正常运行，否则认为应用程序运行不正常。
		
		……      
		livenessProbe:
		tcpSocket:
		              port: 8080
		……
		HTTPGet
		
		调用容器内Web应用的web hook，如果返回的HTTP状态码在200和399之间，则认为应用程序正常运行，否则认为应用程序运行不正常。每进行一次HTTP健康检查都会访问一次指定的URL。 …… httpGet: #通过httpget检查健康，返回200-399之间，则认为容器正常 path: / #URI地址 port: 80 #端口号 #host: 127.0.0.1 #主机地址 scheme: HTTP #支持的协议，http或者https httpHeaders：’’ #自定义请求的header ……
		
		部署例子
		cat << EOF > inessprobe.yaml
		apiVersion: v1 
		kind: ReplicationController 
		metadata: 
		  name: inessprobe
		  labels: 
		    project: lykops
		    app: inessprobe
		    version: v1  
		spec:
		  replicas: 6
		  selector: 
		    project: lykops
		    app: inessprobe
		    version: v1
		    name: inessprobe
		  template: 
		    metadata:
		      labels: 
		        project: lykops
		        app: inessprobe
		        version: v1
		        name: inessprobe
		    spec:
		      restartPolicy: Always 
		      containers:
		      - name: inessprobe
		        image: web:apache 
		        imagePullPolicy: Never 
		        command: ['sh',"/etc/run.sh" ] 
		        ports:
		        - containerPort: 80
		          name: httpd
		          protocol: TCP
		        readinessProbe:
		          httpGet:
		            path: /
		            port: 80
		            scheme: HTTP
		          initialDelaySeconds: 120 
		          periodSeconds: 15 
		          timeoutSeconds: 5
		        livenessProbe: 
		          httpGet: 
		            path: /
		            port: 80
		            scheme: HTTP
		          initialDelaySeconds: 180 
		          timeoutSeconds: 5 
		          periodSeconds: 15 
		EOF
		
		cat << EOF > inessprobe-svc.yaml
		apiVersion: v1
		kind: Service
		metadata:
		  name: inessprobe
		  labels:
		    project: lykops
		    app: inessprobe
		    version: v1
		spec:
		  selector:
		    project: lykops
		    app: inessprobe
		    version: v1
		  ports:
		  - name: http
		    port: 80
		    protocol: TCP
		EOF
		
		kubectl create -f inessprobe-svc.yaml
		kubectl create -f inessprobe.yaml
		参数说明
		initialDelaySeconds：容器启动后第一次执行探测是需要等待多少秒。
		
		periodSeconds：执行探测的频率。默认是10秒，最小1秒。
		
		timeoutSeconds：探测超时时间。默认1秒，最小1秒。
		
		successThreshold：探测失败后，最少连续探测成功多少次才被认定为成功。默认是1。对于liveness必须是1。最小值是1。
		
		failureThreshold：探测成功后，最少连续探测失败多少次才被认定为失败。默认是3。最小值是1。	
	

### 探测类型有三种
	
	ExecAction,TCPSicketAction,HttpGetAction
	
	
###ExecAction自定义命令探测并重启	
	
	查看文件cat liveness-exec-pod.yaml  检测liveness-exec-pod，自定义30s删除，检测被删除自动重启
	apiVersion: v1
	kind: Pod
	metadata:
	  name: liveness-exec-pod
	  namespace: default
	spec:
	  containers:
	  - name: liveness-exec-container
	    image: busybox:latest
	    imagepullpolicy: IfNotPresent
	    command: ["/bin/sh","-c","touch /tem/healthy;sleep 30;rm -f /tem/healthy;sleep 3600"]
	    livenessProbe:
	      exec:
	        command: ["test","-e","/tem/healthy"]
	      initialDeplaySeconds: 1
	      periodSeconds: 3
	      timeoutSeconds: 1
	      successThreshold: 1
	      failureTHreshold: 3
	
	启动：
	kubectl create -f liveness-exec-pod.yaml --validate-false
	
	查看pod和deployments
	kubectl get pod && kubectl get deployments
	
	查看被重启的详细信息
	kubectl describe pod liveness-exec-pod
	
	结果：
	Name:               liveness-exec-pod
	Namespace:          default
	Priority:           0
	PriorityClassName:  <none>
	Node:               k8s-docker-node-3/192.168.57.133
	Start Time:         Sun, 12 May 2019 23:04:07 +0800
	Labels:             <none>
	Annotations:        <none>
	Status:             Running
	IP:                 192.168.1.8
	Containers:
	  liveness-exec-container:
	    Container ID:  docker://eeac0f143e84c3186ff9e58ce5055c5f1ea98e6173530653c9a922d9f0d0c17b
	    Image:         busybox:latest
	    Image ID:      docker-pullable://docker.io/busybox@sha256:4b6ad3a68d34da29bf7c8ccb5d355ba8b4babcad1f99798204e7abb43e54ee3d
	    Port:          <none>
	    Host Port:     <none>
	    Command:
	      /bin/sh
	      -c
	      touch /tem/healthy;sleep 30;rm -f /tem/healthy;sleep 3600
	    State:          Waiting
	      Reason:       CrashLoopBackOff
	    Last State:     Terminated
	      Reason:       Error
	      Exit Code:    137
	      Started:      Sun, 12 May 2019 23:14:09 +0800
	      Finished:     Sun, 12 May 2019 23:14:48 +0800
	    Ready:          False
	    Restart Count:  7
	    Liveness:       exec [test -e /tem/healthy] delay=0s timeout=1s period=3s #success=1 #failure=3
	    Environment:    <none>
	    Mounts:
	      /var/run/secrets/kubernetes.io/serviceaccount from default-token-kllvx (ro)
	Conditions:
	  Type              Status
	  Initialized       True 
	  Ready             False 
	  ContainersReady   False 
	  PodScheduled      True 
	Volumes:
	  default-token-kllvx:
	    Type:        Secret (a volume populated by a Secret)
	    SecretName:  default-token-kllvx
	    Optional:    false
	QoS Class:       BestEffort
	Node-Selectors:  <none>
	Tolerations:     node.kubernetes.io/not-ready:NoExecute for 300s
	                 node.kubernetes.io/unreachable:NoExecute for 300s
	 ...........................
	 ...........................
	 ...........................
		
### HttpGetAction重启探测
	
	查看cat liveness-httpget-pod.yaml  ikubernetes/myapp:v1是busybox的镜像，index.html是nginx的html
	apiVersion: v1
	kind: Pod
	metadata:
	  name: liveness-httpget-pod
	  namespace: default
	spec:
	  containers:
	  - name: liveness-httpget-container
	    image: ikubernetes/myapp:v1
	    imagepullpolicy: IfNotPresent
	    ports:
	    - name: http
	      containerPort: 80
	    livenessProbe:
	      httpGet:
	        port: http
	        path: /index.html
	      initialDeplaySeconds: 1
	      periodSeconds: 3
	      timeoutSeconds: 1
	      successThreshold: 1
	      failureTHreshold: 3	
	      
    启动:
    kubectl create -f liveness-httpget-pod --validate=false
	
	 查看pod和deployments
	 kubectl get pod && kubectl get deployments
	
	 查看被重启的详细信息
	 kubectl describe pod liveness-exec-pod
	 此时无法查看到restart大于1
	 
	 使用shell命令删除
	 kubectl exec -it liveness-httpget-pod  -- /bin/sh
	 rm -f index.html 删除之后，pod会自动检测发现不存在自动重启，重启之后index.html又有了
	 
	 删除启动的资源
	 kubectl delete -f liveness-httpget-pod
	 
###Pod控制器
 控制器类型如下：
 	ReplicationController :ReplicationController用来确保容器应用的副本数始终保持在用户定义的副本数，即如果有容器异常退出，会自动创建新的Pod来替代；而如果异常多出来的容器也会自动回收。
 	
 	ReplicaSet:ReplicaSet跟ReplicationController没有本质的不同，只是名字不一样，并且ReplicaSet支持集合式的selector。
 	
 	Deployment: Deployment 为 Pod 和 ReplicaSet 提供了一个声明式定义(declarative)方法
 	
 	StatefulSet: StatefulSet 作为 Controller 为 Pod 提供唯一的标识。它可以保证部署和 scale 的顺序。
 	
 	DaemonSet: DaemonSet 确保全部（或者一些）Node 上运行一个 Pod 的副本。当有 Node 加入集群时，也会为他们新增一	个 Pod 。当有 Node 从集群移除时，这些 Pod 也会被回收。删除 DaemonSet 将会删除它创建的所有 Pod。
 	
 	Job: Job负责批处理任务，即仅执行一次的任务，它保证批处理任务的一个或多个Pod成功结束。
 	
 	CronJob :周期性地在给定时间点运行
 	
 	CDR: 用户自定义资源
 	
 	Helm:  可以理解为 Kubernetes 的包管理工具，可以方便地发现、共享和使用为Kubernetes构建的应用。

ReplicationController和ReplicaSet详解

		ReplicationController用来确保容器应用的副本数始终保持在用户定义的副本数，即如果有容器异常退出，会自动创建新的Pod来替代；而如果异常多出来的容器也会自动回收。
		
		在新版本的Kubernetes中建议使用ReplicaSet来取代ReplicationController。ReplicaSet跟ReplicationController没有本质的不同，只是名字不一样，并且ReplicaSet支持集合式的selector。
		
		虽然ReplicaSet可以独立使用，但一般还是建议使用 Deployment 来自动管理ReplicaSet，这样就无需担心跟其他机制的不兼容问题（比如ReplicaSet不支持rolling-update但Deployment支持）。
		
		ReplicaSet示例：
		
		apiVersion: extensions/v1beta1
		kind: ReplicaSet
		metadata:
		  name: frontend
		  # these labels can be applied automatically
		  # from the labels in the pod template if not set
		  # labels:
		    # app: guestbook
		    # tier: frontend
		spec:
		  # this replicas value is default
		  # modify it according to your case
		  replicas: 3
		  # selector can be applied automatically
		  # from the labels in the pod template if not set,
		  # but we are specifying the selector here to
		  # demonstrate its usage.
		  selector:
		    matchLabels:
		      tier: frontend
		    matchExpressions:
		      - {key: tier, operator: In, values: [frontend]}
		  template:
		    metadata:
		      labels:
		        app: guestbook
		        tier: frontend
		    spec:
		      containers:
		      - name: php-redis
		        image: gcr.io/google_samples/gb-frontend:v3
		        resources:
		          requests:
		            cpu: 100m
		            memory: 100Mi
		        env:
		        - name: GET_HOSTS_FROM
		          value: dns
		          # If your cluster config does not include a dns service, then to
		          # instead access environment variables to find service host
		          # info, comment out the 'value: dns' line above, and uncomment the
		          # line below.
		          # value: env
		        ports:
		        - containerPort: 80

Deployment详解
	
		Deployment 为 Pod 和 ReplicaSet 提供了一个声明式定义(declarative)方法，用来替代以前的ReplicationController 来方便的管理应用。典型的应用场景包括：
		
		定义Deployment来创建Pod和ReplicaSet
		滚动升级和回滚应用
		扩容和缩容
		暂停和继续Deployment
		比如一个简单的nginx应用可以定义为
		
		apiVersion: extensions/v1beta1
		kind: Deployment
		metadata:
		  name: nginx-deployment
		spec:
		  replicas: 3
		  template:
		    metadata:
		      labels:
		        app: nginx
		    spec:
		      containers:
		      - name: nginx
		        image: nginx:1.7.9
		        ports:
		        - containerPort: 80
		扩容：
		
		kubectl scale deployment nginx-deployment --replicas 10
		如果集群支持 horizontal pod autoscaling 的话，还可以为Deployment设置自动扩展：
		
		kubectl autoscale deployment nginx-deployment --min=10 --max=15 --cpu-percent=80
		更新镜像也比较简单:
		
		kubectl set image deployment/nginx-deployment nginx=nginx:1.9.1
		回滚：
		
		kubectl rollout undo deployment/nginx-deployment

	  
	

##kubernetes Service资源

 service依赖：  
 
    CoreDNS和kube-dns
 
 工作模式和类型：  
    
    模式：ipvs 
    类型：service类型有ClusterIP, NodePort, LoadBalancer, or ExternalName. Default is 'ClusterIP'.
		-- ClusterIP：表示这个service只能在群集内部访问，不能在集群外部访问；
		-- NodePort：表示可以在集群外部访问到；
    
 
 使用清单部署service  
 	
 	sss
 


##P2121. 11-kubernetes ingress

#### ingress解释
通常情况下，service和pod仅可在集群内部网络中通过IP地址访问。所有到达边界路由器的流量或被丢弃或被转发到其他地方,Ingress 是从Kubernetes集群外部访问集群内部服务的入口

	节点：Kubernetes集群中的一台物理机或者虚拟机。
	集群：位于Internet防火墙后的节点，这是kubernetes管理的主要计算资源。
	边界路由器：为集群强制执行防火墙策略的路由器。 这可能是由云提供商或物理硬件管理的网关。
	集群网络：一组逻辑或物理链接，可根据Kubernetes网络模型实现群集内的通信。 集群网络的实现包括Overlay模型的 flannel 和基于SDN的OVS。
	服务：使用标签选择器标识一组pod成为的Kubernetes服务。 除非另有说明，否则服务假定在集群网络内仅可通过虚拟IP访问。


#### Ingress可用的调度器种类

	Nginx
	Traefik
	Envoy
	Istio
	
	
#### Ingress Controller是K8S核心附件之一。接下来我们来部署Ingress-nginx。

 创建namespace的命令空间
  kubectlcreate namespaces ingress-nginx
  
 创建namespace的命令空间
 kubectl delete namespaces ingress-nginx
 
 删除的时候报错：
Error from server (Conflict): Operation cannot be fulfilled on namespaces "ingress-nginx": The system is ensuring all content is removed from this namespace.  Upon completion, this namespace will automatically be purged by the system.
	
 kubectl delete namespaces ingress-nginx --br


1,下载安装  

	https://github.com/kubernetes/ingress-nginx/

	git clone https://github.com/kubernetes/ingress-nginx.git
	cd ingress-nginx/deploy
	kubectl apply -f mandatory.yaml
	
	如果嫌克隆太慢，也可以直接执行如下命令：
	kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/master/deploy/mandatory.yaml
	
	上述命令执行完后，会拉取nginx-ingress-controller镜像，需要一点时间
	
 2，根据namespace查看pod详情
 
    kubectl get pods -n  ingress-nginx	



####Istio详解

Istio是由Google、IBM和Lyft开源的微服务管理、保护和监控框架

	https://www.jianshu.com/p/b72c1e06b140
	https://jimmysong.io/kubernetes-handbook/usecases/istio.html
	
	





##P2222. 12-存储卷

 管理存储，Kubernetes提供了Secret用于管理敏感信息，ConfigMap存储配置，Volume、PV、PVC、StorageClass等用来管理存储卷。
 
 
#### ConfigMap存储配置

#####创建configmap，提供参数
 创建配置
 kubectl create configmap configmapdemo  --from-literal=nginx_port=80   --from-literal=server_name=myapp.magedu.com
 查看配置
 kubectl get configmap
 删除configmap
 kubectl delete configmap configmapdemo
 
 
#####创建pod使用configmap
 
 创建pod文件内容cat pod-lrean.yaml 
apiVersion: v1
kind: Pod
metadata: 
  name: pod-cm-1
  namespace: default
  labels:
    app: myapp
    tier: frontend
spec:
  containers:
  - name: myapp
    image: ikubernetes/myapp:v1
    ports:
    - name: http
      containerPort: 80
    env: 
    - name: NGINX_SERVER_PORT
      valueFrom:
        configMapKeyRef:
          key: nginx_port
          name: configmapdemo 
    env: 
    - name: NGINX_SERVER_NAME
      valueFrom:
        configMapKeyRef:
          key: server_name
          name: configmapdemo 
          
          
#####查看pod使用configmap的env参数

	kubectl exec -it pod-cm-1 -- /bin/sh
	
	
	
	
	
	
	
	
	
	
	
	
	
	

##P2323. 13-kubernetes pv、pvc、configmap和secret

###pv
	PersistentVolume（PV）是由管理员设置的存储，它是群集的一部分。就像节点是集群中的资源一样，PV 也是集群中的资源。 PV 是 Volume 之类的卷插件，但具有独立于使用 PV 的 Pod 的生命周期。此 API 对象包含存储实现的细节，即 NFS、iSCSI 或特定于云供应商的存储系统。
	

####创建pv-volume.yaml

kind: PersistentVolume
apiVersion: v1
metadata:
  name: task-pv-volume
  labels:
    type: local
spec:
  storageClassName: manual
  capacity:
    storage: 10Gi
  accessModes:
    - ReadWriteOnce
  hostPath:
    path: "/mnt/data"
	
配置文件指定卷位于/mnt/data群集的节点上。该配置还指定了10个字节的大小和访问模式ReadWriteOnce，这意味着卷可以由单个节点以读写方式安装。它定义PersistentVolume 的StorageClass名称 manual，该名称将用于将PersistentVolumeClaim请求绑定到此PersistentVolume。	
	
部署：
	
	kubectl apply -f pv-volume.yaml

查看状态	
	
	kubectl get pv task-pv-volume
	
	
	

###pvc
	PersistentVolumeClaim（PVC）是用户存储的请求。它与 Pod 相似。Pod 消耗节点资源，PVC 消耗 PV 资源。Pod 可以请求特定级别的资源（CPU 和内存）。声明可以请求特定的大小和访问模式（例如，可以以读/写一次或 只读多次模式挂载）。
	
	
	
	
	

###configMap
	

###secret
  加密使用



##P2424. 14-kubernetes statefulset控制器

在 Kubernetes 系统中，Pod 的管理对象 RC、Deployment、DaemonSet 和 Job 都是面向无状态的服务。但现实中有很多服务是有状态的，特别是一些复杂的 中间件集群，例如 MySQL 集群、MongoDB 集群、Akka 集群、Zookeeper 集群的等，这些应用集群有以下一些共同点。

	每个节点都有固定的身份 ID，通过这个 ID，集群中的成员可以相互发现并且通信。
	集群的规模是比较固定的，集群规模不能随意变道。
	集群里的每个节点都是有状态的，通常会持久化数据到永久存储中。
	如果磁盘损坏，则集群里的某个节点无法正常运行，集群功能受损。
	
	


##P2525. 15-kubernetes认证及serviceaccount

###Service Account为Pod中的进程提供身份信息。

####使用以下命令列出 namespace 下的所有 serviceAccount 资源。
	$ kubectl get serviceAccounts
	NAME      SECRETS    AGE
	default   1          1d
	
####您可以像这样创建一个 ServiceAccount 对象：
	$ cat > /tmp/serviceaccount.yaml <<EOF
	apiVersion: v1
	kind: ServiceAccount
	metadata:
	  name: build-robot
	EOF
	$ kubectl create -f /tmp/serviceaccount.yaml
	serviceaccount "build-robot" created

####如果您看到如下的 service account 对象的完整输出信息：
	$ kubectl get serviceaccounts/build-robot -o yaml
	apiVersion: v1
	kind: ServiceAccount
	metadata:
	  creationTimestamp: 2015-06-16T00:12:59Z
	  name: build-robot
	  namespace: default
	  resourceVersion: "272500"
	  selfLink: /api/v1/namespaces/default/serviceaccounts/build-robot
	  uid: 721ab723-13bc-11e5-aec2-42010af0021e
	secrets:
	- name: build-robot-token-bvbk5
	然后您将看到有一个 token 已经被自动创建，并被 service account 引用。
	
####service account 的describe完整输出信息：

	kubectl describe sa/build-robot
	
	.......
	Mountable secrets:   build-robot-token-8pxdg
	Tokens:              build-robot-token-8pxdg
	Events:              <none>
	
	查看Secret 的内容包含token、ca.crt、namespace
	kubectl describe secrets build-robot-token-8pxdg 
	
	
####如上文提到的名为 ”build-robot“ 的 service account，我们手动创建一个新的 secret。

	 cat > /tmp/build-robot-secret.yaml <<EOF
	apiVersion: v1
	kind: Secret
	metadata:
	  name: build-robot-secret
	  annotations: 
	    kubernetes.io/service-account.name: build-robot
	type: kubernetes.io/service-account-token
	EOF
	$ kubectl create -f /tmp/build-robot-secret.yaml
	secret "build-robot-secret" created
	
	查看build-robot-secret的token
	kubectl describe secrets/build-robot-secret 
	
	查看build-robot的token，两成两个
	kubectl describe secrets/build-robot
	Mountable secrets:   build-robot-token-8pxdg
	Tokens:              build-robot-secret
                     build-robot-token-8pxdg
	
	
	
	
	

##P2626. 16-kubernetes RBAC详解，Admin详解，ABAC详解

### RBAC基于角色的访问控制（Role-Based Access Control, 即”RBAC”）使用”rbac.authorization.k8s.io” API Group实现授权决策，允许管理员通过Kubernetes API动态配置策略。

###RBAC 引入了 4 个新的顶级资源对象：Role、ClusterRole、RoleBinding 和 ClusterRoleBinding。同其他 API 资源对象一样，用户可以使用 kubectl 或者 API 调用等方式操作这些资源对象。


###RBAC角色分两种Role（NameSpace的角色）和ClusterRole（Kubenetes集群的角色）

1.新建K8S内建用户sa

	apiVersion: v1
	kind: ServiceAccount
	metadata:
	  namespace: mynamespace
	  name: iyunw-sa
	  
2.新建权限Role

	kind: Role
	apiVersion: rbac.authorization.k8s.io/v1
	metadata:
	  namespace: mynamespace  ## 指定它能产生作用的Namespace
	  name: iyunw-role
	rules:    ##  定义权限规则
	- apiGroups: [""]
	  resources: ["pods"]  ## 对mynamespace下面的Pod对象
	  verbs: ["get", "watch", "list"]   ## 进行GET、WATCH、LIST操作


3.建立角色绑定

	kind: RoleBinding
	apiVersion: rbac.authorization.k8s.io/v1
	metadata:
	  name: iyunw-rolebinding
	  namespace: mynamespace
	subjects:
	- kind: ServiceAccount
	  name: iyunw
	  namespace: mynamespace
	roleRef:
	  kind: Role
	  name: iyunw-role
	  apiGroup: rbac.authorization.k8s.io

到此iyunw  sa用户就对namespace mynamespace下pod有get watch list权限


##P2727. 17-kubernetes dashboard认证及分级授权

####dashboard安装使用详解

通过配置文件安装dashboard
   
	kubectl apply -f https://raw.githubusercontent.com/kubernetes/dashboard/v1.10.1/src/deploy/recommended/kubernetes-dashboard.yaml
	
报错错误信息，因为被墙，而失败拉取的镜像

	 kubelet, k8s-docker-node-1  Failed to pull image "k8s.gcr.io/kubernetes-dashboard-amd64:v1.10.1": rpc error: code = Unknown desc = Get https://k8s.gcr.io/v1/_ping: dial tcp 74.125.204.82:443: i/o timeout

解决方案

	使用docker拉去对应镜像
	sudo docker pull mirrorgooglecontainers/kubernetes-dashboard-amd64:v1.10.1
	
	镜像打tag,方便使用
	sudo docker tag mirrorgooglecontainers/kubernetes-dashboard-amd64:v1.10.1 k8s.gcr.io/kubernetes-dashboard-amd64:v1.10.1 
	删除docker拉去镜像
	docker rmi docker.io/mirrorgooglecontainers/kubernetes-dashboard-amd64:v1.10.1
	
	
将service的type类型ClusterIp改为NodePort，便于集群外部访问
	
	kubectl edit service kubernetes-dashboard -n kube-system

	kubectl -n kube-system get service kubernetes-dashboard
	

访问地址

	https://192.168.57.131:32053


创建token登录dashboard
	
	cd /etc/kubernetes/pki
	
	第一步生成私钥
	(umask 077;openssl genrsa -out dashboard.key 2048)
	  
	第二步，创建证书
	openssl req -new -key dashboard.key -out dashboard.csr -subj "/O=magedu/CN=dashboard"
	
	第三步CA签署认证
	openssl x509 -req -in dashboard.csr -CA ca.crt -CAkey ca.key -CAcreateserial -out dashboard.crt -days 365
	
	第四步创建secret generic 
	kubectl create secret generic  dashboard-cret -n kube-system --from-file=dashboard.crt=./dashboard.crt --from-file=dashboard.key=./dashboard.key

	第五步 flannel 安装
	
	第六步创建serviceaccount账户
	kubectl create sa  dashboard-admin -n kube-system
	kubectl get sa  dashboard-admin -n kube-system //查看
	
	第七步 sa和集群管理绑定
	kubectl create clusterrolebinding  dashboard-binding-admin --clusterrole=cluster-admin --serviceaccount=kube-system:dashboard-admin 
	
	第八步 查看dashboard-admin
	kubectl get secret -n kube-system
	
	 结果：dashboard-admin-token-7mphs
	
	第八步：解析dashboard-admin-token-7mphs的token
	
	  kubectl describe secret dashboard-admin-token-7mphs -n kube-system
	
	 将token的复制到dashboard中可登录
	 
	 eyJhbGciOiJSUzI1NiIsImtpZCI6IiJ9.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJrdWJlLXN5c3RlbSIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJkYXNoYm9hcmQtYWRtaW4tdG9rZW4tN21waHMiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC5uYW1lIjoiZGFzaGJvYXJkLWFkbWluIiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZXJ2aWNlLWFjY291bnQudWlkIjoiY2YzYWYyYzEtN2QzNC0xMWU5LTg3NzItMDAwYzI5NDcxOTQzIiwic3ViIjoic3lzdGVtOnNlcnZpY2VhY2NvdW50Omt1YmUtc3lzdGVtOmRhc2hib2FyZC1hZG1pbiJ9.NYIR0_qv3yDrcjh7DbEDiptaT6s6MDaQxQtm0HBuJl50taW1w48_iIdH-PtYrpFHzw-IzXIaDsjDvhNhPvkxgUBqdoMIdD2pVI4L_LQXeafHy_sFMWh5cIbTHwXLnw0_DYGxMmEz2sR4CcrZqJfMdLnouD0SNic0Rp-dE-Ee49kBpk2o5ZMe-Ecz_cv0CIUiKVAB8Cx9-w7rsx892viMvphJEHk8Em_SdK9QyK19C38luHg2IcUduynnv8cCyfDppmmY7q61m2iq0krGSd_V5d5Bp2glRQUjPv-nIHmTHyPJZpMViSyMCkWWivhp3pJlr6bTY2S7MU2SqQBUdgZeBA
	
	
	

##P2828. 18-配置网络插件flannel

###flannel作用：

	flannel，k8s的网络模型，为k8s集群内的容器提供网络服务的组件。
	
	主要作用：为集群内所有容器提供一个扁平化的网络环境，即：所有容器在flannel提供的网络平面.   
	上可以看作是. 在同一网段，自由通信。其模型为全部的容器使用一个network，然后在每个host上从   
	network中划分一个子网  subnet。为host上的容器创建网络时，从subnet中划分一个ip给容器。
	这样就大大提高了容器之间工作效率，不用考虑IP. 转换问题。  
	

![flannel网络模型](https://upload-images.jianshu.io/upload_images/3764857-1a7f25eb0756a3c3.png)
	
	1、容器网卡是通过docker0桥接到flannel0网卡，而每个host对应的flannel0网段为10.1.x.[1-255]/24，而flannel所组成的一个跨host的网段为10.1.x.x/16，而flannel0则为flanneld进程虚拟出来的网卡。
	
	2、docker0的地址是由 /run/flannel/subnet.env 的 FLANNEL_SUBNET 参数决定的。在启动flannel的同时会产生一个通过flannel生成的配置文件subnet.env，参数内容如下：
		FLANNEL_NETWORK=10.244.0.0/16
		FLANNEL_SUBNET=192.168.0.1/24
		FLANNEL_MTU=1450
		FLANNEL_IPMASQ=true
			
	3、跨接点容器之间通信流程
		containerA --> docker0 --> flannel0 --> NodeA --> (IP Address)
		 -->  NodeB --> flannel0 --> docker0 --> containerB
		
		(1) 容器A向容器B请求数据，首先通过路由规则将数据发往docker0，docker0接受到数据后通过路由规则将数据包转交给本节点的flannel0处理。
		(2)flannel0 将数据进行封装并发给宿主机的eth0，然后走TCP协议转发给containerB所在的宿主机。 		(3)containerB所在的宿主机接收到数据后，根据路由规则转发给flannel0。
		(4)flannel0 再次根据路由协议将数据包发送给docker0
		(5)最后数据包到达containerB，完成容器之间的数据通信。
	

####kubectl查看kube-flannel-cfg配置

查看configmap是否存在kube-flannel-cfg
kubectl get configmap  kube-flannel-cfg   -n kube-system

查看kube-flannel-cfg的详细信息
kubectl describe configmap  kube-flannel-cfg   -n kube-system
		
		Name:         kube-flannel-cfg
		Namespace:    kube-system
		Labels:       app=flannel 
		              tier=node
		Annotations:  kubectl.kubernetes.io/last-applied-configuration:
		                {"apiVersion":"v1","data":{"cni-conf.json":"{\n  \"name\": \"cbr0\",\n  \"plugins\": [\n    {\n      \"type\": \"flannel\",\n      \"deleg...
		
		Data
		====
		net-conf.json:
		----
		{
		  "Network": "10.244.0.0/16",
		  "Backend": {
		    "Type": "vxlan"
		  }
		}
		
		cni-conf.json:
		----
		{
		  "name": "cbr0",
		  "plugins": [
		    {
		      "type": "flannel",
		      "delegate": {
		        "hairpinMode": true,
		        "isDefaultGateway": true
		      }
		    },
		    {
		      "type": "portmap",
		      "capabilities": {
		        "portMappings": true
		      }
		    }
		  ]
		}
		
		Events:  <none>	



####CNI flaanel详解：
[root@k8s-docker-node-1 net.d]# ls
10-flannel.conflist
[root@k8s-docker-node-1 net.d]# cat 10-flannel.conflist 
{
  "name": "cbr0",
  "plugins": [
    {
      "type": "flannel",
      "delegate": {
        "hairpinMode": true,
        "isDefaultGateway": true
      }
    },
    {
      "type": "portmap",
      "capabilities": {
        "portMappings": true
      }
    }
  ]
}


#### flannel的udp详解

	


#### flannel的vxlan详解
	
	
	
	

##P2929. 19-基于calico,canel的网络策略

####Calico安装教程

	https://docs.projectcalico.org/v3.7/getting-started/kubernetes/installation/integration

####Calico详解
	calico支持bgp协议
	Calico可以在符合以下标准的任何Kubernetes集群上运行。
		必须将kubelet配置为使用CNI网络插件（例如--network-plugin=cni）。
		必须以iptables代理模式启动kube-proxy 。这是Kubernetes v1.2.0的默认值。
		必须在没有--masquerade-all标志的情况下启动kube-proxy ，这与Calico策略冲突。
		Kubernetes NetworkPolicy API至少需要Kubernetes版本v1.3.0。
		
			

##P3030. 20-网络插件安装

###1，flannel安装

	# 创建flannel目录下载相关文件
	mkdir flannel && cd flannel
	wget https://raw.githubusercontent.com/coreos/flannel/master/Documentation/kube-flannel.yml
	
	# 修改配置
	# 此处的ip配置要与kubeadm的pod-network参数配置的一致
	  net-conf.json: |
	    {
	      "Network": "192.168.0.0/16",
	      "Backend": {
	        "Type": "vxlan"
	      }
	    }
	
	# 修改镜像
	image: registry.cn-shanghai.aliyuncs.com/gcr-k8s/flannel:v0.10.0-amd64
	
	# 如果Node有多个网卡的话，参考flannel issues 39701，
	# https://github.com/kubernetes/kubernetes/issues/39701
	# 目前需要在kube-flannel.yml中使用--iface参数指定集群主机内网网卡的名称，
	# 否则可能会出现dns无法解析。容器无法通信的情况，需要将kube-flannel.yml下载到本地，
	# flanneld启动参数加上--iface=<iface-name>
	    containers:
	      - name: kube-flannel
	        image: registry.cn-shanghai.aliyuncs.com/gcr-k8s/flannel:v0.10.0-amd64
	        command:
	        - /opt/bin/flanneld
	        args:
	        - --ip-masq
	        - --kube-subnet-mgr
	        - --iface=eth1
	
	# 启动
	kubectl apply -f kube-flannel.yml
	
	# 查看
	kubectl get pods --namespace kube-system
	kubectl get svc --namespace kube-system
	

###2，calico

	1.配置启动etcd集群
	# 本次实验使用与k8s一个etcd集群
	# 生境环境建议使用单独的一套集群
	复制代码2.配置启动calico
	# 创建calico目录下载相关文件
	mkdir calico && cd calico
	wget https://docs.projectcalico.org/v3.2/getting-started/kubernetes/installation/rbac.yaml
	wget https://docs.projectcalico.org/v3.2/getting-started/kubernetes/installation/hosted/calico.yaml
	
	# 如果启用了RBAC（默认k8s集群启用），配置RBAC
	kubectl apply -f rbac.yaml
	
	# 修改calico.yaml文件中名为calico-config的ConfigMap中的etcd_endpoints参数为自己的etcd集群
	etcd_endpoints: "http://11.11.11.111:2379,http://11.11.11.112:2379,http://11.11.11.113:2379"
	
	# 修改镜像为国内镜像
	sed -i 's@image: quay.io/calico/@image: registry.cn-shanghai.aliyuncs.com/gcr-k8s/calico-@g' calico.yaml
	
	quay.io/calico/node:v3.1.6  mirrorgooglecontainers/calico/node:v3.1.6
   quay.io/calico/cni:v3.1.6   mirrorgooglecontainers/calico/cni:v3.1.6
   quay.io/calico/kube-controllers:v3.1.6  mirrorgooglecontainers/calico/kube-controllers:v3.1.6
	
	# 启动
	kubectl apply -f calico.yaml
	
	# 查看
	kubectl get pods --namespace kube-system
	kubectl get svc --namespace kube-system
	复制代码3.参考文档
	
	https://docs.projectcalico.org/v3.1/getting-started/kubernetes/installation/calico#installing-with-the-etcd-datastore
	
###3，canal安装

	# 创建flannel目录下载相关文件
	mkdir canal && cd canal
	wget https://docs.projectcalico.org/v3.1/getting-started/kubernetes/installation/hosted/canal/rbac.yaml
	wget https://docs.projectcalico.org/v3.1/getting-started/kubernetes/installation/hosted/canal/canal.yaml
	
	# 修改配置
	# 此处的ip配置要与kubeadm的pod-network参数配置的一致
	  net-conf.json: |
	    {
	      "Network": "192.168.0.0/16",
	      "Backend": {
	        "Type": "vxlan"
	      }
	    }
	
	# 修改calico镜像
	sed -i 's@image: quay.io/calico/@image: registry.cn-shanghai.aliyuncs.com/gcr-k8s/calico-@g' canal.yaml
	
	# 修改flannel镜像
	image: registry.cn-shanghai.aliyuncs.com/gcr-k8s/flannel:v0.10.0-amd64
	
	# 如果Node有多个网卡的话，参考flannel issues 39701，
	# https://github.com/kubernetes/kubernetes/issues/39701
	# 目前需要在kube-flannel.yml中使用--iface参数指定集群主机内网网卡的名称，
	# 否则可能会出现dns无法解析。容器无法通信的情况，需要将kube-flannel.yml下载到本地，
	# flanneld启动参数加上--iface=<iface-name>
	    containers:
	      - name: kube-flannel
	        image: registry.cn-shanghai.aliyuncs.com/gcr-k8s/flannel:v0.10.0-amd64
	   	    command: [ "/opt/bin/flanneld", "--ip-masq", "--kube-subnet-mgr", "--iface=eth1" ]
	
	
	# 启动
	kubectl apply -f rbac.yaml
	kubectl apply -f canal.yaml
	
	# 查看
	kubectl get pods --namespace kube-system
	kubectl get svc --namespace kube-system

###4，kube-router安装

	# 本次实验重新创建了集群，使用之前测试其他网络插件的集群环境没有成功
	# 可能是由于环境干扰，实验时需要注意
	
	# 创建kube-router目录下载相关文件
	mkdir kube-router && cd kube-router
	wget https://raw.githubusercontent.com/cloudnativelabs/kube-router/master/daemonset/kubeadm-kuberouter.yaml
	wget https://raw.githubusercontent.com/cloudnativelabs/kube-router/master/daemonset/kubeadm-kuberouter-all-features.yaml
	
	# 以下两种部署方式任选其一
	
	# 1. 只启用 pod网络通信，网络隔离策略 功能
	kubectl apply -f kubeadm-kuberouter.yaml
	
	# 2. 启用 pod网络通信，网络隔离策略，服务代理 所有功能
	# 删除kube-proxy和其之前配置的服务代理
	kubectl apply -f kubeadm-kuberouter-all-features.yaml
	kubectl -n kube-system delete ds kube-proxy
	
	# 在每个节点上执行
	docker run --privileged --net=host registry.cn-hangzhou.aliyuncs.com/google_containers/kube-proxy-amd64:v1.10.2 kube-proxy --cleanup
	
	# 查看
	kubectl get pods --namespace kube-system
	kubectl get svc --namespace kube-system
	复制代码romana
	# 创建flannel目录下载相关文件
	mkdir romana && cd romana
	wget https://raw.githubusercontent.com/romana/romana/master/containerize/specs/romana-kubeadm.yml
	
	# 修改镜像
	sed -i 's@gcr.io/@registry.cn-hangzhou.aliyuncs.com/@g' romana-kubeadm.yml
	sed -i 's@quay.io/romana/@registry.cn-shanghai.aliyuncs.com/gcr-k8s/romana-@g' romana-kubeadm.yml
	
	# 启动
	kubectl apply -f romana-kubeadm.yml
	
	# 查看
	kubectl get pods --namespace kube-system
	kubectl get svc --namespace kube-system
###5，CNI-Genie安装

	# CNI-Genie是华为开源的网络组件，可以使k8s同时部署多个网络插件
	
	# 在k8s集群中安装calico组件
	
	# 在k8s集群中安装flannel组件
	
	# 在k8s集群中安装Genie组件
	mkdir CNI-Genie && cd CNI-Genie
	wget  https://raw.githubusercontent.com/Huawei-PaaS/CNI-Genie/master/conf/1.8/genie.yaml
	sed -i 's@image: quay.io/cnigenie/v1.5:latest@image: registry.cn-shanghai.aliyuncs.com/gcr-k8s/cnigenie-v1.5:latest@g' genie.yaml
	kubectl apply -f genie.yaml
	
	# 查看
	kubectl get pods --namespace kube-system
	kubectl get svc --namespace kube-system
	
	# 测试
	cat >nginx-calico.yml<<EOF
	apiVersion: v1
	kind: Pod
	metadata:
	  name: nginx-calico
	  labels:
	    app: web
	  annotations:
	    cni: "calico"
	spec:
	  containers:
	    - name: nginx
	      image: nginx:alpine
	      imagePullPolicy: IfNotPresent
	      ports:
	        - containerPort: 80
	EOF
	cat >nginx-flannel.yml<<EOF
	apiVersion: v1
	kind: Pod
	metadata:
	  name: nginx-flannel
	  labels:
	    app: web
	  annotations:
	    cni: "flannel"
	spec:
	  containers:
	    - name: nginx
	      image: nginx:alpine
	      imagePullPolicy: IfNotPresent
	      ports:
	        - containerPort: 80
	EOF
	kubectl apply -f nginx-calico.yml
	kubectl apply -f nginx-flannel.yml
	
	# 查看
	kubectl get pods -o wide
	
	# 测试网络通信
	kubectl exec nginx-calico -i -t -- ping -c4 1.1.1.1
	kubectl exec nginx-flannel -i -t -- ping -c4 1.1.1.1
	
	# 由于先启动的flannel，然后k8s创建了coredns，所以使用flannel cni的能正常使用dns
	# 使用calico cni无法使用正常dns
	
	# 测试dns
	kubectl exec nginx-calico -i -t -- ping -c4 www.baidu.com
	kubectl exec nginx-flannel -i -t -- ping -c4 www.baidu.com
	
	复制代码总结
	
	kube-router性能损失最小，时延最小，其他网络插件性能差距不大。除了flannel没有网络隔离策略，其他均支持网络隔离策略。CNI-Genie是一个可以让k8s使用多个cni网络插件的组件，暂时不支持隔离策略。
	理论结果： kube-router > calico > canal = flannel = romana



##P3132.21-调度器、预选策略及优选函数
##P3131. 21-kubernetes高级调度方式
##P3232. 22-容器资源需求、资源限制及HeapSter
##P3333. 23-资源指标API及自定义指标API
##P3434. 24-helm入门
##P3535. 25-创建自定义Chart及部署efk日志系统
##P3636. 26-基于Kubernetes的PaaS概述

