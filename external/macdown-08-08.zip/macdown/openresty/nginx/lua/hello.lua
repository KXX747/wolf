-- /usr/local/var/log/nginx/openresty_error.log
--/usr/local/var/log/nginx/openresty_access.log

--local json = require "cjson"
ngx.say("获取到了请求！！！！");
--获取请求的参数 http://127.0.0.1/hello?foo=bar&p%20=%20222
local args = ngx.req.get_uri_args();

--获取header的参数
local h = ngx.req.get_headers()
for k, v in pairs(h) do
    ngx.say(k ," = ",v)
end

--获取参数的foo值
local p =args.foo;
--如果不存在p，返回400
if not p then
   ngx.exit(ngx.HTTP_BAD_REQUEST);
  ngx.say("没有获取到参数。。。");
end

--存在，使用当前时间+p的值 md5
local md5=ngx.md5(ngx.time() .. p);
--输md5的值
ngx.say(md5);








-- for key, val in pairs(args) do
--             if type(val) == "table" then
--                 ngx.say(key, ": ", table.concat(val, ","))
--             else
--                 ngx.say(key, ": ", val)
--           end
--   end
