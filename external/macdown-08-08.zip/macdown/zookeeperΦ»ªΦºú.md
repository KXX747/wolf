
#一，节点类型和event

1、PERSISTENT--持久化目录节点

	客户端与zookeeper断开连接后，该节点依旧存在

2、PERSISTENT_SEQUENTIAL-持久化顺序编号目录节点

	客户端与zookeeper断开连接后，该节点依旧存在，只是Zookeeper给该节点名称进行顺序编号

3、EPHEMERAL-临时目录节点

	客户端与zookeeper断开连接后，该节点被删除

4、EPHEMERAL_SEQUENTIAL-临时顺序编号目录节点

	客户端与zookeeper断开连接后，该节点被删除，只是Zookeeper给该节点名称进行顺序编号

5,github.com/samuel/go-zookeeper/zk创建节点时flags对应的类型如下
	
	//0 持久节点（PERSISTENT）
	//1 临时节点（EPHEMERAL）
	//2 持久顺序节点（PERSISTENT_SEQUENTIAL） 带顺序编号 2_0000000007
	//3 临时顺序节点(EPHEMERAL_SEQUENTIAL)带顺序编号 33_0000000009
	
	
#二，zk分布式锁
	
	  在zookeeper指定节点（locks）下创建临时顺序节点node_n
    获取locks下所有子节点children
    对子节点按节点自增序号从小到大排序
    判断本节点是不是第一个子节点，若是，则获取锁；若不是，则监听比该节点小的那个节点的删除事件
    若监听事件生效，则回到第二步重新进行判断，直到获取到锁




#，如何保证宕机时数据不丢失

#，多副本冗余的高可用机制

#，多副本之间数据如何同步

#，ISR到底指什么