参考地址：https://www.elastic.co/guide/en/elasticsearch/reference/current/docker.html

elasticsearch csdn教程
https://blog.csdn.net/zyc88888/article/category/7254828/2?

#一,elasticsearch基础入门案例


>1,document

>2,index

>3,type

>4,管理集群健康状态：GET _cat/health?v

	epoch      timestamp cluster            status node.total node.data shards pri relo init unassign pending_tasks max_task_wait_time active_shards_percent
1566185132 03:25:32  elasticsearch_a747 yellow          1         1      7   7    0    0        5             0                  -                 58.3%
	
	如何快速了解集群的健康状态，green,yellow,red?
	green 每个索引的primary shard和replica shard都是active状态de
	yellow 每个索引的primary shard都是active状态，但是部分的replica shard不是active状态，处于不可用状态
	red 不是所有的索引primary shard都是active状态，部分索引有数据丢失
	
	单机启动为什么会出现一个yellow状态？
	单机值启动一个es进程，相当于一个node节点，现在es中有一个index，就是kibana自己内置建立的index，由于默认的配置是给每个index分配7个peimary shard和7个replica shard，而且peimary shard和replica shard不能在同一台机器上(为了容错)，现在kibana自己建立的index是1个oeimary shard和1个replica shard，当前就一个node，所以只有7个primary shard被分配了和启动了，但是replica shard 没有第二启动
	
	如果再启动一个 es集群基友会2个node，然后那个5个(unassign)replica shard就会被自动分配过去，整个集群就会成green状态


>5,查看集群的索引有哪些:GET _cat/indices?v
	
	health status index                   uuid                   pri rep docs.count docs.deleted store.size pri.store.size
	yellow open   twitter                 bmDYXfFMRpSwjm-PvVETqA   5   1         21            0     25.1kb         25.1kb
	green  open   .kibana_1               yVaJFqXHR1GFt5naSGVmEg   1   0         15            1     66.3kb         66.3kb
	green  open   kibana_sample_data_logs EIwk37JKRUiQ1oSu-WpX6Q   1   0      14005            0     11.4mb         11.4mb
	
	
	看看哪些shard是unassign
	
	GET /_cat/shards?v&pretty

	//查看各结点的存储使用情况
	GET _cat/allocation?v&pretty

	
	
>6,索引的curd
	
>>创建索引：

	PUT /test_index?pretty
	
	GET _cat/indices?v
	
	health status index                   uuid                   pri rep docs.count docs.deleted store.size pri.store.size
	yellow open   test_index              HWq1LujlQniwhy6gf_pN8w   5   1          0            0      1.1kb          1.1kb
	yellow open   twitter                 bmDYXfFMRpSwjm-PvVETqA   5   1         21            0     25.1kb         25.1kb
	green  open   kibana_sample_data_logs EIwk37JKRUiQ1oSu-WpX6Q   1   0      14005            0     11.4mb         11.4mb
	green  open   .kibana_1               yVaJFqXHR1GFt5naSGVmEg   1   0         15            1     66.3kb         66.3kb

	

>>删除索引

	DELETE /test_index?pretty

	{
	  "acknowledged" : true
	}



	
>7,商品的curd操作

>>添加数据
	
 （1）,新增加商品：新增文档，建立索引
 	PUT  /index/type/id
 	{
 		"json数据"
 	}
	
	
	PUT /ecommerce/product/1
	{
	  "name":"gaolujie yaogao",
	  "desc":"gaoxiao meibai",
	  "price":30,
	  "producer": "gaolujie producer",
	  "tags":["meibai","fangzhu"]
	}
	
	PUT /ecommerce/product/2
	{
	  "name":"jiashijie yaogao",
	  "desc":"youxiao fangzhu",
	  "price":20,
	  "producer": "jiajieshi producer",
	  "tags":["fangzhu"]
	}
	PUT /ecommerce/product/3
	{
	  "name":"zhonghua yaogao",
	  "desc":"caoben zhiwu",
	  "price":35,
	  "producer": "zhonghuaproducer",
	  "tags":["qingxin]
	}
	
	
	返回数据：
		{
	  "_index" : "ecommerce",
	  "_type" : "product",
	  "_id" : "1",
	  "_version" : 1,
	  "result" : "created",
	  "_shards" : {
	    "total" : 2,
	    "successful" : 1,
	    "failed" : 0
	  },
	  "_seq_no" : 0,
	  "_primary_term" : 1
	}

	
	
	
	
>>查询数据	


 	 GET /ecommerce/product/1
	
>>删除数据	
	
	DELETE /ecommerce/product/1
	
	
>>修改数据	
	
	PUT /ecommerce/product/1
	{
	  "name":"qqq gaolujie yaogao",
	  "desc":"gaoxiao meibai",
	  "price":30,
	  "producer": "gaolujie producer",
	  "tags":["meibai","fangzhu"]
	}
	
	//修改指定的数据
	POST /ecommerce/product/1/_update
	{
	  "doc":{
	    "name":"gaolujie yaogao"
	  }
	}
	
	
	

数据无法写入，修改删除操作

   修改索引的设置
   
	PUT /ecommerce/_settings
	{
	  "index.blocks.read_only_allow_delete": null
	}	
		
	


>8,文档的检索-query

>>query string search		
	
	  GET /ecommerce/product/_search
	  
	 （1，） 检索ecommerce索引的product类别所有数据
	  
	  {
		  "took" : 3,   //耗费时间毫秒
		  "timed_out" : false, //是否超时
		  "_shards" : { 分片，数据被拆分成了5个嗯片
		    "total" : 5,
		    "successful" : 5, //成功写入数据
		    "skipped" : 0,
		    "failed" : 0
		  },
		  "hits" : { 
		    "total" : 3,//查询数量，3个document
		    "max_score" : 1.0, //docuemnt对于一个search的相关度匹配分数，越相关，就越匹配，分数也高
		    "hits" : [ //包含匹配搜索document的详细数据
		      {
		        "_index" : "ecommerce",
		        "_type" : "product",
		        "_id" : "2",
		        "_score" : 1.0,
		        "_source" : {
		          "name" : "jiashijie yaogao",
		          "desc" : "youxiao fangzhu",
		          "price" : 20,
		          "producer" : "jiajieshi producer",
		          "tags" : [
		            "fangzhu"
		          ]
		        }
		      },
		      {
		        "_index" : "ecommerce",
		        "_type" : "product",
		        "_id" : "1",
		        "_score" : 1.0,
		        "_source" : {
		          "name" : "gaolujie yaogao",
		          "desc" : "gaoxiao meibai",
		          "price" : 30,
		          "producer" : "gaolujie producer",
		          "tags" : [
		            "meibai",
		            "fangzhu"
		          ]
		        }
		      },
		      {
		        "_index" : "ecommerce",
		        "_type" : "product",
		        "_id" : "3",
		        "_score" : 1.0,
		        "_source" : {
		          "name" : "zhonghua yaogao",
		          "desc" : "caoben zhiwu",
		          "price" : 35,
		          "producer" : "zhonghuaproducer",
		          "tags" : [
		            "qingxin"
		          ]
		        }
		      }
		    ]
		  }
		}
		
		
	（2，）检索包含牙膏的商品，因为search参数都是以http请求的query string来附带的，
	     检索包含牙膏的商品。而且价格按照讲叙排序: 
	     	GET /ecommerce/product/_search?q=name:yaogao&sort=price:desc
	     
	     
	     
			

>>9,query DSL特定领域的语言

  http request body :请求体，可以用json的格式来构建查询语法，比较方便，可以构建各类复杂的语法，比query string search 强大
  
  (1)，查询所有的数据
  
	  GET  /ecommerce/product/_search
	  {
	  	"query":{"match_all":{}}
	  }
  
  （2），检索包含牙膏的商品。而且价格按照讲叙排序
  
	  	GET /ecommerce/product/_search
		  {
		  	"query":{
		  	  "match":{
		  	    "name":"gaolujie"
		  	   }
		  	 },
		  	 "sort":[
		  	     {
		  	      "price":"desc"
		  	    }
		  	   ]
		  }
	  
	  
  （3），分页检索数据
  		
  		  GET /ecommerce/product/_search
		  {
		    "query": {"match_all": {}},
		    "from": 1,
		    "size": 1
		  }
  
	
  (4),指定要查询出来商品的名称和价格就可以
  					
  		  GET /ecommerce/product/_search
		  {
		      "query": {"match_all": {}},
		        "from": 1,
				    "size": 1,
		      "_source": ["name","price"]
		    
		  }
  	
		  	{
			  "took" : 2,
			  "timed_out" : false,
			  "_shards" : {
			    "total" : 5,
			    "successful" : 5,
			    "skipped" : 0,
			    "failed" : 0
			  },
			  "hits" : {
			    "total" : 3,
			    "max_score" : 1.0,
			    "hits" : [
			      {
			        "_index" : "ecommerce",
			        "_type" : "product",
			        "_id" : "1",
			        "_score" : 1.0,
			        "_source" : {
			          "price" : 30,
			          "name" : "gaolujie yaogao"
			        }
			      }
			    ]
			  }
			}



>>query filter（查询条件过滤）
	
	检索名称包含yaogao，价格小于等于30的商品
	
	GET /ecommerce/product/_search
	{
		  "query": {
		    "bool": {
		      "must": [
		        {"match": {
		          "name": "yaogao"
		        }}
		      ],
		      "filter": {
		         "range": {
		           "price": {
		             "lte": 30
		           }
		         }
		      }
		    
		    }
		    
		  }
		  
		}
		  

	
>>full-text search（全文检索）

	全文检索查找含有yaogao或者producer的字段
	
	GET /ecommerce/product/_search
	{
	  "query": {
	    "match_phrase": {
	      "producer": "producer"
	    }
	    
	  }
	}
		
	
>>phrase search(短语搜索)
	
	跟全文检索相对应，相反，全文检索会将输入的锁搜串拆解开来，去倒排索引里面去--匹配。只要匹配上任意一个拆解的单词，就可以作为结果返回
	phrase search要求输入的搜索串，必须在指定的字段文本中，完全包含一摸一样的，才可以算匹配，才能作为结果返回
		
	GET /ecommerce/product/_search
	{
	  "query": {
	    "match_phrase": {
	      "producer": "producer"
	    }
	    
	  }
	}
		


>>highlight search --高亮搜索，检索的关键词会被标记为高亮显示
	
  GET /ecommerce/product/_search
	{
	  "query": {
	    "match": {
	      "producer": "producer"
	    }
	  }, 
	  "highlight": {
	      "fields": {
	        "producer": {}
	      }
	  }
	}
	
	运行结果：
	{
	  "took" : 44,
	  "timed_out" : false,
	  "_shards" : {
	    "total" : 5,
	    "successful" : 5,
	    "skipped" : 0,
	    "failed" : 0
	  },
	  "hits" : {
	    "total" : 2,
	    "max_score" : 0.2876821,
	    "hits" : [
	      {
	        "_index" : "ecommerce",
	        "_type" : "product",
	        "_id" : "2",
	        "_score" : 0.2876821,
	        "_source" : {
	          "name" : "jiashijie yaogao",
	          "desc" : "youxiao fangzhu",
	          "price" : 20,
	          "producer" : "jiajieshi producer",
	          "tags" : [
	            "fangzhu"
	          ]
	        },
	        "highlight" : {
	          "producer" : [
	            "jiajieshi <em>producer</em>"
	          ]
	        }
	      }
	    ]
	  }
	}
	
	
>10,elasticsearch的聚合操作
	
>>统计每个tag下的数量：
	
	//下面的写法会把数据和统计全部输出
	GET /ecommerce/product/_search
	{
	  "aggs":{
	    "group_by_tags":{
	      "terms":{"field":"tags"}
	    }
	  }
	}
	
	
	PUT /ecommerce/_mapping/product
	{
	  "properties": {
	     "tags":{
	       "type": "text",
	       "fielddata": true
	     }
	  }
	}
	
	PUT /ecommerce/_settings
		{
		  "index.blocks.read_only_allow_delete": null
	}	
	
	//只显示出统计tags的数据，设置size：0
	GET /ecommerce/product/_search
	{
	  "size": 0, 
	  "aggs":{
	    "group_by_tags":{
	      "terms":{"field":"tags"}
	    }
	  }
	}


>>先分组再计算每个tags的平均价格
	
	//分组分组，然后在分组里面计算平均值
	GET /ecommerce/product/_search
		{
		  "size": 0, 
		  "aggs":{
		    "group_by_tags":{
		       "terms": {
		         "field": "tags"
		       },
		       "aggs":{
		        "avg_price":{
		          "avg": {
		            "field": "price"
		         }
		       }
		     }
		    }
		  }
		}



>>计算每个tags的平均价格，然后按照价格排序
	
	GET /ecommerce/product/_search
	{
	    "size": 0,
	    "aggs":{
	      "all_tags":{
	        "terms": {
	          "field": "tags",
	          "order": {
	            "avg_price": "desc"
	          }
	        },
	        "aggs": {
	          "avg_price": {
	            "avg": {
	              "field": "price"
	            }
	          }
	        }
	      }
	    }
	}
	


>>指定的价格范围分组，每组按照tags分组，计算每组的平均价格
	
	
	GET /ecommerce/product/_search
	{
	  "size": 0,
	  "aggs": {
	    "group_by_price": { //按照价格分组
	      "range": {
	        "field": "price",
	        "ranges": [
	          {
	            "from": 0,
	            "to": 28
	          },
	          {
	            "from": 28,
	            "to": 31
	          },
	          {
	            "from": 31,
	            "to": 10000
	          }
	        ]
	      },
	      "aggs": {　　//根据分组的价格进行tags分组
	      "group_by_tags": {
	      "terms": {
	        "field": "tags"
	       },
	       "aggs":{ //计算tags分组的平均值
	        "avg_price":{
	          "avg": {
	            "field": "price"
	          }
	        }
	       }
	     }
	    }
	    }
	
	  }
	 
	}

	计算结果：
		{
		  "took" : 7,
		  "timed_out" : false,
		  "_shards" : {
		    "total" : 5,
		    "successful" : 5,
		    "skipped" : 0,
		    "failed" : 0
		  },
		  "hits" : {
		    "total" : 3,
		    "max_score" : 0.0,
		    "hits" : [ ]
		  },
		  "aggregations" : {
		    "group_by_price" : {
		      "buckets" : [
		        {
		          "key" : "0.0-28.0",
		          "from" : 0.0,
		          "to" : 28.0,
		          "doc_count" : 1,
		          "group_by_tags" : {
		            "doc_count_error_upper_bound" : 0,
		            "sum_other_doc_count" : 0,
		            "buckets" : [
		              {
		                "key" : "fangzhu",
		                "doc_count" : 1,
		                "avg_price" : {
		                  "value" : 20.0
		                }
		              }
		            ]
		          }
		        },
		        {
		          "key" : "28.0-31.0",
		          "from" : 28.0,
		          "to" : 31.0,
		          "doc_count" : 1,
		          "group_by_tags" : {
		            "doc_count_error_upper_bound" : 0,
		            "sum_other_doc_count" : 0,
		            "buckets" : [
		              {
		                "key" : "fangzhu",
		                "doc_count" : 1,
		                "avg_price" : {
		                  "value" : 30.0
		                }
		              },
		              {
		                "key" : "meibai",
		                "doc_count" : 1,
		                "avg_price" : {
		                  "value" : 30.0
		                }
		              }
		            ]
		          }
		        },
		        {
		          "key" : "31.0-10000.0",
		          "from" : 31.0,
		          "to" : 10000.0,
		          "doc_count" : 1,
		          "group_by_tags" : {
		            "doc_count_error_upper_bound" : 0,
		            "sum_other_doc_count" : 0,
		            "buckets" : [
		              {
		                "key" : "qingxin",
		                "doc_count" : 1,
		                "avg_price" : {
		                  "value" : 35.0
		                }
		              }
		            ]
		          }
		        }
		      ]
		    }
		  }
		}
		

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***

#二，Elasticsearch基础分布式架构详解

	
>es对分布式机制的透明隐藏性：
	
	shard副本负载均衡，replica备份， cluster discovery集群节点发现注册,请求路由，集群扩容，shard重新分配
	
	
>es扩容方案

	（1），垂直扩容，采购服务器组建新的集群,替换到老的服务器
	（2），水平扩容	  普通服务器组建集群，直接加入到集群中去
	
>es增加减少节点的rebalance
	
	es会自动调整shard的请求节点分布均匀


>master节点
	
	master节点不承载所有的请求，所以不会成为性能的单点瓶颈
	管理es集群的元数据，比如索引的创建和删除，维护索引元数据，及诶单的增加和转移，维护集群的元数据
	默认情况下为自动选择出一台节点，作为master节点
	
>节点对等分布式架构
	
	每个节点都能接收所有的请求
	自动请求路由
	相应集群
	
	
>shard和replica机制
	
	shard&replica机制：

    index包含多个shard
    每个shard都是一个最小工作单元，承载部分数据，lucene实例，完整的建立索引和处理请求的能力
    增减节点时，shard会自动在nodes中负载均衡
    primary shard和replica shard，每个document肯定只存在于某一个primary shard以及其对应的replica shard中，不可能存在于多个primary shard
    replica shard是primary shard的副本，负责容错，以及承担读请求负载
    primary shard的数量在创建索引的时候就固定了，replica shard的数量可以随时修改
    primary shard的默认数量是5，replica默认是1，默认有10个shard，5个primary shard，5个replica shard
    primary shard不能和自己的replica shard放在同一个节点上（否则节点宕机，primary shard和副本都丢失，起不到容错的作用），但是可以和其他primary shard的replica shard放在同一个节点上
	
	
![jiqun ](https://images2017.cnblogs.com/blog/294879/201712/294879-20171230170146038-1763633664.png)
	
	
>多个机器中replica shard是如何分配的	
	
	   节点1中有 primary1 primary2 primary3
	   节点2中有 replica1 replica2  replica3 
	   replica是对primary的备份，replica可以接受读请求
	

>横向扩容和提升容错性
	
		扩容机器，由于primary shard是不可能被增加的，只能增加replica shard的数量
	
	
>es容错机制的master选举，replica容错，数据恢复	
	容错第一步：master选举，自动选举另外一个node为新的master，承担起master的责任来
	容错第二步：新的master，将丢失掉的peimary shard的某个replica shard提升为primary shard,此时cluster status会变成yellow，因为peimary shard全部变成active了，但是，少了一个replica shard，所以不是所有的replica shard都是active了
	容错第三步: 重启故障里的node new master，会将确实的副本都copy一份到该node上去，而且改node会使用之前已有的shard数据，只是同步一下宕机之后发生过的修改,clustr status 变为green,因为primary shaerd和replica shard都齐全了
	
	
 		

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***		


#3,es的document详解

参考：
	https://www.cnblogs.com/dreamroute/p/8484457.html

>1，元数据，_index,_type,_id
	
	
	GET /ecommerce/product/1
	{
	  "_index" : "ecommerce",
	  "_type" : "product",
	  "_id" : "1",
	  "_version" : 10,
	  "found" : true,
	  "_source" : {
	    "name" : "gaolujie yaogao",
	    "desc" : "gaoxiao meibai",
	    "price" : 30,
	    "producer" : "gaolujie producer",
	    "tags" : [
	      "meibai",
	      "fangzhu"
	    ]
	  }
	}
	
  (1),index 索引
  		
  		同一个类型的数据放在一个索引里面，比如所有的商品，等
  		索引名称必须是小写
  	
  (2),type -类型
  		
  		type属于index的类别
  		一个索引通常会被划分为多个type
  		type可以是大小写，但是不能使用下划线开头，不能包含逗号
  		
  
  (3),id
  		
  		代表document的唯一标示，与index和type一起，可以唯一定位的docuemnt
  		可以手动指定document的id（put /index/type/id），也可以不指定，由es自动为我们创建一个id


>2，document的_id手动指定和自动生成
	
		
	（1），手动指定id,被导入的数据适合指定唯一id
		
		PUT /index/type/id
	
	
	（2），自动生成id,使用es作为存储的 使用es自动生成
		
		POST /index/type
		
		自动生成的id，长度为20字符，URL安全的，base64编码，GUID，分布式安全的
	
	
>3,document的source元数据,指定元素返回的字段
		
		
		GET /ecommerce/product/_search?q=name:yaogao&_source=name,desc
		
		只返回name和desc字段
	
		
>4,docuemnt的全量替换，强制创建以及文档删除等操作分析
	
	(1),全量替换
		如果_id不存在就创建，存在就是全量替换
		document是不可变的，如果要修改document的内容，第一种方式就是全量替换，直接对document重新建立索引，替换里面所有的内容
		es会将老的document标记为deleted,然后新增我们给定的一个docuemnt，当我们创建越来越多时，es会在适当的时机在后后台自动删除标记为delete的document
	
   (2),强制创建
   		
   		PUT /web/app/1/_create
   		
   
   
   (3),文档删除		
   
   		DELETE /index/type/id
   		
   		数据不会被立即删除，再添加相同的id，id会在删除的version上加1
   
   
> 5,es的并发冲突问题
	
	多个线程操作同一份数据，会出现数据错乱。
	
	
>6,es的并发控制悲观锁和乐观锁
	
	(1),悲观锁的方案，在各种情况下都上锁，就只有一个线程可以操作一条数据，不同的场景下，上的锁不一样，行级锁，表级锁，读锁，写锁   
   
   
   （2),乐观锁，根据version判断数据源
   
   
   
>7,es基于乐观锁进行并发控制  
		
	例子：
	
	PUT /web/app/1
	{
	  "name":"ioss"
	}
		
	{
	  "_index" : "web",
	  "_type" : "app",
	  "_id" : "1",
	  "_version" : 2,
	  "found" : true,
	  "_source" : {
	    "name" : "ios"
	  }
	}
	
	
	数据时按照version版本来操作的，先操作的version加1，后修改的在前面的version加1
	
	
	//修改version版本号为1的数据
	PUT /web/app/1?version=4
	{
	  "name":"android"
	}
	
	//重复执行上面的version，会提示，version5已经被使用了
	{
	  "error": {
	    "root_cause": [
	      {
	        "type": "version_conflict_engine_exception",
	        "reason": "[app][1]: version conflict, current version [5] is different than the one provided [4]",
	        "index_uuid": "m5QzMy0FT4O25eTaJx4zow",
	        "shard": "3",
	        "index": "web"
	      }
	    ],
	    "type": "version_conflict_engine_exception",
	    "reason": "[app][1]: version conflict, current version [5] is different than the one provided [4]",
	    "index_uuid": "m5QzMy0FT4O25eTaJx4zow",
	    "shard": "3",
	    "index": "web"
	  },
	  "status": 409
	}
	

	
>8,es的批量查询 mget
		
		mget查询多个id
		GET /_mget
		{
		  "docs":[
		    {
		       "_index" : "ecommerce",
		        "_type" : "product",
		        "_id" : "2"
		    },
		    {
		       "_index" : "ecommerce",
		        "_type" : "product",
		        "_id" : "1"
		    },
		    {
		       "_index" : "web",
		      "_type" : "app",
		      "_id" : "1"
		    }
		    
		  ]
		  
		}
		
		
		运行结果：
		{
		  "docs" : [
		    {
		      "_index" : "ecommerce",
		      "_type" : "product",
		      "_id" : "2",
		      "_version" : 1,
		      "found" : true,
		      "_source" : {
		        "name" : "jiashijie yaogao",
		        "desc" : "youxiao fangzhu",
		        "price" : 20,
		        "producer" : "jiajieshi producer",
		        "tags" : [
		          "fangzhu"
		        ]
		      }
		    },
		    {
		      "_index" : "ecommerce",
		      "_type" : "product",
		      "_id" : "1",
		      "_version" : 10,
		      "found" : true,
		      "_source" : {
		        "name" : "gaolujie yaogao",
		        "desc" : "gaoxiao meibai",
		        "price" : 30,
		        "producer" : "gaolujie producer",
		        "tags" : [
		          "meibai",
		          "fangzhu"
		        ]
		      }
		    },
		    {
		      "_index" : "web",
		      "_type" : "app",
		      "_id" : "1",
		      "_version" : 5,
		      "found" : true,
		      "_source" : {
		        "name" : "android"
		      }
		    }
		  ]
		}
			
	
	
>9,es的bulk批量操作用法，json之间不需要换行，不同的json需要换行
	
	（1），bulk语法
		{"index":{"_index":"test_index","_type":"test_type","_id":"1"}}
		{"test_field1":"test1","test_feild2":"test2"}
	
   	（2）,bulk有哪些操作
   
	  delete:删除一个文档
	  create: PUT/index/type/id/_create强制创建文档
	  index : 普通的put操作，可以是创建文档，也可以是全量替换文档
	  update: 执行的update操作
	 
	 GET /web/app/2
	 
	 POST /_bulk
	{"delete":{  "_index" : "web","_type" : "app", "_id" : "1"}}
	{"create":{  "_index" : "web","_type" : "app", "_id" : "2"}}
	{"name":"ios"}
	{"update":{  "_index" : "web","_type" : "app", "_id" : "2"}}
	{"doc":{"name":"golang"}}
	
	运行结果：
	{
	  "took" : 27,
	  "errors" : false,
	  "items" : [
	    {
	      "delete" : {
	        "_index" : "web",
	        "_type" : "app",
	        "_id" : "1",
	        "_version" : 6,
	        "result" : "deleted",
	        "_shards" : {
	          "total" : 2,
	          "successful" : 1,
	          "failed" : 0
	        },
	        "_seq_no" : 5,
	        "_primary_term" : 1,
	        "status" : 200
	      }
	    },
	    {
	      "create" : {
	        "_index" : "web",
	        "_type" : "app",
	        "_id" : "2",
	        "_version" : 1,
	        "result" : "created",
	        "_shards" : {
	          "total" : 2,
	          "successful" : 1,
	          "failed" : 0
	        },
	        "_seq_no" : 0,
	        "_primary_term" : 1,
	        "status" : 201
	      }
	    },
	    {
	      "update" : {
	        "_index" : "web",
	        "_type" : "app",
	        "_id" : "2",
	        "_version" : 2,
	        "result" : "updated",
	        "_shards" : {
	          "total" : 2,
	          "successful" : 1,
	          "failed" : 0
	        },
	        "_seq_no" : 1,
	        "_primary_term" : 1,
	        "status" : 200
	      }
	    }
	  ]
	}
   	
   		
   	（3）,bulk奇怪的json格式
   	
   		 json数组的方式会被解析成jsonarray数据，导致在内存中出现两份数据，，一份是json，一份是jsonarray对象
   		 bulk 的size最大在10M左右
   		
   		//下面的写法不需要进行json转换，直接获取到数据执行就可以
   		 {"create":{  "_index" : "web","_type" : "app", "_id" : "2"}}\n
		 {"name":"ios"}\n

>10, document路由到shard的原理
	
		document路由到shard的过程
		
		路由算法：
			shard = (routing)% number_of_primary_shard
		
		 
		primary_shard不可改变是因为路由的shard会使用，如果primary_shard改变会导致数据丢失
   
   
   
>11,document的curd原理
	
		删除，修改，添加 操作的是primary shard
		查询 replica shard，通过轮训算法选择节点
		


>12,document的分布式一致性原理和Quorum机制深入剖析
		
	（1），consistency  one(primary shard) all（all shard） quorum（default）
	 	发送请求增删改的时候，可以带上consistency参数，指明我们想要的一致性
	 	put /index/type/id?consistency=one
	 	
	 	one:要求我们写操作，只要有一个primary shard是active活跃可用的，就可以执行
	 	all:要求我们写操作，必须所有的primary shard和replica shard都是活跃的，才可以执行写操作
	 	quorum：默认值，要求所有的shard中，必须要大部分都是活跃的，可用的，才可以执行这个操作
	 
	 （2）,quroum机制，写之前必须确保大多数shard都可用的，int(（primary +number_of_reolica）/2)+1，当number_of_replica>1是才有效
	 	
	 （3）,如果节点数少于quorum数量，可能会导致quroum步齐全，进而导致五大执行任何操作
	 
	 （4）,quroum不齐全是，wait默认1分钟，timeout，100，30s

   
      
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***		
  


#三，Elasticsearch的引擎   
  
  
>_search格式详解
	
	GET /web/app/_search
	运行结果：	
	{
	  "took" : 1,
	  "timed_out" : false,
	  "_shards" : {
	    "total" : 5,
	    "successful" : 5,
	    "skipped" : 0,
	    "failed" : 0
	  },
	  "hits" : {
	    "total" : 2,
	    "max_score" : 1.0,
	    "hits" : [
	      {
	        "_index" : "web",
	        "_type" : "app",
	        "_id" : "4",
	        "_score" : 1.0,
	        "_source" : {
	          "name" : "golang"
	        }
	      },
	      {
	        "_index" : "web",
	        "_type" : "app",
	        "_id" : "3",
	        "_score" : 1.0,
	        "_source" : {
	          "name" : "ios"
	        }
	      }
	    ]
	  }
	}
		
	
	took 耗时
	hits.total
	hits.hits前两条完整数据，_score降序排序，max_conn
	shards:shard fail的条件（primary 和replica全部挂掉），不影响其他的shard	
  
 
>2,multi-index和multi-type搜索模式
	
	
	   
>3,es分页问题deep paging
		
	(1),	
		//查询index为ecommerce和web的数据查询第一页每页两条数据
		GET /ecommerce,web/_search?size=2&from=0
	 
	(2),deep piging问题
		
		假如有三个shard，每个shard有2万条数据，总数据是6万，现在分页查询第10000-10010条数据时，每个shard会返回10010条数据给coordinate node，然后进行排序，再取出对应的那一页
    
 
>4,query all string以及_all match原理
	
   （1）query all string
   
		GET /ecommerce,web/_search?q=name:yaogao
		GET /ecommerce,web/_search?q=+name:yaogao //必须包含这个字段
		GET /ecommerce,web/_search?q=-name:yaogao //不包含这个字段
	
	（2）_all match原理
			
			//使用es的_all匹配检索，由于q=yaogao没有指定检索的字段，默认检索所有的字段
			
			GET /ecommerce,web/_search?q=yaogao

		
		
		
>5,es的mapping例子	
		
		
 （1），创建数据	
 	
	PUT /website/article/1
	{
	  "post_date":"2017-01-01",
	  "title":"my frist article",
	  "content":"this is my frist article in this website",
	  "author_id":11400
	}
	
	PUT /website/article/2
	{
	  "post_date":"2017-01-02",
	  "title":"my seconde article",
	  "content":"this is my seconde article in this website",
	  "author_id":11400
	}
	
	PUT /website/article/3
	{
	  "post_date":"2017-01-03",
	  "title":"my thrid article",
	  "content":"this is my thrid article in this website",
	  "author_id":11400
	}

   
	PUT /website/_settings
	{
	  "index.blocks.read_only_allow_delete": null
	}	
	
 （2）查询数据
 		
		GET /website/_search  //所有数据
		GET /website/_search?q=2017  //1条数据 第一条
		GET /website/_search?q=2017-01 //1条数据 第一条		GET /website/_search?q=post_date:2017  //1条数据 第一条
		GET /website/_search?q=post_date:2017-01  //1条数据 第一条	
 （3），mapping简介
 		
 		自动或者手动为index中的type建立的一种数据结果和相关配置，以及type对应的mapping，maooing中包含了每个field对应的数据类型，以及如何分词等设置，
 		
		//查看website索引下的article的结构
		GET /website/_mapping/article
		结果：
		{
		  "website" : {
		    "mappings" : {
		      "article" : {
		        "properties" : {
		          "author_id" : {
		            "type" : "long"
		          },
		          "content" : {
		            "type" : "text",
		            "fields" : {
		              "keyword" : {
		                "type" : "keyword",
		                "ignore_above" : 256
		              }
		            }
		          },
		          "post_date" : {
		            "type" : "date"
		          },
		          "title" : {
		            "type" : "text",
		            "fields" : {
		              "keyword" : {
		                "type" : "keyword",
		                "ignore_above" : 256
		              }
		            }
		          }
		        }
		      }
		    }
		  }
		}
		


>6,精确匹配和全文匹配对比分析

	
	(1),exact value
	
		2017-01-01 使用exact value时，必须输入2017-01-01,才能检索出来，如果你输入一个01，是搜索不出来的
	
	
	(2),full text

		缩写： cn china
		格式转化 ： like liked likeds
		大小写：tom Tom
		同义词： like love



>7，倒排索引核心原理分析
	
	//检索下面两句话
	doc1: I readlly liked my small dogs
	doc2: he never liked any dog
	
	分词的建立规则如下：
	word。       doc1.        doc2
	I				*
	readlly		*
	liked			*             *
	my				*
	small			*
	dogs			*				*
	he								*
	never							*
	any								*
	
	like little dog 这句话不会搜索到结果
	
	使用倒排索引排序normalization



>8,分词器
		
 （1）,什么是分词器
 		
 		切分词语，normalization(提升recall召回率)
 		recall是增加搜索的结果的数量
 		
 		character filter :在一段文本进行分词之前，先进行预处理，比如常见的就是html标签过滤(<span>hello</span>)
 		
 		tokenizer  分词 hello  your and mo -->hello,your,and,me
 		token filter :Token Filters：针对Tokenizer处理的单词进行再加工，比如转小写、删除或增新等处理 mother -->mom
 		
 		 分词器最好的就是将文本进行各种处理，最好处理好的结果才会去建立倒排索引	
	
 （2），内置分词器
		
	Standard Analyzer
		1、描述&特征：
		（1）默认分词器，如果未指定，则使用该分词器。
		（2）按词切分，支持多语言
		（3）小写处理，它删除大多数标点符号、小写术语，并支持删除停止词。
		2、组成：
		（1）Tokenizer：Standard Tokenizer
		（2）Token Filters：Lower Case Token Filter
		例：POST _analyze
		{
		"analyzer": "standard",
		"text": "The 2 QUICK Brown-Foxes jumped over the lazy dog's bone."
		}
		上面的句子会产生下面的条件：
		[ the, 2, quick, brown, foxes, jumped, over, the, lazy, dog's, bone ]
		
	Simple Analyzer
		1、描述&特征：
		（1）按照非字母切分，简单分词器在遇到不是字母的字符时将文本分解为术语
		（2）小写处理，所有条款都是小写的。
		2、组成：
		（1）Tokenizer：Lower Case Tokenizer
		例：
		POST _analyze
		{
		"analyzer": "simple",
		"text": "The 2 QUICK Brown-Foxes jumped over the lazy dog's bone."
		}
		上面的句子会产生下面的条件：
		[ the, quick, brown, foxes, jumped, over, the, lazy, dog, s, bone ]
		
	Whitespace Analyzer
		1、描述&特征
		（1）空白字符作为分隔符，当遇到任何空白字符，空白分词器将文本分成术语。
		2、组成：
		（1）Tokenizer：Whitespace Tokenizer
		例：
		POST _analyze
		{
		"analyzer": "whitespace",
		"text": "The 2 QUICK Brown-Foxes jumped over the lazy dog's bone."
		}
		上面的句子会产生下面的条件：
		[ The, 2, QUICK, Brown-Foxes, jumped, over, the, lazy, dog's, bone. ]
		
	Stop Analyzer
		1、描述&特征：
		（1）类似于Simple Analyzer，但相比Simple Analyzer，支持删除停止字
		（2）停用词指语气助词等修饰性词语，如the, an, 的， 这等
		2、组成 ：
		（1）Tokenizer：Lower Case Tokenizer
		（2）Token Filters：Stop Token Filter
		例：
		POST _analyze
		{
		"analyzer": "stop",
		"text": "The 2 QUICK Brown-Foxes jumped over the lazy dog's bone."
		}
		上面的句子会产生下面的条件：
		[ quick, brown, foxes, jumped, over, lazy, dog, s, bone ]
		
	Keyword Analyzer
		1、组成&特征：
		（1）不分词，直接将输入作为一个单词输出，它接受给定的任何文本，并输出与单个术语完全相同的文本。
		2、组成：
		（1）Tokenizer：Keyword Tokenizer
		例：
		POST _analyze
		{
		"analyzer": "keyword",
		"text": "The 2 QUICK Brown-Foxes jumped over the lazy dog's bone."
		}
		上面的句子会产生下面的条件：
		[ The 2 QUICK Brown-Foxes jumped over the lazy dog's bone. ]
		
	Pattern Analyzer
		模式分词器使用正则表达式将文本拆分为术语。
		（1）通过正则表达式自定义分隔符
		（2）默认是\W+，即非字词的符号作为分隔符
		
	Language Analyzers
		ElasticSearch提供许多语言特定的分析工具，如英语或法语。
		
	Fingerprint Analyzer
		指纹分词器是一种专业的指纹分词器，它可以创建一个指纹，用于重复检测。
		
	Custom analyzers
	如果您找不到适合您需要的分词器，您可以创建一个自定义分词器，它结合了适当的字符过滤器、记号赋予器和记号过滤器。

		

>9,search中的query和filter的对比
	
   (1),例子:
   
   		GET /website/_search
			{
			  "query": {
			    "bool": {
			      "must": [
			        {
			          "match": {"post_date" : "2017-01-01"}
			        }
			      ],
			      "filter": {
			        "range": {
			          "author_id": {
			            "gte": 11400
			          }
			        }
			      }
			      
			    }
			  }
		}
  
   (2),filter和query对比大揭秘
   	
   		filter: 仅仅按照搜索条件过滤出结果
   		query: 会去计算每个document相对于搜索条件的相关度，并按照相关度进行排序，如果在搜索，需要将最匹配搜索条件的数据先返回，那么用query，如果只是根据一些条件筛选出一部分数据，不关注其排序，那么用filter
   		
  （3）,filter和query性能
  	
  		filter，不需要计算分数，不需要按照相关度排序，同时内置的自动cache最常用filter的功能
  		query，需要计算分数，按照相关度排序，无法cache结果




>10,search的query使用教程
	
	(1),multi_query多个字段查询
		
		
		GET /ecommerce,web/product,app/_search
		{
		  "query":{
		    "multi_match": {
		      "query": "yaogao", //查询的名称
		      "fields": ["name","producer"] //满足一个就可以
		    }
		  }
		}
		
	
	(),range范围查找
		
		GET /ecommerce/product/_search
			{
			  "query": {
			    "range": {
			      "price": {
			        "gte": 10,
			        "lte": 30
			      }
			    }
			    
			  }
			}


	（3）,term查询，把他当成exact value进行查询
			
			GET /ecommerce/product/_search
			{
			  "query": {"term": {
			      "tags": "yaogao"
			  }}
			}
		
		
	 (4), terms ，查询匹配多个条件其中一个就可以
	 	
	 	GET /ecommerce/product/_search
			{
			  "query": {"terms": {
			    "tags": [ //查询tags的标签，包含meibai和yaogao
			      "meibai",
			      "yaogao"
			    ]
			  }}
			}
  	
  		
  
>11,query的多搜索条件组合查询	

    bool must must_not should filter
    
    	//查询，name为yaogao ，tags不为meibai，producer可以是producer的，价格在10到200之间的
		GET /ecommerce/product/_search
		{
		  "query": {
		    "bool": {
		      
		      "must": [
		        {"match": {
		          "name": "yaogao"
		        }}
		      ]
		      
		      , "must_not": [
		        {"match": {
		          "tags": "meibai"
		        }}
		      ]
		      , "should": [
		        {"match": {
		          "producer": "producer"
		        }}
		      ],"filter": {
		          "range": {
		            "price": {
		              "gte": 10,
		              "lte": 200
		            }
		          }
		      }
		    }
		    
		  }
		}


>12，search定位出检索不合法的原因
		
		使用_validate/query?explain检查查询是否合法
		
		GET /web/app/_validate/query?explain
		{
		  "query":{
		    "multi_matchs": { //  "multi_match"
		      "query": "golang",
		      "fields": ["name","producer"]
		    }
		  }
		}
		
		//给出不合法的原因
		{
		  "valid" : false,
		  "error" : "org.elasticsearch.common.ParsingException: no [query] registered for [multi_matchs]"
		}


>13，指定search的排序规则
	
	 使用query和sort组合使用排序
	 
	 

>14,feild使用两次索引解决字符串排序问题	 
		
 
 //创建表
 		 
 PUT /st
	{
	  "mappings": {
	    "article":{
	      "properties":{
	        "title":{
	          "type":"text",
	          "fields":{
	            "raw":{
	              "type":"string",
	              "index":"not_analyzed"
	            }
	          }
	        },
	        "content":{
	          "type":"text"
	        },
	        "post_date":{
	          "type":"date"
	        },
	        "author_id":{
	          "type":"long"
	        }
	      }
	       
	    }
	  }
	}
		

>15,相关度评分算法TF&IDF---分数越高，匹配程度越高
	
 （1）,算法简介
	
	relevance scroe算法，简单来说，就是计算出，一个索引中的文本，与搜索文本，他们与之间的关联匹配程度越高
	Elasticsearch使用的是term frequency/inverse document frequency算法简称为TF&IDF算法
	term frequency：就是统计各个词条出现的次数，出现次数越多，就越想关
	inverse document frequency：搜索文本中的各个词条在整个索引的文档中出现了多少次，出现的次数越多不相关
	Field-length norm: field长度 field越长，相关度越弱
	
	
  （2），_scroe分数计算？
  		
  		
  		
>16,scoll滚动查询数据，防止一次性查询出过多的数据
	
	需要指定时间，第一次查询之后会生成快照，后期的数据基于快照查询
	
	GET /ecommerce/product/_search?scroll=1m
	{
	  "query":{
	    
	    "match_all": {}
	  },
	  "sort":["_doc"],
	  "size":1
	
	}
		
	运行结果：
	{
		"_scroll_id" : "DnF1ZXJ5VGhlbkZldGNoBQAAAAAAAATYFktCT2dwa3huU3NlclhNQklfUUpjZ3cAAAAAAAAE2RZLQk9ncGt4blNzZXJYTUJJX1FKY2d3AAAAAAAABNoWS0JPZ3BreG5Tc2VyWE1CSV9RSmNndwAAAAAAAATbFktCT2dwa3huU3NlclhNQklfUUpjZ3cAAAAAAAAE3BZLQk9ncGt4blNzZXJYTUJJX1FKY2d3",
		  "took" : 0,
		  "timed_out" : false,
		  "_shards" : {
		    "total" : 5,
		    "successful" : 5,
		    "skipped" : 0,
		    "failed" : 0
		  },
		  "hits" : {
		    "total" : 5,
		    "max_score" : null,
		    "hits" : [
		      {
		        "_index" : "ecommerce",
		        "_type" : "product",
		        "_id" : "5",
		        "_score" : null,
		        "_source" : {
		          "name" : "yaogao",
		          "desc" : "meibai",
		          "price" : 41,
		          "producer" : "producer",
		          "tags" : [
		            "heimei",
		            "meibai",
		            "fangzhu",
		            "baohuyaci"
		          ]
		        },
		        "sort" : [
		          0
		        ]
		      }
		    ]
		  }
		}
	
		//下一次查询直接使用scroll和scroll_id查询下一页的数据
		GET /_search/scroll
		{
		   "scroll":"1m",
		   "scroll_id":"DnF1ZXJ5VGhlbkZldGNoBQAAAAAAAATjFktCT2dwa3huU3NlclhNQklfUUpjZ3cAAAAAAAAE5BZLQk9ncGt4blNzZXJYTUJJX1FKY2d3AAAAAAAABOUWS0JPZ3BreG5Tc2VyWE1CSV9RSmNndwAAAAAAAATmFktCT2dwa3huU3NlclhNQklfUUpjZ3cAAAAAAAAE5xZLQk9ncGt4blNzZXJYTUJJX1FKY2d3"
		}
		

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***	



#四，Elasticsearch索引
	
>1,索引的curd
	
	(1),创建索引
		//创建ag_index 索引 ag_type类型，字段为ag_field
		PUT /ag_index
			{
			  "settings": {
			    "number_of_replicas": 0,
			    "number_of_shards": 1
			  },
			  "mappings": {
			    "ag_type":{
			      "properties":{
			        "ag_field":{
			          "type":"text"
			        }
			      }
			    }
			  }
			}
			
			//添加数据
			PUT /ag_index/ag_type/1
			{
			  "ag_field":"golang"
			}
			
			//查询数据
			GET /ag_index/ag_type/_search
		
	
   (2),修改索引的settings
   			
   		//修改配置
   			
   		PUT /ag_index/_settings
   		{
   			"number_of_replicas": 1
   		}
   			
   		//查询配置
   		GET /ag_index/_settings
   
   
	(3),删除索引
	
		
		DELETE /ag_index


>2,修改索引的分词和实现指定的分词
	
	 默认使用的是standard tokenizer以单词边界进行切分
	
	（1）,修改索引的分词
			默认为standard
	
	 (2）,指定的分词
	 
	 PUT /ag_index
		{
		  "settings": {
		    "analysis": {
		      "analyzer": {
		        "es_std":{
		          "type":"standard",
		          "stopwords":"_english_"
		        }
		      }
		    }
		  }
		}
		
		
		GET /ag_index/_analyze
		{
		  "analyzer": "es_std",
		  "text":"a dog is in the house"
		  
		}
		
		GET /ag_index/_analyze
		{
		  "analyzer": "standard",
		  "text":"a dog is in the house"
		  
		}



>3,索引的type底层数据结构
		
	type:是index用来区分类似的数据的，可能是不同的fields，而且有不同的属性来控制索引建立，分词器field的value，在底层的lucene中建立索引的时候，全部是opaque bytes类型，不区分类型的，
	luence是没有type的概念的，在document中，实际上将type作为一个document的field来存储，即type，es通过_type来进行type的过滤和筛选一个index中有多个type，实际上是放在一起存储的，因此一个index下，不能有多个type重名，而类型或者其他设置不同的，因为那样事无法处理的
	
	
		
		PUT /ag_index
			  "mappings": {
			    "ag_type":{ //第一个type
			      "properties":{
			        "ag_field":{
			          "type":"text"
			        },
			        "age":{
			        	"type":"long"
			        }
			      }
			    },
			     "bg_type":{//第二个type
			      "properties":{
			        "ag_field":{
			          "type":"text"
			        },
			        "sex":{
			        	"type":"long"
			        }
			      }
			    }
			  }
			}	
			
			存入一下两条数据，index的type是如何存储的
			{
			 ag_field:"golang",
			 age:"10"
			}
			
			{
			 ag_field:"java",
			 sex:"1"
			}	
			
			//ag_index的bg_type和ag_type会合并成以下结构：
			PUT /ag_index
			{
				"mappings": {
					
					"_type":{
						"type":"string",
						"index":"string"
					},
					ag_field:{
						"type":"text"
					},
					age:{
						"type":"long"
					},
					sex:{
						"type":"long"
					}
				
			   	}	
			}
			
			//最终存储的结构：
			{
			 ag_field:"golang",
			 age:"10",
			 sex:""
			}
			
			{
			 ag_field:"java",
			 sex:"1",
			 age:""
			}	
			
	
	  需要将结构类似的type放在一个index下，这些type应该多一些field相同
			
	

>4,mapping root object深入剖析
		

		
	（1）,root object
		就是某个type对应的mapping json，包含properties,metadata(_id,_index,_type),setting(analyzer),
		
	PUT /ag_index
		{
			  "mappings": {
			    "ag_type":{
			      "properties":{}
			    }
			  }
			}
	
	（2）,properties
		
		type ,index,analyzer
		
		PUT /ag_index/ag_type/_mappings
		{
			  "mappings": {
			    "ag_type":{
			      "properties":{
			      		"title":{
			      			"type":"string",
			      			 "index":"analyzed",
			      			  "analzer":"standard"
			      		}
			      }
			    }
			  }
			}	
			
		(3),_source 定制返回字段
			
		PUT /ag_index
			{
				  "mappings": {
				   	"ag_type":{
				   		"_source":{
				   			"enabled":false
				   		}
				   	}
				  }
			}	
			
		(4),_all将所有的field打包在一起。作为一个_all field,建立索引，没指定任何field进行搜索时，就是使用_all field搜索
			 
		PUT /ag_index/_mapping/ag_type
			{
				"ag_type":{
					"_all":{"enable":false}
				}
			}	
			
		
>6,mapping的dynamic策略
	
	(1),true	 添加未声明字段	,进行mapping dynamic
   (2),false	 添加未声明字段，就忽略
   (3),strict 添加未声明字段，就报错
   
   
   
#五,es内核原理

>1,docuemnt写入原理（buffer->segment->commit）
	
	(1),数据写入buffer
	(2),commit提交
	(3),buffer数据写到index segment
	(4),等待os cache中的index segment被fsync强制刷新到磁盘上
	(5),新的index segment被打开，供search使用
	(6),buffer被清空
	
	//写入流程
	client--->内存buffer缓冲--->commint提交-->index segment文件-->os cache缓冲-->os fsync(清空buffer数据) --> os disk(写入成功后index segment被打开，供search使用)
   
   //删除流程
   	每次commit的时候，会生成一个.del文件，标明这个index segment中需要被删除的docuemnt
   	搜索的时候，在index segment汇总，匹配到了id=1的doc，此时会发现在.del文件中已经被表识为deleted了，这种数据就会被过滤掉，不会作为搜索结果返回	
   	
   	
	
	//更新操作
	更新实际时将所有的doc标记为deleted,然后将新的document写入新的index srgment中，下次search过来的时候，也许会匹配到一个document的多个版本，但是之前的版本已经被标记为deleted了，所有返回最新版本的doc


>2,写入流程NRT近实时(filesystem cache,refresh)
	
	写入的流程，必须buffer满了才会被执行fsync，有可能等待时间过长，并且fsync的写入发生在IO硬盘，耗时
	写入流程改造如下：
	 
	  （1），数据写入buffer
	  （2），每隔一段时间，buffer中的数据被写入segment文件，但是先写入os cache
	  （3），只要segment写入os cache,那就直接打开提供search，不立即commit
	
	数据写入os cache 并提供搜索 叫做refresh，默认每隔1秒refresh一次
	
		POST /ad_index/_refresh 手动设置refresh时间
		
		PUT /ad_index
		{
			"settings":{
				"refresh_interval":"30s"
			}
		}
		
		
	
>3,写入的可靠性保证（translog,flush)
		
		可靠性保证：
		（1）,数据写入buffer缓冲和translog文件
		（2）,每隔1秒，buffer缓冲数据被写入新的segment file，并进入os cache，此时segment被打开并供search使用
		（3）,buffer被清空
		（4）,重复前三步操作，新的segment部钝添加，buffer不断被清空，而translog中的数据不断累加
		（5）,当translog数据达到一定程度的时候，commint操作发生
			（5-1）,buffer缓冲数据写入一个新的segment，并写入os cache ，打开供使用
			（5-2）,buffer被清空
			（5-3）, 写一个commit point被写入磁盘，标明了所有的index segment
			（5-4）, filesystem cache 中的所有index segemnt file缓存数据，被fsync强制刷到磁盘上
			（5-5）, translog被清空，创建一个新的translog
				
		异步fsync translog：防止在写入的过程中数据丢失
		
		
		宕机恢复：
			translog保存了数据，根据commit point写入磁盘的点来重新刷到segemnt等操作就可以恢复
	
			
>写入的文件合并（segment merge,optimize）
		
	（1）,segment merge合并
		每1秒创建一个segment file，检索所有的segemnt，耗时。es默认会合并segment，将合并的segment. flush到磁盘，写一个新的commit point 包含新的segemnt 排除旧的segment，提供搜索，删除旧的的segment
		
		
		
		
		
	
	   4338567
    
    企业 6千多 3万多  15  一千多   女55岁 60岁退休 需要到社保登记  子龙车站
    农保 1百  3千    15  4百多一个月     60岁第二月个月  
	
	
	str += i + data[i] 
	
	
	
	
	
	
	
	
	
	