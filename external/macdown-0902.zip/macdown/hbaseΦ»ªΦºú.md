#一，hbase使用
![HBase的表结构](https://img2018.cnblogs.com/blog/1337502/201901/1337502-20190102150144133-960627497.png)

0)namaspace命名空间
	
	//创建命名空间：
	你可以创建、删除或更改命名空间。通过指定表单的完全限定表名，在创建表时确定命名空间成员权限：
	<table namespace>:<table qualifier>
 
   
	----Create a namespace 
	create_namespace 'my_ns' 
	 
	----create my_table in my_ns namespace 
	create 'my_ns:my_table', 'fam' 
	 
	----drop namespace 
	drop_namespace 'my_ns' 
	 
	----alter namespace 
	alter_namespace 'my_ns', {METHOD => 'set', 'PROPERTY_NAME' => 'PROPERTY_VALUE'}

	HBase预定义的命名空间

	在 HBase 中有两个预定义的特殊命名空间：
	
	    hbase：系统命名空间，用于包含 HBase 内部表
	
	    default：没有显式指定命名空间的表将自动落入此命名空间
	
	----示例：
	----namespace=foo and table qualifier=bar 
		create 'foo:bar', 'fam' 
	 
	----namespace=default and table qualifier=bar 
		create 'bar', 'fam'
	



创建表,第一个参数是表名，第二个参数是列簇名

   //创建表的格式：
   
  	create ‘<table name>’,’<column family>’
  	
	create 'table1' , 'cf1'
	
	
1）查看有哪些表	

	hbase shell 进入命令行
	hbase(main)> list
	
2）创建表

	语法：create <table>, {NAME => <family>, VERSIONS => <VERSIONS>}
	例如：创建表t1，有两个family name：f1，f2，且版本数均为2
	hbase(main)> create 't1',{NAME => 'f1', VERSIONS => 2},{NAME => 'f2', VERSIONS => 2}
	
3）删除表

	分两步：首先disable，然后drop
	例如：删除表t1
	hbase(main)> disable 't1'
	hbase(main)> drop 't1'
	
4）查看表的结构

	语法：describe <table>
	例如：查看表t1的结构
	hbase(main)> describe 't1'
	
5）修改表结构

	修改表结构必须先disable
	语法：alter 't1', {NAME => 'f1'}, {NAME => 'f2', METHOD => 'delete'}
	例如：修改表test1的cf的TTL为180天
	hbase(main)> disable 'test1'
	hbase(main)> alter 'test1',{NAME=>'body',TTL=>'15552000'},{NAME=>'meta', TTL=>'15552000'}
	hbase(main)> enable 'test1'

作者：编程老司机
链接：https://www.jianshu.com/p/4812db0a429d
来源：简书
简书著作权归作者所有，任何形式的转载都请联系作者获得授权并注明出处。

#二,数据模型

 	hbase的数据模型是由表组成的，各个表中又包含数据行和列，在这些表中存储了hbase数据。
 		
>Table 表

	hbase会将数据存储在表，一个hbase由多个表组成
	
>Row  行

	HBase 中的一行包含一个行键和一个或多个与其相关的值的列。在存储行时，行按字母顺序排序。出于这个原因，行键的设计非常重要。目标是以相关行相互靠近的方式存储数据。常用的行键模式是网站域。如果你的行键是域名，则你可能应该将它们存储在相反的位置（org.apache.www，org.apache.mail，org.apache.jira）。这样，表中的所有 Apache 域都彼此靠近，而不是根据子域的第一个字母分布。
	

>Column 列
	
	HBase 中的列由一个列族和一个列限定符组成，它们由:（冒号）字符分隔。


>Column Family 列族

	出于性能原因，列族在物理上共同存在一组列和它们的值。在 HBase 中每个列族都有一组存储属性，例如其值是否应缓存在内存中，数据如何压缩或其行编码是如何编码的等等。表中的每一行都有相同的列族，但给定的行可能不会在给定的列族中存储任何内容。
	
	列族一旦确定后，就不能轻易修改，因为它会影响到 HBase 真实的物理存储结构，但是列族中的列标识(Column Qualifier)以及其对应的值可以动态增删。

>Column Qualifier 列限定符
	
	列限定符被添加到列族中，以提供给定数据段的索引。鉴于列族的content，列限定符可能是content:html，而另一个可能是content:pdf。虽然列族在创建表时是固定的，但列限定符是可变的，并且在行之间可能差别很大。

>Cell 单元格

	单元格是行、列族和列限定符的组合，并且包含值和时间戳，它表示值的版本。
	
>Timestamp 时间戳
	
	时间戳与每个值一起编写，并且是给定版本的值的标识符。默认情况下，时间戳表示写入数据时 RegionServer 上的时间，但可以在将数据放入单元格时指定不同的时间戳值。
	
	
#三,数据模型操作（get ,put ,scan,delete）
	
		
> Put（添加数据）Put 可以将新行添加到表中（如果该项是新的）或者可以更新现有行（如果该项已经存在）。Put 操作通过 Table.put（non-writeBuffer）或 Table.batch（non-writeBuffer）执行。

	//添加数据语法
	put ‘table name’,’row ’,'Column family:column name',’new value’
	
	put "web","app","app:city","shanghai"
	Took 0.0235 seconds  
	
> Get 指定行的返回属性。读取通过 Table.get 执行。
	
	//查询数据语法
	get ’<table name>’,’row1’
	
	get "web","app"
	COLUMN                                     CELL                                                                                                                     
	 app:city                                  timestamp=1565837858082, value=shanghai                                                                                  
	1 row(s)
		
	
> Scan 允许在多个行上对指定属性进行迭代。
 
	//Scan 操作的语法
    scan ‘<table name>’
    
    scan "web"
    
	 ROW                                COLUMN+CELL                                                                                        
	 app                               column=app:city, timestamp=1565837858082, value=shanghai                                           
	1 row(s)
	   
	
> Delete 操作用于从表中删除一行。Delete 通过 Table.delete 执行。
> HBase 不会修改数据，因此通过创建名为 tombstones 的新标记来处理 Delete 操作。这些  tombstones，以及没用的价值，都在重大的压实中清理干净。

	使用 Delete 命令的语法如下：
	delete ‘<table name>’, ‘<row>’, ‘<column name >’, ‘<time stamp>’
	
	
	delete "web","app","app:city",1565837858082
	Took 0.0589 seconds  



	
参考学习：
https://wiki.imooc.com/hbase/schemacreate.html	