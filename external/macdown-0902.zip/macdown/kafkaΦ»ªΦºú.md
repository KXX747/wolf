# 一，架构

![kafka流程](https://upload-images.jianshu.io/upload_images/2835676-f378607bc841309a.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1000)
	
	1，Sync Producer
		低延迟
		低吞吐率
		数据不可能丢失
	
	2，Aync Producer 
		高延迟
		高吞吐率
		数据可能丢失
		
		Terminology 
	
	3,Terminology

    Broker
    Kafka集群包含一个或多个服务器，这种服务器被称为broker
    Topic
    每条发布到Kafka集群的消息都有一个类别，这个类别被称为topic。（物理上不同topic的消息分开存储，逻辑上一个topic的消息虽然保存于一个或多个broker上但用户只需指定消息的topic即可生产或消费数据而不必关心数据存于何处）
    Partition
    parition是物理上的概念，每个topic包含一个或多个partition，创建topic时可指定parition数量。每个partition对应于一个文件夹，该文件夹下存储该partition的数据和索引文件
    Producer
    负责发布消息到Kafka broker
    Consumer
    消费消息。每个consumer属于一个特定的consumer group（可为每个consumer指定group name，若不指定group name则属于默认的group）。使用consumer high level API时，同一topic的一条消息只能被同一个consumer group内的一个consumer消费，但多个consumer group可同时消费这一消息。

		
		
	
	

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***  

#二,topic的日志文件
	
	
	1，000000000.index索引 存消息的起始位置和offset的对应关系
	2，000000000.log 日志文件
	
	3,000000000.index和000000000.log组成一个segment, 000000000是按照最小消息的名称创建的 .
	
	例子：topic = kafka_go_test-0
	
		00000000000000000003.index      00000000000000000003.snapshot   leader-epoch-checkpoint
		00000000000000000003.log        00000000000000000003.timeindex
		
		
	
	4,leader-epoch-checkpoint详解
		
		参考：https://www.cnblogs.com/huxi2b/p/7453543.html
	
	5，snapshot快照详解
	
	6，timeindex详解

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***  	
	
#三，kafka数据复制和failover

>CAP理论
	
	c  consistency 一致性
	a  avilability 可用性
	p  parttion tolerance 网络分区容错 
	
	
>>master-slave同步方案
	
	同步复制可保证强一致性但会影响可用性
	异步复制可提供高可用性但会降低一致性

>>WNR同步方案
	
	主要是去中心化的系统,Cassandra采用此方案
	N代表副本数，W代表每次写操作总要保证的最少写成功的副本数，R代表每次读至少读取的副本数
	当W+R>N时，可保证每次读取的数据至少有一个副本具有最新的更新
	多个写操作的顺序难度保证，可能导致多副本间的写操作顺序不一致，Dynamo通过向量时钟保证最终一致性。


>>	Paxos及其变种方案
	
	zookeeper的zap raft等
	
	
>kafka的Replica详解	
	
	参考replica详解：https://blog.csdn.net/dshf_1/article/details/82460110
	
	当某个Topic的replication-factor为N且N大于1时，每个Parttiion都会有N个副本（Replica）
	Replica的个数小于等于Broker数，即对每个Patition而言每个Broker上智慧有一个Replica，因此可用Broker ID表示Replica
	所有Partition的所有Replica默认情况会均匀分布到所有Broker上	
![kakfa的replica同步](https://img-blog.csdn.net/20160620014329074)

　Kafka分配Replica的算法如下：

    将所有Broker（假设共n个Broker）和待分配的Partition排序
    将第i个Partition分配到第（i mod n）个Broker上
    将第i个Partition的第j个Replica分配到第（(i + j) mod n）个Broker上


>data replication需要解决的问题	


>>1,如何Propagate消息
	
![数据写入的流程](https://5b0988e595225.cdn.sohucs.com/images/20170906/bd5b9337d157460b94f045d5b407c042.png)

	数据写入leader,follower再去同步leader的数据。。
	

>>2,何时commit
	
>>> commit是leader告诉客户端数据写成功了，只要被commit的数据是不会被丢失的
	
>>> ISR机制：	
	
	Leader会维护一个与其基本保持同步的Replica里列表，该列表成为ISR（in-sync Replica）
	如果一个Follower比Leader落后太多，或者超过一定时间未发起数据复制请求，则Leader将其从ISR中移除
	当ISR中所有Replica都向Leader发送ACK时，Leader即Commit。
	
	
>>> Commit策略
	
	Server配置:
		 replica.lag.time.max.ms=10000 
		 replica.lag.max.messages =4000
	 
	Topic配置-保证topic中至少有多少个replicas：
	 	 min.insync.replicas=1
	 
	 Producer配置：
	    request.required.acks=0
	   
	   
	参数详解request.required.acks ： 
	  0 发过去就完事了，不关心broker是否处理成功，可能丢数据.
	  1 当写Leader成功后就返回,其他的replica都是通过fetcher去同步的,所以kafka是异步写，主备切换可能丢数据。
  	  -1 要等到isr里所有机器同步成功，才能返回成功，延时取决于最慢的机器。强一致，不会丢数据。

	
	在acks=-1的时候，如果ISR少于min.insync.replicas指定的数目，那么就会返回不可用。	
	
	

>>3,如何处理replica恢复
	
![](https://img2018.cnblogs.com/blog/1079709/201811/1079709-20181121223651361-1842860354.png)
	
 详解:
	1. 可以看到SR={A,B,C},Leader(A)节点中存在m1,m2,m3三条消息，F(B)存在m1,m2两条消息，f（c）只存在m1一消息，所以这里只会提交m1这条消息，因为m2这条消息还没有在ISR中完成复制。它只会提交三个ISR中都存在的消息。

　　2. 当L(A)在将消息m2复制到B,C之后挂掉，此时ISR中只有{B,C}，B被选举成为新的主节点，当m2,m1都存在于B,C节点中时，B将会提交m1,m2两条消息，不会提交m3消息。

　　3. 此时消息将都会发送到B节点上，C节点同步了B节点中的新发的消息m4,m5之后，将会提交m4,m5.

　　4.此时A节点连接集群成功或重启，可以使用了，它会从B节点中同步从m1,到m5的消息，直到它的消息与B和C中的一致为止，此时的Replica将会变成ISR={A,B,C},完成了Replica的恢复。这里我们发现m3并没有存在了，这里并不是丢失了，只是当没有主节点提交m3这条消息时，它将会自动反馈到Producer，Producer会重试，或做其他处理，当重试成功后可能m3消息将会append到m5的后面，所以consumer消费消息时，我们保证的顺序性不是producer发送消息的顺序，而是commit时的顺序。


>>4,如何处理replicas全部宕机 
	
	当ISR中的Replica全部宕机时，可以通过如下方式处理：

　　1. 等待ISR中任一Replica恢复，并选它为Leader。

　　缺点：等待时间较长，降低可用性（因为不能使用所有集群节点），因此或ISR中的所有Replica都无法恢复或者数据丢失，则该Partition将永不可用。

　　2. 选择第一个恢复的Replica为新的Leader，无论它是否在ISR中。

　　缺点：并未包含所有已被之前Leader Commit过的消息（因为它不在之前的ISR中），因此会造成数据丢失，但是它提高了可用节点的范围，可用性比较高。

	
	配置replicas宕机后的恢复策略：
	
		默认情况下，Kafka 采用第二种策略	unclean.leader.election.enable=true 也可以将此参数设置为 false 来启用第一种策略。
		
![](https://static001.infoq.cn/resource/image/36/b2/363b6ac0b3d330aaea3bdfedba9904b2.jpg)

		如果上图所示，假设某个 partition 中的副本数为 3，replica-0, replica-1, replica-2 分别存放在 broker0, broker1 和 broker2 中。AR=(0,1,2)，ISR=(0,1)。设置 request.required.acks=-1, min.insync.replicas=2，unclean.leader.election.enable=false。这里讲 broker0 中的副本也称之为 broker0 起初 broker0 为 leader，broker1 为 follower。

	当 ISR 中的 replica-0 出现 crash 的情况时，broker1 选举为新的 leader[ISR=(1)]，因为受 min.insync.replicas=2 影响，write 不能服务，但是 read 能继续正常服务。此种情况恢复方案：

	尝试恢复 (重启)replica-0，如果能起来，系统正常；
	
	如果 replica-0 不能恢复，需要将 min.insync.replicas 设置为 1，恢复 write 功能。
	
	当 ISR 中的 replica-0 出现 crash，紧接着 replica-1 也出现了 crash, 此时 [ISR=(1),leader=-1], 不能对外提供服务，此种情况恢复方案：
	
	尝试恢复 replica-0 和 replica-1，如果都能起来，则系统恢复正常；
	
	如果 replica-0 起来，而 replica-1 不能起来，这时候仍然不能选出 leader，因为当设置 unclean.leader.election.enable=false 时，leader 只能从 ISR 中选举，当 ISR 中所有副本都失效之后，需要 ISR 中最后失效的那个副本能恢复之后才能选举 leader, 即 replica-0 先失效，replica-1 后失效，需要 replica-1 恢复后才能选举 leader。保守的方案建议把 unclean.leader.election.enable 设置为 true, 但是这样会有丢失数据的情况发生，这样可以恢复 read 服务。同样需要将 min.insync.replicas 设置为 1，恢复 write 功能；
	
	replica-1 恢复，replica-0 不能恢复，这个情况上面遇到过，read 服务可用，需要将 min.insync.replicas 设置为 1，恢复 write 功能；
	
	replica-0 和 replica-1 都不能恢复，这种情况可以参考情形 2.
	
	当 ISR 中的 replica-0, replica-1 同时宕机, 此时 [ISR=(0,1)], 不能对外提供服务，此种情况恢复方案：尝试恢复 replica-0 和 replica-1，当其中任意一个副本恢复正常时，对外可以提供 read 服务。直到 2 个副本恢复正常，write 功能才能恢复，或者将将 min.insync.replicas 设置为 1。


***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***  

#四，kafka的 leader-election--选举leader

	
> Zookeeper的基本操作

　　zookeeper中的节点可以持久化/有序的两个维度分为四种类型：
　　PERSIST：持久化无序（保存在磁盘中）
　　PERSIST_SEQUENTIAL：持久化有序递增
　　EPHEMERAL：非持久化的无序的，保存在内存中，当客户端关闭后消失。
　　EPHEMERAL_SEQUENTIAL：非持久有序递增，保存在内存中，当客户端关闭后消失

　　每个节点都可以注册Watch操作，用于监听节点的变化，有四种事件类型如下：

　　Created event: Enabled with a call to exists
　　Deleted event: Enabled with a call to exists, getData, and getChildren
　　Changed event: Enabled with a call to exists and getData
　　Child event: Enabled with a call to getChildren

　　Watch的基本特征是客户端先得到通知，然后才能得到数据，Watch被fire之后就立即取消了，不会再有Watch后续变化，想要监听只能重新注册；

	
>基于Zookeeper的Leader Election
	
	1. 抢注Leader节点——非公平模式

　　编码流程：

　　1. 创建Leader父节点，如/chroot，并将其设置为persist节点

　　2. 各客户端通过在/chroot下创建Leader节点，如/chroot/leader，来竞争Leader。该节点应被设置为ephemeral

　　3. 若某创建Leader节点成功，则该客户端成功竞选为Leader

　　4. 若创建Leader节点失败，则竞选Leader失败，在/chroot/leader节点上注册exist的watch，一旦该节点被删除则获得通知

　　5. Leader可通过删除Leader节点来放弃Leader

　　6. 如果Leader宕机，由于Leader节点被设置为ephemeral，Leader节点会自行删除。而其它节点由于在Leader节点上注册了watch，故可得到通知，参与下一轮竞选，从而保证总有客户端以Leader角色工作。	

　　
> Leader Elction在Curator的实现---LeaderLatch
	
	Curator LeaderLatch特点及api的作用：

　　1. 竞选为Leader后，不可自行放弃领导权

　　2. 只能通过close方法放弃领导权

　　3. 强烈建议增加ConnectionStateListener，当连接SUSPENDED或者LOST时视为丢失领导权

　　4. 可通过await方法等待成功获取领导权，并可加入timeout

　　5. 可通过hasLeadership方法判断是否为Leader

　　6. 可通过getLeader方法获取当前Leader

　　7. 可通过getParticipants方法获取当前竞选Leader的参与方


> Leader Elction在Curator的实现---LeaderSelector
	
	Curator LeaderSelector特点及api的作用：

　　1. 竞选Leader成功后回调takeLeadership方法

　　2. 可在takeLeadership方法中实现业务逻辑

　　3. 一旦takeLeadership方法返回，即视为放弃领导权

　　4. 可通过autoRequeue方法循环获取领导权

　　5. 可通过hasLeadership方法判断是否为Leader

　　6. 可通过getLeader方法获取当前Leader

　　7. 可通过getParticipants方法获取当前竞选Leader的参与方

	
	


***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***  

#5,Broker Failover过程
	
>1,controller对broker failover的处理过程
	
	1.1Controller在Zookeeper的/brokers/ids节点上注册Watch。一旦有Broker宕机（本文用宕机代表任何让Kafka认为其Broker die的情景，包括但不限于机器断电，网络不可用，GC导致的Stop The World，进程crash等），其在Zookeeper对应的Znode会自动被删除，Zookeeper会fire Controller注册的Watch，Controller即可获取最新的幸存的Broker列表。
	Controller决定set_p，该集合包含了宕机的所有Broker上的所有Partition。
	对set_p中的每一个Partition：
	1.2从/brokers/topics/[topic]/partitions/[partition]/state读取该Partition当前的ISR。
	1.3 决定该Partition的新Leader。如果当前ISR中有至少一个Replica还幸存，则选择其中一个作为新Leader，新的ISR则包含当前ISR中所有幸存的Replica。否则选择该Partition中任意一个幸存的Replica作为新的Leader以及ISR（该场景下可能会有潜在的数据丢失）。如果该Partition的所有Replica都宕机了，则将新的Leader设置为-1。
	1.4 将新的Leader，ISR和新的leader_epoch及controller_epoch写入/brokers/topics/[topic]/partitions/[partition]/state。注意，该操作只有Controller版本在3.1至3.3的过程中无变化时才会执行，否则跳转到3.1。
	直接通过RPC向set_p相关的Broker发送LeaderAndISRRequest命令。Controller可以在一个RPC操作中发送多个命令从而提高效率。
	
		
	
>2,创建/删除Topic
	
	Controller在Zookeeper的/brokers/topics节点上注册Watch，一旦某个Topic被创建或删除，则Controller会通过Watch得到新创建/删除的Topic的Partition/Replica分配。
	对于删除Topic操作，Topic工具会将该Topic名字存于/admin/delete_topics。若delete.topic.enable为true，则Controller注册在/admin/delete_topics上的Watch被fire，Controller通过回调向对应的Broker发送StopReplicaRequest；若为false则Controller不会在/admin/delete_topics上注册Watch，也就不会对该事件作出反应，此时Topic操作只被记录而不会被执行。
	对于创建Topic操作，Controller从/brokers/ids读取当前所有可用的Broker列表，对于set_p中的每一个Partition：
	从分配给该Partition的所有Replica（称为AR）中任选一个可用的Broker作为新的Leader，并将AR设置为新的ISR（因为该Topic是新创建的，所以AR中所有的Replica都没有数据，可认为它们都是同步的，也即都在ISR中，任意一个Replica都可作为Leader）
	将新的Leader和ISR写入/brokers/topics/[topic]/partitions/[partition]
	直接通过RPC向相关的Broker发送LeaderAndISRRequest。
	创建Topic顺序图如下所示。	
	
	
	
>3,	Broker响应请求流程
	
	Broker通过kafka.network.SocketServer及相关模块接受各种请求并作出响应。整个网络通信模块基于Java NIO开发，并采用Reactor模式，其中包含1个Acceptor负责接受客户请求，N个Processor负责读写数据，M个Handler处理业务逻辑。
	
	
	
>4,LeaderAndIsrRequest响应过程
	
	　对于收到的LeaderAndIsrRequest，Broker主要通过ReplicaManager的becomeLeaderOrFollower处理，流程如下：

    若请求中controllerEpoch小于当前最新的controllerEpoch，则直接返回ErrorMapping.StaleControllerEpochCode。
    对于请求中partitionStateInfos中的每一个元素，即（(topic, partitionId), partitionStateInfo)：
    　　2.1 若partitionStateInfo中的leader epoch大于当前ReplicManager中存储的(topic, partitionId)对应的partition的leader epoch，则：
    　　　　2.1.1 若当前brokerid（或者说replica id）在partitionStateInfo中，则将该partition及partitionStateInfo存入一个名为partitionState的HashMap中
    　　　　2.1.2否则说明该Broker不在该Partition分配的Replica list中，将该信息记录于log中
    　　2.2否则将相应的Error code（ErrorMapping.StaleLeaderEpochCode）存入Response中
    筛选出partitionState中Leader与当前Broker ID相等的所有记录存入partitionsTobeLeader中，其它记录存入partitionsToBeFollower中。
    若partitionsTobeLeader不为空，则对其执行makeLeaders方。
    若partitionsToBeFollower不为空，则对其执行makeFollowers方法。
    若highwatermak线程还未启动，则将其启动，并将hwThreadInitialized设为true。
    关闭所有Idle状态的Fetcher。

	
	
>5,Borker启动过程
	
	Borker启动后首先会根据其UID再Zookeepr的/borkers/ids znode下创建临时子节点，创建成功后controller的ReplicaStateMachine注册其上的Borker Change Watch会被fire，从而通过回调KafkaController.onBrokerStartup方法完成以下步骤：
	
    向所有新启动的Broker发送UpdateMetadataRequest，其定义如下。
    UpdateMetadataRequest
    将新启动的Broker上的所有Replica设置为OnlineReplica状态，同时这些Broker会为这些Partition启动high watermark线程。
    通过partitionStateMachine触发OnlinePartitionStateChange。


>6,Controller Failover
	
	Controller也需要Failover。每个Broker都会在Controller Path (/controller)上注册一个Watch。当前Controller失败时，对应的Controller Path会自动消失（因为它是Ephemeral Node），此时该Watch被fire，所有“活”着的Broker都会去竞选成为新的Controller（创建新的Controller Path），但是只会有一个竞选成功（这点由Zookeeper保证）。竞选成功者即为新的Leader，竞选失败者则重新在新的Controller Path上注册Watch。因为Zookeeper的Watch是一次性的，被fire一次之后即失效，所以需要重新注册。
	
	Broker成功竞选为新Controller后会触发KafkaController.onControllerFailover方法，并在该方法中完成如下操作：
	

    读取并增加Controller Epoch。
    在ReassignedPartitions Path(/admin/reassign_partitions)上注册Watch。
    在PreferredReplicaElection Path(/admin/preferred_replica_election)上注册Watch。
    通过partitionStateMachine在Broker Topics Patch(/brokers/topics)上注册Watch。
    若delete.topic.enable设置为true（默认值是false），则partitionStateMachine在Delete Topic Patch(/admin/delete_topics)上注册Watch。
    通过replicaStateMachine在Broker Ids Patch(/brokers/ids)上注册Watch。
    初始化ControllerContext对象，设置当前所有Topic，“活”着的Broker列表，所有Partition的Leader及ISR等。
    启动replicaStateMachine和partitionStateMachine。
    将brokerState状态设置为RunningAsController。
    将每个Partition的Leadership信息发送给所有“活”着的Broker。
    若auto.leader.rebalance.enable配置为true（默认值是true），则启动partition-rebalance线程。
    若delete.topic.enable设置为true且Delete Topic Patch(/admin/delete_topics)中有值，则删除相应的Topic。
	


>7,Partition重新分配
	
	管理工具发出重新分配Partition请求后，会将相应信息写到/admin/reassign_partitions上，而该操作会触发ReassignedPartitionsIsrChangeListener，从而通过执行回调函数KafkaController.onPartitionReassignment来完成以下操作：
	
	将Zookeeper中的AR（Current Assigned Replicas）更新为OAR（Original list of replicas for partition） + RAR（Reassigned replicas）。
	强制更新Zookeeper中的leader epoch，向AR中的每个Replica发送LeaderAndIsrRequest。
	将RAR - OAR中的Replica设置为NewReplica状态。
	等待直到RAR中所有的Replica都与其Leader同步。
	将RAR中所有的Replica都设置为OnlineReplica状态。
	将Cache中的AR设置为RAR。
	若Leader不在RAR中，则从RAR中重新选举出一个新的Leader并发送LeaderAndIsrRequest。若新的Leader不是从RAR中选举而出，则还要增加Zookeeper中的leader epoch。
	将OAR - RAR中的所有Replica设置为OfflineReplica状态，该过程包含两部分。第一，将Zookeeper上ISR中的OAR - RAR移除并向Leader发送LeaderAndIsrRequest从而通知这些Replica已经从ISR中移除；第二，向OAR - RAR中的Replica发送StopReplicaRequest从而停止不再分配给该Partition的Replica。
	将OAR - RAR中的所有Replica设置为NonExistentReplica状态从而将其从磁盘上删除。
	将Zookeeper中的AR设置为RAR。
	删除/admin/reassign_partition。
	
　　注意：最后一步才将Zookeeper中的AR更新，因为这是唯一一个持久存储AR的地方，如果Controller在这一步之前crash，新的Controller仍然能够继续完成该过程。
　　以下是Partition重新分配的案例，OAR = ｛1，2，3｝，RAR = ｛4，5，6｝，Partition重新分配过程中Zookeeper中的AR和Leader/ISR路径如下
	
	
		AR 				leader/isr 				Step
	{1,2,3} 			1/{1,2,3} 			(initial state)
	{1,2,3,4,5,6} 	1/{1,2,3} 			(step 2)
	{1,2,3,4,5,6} 	1/{1,2,3,4,5,6} 		(step 4)
	{1,2,3,4,5,6} 	4/{1,2,3,4,5,6} 		(step 7)
	{1,2,3,4,5,6} 	4/{4,5,6} 			(step 8)
	{4,5,6} 			4/{4,5,6} 			(step 10)
	
	

>8,Follower从Leader Fetch数据

	
	　Leader收到Fetch请求后，Kafka通过KafkaApis.handleFetchRequest响应该请求，响应过程如下：

    replicaManager根据请求读出数据存入dataRead中。
    如果该请求来自Follower则更新其相应的LEO（log end offset）以及相应Partition的High Watermark
    根据dataRead算出可读消息长度（单位为字节）并存入bytesReadable中。
    满足下面4个条件中的1个，则立即将相应的数据返回

    Fetch请求不希望等待，即fetchRequest.macWait <= 0
    Fetch请求不要求一定能取到消息，即fetchRequest.numPartitions <= 0，也即requestInfo为空
    有足够的数据可供返回，即bytesReadable >= fetchRequest.minBytes
    读取数据时发生异常

    若不满足以上4个条件，FetchRequest将不会立即返回，并将该请求封装成DelayedFetch。检查该DeplayedFetch是否满足，若满足则返回请求，否则将该请求加入Watch列表

　　Leader通过以FetchResponse的形式将消息返回给Follower，FetchResponse结构如下


>9,Topic Tool
	
	　$KAFKA_HOME/bin/kafka-topics.sh，该工具可用于创建、删除、修改、查看某个Topic，也可用于列出所有Topic。另外，该工具还可修改以下配置。

	unclean.leader.election.enable
	delete.retention.ms
	segment.jitter.ms
	retention.ms
	flush.ms
	segment.bytes
	flush.messages
	segment.ms
	retention.bytes
	cleanup.policy
	segment.index.bytes
	min.cleanable.dirty.ratio
	max.message.bytes
	file.delete.delay.ms
	min.insync.replicas
	index.interval.bytes




>10,Replica Verification Tool

	$KAFKA_HOME/bin/kafka-replica-verification.sh，该工具用来验证所指定的一个或多个Topic下每个Partition对应的所有Replica是否都同步。可通过topic-white-list这一参数指定所需要验证的所有Topic，支持正则表达式。 　　


>11,Preferred Replica Leader Election Tool

	用途
	　　有了Replication机制后，每个Partition可能有多个备份。某个Partition的Replica列表叫作AR（Assigned Replicas），AR中的第一个Replica即为“Preferred Replica”。创建一个新的Topic或者给已有Topic增加Partition时，Kafka保证Preferred Replica被均匀分布到集群中的所有Broker上。理想情况下，Preferred Replica会被选为Leader。以上两点保证了所有Partition的Leader被均匀分布到了集群当中，这一点非常重要，因为所有的读写操作都由Leader完成，若Leader分布过于集中，会造成集群负载不均衡。但是，随着集群的运行，该平衡可能会因为Broker的宕机而被打破，该工具就是用来帮助恢复Leader分配的平衡。
	　　事实上，每个Topic从失败中恢复过来后，它默认会被设置为Follower角色，除非某个Partition的Replica全部宕机，而当前Broker是该Partition的AR中第一个恢复回来的Replica。因此，某个Partition的Leader（Preferred Replica）宕机并恢复后，它很可能不再是该Partition的Leader，但仍然是Preferred Replica。
	　　
	原理
	
	    在Zookeeper上创建/admin/preferred_replica_election节点，并存入需要调整Preferred Replica的Partition信息。
	    Controller一直Watch该节点，一旦该节点被创建，Controller会收到通知，并获取该内容。
	    Controller读取Preferred Replica，如果发现该Replica当前并非是Leader并且它在该Partition的ISR中，Controller向该Replica发送LeaderAndIsrRequest，使该Replica成为Leader。如果该Replica当前并非是Leader，且不在ISR中，Controller为了保证没有数据丢失，并不会将其设置为Leader。 　
	
	用法
	　　$KAFKA_HOME/bin/kafka-preferred-replica-election.sh --zookeeper localhost:2181
	
	　　在包含8个Broker的Kafka集群上，创建1个名为topic1，replication-factor为3，Partition数为8的Topic，使用$KAFKA_HOME/bin/kafka-topics.sh --describe --topic topic1 --zookeeper localhost:2181命令查看其Partition/Replica分布。


>12,Kafka Reassign Partitions Tool

	用途
	　　该工具的设计目标与Preferred Replica Leader Election Tool有些类似，都旨在促进Kafka集群的负载均衡。不同的是，Preferred Replica Leader Election只能在Partition的AR范围内调整其Leader，使Leader分布均匀，而该工具还可以调整Partition的AR。
	　　Follower需要从Leader Fetch数据以保持与Leader同步，所以仅仅保持Leader分布的平衡对整个集群的负载均衡来说是不够的。另外，生产环境下，随着负载的增大，可能需要给Kafka集群扩容。向Kafka集群中增加Broker非常简单方便，但是对于已有的Topic，并不会自动将其Partition迁移到新加入的Broker上，此时可用该工具达到此目的。某些场景下，实际负载可能远小于最初预期负载，此时可用该工具将分布在整个集群上的Partition重装分配到某些机器上，然后可以停止不需要的Broker从而实现节约资源的目的。
	　　需要说明的是，该工具不仅可以调整Partition的AR位置，还可调整其AR数量，即改变该Topic的replication factor。
	　　
	原理
	　　该工具只负责将所需信息存入Zookeeper中相应节点，然后退出，不负责相关的具体操作，所有调整都由Controller完成。
	
	    在Zookeeper上创建/admin/reassign_partitions节点，并存入目标Partition列表及其对应的目标AR列表。
	    Controller注册在/admin/reassign_partitions上的Watch被fire，Controller获取该列表。
	    对列表中的所有Partition，Controller会做如下操作：
	
	    启动RAR - AR中的Replica，即新分配的Replica。（RAR = Reassigned Replicas， AR = Assigned Replicas）
	    等待新的Replica与Leader同步
	    如果Leader不在RAR中，从RAR中选出新的Leader
	    停止并删除AR - RAR中的Replica，即不再需要的Replica
	    删除/admin/reassign_partitions节点
	
	用法
	　　该工具有三种使用模式
	
	    generate模式，给定需要重新分配的Topic，自动生成reassign plan（并不执行）
	    execute模式，根据指定的reassign plan重新分配Partition
	    verify模式，验证重新分配Partition是否成功
	
	　　下面这个例子将使用该工具将Topic的所有Partition重新分配到Broker 4/5/6/7上，步骤如下：
	
	    使用generate模式，生成reassign plan。指定需要重新分配的Topic （{“topics”:[{“topic”:”topic1”}],”version”:1}），并存入/tmp/topics-to-move.json文件中，然后执行
	
	$KAFKA_HOME/bin/kafka-reassign-partitions.sh 
		--zookeeper localhost:2181 
		--topics-to-move-json-file /tmp/topics-to-move.json  
		--broker-list "4,5,6,7" --generate
	
	
	
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***  

#6,Kafka Consumer设计解析 

>1,High Level Consumer
	
	不关心消息offset的处理。同时也希望提供一些语义，例如同一条消息只被某一个Consumer消费（单播）或被所有Consumer消费（广播）。因此，Kafka Hight Level Consumer提供了一个从Kafka消费数据的高层抽象，从而屏蔽掉其中的细节并提供丰富的语义。 　　


>2,Consumer Group
	
	High Level Consumer将从某个Partition读取的最后一条消息的offset存于Zookeeper中(Kafka从0.8.2版本开始同时支持将offset存于Zookeeper中与将offset存于专用的Kafka Topic中)。这个offset基于客户程序提供给Kafka的名字来保存，这个名字被称为Consumer Group。Consumer Group是整个Kafka集群全局的，而非某个Topic的。每一个High Level Consumer实例都属于一个Consumer Group，若不指定则属于默认的Group。
	Zookeeper中Consumer相关节点如下图所示
　　
![](http://www.jasongj.com/img/kafka/KafkaColumn4/KafkaColumn4-consumers.png)

	


>3,Consumer Rebalance
	
	Kafka保证同一Consumer Group中只有一个Consumer会消费某条消息，实际上，Kafka保证的是稳定状态下每一个Consumer实例只会消费某一个或多个特定Partition的数据，而某个Partition的数据只会被某一个特定的Consumer实例所消费。也就是说Kafka对消息的分配是以Partition为单位分配的，而非以每一条消息作为分配单元。这样设计的劣势是无法保证同一个Consumer Group里的Consumer均匀消费数据，优势是每个Consumer不用都跟大量的Broker通信，减少通信开销，同时也降低了分配难度，实现也更简单。另外，因为同一个Partition里的数据是有序的，这种设计可以保证每个Partition里的数据可以被有序消费。
	如果某Consumer Group中Consumer（每个Consumer只创建1个MessageStream）数量少于Partition数量，则至少有一个Consumer会消费多个Partition的数据，如果Consumer的数量与Partition数量相同，则正好一个Consumer消费一个Partition的数据。而如果Consumer的数量多于Partition的数量时，会有部分Consumer无法消费该Topic下任何一条消息。
	
	　Consumer Rebalance的算法如下：

    将目标Topic下的所有Partirtion排序，存于PT

	对某Consumer Group下所有Consumer排序，存于CG
	，第i个Consumer记为Ci
	N=size(PT)/size(CG)，向上取整
	解除Ci
	对原来分配的Partition的消费权（i从0开始）
	将第i∗N到（i+1）∗N−1个Partition分配给Ci

	　　目前，最新版（0.8.2.1）Kafka的Consumer Rebalance的控制策略是由每一个Consumer通过在Zookeeper上注册Watch完成的。每个Consumer被创建时会触发Consumer Group的Rebalance，具体启动流程如下：

    High Level Consumer启动时将其ID注册到其Consumer Group下，在Zookeeper上的路径为/consumers/[consumer group]/ids/[consumer id]
    在/consumers/[consumer group]/ids上注册Watch
    在/brokers/ids上注册Watch
    如果Consumer通过Topic Filter创建消息流，则它会同时在/brokers/topics上也创建Watch
    强制自己在其Consumer Group内启动Rebalance流程

	在这种策略下，每一个Consumer或者Broker的增加或者减少都会触发Consumer Rebalance。因为每个Consumer只负责调整自己所消费的Partition，为了保证整个Consumer Group的一致性，当一个Consumer触发了Rebalance时，该Consumer Group内的其它所有其它Consumer也应该同时触发Rebalance。

	该方式有如下缺陷：

    Herd effect
    　　任何Broker或者Consumer的增减都会触发所有的Consumer的Rebalance
    Split Brain
    　　每个Consumer分别单独通过Zookeeper判断哪些Broker和Consumer 宕机了，那么不同Consumer在同一时刻从Zookeeper“看”到的View就可能不一样，这是由Zookeeper的特性决定的，这就会造成不正确的Reblance尝试。
    调整结果不可控
    　　所有的Consumer都并不知道其它Consumer的Rebalance是否成功，这可能会导致Kafka工作在一个不正确的状态。

	根据Kafka社区wiki，Kafka作者正在考虑在还未发布的0.9.x版本中使用中心协调器(Coordinator)。大体思想是为所有Consumer Group的子集选举出一个Broker作为Coordinator，由它Watch Zookeeper，从而判断是否有Partition或者Consumer的增减，然后生成Rebalance命令，并检查是否这些Rebalance在所有相关的Consumer中被执行成功，如果不成功则重试，若成功则认为此次Rebalance成功（这个过程跟Replication Controller非常类似）。具体方案将在后文中详细阐述。 　
	　

>4,Low Level Consumer
	
	使用Low Level Consumer (Simple Consumer)的主要原因是，用户希望比Consumer Group更好的控制数据的消费。比如：

    同一条消息读多次
    只读取某个Topic的部分Partition
    管理事务，从而确保每条消息被处理一次，且仅被处理一次

	与Consumer Group相比，Low Level Consumer要求用户做大量的额外工作。

    必须在应用程序中跟踪offset，从而确定下一条应该消费哪条消息
    应用程序需要通过程序获知每个Partition的Leader是谁
    必须处理Leader的变化

	使用Low Level Consumer的一般流程如下

    查找到一个“活着”的Broker，并且找出每个Partition的Leader
    找出每个Partition的Follower
    定义好请求，该请求应该能描述应用程序需要哪些数据
    Fetch数据
    识别Leader的变化，并对之作出必要的响应

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***  

#7,Kafka高性能架构

>1,partition提供并行处理的能力

	Topic包含多个Partition，Partition可位于不同机器，因此可以充分利用集群优势，实现机器间的并行处理。另一方面，由于Partition在物理上对应一个文件夹，即使多个Partition位于同一个节点，也可通过配置让同一节点上的不同Partition置于不同的disk drive上，从而实现磁盘间的并行处理，充分发挥多磁盘的优势。 

>2,ISR同步数据
	
	基于ISR方案。

>3,顺序写磁盘
	
	将写磁盘的过程变为顺序写，可极大提高对磁盘的利用率。
	
	Kafka的整个设计中，Partition相当于一个非常长的数组，而Broker接收到的所有消息顺序写入这个大数组中。同时Consumer通过Offset顺序消费这些数据，并且不删除已经消费的数据，从而避免了随机写磁盘的过程。

	由于磁盘有限，不可能保存所有数据，实际上作为消息系统Kafka也没必要保存所有数据，需要删除旧的数据。而这个删除过程，并非通过使用“读-写”模式去修改文件，而是将Partition分为多个Segment，每个Segment对应一个物理文件，通过删除整个文件的方式去删除Partition内的数据。这种方式清除旧数据的方式，也避免了对文件的随机写操作。
	


>4,临拷贝

	Kafka中存在大量的网络数据持久化到磁盘（Producer到Broker）和磁盘文件通过网络发送（Broker到Consumer）的过程。这一过程的性能直接影响Kafka的整体吞吐量。 
	
	传统模式下的四次拷贝与四次上下文切换

	以将磁盘文件通过网络发送为例。传统模式下，一般使用如下伪代码所示的方法先将文件数据读入内存，然后通过Socket将内存中的数据发送出去。

	buffer = File.read
	Socket.send(buffer)
	
	这一过程实际上发生了四次数据拷贝。首先通过系统调用将文件数据读入到内核态Buffer（DMA拷贝），然后应用程序将内存态Buffer数据读入到用户态Buffer（CPU拷贝），接着用户程序通过Socket发送数据时将用户态Buffer数据拷贝到内核态Buffer（CPU拷贝），最后通过DMA拷贝将数据拷贝到NIC Buffer。同时，还伴随着四次上下文切换，如下图所示。 
  
  sendfile和transferTo实现零拷贝

	Linux 2.4+内核通过sendfile系统调用，提供了零拷贝。数据通过DMA拷贝到内核态Buffer后，直接通过DMA拷贝到NIC Buffer，无需CPU拷贝。这也是零拷贝这一说法的来源。除了减少数据拷贝外，因为整个读文件-网络发送由一个sendfile调用完成，整个过程只有两次上下文切换，因此大大提高了性能。
	
可靠性保证
	1、AR

    在Kafka中维护了一个AR列表，包括所有的分区的副本。AR又分为ISR和OSR。

    AR = ISR + OSR。

    AR、ISR、OSR、LEO、HW这些信息都被保存在Zookeeper中。
	
	ISR
    ISR中的副本都要同步leader中的数据，只有都同步完成了数据才认为是成功提交了，成功提交之后才能供外界访问。

    在这个同步的过程中，数据即使已经写入也不能被外界访问，这个过程是通过LEO-HW机制来实现的。
	2．OSR

    OSR内的副本是否同步了leader的数据，不影响数据的提交，OSR内的follower尽力的去同步leader，可能数据版本会落后。

    最开始所有的副本都在ISR中，在kafka工作的过程中，如果某个副本同步速度慢于replica.lag.time.max.ms指定的阈值，则被踢出ISR存入OSR，如果后续速度恢复可以回到ISR中。
	3．LEO

    LogEndOffset：分区的最新的数据的offset，当数据写入leader后，LEO就立即执行该最新数据。相当于最新数据标识位。
	4．HW

    HighWatermark：只有写入的数据被同步到所有的ISR中的副本后，数据才认为已提交，HW更新到该位置，HW之前的数据才可以被消费者访问，保证没有同步完成的数据不会被消费者访问到。相当于所有副本同步数据标识位。

    在leader宕机后，只能从ISR列表中选取新的leader，无论ISR中哪个副本被选为新的leader，它都知道HW之前的数据，可以保证在切换了leader后，消费者可以继续看到HW之前已经提交的数据。

    所以LEO代表已经写入的最新数据位置，而HW表示已经同步完成的数据，只有HW之前的数据才能被外界访问。
	5．HW截断机制

    如果leader宕机，选出了新的leader，而新的leader并不能保证已经完全同步了之前leader的所有数据，只能保证HW之前的数据是同步过的，此时所有的follower都要将数据截断到HW的位置，再和新的leader同步数据，来保证数据一致。

    当宕机的leader恢复，发现新的leader中的数据和自己持有的数据不一致，此时宕机的leader会将自己的数据截断到宕机之前的hw位置，然后同步新leader的数据。宕机的leader活过来也像follower一样同步数据，来保证数据的一致性。

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 	
	
#8,Exactly Once语义与事务机制原理 


>1,Kafka事务机制的实现主要是为了支持

    Exactly Once即正好一次语义
    操作的原子性 
    有状态操作的可恢复性

>2,实现事务机制的几个阶段
	
	(1),幂等性发送	--通过引入pid和segquence number增加1来解决，当segquence 大于1以上说明有数据未写入，拒绝写入数据，小于等于borker维护的序号说明消息被保存了 为重复消息
	为了实现Producer的幂等语义，Kafka引入了Producer ID（即PID）和Sequence Number。每个新的Producer在初始化的时候会被分配一个唯一的PID，该PID对用户完全透明而不会暴露给用户。
	对于每个PID，该Producer发送数据的每个<Topic, Partition>都对应一个从0开始单调递增的Sequence Number。
	类似地，Broker端也会为每个<PID, Topic, Partition>维护一个序号，并且每次Commit一条消息时将其对应序号递增。对于接收的每条消息，如果其序号比Broker维护的序号（即最后一次Commit的消息的序号）大一，则Broker会接受它，否则将其丢弃：
    如果消息序号比Broker维护的序号大一以上，说明中间有数据尚未写入，也即乱序，此时Broker拒绝该消息，Producer抛出InvalidSequenceNumber
    如果消息序号小于等于Broker维护的序号，说明该消息已被保存，即为重复消息，Broker直接丢弃该消息，Producer抛出DuplicateSequenceNumber


>3,事务性保证
	
		上述幂等设计只能保证单个Producer对于同一个<Topic, Partition>的Exactly Once语义。不能保证多个操作的恢复。事务需要保证全部失败或者全部成功，有状态的应用也可以保证重启后从断点处继续处理-事务恢复。kafka为了实现引入了txid来解决，类型mongodb和mysql的txid多版本
		
		为了实现这种效果，应用程序必须提供一个稳定的（重启后不变）唯一的ID，也即Transaction ID。Transactin ID与PID可能一一对应。区别在于Transaction ID由用户提供，而PID是内部的实现对用户透明。

	另外，为了保证新的Producer启动后，旧的具有相同Transaction ID的Producer即失效，每次Producer通过Transaction ID拿到PID的同时，还会获取一个单调递增的epoch。由于旧的Producer的epoch比新Producer的epoch小，Kafka可以很容易识别出该Producer是老的Producer并拒绝其请求。

	有了Transaction ID后，Kafka可保证：

    跨Session的数据幂等发送。当具有相同Transaction ID的新的Producer实例被创建且工作时，旧的且拥有相同Transaction ID的Producer将不再工作。
    跨Session的事务恢复。如果某个应用实例宕机，新的实例可以保证任何未完成的旧的事务要么Commit要么Abort，使得新实例从一个正常状态开始工作。

	需要注意的是，上述的事务保证是从Producer的角度去考虑的。从Consumer的角度来看，该保证会相对弱一些。尤其是不能保证所有被某事务Commit过的所有消息都被一起消费，因为：

    对于压缩的Topic而言，同一事务的某些消息可能被其它版本覆盖
    事务包含的消息可能分布在多个Segment中（即使在同一个Partition内），当老的Segment被删除时，该事务的部分数据可能会丢失
    Consumer在一个事务内可能通过seek方法访问任意Offset的消息，从而可能丢失部分消息
    Consumer可能并不需要消费某一事务内的所有Partition，因此它将永远不会读取组成该事务的所有消息

>4,事务机制原理
>>4.1,事务性消息传递
	
	这一节所说的事务主要指原子性，也即Producer将多条消息作为一个事务批量发送，要么全部成功要么全部失败。

	为了实现这一点，Kafka 0.11.0.0引入了一个服务器端的模块，名为Transaction Coordinator，用于管理Producer发送的消息的事务性。

	该Transaction Coordinator维护Transaction Log，该log存于一个内部的Topic内。由于Topic数据具有持久性，因此事务的状态也具有持久性。

	Producer并不直接读写Transaction Log，它与Transaction Coordinator通信，然后由Transaction Coordinator将该事务的状态插入相应的Transaction Log。

	Transaction Log的设计与Offset Log用于保存Consumer的Offset类似。
	
	
>>4.2,事务中offset的提交	
	
	许多基于Kafka的应用，尤其是Kafka Stream应用中同时包含Consumer和Producer，前者负责从Kafka中获取消息，后者负责将处理完的数据写回Kafka的其它Topic中。

	为了实现该场景下的事务的原子性，Kafka需要保证对Consumer Offset的Commit与Producer对发送消息的Commit包含在同一个事务中。否则，如果在二者Commit中间发生异常，根据二者Commit的顺序可能会造成数据丢失和数据重复：

    如果先Commit Producer发送数据的事务再Commit Consumer的Offset，即At Least Once语义，可能造成数据重复。
    如果先Commit Consumer的Offset，再Commit Producer数据发送事务，即At Most Once语义，可能造成数据丢失。

	
	
>>4.3,用于事务特性的控制型消息	
		
		为了区分写入Partition的消息被Commit还是Abort，Kafka引入了一种特殊类型的消息，即Control Message。该类消息的Value内不包含任何应用相关的数据，并且不会暴露给应用程序。它只用于Broker与Client间的内部通信。

	对于Producer端事务，Kafka以Control Message的形式引入一系列的Transaction Marker。Consumer即可通过该标记判定对应的消息被Commit了还是Abort了，然后结合该Consumer配置的隔离级别决定是否应该将该消息返回给应用程序。
	

>5,事务完整过程
	
![事务完整过程](http://www.jasongj.com/img/kafka/KafkaColumn8/KafkaTransaction.png)
	
>5.1,找到Transaction Coordinator

由于Transaction Coordinator是分配PID和管理事务的核心，因此Producer要做的第一件事情就是通过向任意一个Broker发送FindCoordinator请求找到Transaction Coordinator的位置。

注意：只有应用程序为Producer配置了Transaction ID时才可使用事务特性，也才需要这一步。另外，由于事务性要求Producer开启幂等特性，因此通过将transactional.id设置为非空从而开启事务特性的同时也需要通过将enable.idempotence设置为true来开启幂等特性。
	
	
>5.2,获取PID

找到Transaction Coordinator后，具有幂等特性的Producer必须发起InitPidRequest请求以获取PID。

注意：只要开启了幂等特性即必须执行该操作，而无须考虑该Producer是否开启了事务特性。

如果事务特性被开启
InitPidRequest会发送给Transaction Coordinator。如果Transaction Coordinator是第一次收到包含有该Transaction ID的InitPidRequest请求，它将会把该<TransactionID, PID>存入Transaction Log，如上图中步骤2.1所示。这样可保证该对应关系被持久化，从而保证即使Transaction Coordinator宕机该对应关系也不会丢失。

除了返回PID外，InitPidRequest还会执行如下任务：

    增加该PID对应的epoch。具有相同PID但epoch小于该epoch的其它Producer（如果有）新开启的事务将被拒绝。
    恢复（Commit或Abort）之前的Producer未完成的事务（如果有）。

注意：InitPidRequest的处理过程是同步阻塞的。一旦该调用正确返回，Producer即可开始新的事务。

另外，如果事务特性未开启，InitPidRequest可发送至任意Broker，并且会得到一个全新的唯一的PID。该Producer将只能使用幂等特性以及单一Session内的事务特性，而不能使用跨Session的事务特性。

>5.3,开启事务

Kafka从0.11.0.0版本开始，提供beginTransaction()方法用于开启一个事务。调用该方法后，Producer本地会记录已经开启了事务，但Transaction Coordinator只有在Producer发送第一条消息后才认为事务已经开启。
	
	
		
>6,Consume-Transform-Produce 事务的多阶段请求,需要保证全部成功或者全部失败
	
AddPartitionsToTxnRequest
一个Producer可能会给多个<Topic, Partition>发送数据，给一个新的<Topic, Partition>发送数据前，它需要先向Transaction Coordinator发送AddPartitionsToTxnRequest。

Transaction Coordinator会将该<Transaction, Topic, Partition>存于Transaction Log内，并将其状态置为BEGIN，如上图中步骤4.1所示。有了该信息后，我们才可以在后续步骤中为每个Topic, Partition>设置COMMIT或者ABORT标记（如上图中步骤5.2所示）。

另外，如果该<Topic, Partition>为该事务中第一个<Topic, Partition>，Transaction Coordinator还会启动对该事务的计时（每个事务都有自己的超时时间）。

ProduceRequest
Producer通过一个或多个ProduceRequest发送一系列消息。除了应用数据外，该请求还包含了PID，epoch，和Sequence Number。该过程如上图中步骤4.2所示。

AddOffsetsToTxnRequest
为了提供事务性，Producer新增了sendOffsetsToTransaction方法，该方法将多组消息的发送和消费放入同一批处理内。

该方法先判断在当前事务中该方法是否已经被调用并传入了相同的Group ID。若是，直接跳到下一步；若不是，则向Transaction Coordinator发送AddOffsetsToTxnRequests请求，Transaction Coordinator将对应的所有<Topic, Partition>存于Transaction Log中，并将其状态记为BEGIN，如上图中步骤4.3所示。该方法会阻塞直到收到响应。

TxnOffsetCommitRequest
作为sendOffsetsToTransaction方法的一部分，在处理完AddOffsetsToTxnRequest后，Producer也会发送TxnOffsetCommit请求给Consumer Coordinator从而将本事务包含的与读操作相关的各<Topic, Partition>的Offset持久化到内部的__consumer_offsets中，如上图步骤4.4所示。

在此过程中，Consumer Coordinator会通过PID和对应的epoch来验证是否应该允许该Producer的该请求。

这里需要注意：

    写入__consumer_offsets的Offset信息在当前事务Commit前对外是不可见的。也即在当前事务被Commit前，可认为该Offset尚未Commit，也即对应的消息尚未被完成处理。
    Consumer Coordinator并不会立即更新缓存中相应<Topic, Partition>的Offset，因为此时这些更新操作尚未被COMMIT或ABORT。


	
>7,事务commit或者abort

一旦上述数据写入操作完成，应用程序必须调用KafkaProducer的commitTransaction方法或者abortTransaction方法以结束当前事务。

EndTxnRequest
commitTransaction方法使得Producer写入的数据对下游Consumer可见。abortTransaction方法通过Transaction Marker将Producer写入的数据标记为Aborted状态。下游的Consumer如果将isolation.level设置为READ_COMMITTED，则它读到被Abort的消息后直接将其丢弃而不会返回给客户程序，也即被Abort的消息对应用程序不可见。

无论是Commit还是Abort，Producer都会发送EndTxnRequest请求给Transaction Coordinator，并通过标志位标识是应该Commit还是Abort。

收到该请求后，Transaction Coordinator会进行如下操作

    将PREPARE_COMMIT或PREPARE_ABORT消息写入Transaction Log，如上图中步骤5.1所示
    通过WriteTxnMarker请求以Transaction Marker的形式将COMMIT或ABORT信息写入用户数据日志以及Offset Log中，如上图中步骤5.2所示
    最后将COMPLETE_COMMIT或COMPLETE_ABORT信息写入Transaction Log中，如上图中步骤5.3所示

补充说明：对于commitTransaction方法，它会在发送EndTxnRequest之前先调用flush方法以确保所有发送出去的数据都得到相应的ACK。对于abortTransaction方法，在发送EndTxnRequest之前直接将当前Buffer中的事务性消息（如果有）全部丢弃，但必须等待所有被发送但尚未收到ACK的消息发送完成。

上述第二步是实现将一组读操作与写操作作为一个事务处理的关键。因为Producer写入的数据Topic以及记录Comsumer Offset的Topic会被写入相同的Transactin Marker，所以这一组读操作与写操作要么全部COMMIT要么全部ABORT。

WriteTxnMarkerRequest
上面提到的WriteTxnMarkerRequest由Transaction Coordinator发送给当前事务涉及到的每个<Topic, Partition>的Leader。收到该请求后，对应的Leader会将对应的COMMIT(PID)或者ABORT(PID)控制信息写入日志，如上图中步骤5.2所示。

该控制消息向Broker以及Consumer表明对应PID的消息被Commit了还是被Abort了。

这里要注意，如果事务也涉及到__consumer_offsets，即该事务中有消费数据的操作且将该消费的Offset存于__consumer_offsets中，Transaction Coordinator也需要向该内部Topic的各Partition的Leader发送WriteTxnMarkerRequest从而写入COMMIT(PID)或COMMIT(PID)控制信息。

写入最终的COMPLETE_COMMIT或COMPLETE_ABORT消息
写完所有的Transaction Marker后，Transaction Coordinator会将最终的COMPLETE_COMMIT或COMPLETE_ABORT消息写入Transaction Log中以标明该事务结束，如上图中步骤5.3所示。

此时，Transaction Log中所有关于该事务的消息全部可以移除。当然，由于Kafka内数据是Append Only的，不可直接更新和删除，这里说的移除只是将其标记为null从而在Log Compact时不再保留。

另外，COMPLETE_COMMIT或COMPLETE_ABORT的写入并不需要得到所有Rreplica的ACK，因为如果该消息丢失，可以根据事务协议重发。

补充说明，如果参与该事务的某些<Topic, Partition>在被写入Transaction Marker前不可用，它对READ_COMMITTED的Consumer不可见，但不影响其它可用<Topic, Partition>的COMMIT或ABORT。在该<Topic, Partition>恢复可用后，Transaction Coordinator会重新根据PREPARE_COMMIT或PREPARE_ABORT向该<Topic, Partition>发送Transaction Marker。


	
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 


#9,要确定Kafka的消息是否丢失或重复，从两个方面分析入手：消息发送和消息消费

>1、消息发送

         Kafka消息发送有两种方式：同步（sync）和异步（async），默认是同步方式，可通过producer.type属性进行配置。Kafka通过配置request.required.acks属性来确认消息的生产：

    0---表示不进行消息接收是否成功的确认；

    1---表示当Leader接收成功时确认；

    -1---表示Leader和Follower都接收成功时确认；

综上所述，有6种消息生产的情况，下面分情况来分析消息丢失的场景：

    （1）acks=0，不和Kafka集群进行消息接收确认，则当网络异常、缓冲区满了等情况时，消息可能丢失；

    （2）acks=1、同步模式下，只有Leader确认接收成功后但挂掉了，副本没有同步，数据可能丢失；

>2、消息消费

        Kafka消息消费有两个consumer接口，Low-level API和High-level API：

    Low-level API：消费者自己维护offset等值，可以实现对Kafka的完全控制；

    High-level API：封装了对parition和offset的管理，使用简单；

	如果使用高级接口High-level API，可能存在一个问题就是当消息消费者从集群中把消息取出来、并提交了新的消息offset值后，还没来得及消费就挂掉了，那么下次再消费时之前没消费成功的消息就“诡异”的消失了；    

解决办法：

      针对消息丢失：同步模式下，确认机制设置为-1，即让消息写入Leader和Follower之后再确认消息发送成功；异步模式下，为防止缓冲区满，可以在配置文件设置不限制阻塞超时时间，当缓冲区满时让生产者一直处于阻塞状态；

      针对消息重复：将消息的唯一标识保存到外部介质中，每次消费时判断是否处理过即可。

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 

#10,延迟,重试,死信队列实现

>1,延迟队列 
 
 （1），时间轮算法实现

	简单说说时间轮吧，它是一个高效的延时队列，或者说定时器。实际上现在网上对于时间轮算法的解释很多，定义也很全，这里引用一下朱小厮博客里出现的定义：
	
	参考下图，Kafka中的时间轮（TimingWheel）是一个存储定时任务的环形队列，底层采用数组实现，数组中的每个元素可以存放一个定时任务列表（TimerTaskList）。TimerTaskList是一个环形的双向链表，链表中的每一项表示的都是定时任务项（TimerTaskEntry），其中封装了真正的定时任务TimerTask。

![](https://oscimg.oschina.net/oscnet/05ffd5fc66084180a8ab65e276be9dcac8a.jpg)
	
	如果你理解了上面的定义，那么就不必往下看了。但如果你第一次看到和我一样懵比，并且有不少疑问，那么这篇博文将带你进一步了解时间轮，甚至理解时间轮算法。

	时间轮定时器最大的优点：
        是任务的添加与移除，都是O(1)级的复杂度；
        不会占用大量的资源；
        只需要有一个线程去推进时间轮就可以工作了。

	(2),DelayQueue实现
	
	无界、延迟、阻塞队列
	a、BlockingQueue+PriorityQueue（堆排序）+Delayed
	b、DelayQueue中存放的对象需要实现compareTo()方法和getDelay()方法。
	c、getDelay方法返回该元素距离失效还剩余的时间，当<=0时元素就失效了，
	就可以从队列中获取到。
				
![](https://user-gold-cdn.xitu.io/2018/7/30/164e87af387ae062?imageView2/0/w/1280/h/960/ignore-error/1)
				
				

>2,死信队列 -- 指连接器的数据
	
	





		
		http://www.jasongj.com/2015/06/08/KafkaColumn3/
		//kafka系列详解
		https://blog.csdn.net/u013256816/column/info/14800
		
