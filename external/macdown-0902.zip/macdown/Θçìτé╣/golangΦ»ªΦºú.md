
https://rainbowmango.gitbook.io/go/chapter01/1.6-string
http://legendtkl.com/page/5/
https://www.jianshu.com/u/8168fa45c4ca

#1,slice和array

（1）,slice切片,可变的数组
		
	(1-1),创建语法：
		
			func make([]T, len, cap) []T  make函数采用类型，长度和可选容量

		
	(1-2),长度和容量之间的关系
		
			b := []byte{'g', 'o', 'l', 'a', 'n', 'g'}
			// b[1:4] == []byte{'o', 'l', 'a'}, sharing the same storage as b
			// b[:2] == []byte{'g', 'o'} //获取数据的第一位和第二位，修改为新的值
			// b[2:] == []byte{'l', 'a', 'n', 'g'} //
			// b[:] == b //数组b赋值
		
	(1-3),Slice共享和结构剖析类似redis的SDS类型
		
	 切片是数组段的描述符。 它由指向数组的指针，段的长度及其容量（段的最大长度）组成。
			
![slice内部构造图一](https://upload-images.jianshu.io/upload_images/7179784-8cb4e76996a1482f.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/517)			
		
	我们之前由 make([] byte, 5) 创建的变量s的结构如下：
	
![slice内部构造图二](https://upload-images.jianshu.io/upload_images/7179784-8cf9c39bcec5a272.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/517)	

	长度是切片引用的元素数。 容量是底层数组中元素的数量（从切片指针引用的元素开始）。 我们将通过接下来的几个例子来说明长度和容量之间的区别。
	在切片时，观察切片数据结构中的变化及其与底层数组的关系： 
![slice内部构造图三](https://upload-images.jianshu.io/upload_images/7179784-42e4070017fea073.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/517)		
	
	切片不会复制切片的数据。 它创建一个指向原始数组的新切片值。 这使切片操作与操作数组索引一样高效。 因此，修改重新切片的元素（而不是切片本身）会修改原始切片的元素：
		
		d := []byte{'r', 'o', 'a', 'd'}
		e := d[2:] 
		// e == []byte{'a', 'd'}
		e[1] = 'm'
		// e == []byte{'a', 'm'}
		// d == []byte{'r', 'o', 'a', 'm'}
		
		
	切片不能超出其容量。 尝试这样做会导致运行时出现混乱，就像在切片或数组的边界之外进行索引一样。 类似地，切片不能在零以下重新切片以访问数组中的早期元素。
	
	
		
	(1-4),slice的复制和追加
		
	要增加切片的容量，必须创建一个新的更大的切片并将原始切片的内容复制到切片中。 这种技术是其他语言的动态数组实现在幕后工作的方式。 下一个例子通过创建一个新的切片t，将s的内容复制到t，然后将切片值t分配给s，使s的容量加倍：
	
	t := make([]byte, len(s), (cap(s)+1)*2) // +1 in case cap(s) == 0
		for i := range s {
		        t[i] = s[i]
	}
	s = t
		
	
	通过内置复制功能，可以更轻松地完成此常用操作的循环操作。 顾名思义，复制将数据从源切片复制到目标切片。 它返回复制的元素数。
	
	func copy(dst, src []T) int
	
	复制功能支持在不同长度的切片之间进行复制（它将仅复制到较少数量的元素）。 此外，copy可以处理共享相同底层数组的源和目标片，正确处理重叠片。
	使用copy，我们可以简化上面的代码片段：	
		
	
	(1-5),slice的扩容规则
	
	 如果切片的容量小于1024个元素，那么扩容的时候slice的cap就翻番，乘以2；一旦元素个数超过1024个元素，增长因子就变成1.25，即每次增加原来容量的四分之一。如果扩容之后，还没有触及原数组的容量，那么，切片中的指针指向的位置，就还是原数组，如果扩容之后，超过了原数组的容量，那么，Go就会开辟一块新的内存，把原来的值拷贝过来，这种情况丝毫不会影响到原数组。
	
				
（2）,array数组
		
		数组类型的数据结构
		不可变
	

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 

#二,struct详解

	结构体是值类型，因此可以通过 new 函数来创建。
	
	指针对象和对象的区别:
	  指针对象:可以调用和修改指针对象属性
	  对象 :可以调用属性
		

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 

#三,Interface详解

>1,Go汇编分析运行原理
	
	package main
	
	import "fmt"
	
	func main() {
		c := China{"china-shanghai"}
		fmt.Println(c.Get())
	}
	
	//定义实体类
	type China struct {
		name string
	}
	
	//实体类实现接口
	func (c *China) Get() string {
		return c.name
	}
	
	//定义接口
	type Person interface {
		Get() string
	}
	//编译
	go build -gcflags '-l -N' main.go
	//运行
	go tool objdump -s "main.main" mian


>2,实现方式
	
	interface也是一个Go语言中的一种类型，是一种比较特殊的类型，存在两种interface，一种是带有方法的interface，一种是不带方法的interface
	
	// 没有方法的interface
	type eface struct {
	    _type *_type
	    data  unsafe.Pointer
	}
	
	// 记录着Go语言中某个数据类型的基本特征
	type _type struct {
	    size       uintptr
	    ptrdata    uintptr
	    hash       uint32
	    tflag      tflag
	    align      uint8
	    fieldalign uint8
	    kind       uint8
	    alg        *typeAlg
	    gcdata    *byte
	    str       nameOff
	    ptrToThis typeOff
	}
	
	// 有方法的interface
	type iface struct {
	    tab  *itab
	    data unsafe.Pointer
	}
	
	type itab struct {
	    inter  *interfacetype
	    _type  *_type
	    link   *itab
	    hash   uint32
	    bad    bool
	    inhash bool
	    unused [2]byte
	    fun    [1]uintptr
	}
	
	// interface数据类型对应的type
	type interfacetype struct {
	    typ     _type
	    pkgpath name
	    mhdr    []imethod
	}
	
	可以看到两种类型的interface在内部实现时都是定义成了一个2个字段的结构体，所以任何一个interface变量都是占用16个byte的内存空间。
	iface->itab->interfacetype->类似包含eface
	
	在Go语言中_type这个结构体非常重要，记录着某种数据类型的一些基本特征，比如这个数据类型占用的内存大小（size字段），数据类型的名称（nameOff字段）
![](https://upload-images.jianshu.io/upload_images/14384850-28a84cbe839999c6.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/744)
		
		
>3,interface的赋值
	
 （1）,没有方法的interface变量赋值
 
 		
   package main

  type Struct1 struct {
	      A int64
	      B int64
	  }
func main() {
	     s := new(Struct1)
	      var i interface{}
	      i = s

	      _ = i
}

go build -gcflags “-N -l”
    	
    	
![没有方法的interface变量赋值](https://upload-images.jianshu.io/upload_images/14384850-a7e319b9bc0ed59f.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/691) 		
 		
 				
 
  (2）,有方法的interface变量赋值
  
![有方法的interface变量赋值](https://upload-images.jianshu.io/upload_images/14384850-cdb07f6548b760ce.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1000)
  	
  	   方法的调用
 ![iface方法的调用](https://upload-images.jianshu.io/upload_images/14384850-7c9a5057df722c1c.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/766)
  
  
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 
  
#四,Reflect 反射详解
	
>1, 反射获取变量的信息
	
	  1  type Value struct {
     2      typ *rtype
     3      ptr unsafe.Pointer
     4      flag
     5  }
     6
     7  func ValueOf(i interface{}) Value {
     8  }
     9
    10  type Type interface {
    11      Align() int
    12      FieldAlign() int
    13      Method(int) Method
    14      Name() string
    15      //一堆方法
    16      //....
    17  }
    18
    19  func TypeOf(i interface{}) Type {
    20      eface := *(*emptyInterface)(unsafe.Pointer(&i))
    21      return toType(eface.typ)
    22  }
    23
    24  type emptyInterface struct {
    25      typ  *rtype
    26      word unsafe.Pointer
    27  }
    	
    	
    任何一个变量可以通过调用ValueOf来获取到变量的Value结构体，通过TypeOf方法来获取变量的Type接口类型。通过TypeOf方法获取到的Type接口实际上就是该变量对应的_type。
    通过前面的分析，当通过TypeOf方法获取到变量的_type结构体后，很容易获取到该变量的一些基本信息，比如_type结构体中的各种字段都可以直接获取到。
	
	_type的结构体
    size  uintptr  大小
	ptrdata uintptr //可以包含指针的类型中的字节数
	hash uint32 //类型的哈希; 避免在哈希表中计算
	tflag tflag //额外类型信息标志
	align uint8 //使用此类型对齐变量
	fieldAlign uint8 //使用此类型对齐struct字段
	kind uint8 // C的枚举
	alg * typeAlg //算法表
	gcdata * byte //垃圾收集数据
	str nameOff //字符串形式
	ptrToThis typeOff //指向此类型的指针的类型可能为零
	
	
	
	
>2,	reflect修改变量的值
	
	  1  package main
     2
     3  import (
     4      "reflect"
     5  )
     6
     7  func main() {
     8      var x int64 = 10
     9
    10      reflect.ValueOf(x).SetInt(20)
    11
    12      reflect.ValueOf(&x).SetInt(20)
    13
    14      reflect.ValueOf(&x).Elem().SetInt(20)
    15  }
	
	上面的例子中，第10行，12行都会报panic，只有第14行能修改变量的值。在使用ValueOf获取到Value结构体以后，flag字段记录着值能否进行修改，这样应该是为了避免误操作，保证api调用者明确了解到是否需要修改值。
	
	
>3,反射修改结构体变量字段的值	
	
	如果需要通过反射修改某结构体里面各个字段的值。
	
  	 1  package main
     2
     3  import (
     4      "reflect"
     5      "fmt"
     6  )
     7
     8  type Struct1 struct {
     9      A int64
    10      B int64
    11      C int64
    12  }
    13
    14  func main() {
    15      P := new(Struct1)
    16
    17      V := reflect.ValueOf(P).Elem()  //value修改的时候一定要先使用Elem()方法
    18      V.FieldByName("A").SetInt(100)
    19      V.FieldByName("B").SetInt(200)
    20      V.FieldByName("C").SetInt(300)
    21
    22      fmt.Printf("%v", P)
    23  }

	
	上面的代码中，需要根据结构体字段的名称对各个字段的值进行修改，内部是如何实现的呢？
	
![](https://upload-images.jianshu.io/upload_images/14384850-a6f116e1af5efa58.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/955)

	每一个自定义的struct类型都存在这一个对应的structType结构体，该结构体记录了每个字段structField。通过对比structField里面的name字段，就可以获取到某个字段的type和偏移量。从而对具体的值进行修改。



>4,反射动态调用方法
	
	  1  package main
     2
     3  import (
     4      "reflect"
     5  )
     6
     7  type Struct1 struct {
     8      A int64
     9      B int64
    10      C int64
    11  }
    12
    13  func (p *Struct1) Set() {
    14      p.A = 200
    15  }
    16
    17  func main() {
    18      P := new(Struct1)
    19      P.A = 100
    20      P.B = 200
    21      P.C = 300
    22
    23      V := reflect.ValueOf(P)
    24
    25      params := make([]reflect.Value, 0)
    26      V.MethodByName("Set").Call(params) 
    27  }
    
结构体的方法在内存中存在如下的分布
![](https://upload-images.jianshu.io/upload_images/14384850-57fd596e170eb53f.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1000)

	在编译过程中，结构体对应方法的相关信息都已经存在于内存中，分配了一块uncommonType的结构体跟在fields字段后面。根据内存的分布，如果需要根据一个结构体的名称获取到方法并且执行，只需要根据uncommonType结构中的moff字段去获取方法相关信息的地址块，然后逐个对比名称是否为想要获取的方法进行调用。

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 	
	
#五,panic defer recover 深入理解

>1,panic异常终止程序
	
 (1),painc分析 
 
	关键字panic的作用是制造一次宕机，宕机就代表程序运行终止，但是已经“生效”的延迟函数仍会执行（即已经压入栈的defer延迟函数，panic之前的）。
	
	panic("退出程序 。。。")
	
	func main() {
    defer func() {
        defer func() {
            fmt.Println("6:", recover())
        }()
    }()
    defer func() {
        func() {
            fmt.Println("5:", recover())
        }()
    }()
    func() {
        defer func() {
            fmt.Println("1:", recover())
        }()
    }()
    func() {
        defer fmt.Println("2:", recover())
    }()
    func() {
        fmt.Println("3:", recover())
    }()

    fmt.Println("4:", recover())
    panic(1)
    defer func() {
        fmt.Println("0:", recover()) // never go here
    }()
	}
	
	运行结果：
		1: <nil>
		panic: 1
		2: <nil>
		
		3: <nil>
		goroutine 1 [running]:
		4: <nil>
		main.main()
		5: <nil>
		6: <nil>
		
	Go规范： 如果满足以下任一条件，recover的返回值为nil：

    1.panic参数是nil
    2.当前goroutine没有产生panic
    3.recover不是由延迟函数直接调用。
	
	让我们忽略第一个条件。 第二个条件覆盖第一/第二/第三和第四recover调用。 第三个覆盖第5个recover调用。 然而，三个条件中没有一个覆盖第六个recover调用。 怎样才能让recover调用起作用?如下 ：

	import("fmt")
	func main(){
	    defer func(){
	    fmt.Println(recover())// 1
	    }()
	    panic(1)
	}
	
	
	现在，panic值被recover调用捕获，并且程序不会崩溃。 那么，使recover调用生效的主要规则是什么？ 首先，让我们学习一些概念和说明。
	
 （2）,概念：延迟函数调用概念：延迟函数调用
 		
 		golang中一般使用defer关键词作为前缀，则调用被称为延迟调用
 		
	
 （3）,函数调用级别和Goroutine执行级别
 		
 		函数调用级别是指函数调用的深度，与主函数或者goroutine的入口函数相关。
 		
 		package main

			funcmain(){
			// level 0  
			    go func(){
			    // level 0
			        func(){
			        // level 1
			        }()
			        func(){
			        // level 1          
			            func(){
			            // level 2
			            }()
			        }()
			    }()
			    func(){
			    // level 1
			        func(){
			        // level 2
			            go func(){
			            // level 0
			            }()
			        }()
			        go func(){
			        // level 0
			        }()
			    }()
			}
  	
  	goroutine当前执行点的调用级别称为goroutine的执行级别。
  	
	
    注意panix只能向上传播	
    		
    	是的，panic只能向上传播，沿着函数调用堆栈反向。panic从不通过深入到函数调用中传播。
    	
>2,panic和recover 
		
    package main

	import"fmt"
	func main(){// calling level 0
	    defer func(){// calling level 1
	        fmt.Println("Now, the panic is still in calling level 0")
	        func(){// calling level 2
	            fmt.Println("Now, the panic is still in calling level 0")
	            func(){// calling level 3
	                fmt.Println("Now, the panic is still in calling level 0")
	            }()
	        }()
	    }()
	    defer fmt.Println("Now, the panic is in calling level 0")
	    func(){
	        // calling level 1
	        defer fmt.Println("Now, the panic is in calling level 1")
	        func(){// calling level 2
	            defer fmt.Println("Now, the panic is in calling level 2")
	            func(){// calling level 3
	                defer fmt.Println("Now, the panic is in calling level 3")
	                panic(1)
	            }()
	        }()
	    }()
	}  	
	
	运行结果：
	The output: Now, the panic is in calling level 3
	Now, the panic is in calling level 2
	
	Now, the panic is in calling level 1
	
	Now, the panic is in calling level 0
	
	Now, the panic is still in calling level 0
	
	Now, the panic is still in calling level 0
	
	Now, the panic is still in calling level 0
	
	panic: 1
	
	goroutine 1 [running]:
	
	...
    	
	
>3,panic级别
	
	panic级别意味着panic传播到函数调用的哪一层级、因为panic只能向上传递、所以panic等级永远不加增加、只会减小、在goroutine中，当前panic的水平永远不会大于goroutine的执行水平。
	
	说明：在同一层级上、新的panics会压制原有panics
	
	package main

	import"fmt"
	func main(){
	    defer fmt.Println("program will not crash")
	    defer func(){
	        fmt.Println(recover())// 3
	    }()
	    defer fmt.Println("now, panic 3 suppresses panic 2")
	    defer panic(3)
	    defer fmt.Println("now, panic 2 suppresses panic 1")
	    defer panic(2)
	    panic(1)
	}
	运行结果：
	now, panic 2 suppresses panic 1
	now, panic 3 suppresses panic 2
	3
	program will not crash
	
	在以上程序中、我们最终只能看到一个panic 3、panic 3被recover捕获、因此程序不会崩溃 在一个goroutine中，在任何时候在相同的调用级别将有至多一个主动panic。 特别是，当执行点运行在goroutine的调用级别0时，在goroutine中最多只有一个活动的panic。


>4,多个panic在一个Goroutine内存中
	
	
	import"fmt"
	func main(){// callnig level 0
	    defer fmt.Println("program will crash, for panic 3 is stll active")
	    defer func(){// calling level 1
	        defer func(){// calling level 2
	            fmt.Println(recover())// 6
	        }()// the level of panic 3 is 0.// the level of panic 6 is 1.
	        defer fmt.Println("now, there are two active panics: 3 and 6")
	        defer panic(6)// will suppress panic 5
	        defer panic(5)// will suppress panic 4
	        panic(4)// will not suppress panic 3, for they have differrent levels 
	        // the  level of panic 3 is 0.// the level of panic 4 is 1.
	    }()
	    defer fmt.Println("now, only panic 3 is active")
	    defer panic(3)// will suppress panic 2
	    defer panic(2)// will suppress panic 1
	    panic(1)
	}
	
	在该示例中，panic 6、两个处于active状态中的panic之一被recover捕获。 但是其他panic，panic 3，在主调用结束时仍然活动，所以程序将崩溃。 Outputs
	now, only panic 3 is active
	now, there are two active
	panics: 3 and 6
	6
	program will crash, for panic 3 is stll active
	panic: 1
	panic: 2
	panic: 3
	goroutine 1 [running]: ...
	
	
>5,低级的panics将会被首先捕获
	
	
	import"fmt"
	func main(){
	    defer func(){
	        defer func(){
	            fmt.Println("panic",recover(),"is recovered")// panic 2 is recovered
	        }()
	        defer fmt.Println("panic",recover(),"is recovered")// panic 1 is recovered
	        defer fmt.Println("now, two active panics coexist")
	        panic(2)
	    }()
	    panic(1)
	}	
	
	now, two active panics coexist

	panic 1 is recovered
	
	panic 2 is recovered
	
	那么，什么是使recover调用生效的主要规则是什么？ 规则很简单
	
	在一个goroutine中，如果recover调用的调用函数是F并且F调用的级别是L，则为了使recover调用生效，F调用必须是延迟调用，并且必须存在主动panic的水平为L-1。 相对来说、这是一个比go规格更好的描述、 现在你可以回页面检查为什么第一个例子中的第6个recover调用不会生效了
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 		


#六,nil详解
>1,什么是 nil ？
	
	bool      -> false                              
	numbers -> 0                                 
	string    -> ""      
	
	pointers -> nil
	slices -> nil
	maps -> nil
	channels -> nil
	functions -> nil
	interfaces -> nil

	(1). Go的文档中说到，nil是预定义的标识符，代表指针、通道、函数、接口、映射或切片的零值,并不是GO 的关键字之一
	(2). nil只能赋值给指针、channel、func、interface、map或slice类型的变量 (非基础类型) 否则会引发 panic

>2,interface与nil
	
	在底层，interface作为两个成员实现：一个类型和一个值。该值被称为接口的动态值， 它是一个任意的具体值，而该接口的类型则为该值的类型。对于 int 值3， 一个接口值示意性地包含(int, 3)。
	只有在内部值和类型都未设置时(nil, nil)，一个接口的值才为 nil。特别是，一个 nil 接口将总是拥有一个 nil 类型。若我们在一个接口值中存储一个 *int 类型的指针，则内部类型将为 int，无论该指针的值是什么：(int, nil)。 因此，这样的接口值会是非 nil 的，即使在该指针的内部为 nil。
	
	 var val interface{} = int64(58)
    fmt.Println(reflect.TypeOf(val)) // int64
    val = 50
    fmt.Println(reflect.TypeOf(val)) // int
	
	在上面的例子中，第一条打印语句输出的是：int64。这是因为已经显示的将类型为int64的数据58赋值给了interface类型的变量val，所以val的底层结构应该是：(int64, 58)。
	我们暂且用这种二元组的方式来描述，二元组的第一个成员为type，第二个成员为data。第二条打印语句输出的是：int。这是因为字面量的整数在golang中默认的类型是int，所以这个时候val的底层结构就变成了：(int, 50)。
	
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 		


#七,Mutex互斥锁实现原理剖析
	
>1,Mutex结构体
  		
  		type Mutex struct{
  			state int32
  			sema  uint32
  		}	
		
		state 表示互斥锁的状态，比如是否被速定等
		sema表示信号量，协程阻塞等待该信号量，解锁的协程释放信号量从而唤醒等待信号量的协程
		
		我们看到Mutex.state是32位的整型变量，内部实现时把该变量分成四份，用于记录Mutex的四种状态。
![展示Mutex的内存布局](https://oscimg.oschina.net/oscnet/894956cce1cf2658635e3795c6d0a9816d4.jpg)
	 
	    Locked: 表示该Mutex是否已被锁定，0：没有锁定 1：已被锁定。
	    Woken: 表示是否有协程已被唤醒，0：没有协程唤醒 1：已有协程唤醒，正在加锁过程中。
	    Starving：表示该Mutex是否处理饥饿状态， 0：没有饥饿 1：饥饿状态，说明有协程阻塞了超过1ms。
	    Waiter: 表示阻塞等待锁的协程个数，协程解锁时根据此值来判断是否需要释放信号量。

	 
		协程之间抢锁实际上是抢给Locked赋值的权利，能给Locked域置1，就说明抢锁成功。抢不到的话就阻塞等待Mutex.sema信号量，一旦持有锁的协程解锁，等待的协程会依次被唤醒。
		Woken和Starving主要用于控制协程间的抢锁过程，后面再进行了解。
		


>2,Mutex方法
		
	Mutext对外提供两个方法，实际上也只有这两个方法：

    Lock() : 加锁方法
    Unlock(): 解锁方法

	下面我们分析一下加锁和解锁的过程，加锁分成功和失败两种情况，成功的话直接获取锁，失败后当前协程被阻塞，同样，解锁时跟据是否有阻塞协程也有两种处理。
	
>3,简单加锁
	
	假定当前只有一个协程在加锁，没有其他协程干扰，那么过程如下图所示：
![](https://oscimg.oschina.net/oscnet/3a4cabbb3da6a1ca30031214a5de309884d.jpg)

	加锁过程会去判断Locked标志位是否为0，如果是0则把Locked位置1，代表加锁成功。从上图可见，加锁成功后，只是Locked位置1，其他状态位没发生变化。	
>4,加锁被阻塞

	假定加锁时，锁已被其他协程占用了，此时加锁过程如下图所示：
![](https://oscimg.oschina.net/oscnet/6d28d2ebba4c610bed79571c2081ca2517b.jpg)
	
	从上图可看到，当协程B对一个已被占用的锁再次加锁时，Waiter计数器增加了1，此时协程B将被阻塞，直到Locked值变为0后才会被唤醒。	
>5,简单解锁
	
	假定解锁时，没有其他协程阻塞，此时解锁过程如下图所示：
![](https://oscimg.oschina.net/oscnet/f9c9346331aaf09a6c9a6a37d1e8cba2efc.jpg)
	
	由于没有其他协程阻塞等待加锁，所以此时解锁时只需要把Locked位置为0即可，不需要释放信号量。
	
>6,解锁并唤醒协程
	
	假定解锁时，有1个或多个协程阻塞，此时解锁过程如下图所示：				
![](https://oscimg.oschina.net/oscnet/5255c433b21451ddf781fcb90e50b74cd3a.jpg)
	
	协程A解锁过程分为两个步骤，一是把Locked位置0，二是查看到Waiter>0，所以释放一个信号量，唤醒一个阻塞的协程，被唤醒的协程B把Locked位置1，于是协程B获得锁。
	
>7,	锁自旋解锁的获取避免被阻塞
	
	加锁时，如果当前Locked位为1，说明该锁当前由其他协程持有，尝试加锁的协程并不是马上转入阻塞，而是会持续的探测Locked位是否变为0，这个过程即为自旋过程。
	
	自旋时间很短，但如果在自旋过程中发现锁已被释放，那么协程可以立即获取锁。此时即便有协程被唤醒也无法获取锁，只能再次阻塞。
	自旋的好处是，当加锁失败时不必立即转入阻塞，有一定机会获取到锁，这样可以避免协程的切换。
	
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 	
	
#八,rwmutex读写锁
	
>1,语法定义
	
	type RWMutex struct {
    w           Mutex  //用于控制多个写锁，获得写锁首先要获取该锁，如果有一个写锁在进行，那么再到来的写锁将会阻塞于此
    writerSem   uint32 //写阻塞等待的信号量，最后一个读者释放锁时会释放信号量
    readerSem   uint32 //读阻塞的协程等待的信号量，持有写锁的协程释放锁后会释放信号量
    readerCount int32  //记录读者个数
    readerWait  int32  //记录写阻塞时读者个数
	}	
	
	由以上数据结构可见，读写锁内部仍有一个互斥锁，用于将两个写操作隔离开来，其他的几个都用于隔离读操作和写操作。
	
	

>2, 接口定义

	RWMutex提供4个简单的接口来提供服务：

    RLock()：读锁定

    RUnlock()：解除读锁定

    Lock(): 写锁定，与Mutex完全一致

    Unlock()：解除写锁定，与Mutex完全一致	
	
>3, Lock()逻辑实现
	
  写锁定操作需要做两件事：
	获取互斥锁
	阻塞等待所有读操作结束（如果有的话）
	
  		所以func (rw *RWMutex) Lock()接口实现流程如下图所示：
	

>4, Unlock()逻辑实现


>5, RLock()逻辑实现
	
	//写解锁
	func (rw *RWMutex) RLock() {
	if race.Enabled {
		_ = rw.w.state
		race.Disable()
	}
	if atomic.AddInt32(&rw.readerCount, 1) < 0 {
		// A writer is pending, wait for it.
		runtime_SemacquireMutex(&rw.readerSem, false)
	}
	if race.Enabled {
		race.Enable()
		race.Acquire(unsafe.Pointer(&rw.readerSem))
	}
	}
	
	
	读锁定会先将RWMutext.readerCount加1，此时写操作到来时发现读者数量不为0，会阻塞等待所有读操作结束。

		


>6, RUnlock()逻辑实现
	
	//读解锁
	func (rw *RWMutex) RUnlock() {
	if race.Enabled {
		_ = rw.w.state
		race.ReleaseMerge(unsafe.Pointer(&rw.writerSem))
		race.Disable()
	}
	if r := atomic.AddInt32(&rw.readerCount, -1); r < 0 {
		if r+1 == 0 || r+1 == -rwmutexMaxReaders {
			race.Enable()
			throw("sync: RUnlock of unlocked RWMutex")
		}
		// A writer is pending.
		if atomic.AddInt32(&rw.readerWait, -1) == 0 {
			// The last reader unblocks the writer.
			runtime_Semrelease(&rw.writerSem, false)
		}
	}
	if race.Enabled {
		race.Enable()
	}
	}
	
		我们知道RWMutex.readerCount是个整型值，用于表示读者数量，不考虑写操作的情况下，每次读锁定将该值+1，每次解除读锁定将该值-1，所以readerCount取值为[0, N]，N为读者个数，实际上最大可支持2^30个并发读者。
	当写锁定进行时，会先将readerCount减去2^30，从而readerCount变成了负值，此时再有读锁定到来时检测到readerCount为负值，便知道有写操作在进行，只好阻塞等待。而真实的读操作个数并不会丢失，只需要将readerCount加上2^30即可获得。
	所以，写操作将readerCount变成负值来阻止读操作的。
	


***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 

#九,string详解
	
>1,数据结构
	
	type stringStruct struct {
    str unsafe.Pointer
    len int
	}
	
	其数据结构很简单：
	stringStruct.str：字符串的首地址；
	stringStruct.len：字符串的长度；
	
	string数据结构跟切片有些类似，只不过切片还有一个表示容量的成员，事实上string和切片，准确的说是byte切片经常发生转换。这个后面再详细介绍。


>2,声明

	如下代码所示，可以声明一个string变量变赋予初值：
	
	    var str string
	    str = "Hello World"
	
	字符串构建过程是先跟据字符串构建stringStruct，再转换成string。转换的源码如下：
	
	func gostringnocopy(str *byte) string { // 跟据字符串地址构建string
	    ss := stringStruct{str: unsafe.Pointer(str), len: findnull(str)} // 先构造stringStruct
	    s := *(*string)(unsafe.Pointer(&ss))                             // 再将stringStruct转换成string
	    return s
	}
	
	string在runtime包中就是stringStruct，对外呈现叫做string。
	

>3,[]byte转string
	
	func GetStringBySlice(s []byte) string {
	    return string(s)
	}
	需要注意的是这种转换需要一次内存拷贝。
	转换过程如下： 1. 跟据切片的长度申请内存空间，假设内存地址为p，切片长度为len(b)； 2. 构建string（string.str = p；string.len = len；） 3. 拷贝数据(切片中数据拷贝到新申请的内存空间)
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-L_VX-amU1qSzGk3Bq6J%2F-L_VX0Dh0JNhp-BdP-Qa%2Fstring-01-slice2string.png?generation=1552102725295291&alt=media)	
	
	
>4,string转[]byte
	
	func GetSliceByString(str string) []byte {
    return []byte(str)
	}
	
	string转换成byte切片，也需要一次内存拷贝，其过程如下：
	申请切片内存空间
	将string拷贝到切片
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-L_VX-amU1qSzGk3Bq6J%2F-L_VX0DjVM80DYQXOu3E%2Fstring-02-string2slice.png?generation=1552102725476626&alt=media)	

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 

#十,Map详解

>1. map数据结构

	Golang的map使用哈希表作为底层实现，一个哈希表里可以有多个哈希表节点，也即bucket，而每个bucket就保存了map中的一个或一组键值对。
	map数据结构由runtime/map.go/hmap定义:
	
	type hmap struct {
	    count     int // 当前保存的元素个数
	    ...
	    B         uint8  // 指示bucket数组的大小
	    ...
	    buckets    unsafe.Pointer // bucket数组指针，数组的大小为2^B
	    ...
	}
	
	下图展示一个拥有4个bucket的map：
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-LR57LzS5OlclWlPtOY7%2F-LR57Mq6UGls4Raj0Oiu%2Fmap-01-struct.png?generation=1541996118957690&alt=media)
	
	本例中, hmap.B=2， 而hmap.buckets长度是2^B为4. 元素经过哈希运算后会落到某个bucket中进行存储。查找过程类似。
	bucket很多时候被翻译为桶，所谓的哈希桶实际上就是bucket。


>2,bucket数据结构	
	
	bucket数据结构由runtime/map.go/bmap定义：
	type bmap struct {
	    tophash [8]uint8 //存储哈希值的高8位
	    data    byte[1]  //key value数据:key/key/key/.../value/value/value...
	    overflow *bmap   //溢出bucket的地址
	}	

	每个bucket可以存储8个键值对。
	tophash是个长度为8的数组，哈希值相同的键（准确的说是哈希值低位相同的键）存入当前bucket时会将哈希值的高位存储在该数组中，以方便后续匹配。
	data区存放的是key-value数据，存放顺序是key/key/key/...value/value/value，如此存放是为了节省字节对齐带来的空间浪费。
	overflow 指针指向的是下一个bucket，据此将所有冲突的键连接起来。
	注意：上述中data和overflow并不是在结构体中显示定义的，而是直接通过指针运算进行访问的。

	下图展示bucket存放8个key-value对：
	
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-LR57LzS5OlclWlPtOY7%2F-LR57Mq8miQJlghrC0t0%2Fmap-02-struct_sketch.png?generation=1541996118589709&alt=media)

>3,哈希冲突
	
	当有两个或以上数量的键被哈希到了同一个bucket时，我们称这些键发生了冲突。Go使用链地址法来解决键冲突。 由于每个bucket可以存放8个键值对，所以同一个bucket存放超过8个键值对时就会再创建一个键值对，用类似链表的方式将bucket连接起来。		
	下图展示产生冲突后的map：
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-LR57LzS5OlclWlPtOY7%2F-LR57MqA8JhM9uMyzKov%2Fmap-03-struct_sketch.png?generation=1541996125059173&alt=media)
	
	bucket数据结构指示下一个bucket的指针称为overflow bucket，意为当前bucket盛不下而溢出的部分。事实上哈希冲突并不是好事情，它降低了存取效率，好的哈希算法可以保证哈希值的随机性，但冲突过多也是要控制的，后面会再详细介绍。


>4,负载因子
	
	负载因子用于衡量一个哈希表冲突情况，公式为：

		负载因子 = 键数量/bucket数量
		
	
	例如，对于一个bucket数量为4，包含4个键值对的哈希表来说，这个哈希表的负载因子为1.
	
	哈希表需要将负载因子控制在合适的大小，超过其阀值需要进行rehash，也即键值对重新组织：
		哈希因子过小，说明空间利用率低
		哈希因子过大，说明冲突严重，存取效率低
		
	每个哈希表的实现对负载因子容忍程度不同，比如Redis实现中负载因子大于1时就会触发rehash，而Go则在在负载因子达到6.5时才会触发rehash，因为Redis的每个bucket只能存1个键值对，而Go的bucket可能存8个键值对，所以Go可以容忍更高的负载因子。



>5,map的扩容前提条件
	
	为了保证访问效率，当新元素将要添加进map时，都会检查是否需要扩容，扩容实际上是以空间换时间的手段。 触发扩容的条件有二个： 1. 负载因子 > 6.5时，也即平均每个bucket存储的键值对达到6.5个。 2. overflow数量 > 2^15时，也即overflow数量超过32768时。
	
	
>6,增量扩容 -- 主要是迁移不会突然将老数据迁移到新的bucket里面

	当负载因子过大时，就新建一个bucket，新的bucket长度是原来的2倍，然后旧bucket数据搬迁到新的bucket。 考虑到如果map存储了数以亿计的key-value，一次性搬迁将会造成比较大的延时，Go采用逐步搬迁策略，即每次访问map时都会触发一次搬迁，每次搬迁2个键值对。
	下图展示了包含一个bucket满载的map(为了描述方便，图中bucket省略了value区域):
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-LR57LzS5OlclWlPtOY7%2F-LR57MqCGz2jjYBYEfe8%2Fmap-04-struct_sketch.png?generation=1541996119758928&alt=media)

	当前map存储了7个键值对，只有1个bucket。此地负载因子为7。再次插入数据时将会触发扩容操作，扩容之后再将新插入键写入新的bucket。		
	当第8个键值对插入时，将会触发扩容，扩容后示意图如下：
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-LR57LzS5OlclWlPtOY7%2F-LR57MqExwuCD3gkfJbp%2Fmap-05-struct_sketch.png?generation=1541996120739161&alt=media)

	hmap数据结构中oldbuckets成员指身原bucket，而buckets指向了新申请的bucket。新的键值对被插入新的bucket中。 后续对map的访问操作会触发迁移，将oldbuckets中的键值对逐步的搬迁过来。当oldbuckets中的键值对全部搬迁完毕后，删除oldbuckets。
	搬迁完成后的示意图如下：
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-LR57LzS5OlclWlPtOY7%2F-LR57MqG7I7fX4emJGmj%2Fmap-06-struct_sketch.png?generation=1541996119361019&alt=media)

	数据搬迁过程中原bucket中的键值对将存在于新bucket的前面，新插入的键值对将存在于新bucket的后面。 实际搬迁过程中比较复杂，将在后续源码分析中详细介绍。
	
	
>7,查找过程

	查找过程如下： 1. 跟据key值算出哈希值 2. 取哈希值低位与hmpa.B取模确定bucket位置 3. 取哈希值高位在tophash数组中查询 4. 如果tophash[i]中存储值也哈希值相等，则去找到该bucket中的key值进行比较 5. 当前bucket没有找到，则继续从下个overflow的bucket中查找。 6. 如果当前处于搬迁过程，则优先从oldbuckets查找
	
	注：如果查找不到，也不会返回空值，而是返回相应类型的0值。	
>8,插入过程

	新员素插入过程如下： 1. 跟据key值算出哈希值 2. 取哈希值低位与hmap.B取模确定bucket位置 3. 查找该key是否已经存在，如果存在则直接更新值 4. 如果没找到将key，将key插入	
	
	
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 


#十一,sync.Map详解 --基于runtime.map实现

>1,sync.map结构类型

	
	type Map struct {
	   mu Mutex
	    
	   read atomic.Value // readOnly  保存了map中可以并发读的数据
	
	   dirty map[interface{}]*entry 脏数据需要锁。为了尽快提升为read，dirty需要保存read中所有未标记删除的数据（减少数据拷贝？）。标记删除的条目不保存的dirty里面（那就是保存在read里面咯）
	
	   misses int 从read里面读，miss之后再从dirty里面读。当miss多次之后，就将dirty提升为read。
	}
	
	
	
	
	var expunged = unsafe.Pointer(new(interface{}))
	
	type entry struct {
   // If p == nil, the entry has been deleted and m.dirty == nil.
   //
   // If p == expunged, the entry has been deleted, m.dirty != nil, and the entry
   // is missing from m.dirty.
   //
   // Otherwise, the entry is valid and recorded in m.read.m[key] and, if m.dirty
   // != nil, in m.dirty[key].
   p unsafe.Pointer // *interface{}
	}
	
	entry分为三种情况：
    nil：已经被删除，并且dirty不存在
    expunged：已经被删除了，dirty存在，且条目不在dirty里面。标记删除
    其他情况：保存在read和dirty（存在）中

	

	//参考地址：
		https://www.jianshu.com/p/241e7b911591
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 

#十二,WaitGroup并发

>1,WaitGroup例子

	WaitGroup是Golang应用开发过程中经常使用的并发控制技术。
	WaitGroup，可理解为Wait-Goroutine-Group，即等待一组goroutine结束。比如某个goroutine需要等待其他几个goroutine全部完成，那么使用WaitGroup可以轻松实现。
	
	下面程序展示了一个goroutine等待另外两个goroutine结束的例子：
	package main

	import (
	    "fmt"
	    "time"
	    "sync"
	)
	
	func main() {
	    var wg sync.WaitGroup
	
	    wg.Add(2) //设置计数器，数值即为goroutine的个数
	    go func() {
	        //Do some work
	        time.Sleep(1*time.Second)
	
	        fmt.Println("Goroutine 1 finished!")
	        wg.Done() //goroutine执行结束后将计数器减1
	    }()
	
	    go func() {
	        //Do some work
	        time.Sleep(2*time.Second)
	
	        fmt.Println("Goroutine 2 finished!")
	        wg.Done() //goroutine执行结束后将计数器减1
	    }()
	
	    wg.Wait() //主goroutine阻塞等待计数器变为0
	    fmt.Printf("All Goroutine finished!")
	}
	
	简单的说，上面程序中wg内部维护了一个计数器： 1. 启动goroutine前将计数器通过Add(2)将计数器设置为待启动的goroutine个数。 2. 启动goroutine后，使用Wait()方法阻塞自己，等待计数器变为0。 3. 每个goroutine执行结束通过Done()方法将计数器减1。 4. 计数器变为0后，阻塞的goroutine被唤醒。其实WaitGroup也可以实现一组goroutine等待另一组goroutine，这有点像玩杂技，很容出错，如果不了解其实现原理更是如此。实际上，WaitGroup的实现源码非常简单。
	
	
	
>2,信号量
	
	信号量是Unix系统提供的一种保护共享资源的机制，用于防止多个线程同时访问某个资源。
	可简单理解为信号量为一个数值：
		当信号量>0时，表示资源可用，获取信号量时系统自动将信号量减1；
		当信号量==0时，表示资源暂不可用，获取信号量时，当前线程会进入睡眠，当信号量为正时被唤醒；
	由于WaitGroup实现中也使用了信号量，在此做个简单介绍。
		
	
>3,waitgroup数据结构
	
	// A WaitGroup must not be copied after first use.
	type WaitGroup struct {
		noCopy noCopy
	
		// 64-bit value: high 32 bits are counter, low 32 bits are waiter count.
		// 64-bit atomic operations require 64-bit alignment, but 32-bit
		// compilers do not ensure it. So we allocate 12 bytes and then use
		// the aligned 8 bytes in them as state, and the other 4 as storage
		// for the sema.
		state1 [3]uint32
	}
	
	state1是个长度为3的数组，其中包含了state和一个信号量，而state实际上是两个计数器：
	counter： 当前还未执行结束的goroutine计数器
	waiter count: 等待goroutine-group结束的goroutine数量，即有多少个等候者
	semaphore: 信号量
	
	考虑到字节是否对齐，三者出现的位置不同，为简单起见，依照字节已对齐情况下，三者在内存中的位置如下所示：
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-LRC2SHRLPlOXEy84Hqc%2F-LRC2Sz1hb-krUC2hJsb%2Fwg-01-layout.png?generation=1542112273493501&alt=media)

	
 WaitGroup对外提供三个接口：
 
	Add(delta int): 将delta值加到counter中
	Wait()： waiter递增1，并阻塞等待信号量semaphore
	Done()： counter递减1，按照waiter数值释放相应次数信号量
	
	
	
>4,Add(delta int)
	
	Add()做了两件事，一是把delta值累加到counter中，因为delta可以为负值，也就是说counter有可能变成0或负值，所以第二件事就是当counter值变为0时，跟据waiter数值释放等量的信号量，把等待的goroutine全部唤醒，如果counter变为负值，则panic.
	
	func (wg *WaitGroup) Add(delta int) {
    statep, semap := wg.state() //获取state和semaphore地址指针

    state := atomic.AddUint64(statep, uint64(delta)<<32) //把delta左移32位累加到state，即累加到counter中
    v := int32(state >> 32) //获取counter值
    w := uint32(state)      //获取waiter值

    if v < 0 {              //经过累加后counter值变为负值，panic
        panic("sync: negative WaitGroup counter")
    }

    //经过累加后，此时，counter >= 0
    //如果counter为正，说明不需要释放信号量，直接退出
    //如果waiter为零，说明没有等待者，也不需要释放信号量，直接退出
    if v > 0 || w == 0 {
        return
    }

    //此时，counter一定等于0，而waiter一定大于0（内部维护waiter，不会出现小于0的情况），
    //先把counter置为0，再释放waiter个数的信号量
    *statep = 0
    for ; w != 0; w-- {
        runtime_Semrelease(semap, false) //释放信号量，执行一次释放一个，唤醒一个等待者
    }
	}
		
	
	
>5, Wait()

	Wait()方法也做了两件事，一是累加waiter, 二是阻塞等待信号量
	
	func (wg *WaitGroup) Wait() {
    statep, semap := wg.state() //获取state和semaphore地址指针
    for {
        state := atomic.LoadUint64(statep) //获取state值
        v := int32(state >> 32)            //获取counter值
        w := uint32(state)                 //获取waiter值
        if v == 0 {                        //如果counter值为0，说明所有goroutine都退出了，不需要待待，直接返回
            return
        }

        // 使用CAS（比较交换算法）累加waiter，累加可能会失败，失败后通过for loop下次重试
        if atomic.CompareAndSwapUint64(statep, state, state+1) {
            runtime_Semacquire(semap) //累加成功后，等待信号量唤醒自己
            return
        }
    }
	}	
	
	这里用到了CAS算法保证有多个goroutine同时执行Wait()时也能正确累加waiter。
	

>6, Done()

	Done()只做一件事，即把counter减1，我们知道Add()可以接受负值，所以Done实际上只是调用了Add(-1)。
	
	源码如下：
	
	func (wg *WaitGroup) Done() {
	    wg.Add(-1)
	}
	
	Done()的执行逻辑就转到了Add()，实际上也正是最后一个完成的goroutine把等待者唤醒的。
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 
	
#十三,	noCopy详解

>1,noCopy Go中没有原生的禁止拷贝的方式，所以如果有的结构体，你希望使用者无法拷贝
	
	
	type noCopy struct{}

	// Lock is a no-op used by -copylocks checker from `go vet`.
	func (*noCopy) Lock()   {}
	func (*noCopy) Unlock() {}
	
>2,使用go vet查看嵌套在struct里面的是否被拷贝
	
	type noCopy struct{}

	func (*noCopy) Lock()   {}
	func (*noCopy) Unlock() {}
	
	type Demo struct {
		noCopy noCopy
	}
	
	func Copy(d Demo) {
		CopyTwice(d)
	}
	func CopyTwice(d Demo) {
	
	}
	
	func main() {
		d := Demo{}
		fmt.Printf("%+v", d)
	
		Copy(d)
	
		fmt.Printf("%+v", d)
	}	
			
	go vet nocopymain.go
	
	./nocopymain.go:17: Copy passes lock by value: main.Demo contains main.noCopy
	./nocopymain.go:18: call of CopyTwice copies lock value: main.Demo contains main.noCopy
	./nocopymain.go:20: CopyTwice passes lock by value: main.Demo contains main.noCopy
	./nocopymain.go:26: call of fmt.Printf copies lock value: main.Demo contains main.noCopy
	./nocopymain.go:28: call of Copy copies lock value: main.Demo contains main.noCopy
	./nocopymain.go:30: call of fmt.Printf copies lock value: main.Demo contains main.noCopy
	
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 

#十四,sync.Pool详解


>1,pool有点，性能优化，可动态扩展
	
	我们通常用golang来构建高并发场景下的应用，但是由于golang内建的GC机制会影响应用的性能，为了减少GC，golang提供了对象重用的机制，也就是sync.Pool对象池。 sync.Pool是可伸缩的，并发安全的。其大小仅受限于内存的大小，可以被看作是一个存放可重用对象的值的容器。 设计的目的是存放已经分配的但是暂时不用的对象，在需要用到的时候直接从pool中取。
	当执行一个pool的get或者put操作的时候都会先把当前的goroutine固定到某个P的子池上面，然后再对该子池进行操作。每个子池里面有一个私有对象和共享列表对象，私有对象是只有对应的P能够访问，因为一个P同一时间只能执行一个goroutine，因此对私有对象存取操作是不需要加锁的。共享列表是和其他P分享的，因此操作共享列表是需要加锁的。
	
	
>2，pool数据结构	
	
	//（1），pool对象构造
	type Pool struct {
	noCopy noCopy //禁止copy对象

    //维护的本地队列
	local     unsafe.Pointer // local fixed-size per-P pool, actual type is [P]poolLocal
	localSize uintptr        // size of the local array 本地队列的大小

	// New optionally specifies a function to generate
	// a value when Get would otherwise return nil.
	// It may not be changed concurrently with calls to Get.
	New func() interface{} //创建对象
	}
	
	// Local per-P Pool appendix.
	type poolLocalInternal struct {
		private interface{}   // Can be used only by the respective P. 私有的对象
		shared  []interface{} // Can be used by any P.  私有对象对外分享
		Mutex                 // Protects shared. 使用锁操作私有对象
	}
	
	//（2），本地队列
	type poolLocal struct { //每个cpu分配一个poolLocal，所以在操作的时候不会出现多个goroutine的情况，但在操作shared列表是可能被多个goroutine访问需要加锁
		poolLocalInternal
		// Prevents false sharing on widespread platforms with
		// 128 mod (cache line size) = 0 .
		pad [128 - unsafe.Sizeof(poolLocalInternal{})%128]byte  //目的是为了防止false sharing
	}
	
	
	//（3),init 执行清楚本地的对象，防止无限增大,缓存对象的数量和期限
	func init() {
	runtime_registerPoolCleanup(poolCleanup)
	}
	
	//(4),pool操作
	 Get() //获取数据
	 Put(x interface{}) //添加数据
	 
	 
>3,获取添加对象
	
    获取对象过程是：
	1）固定到某个P，尝试从私有对象获取，如果私有对象非空则返回该对象，并把私有对象置空；
	2）如果私有对象是空的时候，就去当前子池的共享列表获取（需要加锁）；
	3）如果当前子池的共享列表也是空的，那么就尝试去其他P的子池的共享列表偷取一个（需要加锁）；
	4）如果其他子池都是空的，最后就用用户指定的New函数产生一个新的对象返回。
	可以看到一次get操作最少0次加锁，最大N（N等于MAXPROCS）次加锁。
	
	归还对象的过程：
	1）固定到某个P，如果私有对象为空则放到私有对象；
	2）否则加入到该P子池的共享列表中（需要加锁）。
	可以看到一次put操作最少0次加锁，最多1次加锁。
	由于goroutine具体会分配到那个P执行是golang的协程调度系统决定的，因此在MAXPROCS>1的情况下，多goroutine用同一个sync.Pool的话，各个P的子池之间缓存的对象是否平衡以及开销如何是没办法准确衡量的。但如果goroutine数目和缓存的对象数目远远大于MAXPROCS的话，概率上说应该是相对平衡的。
	总的来说，sync.Pool的定位不是做类似连接池的东西，它的用途仅仅是增加对象重用的几率，减少gc的负担，而开销方面也不是很便宜的。

	
>4,	总结

	通过以上的解读，我们可以看到，Get方法并不会对获取到的对象值做任何的保证，因为放入本地池中的值有可能会在任何时候被删除，但是不通知调用者。放入共享池中的值有可能被其他的goroutine偷走。 所以对象池比较适合用来存储一些临时切状态无关的数据，但是不适合用来存储数据库连接的实例，因为存入对象池重的值有可能会在垃圾回收时被删除掉，这违反了数据库连接池建立的初衷。
	根据上面的说法，Golang的对象池严格意义上来说是一个临时的对象池，适用于储存一些会在goroutine间分享的临时对象。主要作用是减少GC，提高性能。在Golang中最常见的使用场景是fmt包中的输出缓冲区。
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 
	
#十五，伪共享（false sharing)并发编程无声的性能杀手

>1,缓存在 CPU 架构中的工作原理
	
	CPU 中缓存的最小化单位是缓存行（现在来说，CPU 中常见的缓存行大小为 64 字节）。因此，当 CPU 从内存中读取变量时，它将读取该变量附近的所有变量。


>2,什么是伪共享（false sharing)？
	
	假共享是 SMP 系统上的一种常见性能问题。在SMP系统中，每个处理器均有一个高速缓存。 当不同处理器上的线程修改驻留在同一高速缓存行（Cache Block，或Cache Line）中的变量时就会发生假共享。 这种现象之所以被称为假共享，是因为每个线程并非真正共享相同变量的访问权。 访问同一变量或真正共享要求编程式同步结构，以确保有序的数据访问。
	
![](https://xwxwgo.com/post/2019/07/09/5-4-figure-1.gif)
	
	线程 0 和线程 1 会用到不同变量，它们在内存中彼此相邻，并驻留在同一高速缓存块（Cache Block，或Cache Line）。 高速缓存行被加载到 CPU 0 和 CPU 1 的高速缓存中（灰色箭头）。 尽管这些线程修改的是不同变量（红色和蓝色箭头），高速缓存行（Cache Block，或Cache Line）仍会无效，并强制内存更新以维持高速缓存的一致性，这会降低应用性能。
	

>3,解决该问题的常用方法是缓存填充
	
	在变量之间填充一些无意义的变量。使一个变量单独占用 CPU 核的缓存行，因此当其他核更新时，其他变量不会使该核从内存中重新加载变量。
	我们使用如下的 Go 代码来简要介绍缓存 false sharing 的概念。
	
	(1),三个 uint64 变量的结构体
	type NoPad struct {
		a uint64
		b uint64
		c uint64
	}
	 
	func (myatomic *NoPad) IncreaseAllEles() {
		atomic.AddUint64(&myatomic.a, 1)
		atomic.AddUint64(&myatomic.b, 1)
		atomic.AddUint64(&myatomic.c, 1)
	}
	
	(2),另一个结构，我使用 [8]uint64 来做缓存填充
	
	type Pad struct {
		a   uint64
		_p1 [8]uint64
		b   uint64
		_p2 [8]uint64
		c   uint64
		_p3 [8]uint64
	}
	 
	func (myatomic *Pad) IncreaseAllEles() {
		atomic.AddUint64(&myatomic.a, 1)
		atomic.AddUint64(&myatomic.b, 1)
		atomic.AddUint64(&myatomic.c, 1)
	}
	
	然后写一个简单的代码来运行基准测试：

    func testAtomicIncrease(myatomic MyAtomic) {
    	paraNum := 1000
    	addTimes := 1000
    	var wg sync.WaitGroup
    	wg.Add(paraNum)
    	for i := 0; i < paraNum; i++ {
    		go func() {
    			for j := 0; j < addTimes; j++ {
    				myatomic.IncreaseAllEles()
    			}
    			wg.Done()
    		}()
    	}
    	wg.Wait()
     
    }
    func BenchmarkNoPad(b *testing.B) {
    	myatomic := &NoPad{}
    	b.ResetTimer()
    	testAtomicIncrease(myatomic)
    }
     
    func BenchmarkPad(b *testing.B) {
    	myatomic := &Pad{}
    	b.ResetTimer()
    	testAtomicIncrease(myatomic)
    }
    
    

	使用 2014 年的 MacBook Air 做的基准测试结果如下：

    $> go test -bench=.
    BenchmarkNoPad-4 2000000000 0.07 ns/op
    BenchmarkPad-4 2000000000 0.02 ns/op
    PASS
    ok 1.777s
    复制代码

	基准测试的结果表明它将性能从 0.07 ns/op 提高到了 0.02 ns/op，这是一个很大的提高。
	你也可以用其他语言测试这个，比如 Java，我相信你会得到相同的结果。
	在将其应用于你的代码之前，应该了解两个要点：

    确保系统中 CPU 的缓存行大小：这与你使用的缓存填充大小有关。
    填充更多变量意味着消耗更多内存资源。在你的方案中运行基准测试以确保这些内存消耗是值得的。


***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 
	
#十六,range迭代遍历

>1,range遍历slice	

	打印切片的下标和元素值，请问性能上有没有可优化的空间？
	func RangeSlice(slice []int) {
	    for index, value := range slice {
	        _, _ = index, value
	    }
	}
	参考答案：
	遍历过程中每次迭代会对index和value进行赋值，如果数据量大或者value类型为string时，对value的赋值操作可能是多余的，可以在for-range中忽略value值，使用slice[index]引用value值。

	
>2,Map遍历

	下面函数通过遍历Map，打印Map的key和value，请问性能上有没有可优化的空间？
	func RangeMap(myMap map[int]string) {
	    for key, _ := range myMap {
	        _, _ = key, myMap[key]
	    }
	}	
	
	函数中for-range语句中只获取key值，然后跟据key值获取value值，虽然看似减少了一次赋值，但通过key值查找value值的性能消耗可能高于赋值消耗。能否优化取决于map所存储数据结构特征、结合实际情况进行。
	

>3,range遍历slice原理
	
	下面的注释解释了遍历slice的过程：
	
	// The loop we generate:
	//   for_temp := range
	//   len_temp := len(for_temp)
	//   for index_temp = 0; index_temp < len_temp; index_temp++ {
	//           value_temp = for_temp[index_temp]
	//           index = index_temp
	//           value = value_temp
	//           original body
	//   }
	
	遍历slice前会先获以slice的长度len_temp作为循环次数，循环体中，每次循环会先获取元素值，如果for-range中接收index和value的话，则会对index和value进行一次赋值。
	
	由于循环开始前循环次数就已经确定了，所以循环过程中新添加的元素是没办法遍历到的。
	
	另外，数组与数组指针的遍历过程与slice基本一致，不再赘述。
	
	
>4,	range遍历map原理 --map的mapiterinit遍历
	
	// The loop we generate:
	//   var hiter map_iteration_struct
	//   for mapiterinit(type, range, &hiter); hiter.key != nil; mapiternext(&hiter) {
	//           index_temp = *hiter.key
	//           value_temp = *hiter.val
	//           index = index_temp
	//           value = value_temp
	//           original body
	//   }
	遍历map时没有指定循环次数，循环体与遍历slice类似。由于map底层实现与slice不同，map底层使用hash表实现，插入数据位置是随机的，所以遍历过程中新插入的数据不能保证遍历到。
	

>5,range 遍历channel原理
	
	遍历channel是最特殊的，这是由channel的实现机制决定的：

	// The loop we generate:
	//   for {
	//           index_temp, ok_temp = <-range
	//           if !ok_temp {
	//                   break
	//           }
	//           index = index_temp
	//           original body
	//   }
	
	channel遍历是依次从channel中读取数据,读取前是不知道里面有多少个元素的。如果channel中没有元素，则会阻塞等待，如果channel已被关闭，则会解除阻塞并退出循环。
	
	注：
	上述注释中index_temp实际上描述是有误的，应该为value_temp，因为index对于channel是没有意义的。
	使用for-range遍历channel时只能获取一个返回值。
	
>6,注意事项
	
	 遍历过程中可以适情况放弃接收index或value，可以一定程度上提升性能
    遍历channel时，如果channel中没有数据，可能会阻塞
    尽量避免遍历过程中修改原数据
    
    for-range的实现实际上是C风格的for循环
    使用index,value接收range返回值会发生一次数据拷贝
    
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 

#十七,context详解

>1,context数据结构
		
	type Context interface {
	  Deadline() (deadline time.Time, ok bool)
	 
	  Done() <-chan struct{}
	 
	  Err() error
	 
	  Value(key interface{}) interface{}
	}

![](https://files.jb51.net/file_images/article/201810/2018102611151337.jpg)

>2,cancelCtx实现

	源码包中src/context/context.go:cancelCtx 定义了该类型context：
	
	type cancelCtx struct {
		Context
	
		mu       sync.Mutex            // protects following fields
		done     chan struct{}         // created lazily, closed by first cancel call
		children map[canceler]struct{} // set to nil by the first cancel call
		err      error                 // set to non-nil by the first cancel call
	}
	
	children中记录了由此context派生的所有child，此context被cancle时会把其中的所有child都cancle掉。
	
	cancelCtx与deadline和value无关，所以只需要实现Done()和Err()接口外露接口即可。
	 Done()接口实现
	
	按照Context定义，Done()接口只需要返回一个channel即可，对于cancelCtx来说只需要返回成员变量done即可。
	
	这里直接看下源码，非常简单：
	
	func (c *cancelCtx) Done() <-chan struct{} {
		c.mu.Lock()
		if c.done == nil {
			c.done = make(chan struct{})
		}
		d := c.done
		c.mu.Unlock()
		return d
	}
	
	由于cancelCtx没有指定初始化函数，所以cancelCtx.done可能还未分配，所以需要考虑初始化。
	cancelCtx.done会在context被cancel时关闭，所以cancelCtx.done的值一般经历如三个阶段： nil --> chan struct{} --> closed chan。
	2.3.2 Err()接口实现
	
	按照Context定义，Err()只需要返回一个error告知context被关闭的原因。对于cancelCtx来说只需要返回成员变量err即可。
	
	还是直接看下源码：
	
	func (c *cancelCtx) Err() error {
		c.mu.Lock()
		err := c.err
		c.mu.Unlock()
		return err
	}
	
	cancelCtx.err默认是nil，在context被cancel时指定一个error变量： var Canceled = errors.New("context canceled")。

  cancel()接口实现
  
	cancel()内部方法是理解cancelCtx的最关键的方法，其作用是关闭自己和其后代，其后代存储在cancelCtx.children的map中，其中key值即后代对象，value值并没有意义，这里使用map只是为了方便查询而已。
	
	cancel方法实现伪代码如下所示：
	
	func (c *cancelCtx) cancel(removeFromParent bool, err error) {
	    c.mu.Lock()
		
	    c.err = err	                      //设置一个error，说明关闭原因
	    close(c.done)                     //将channel关闭，以此通知派生的context
		
	    for child := range c.children {   //遍历所有children，逐个调用cancel方法
	        child.cancel(false, err)
	    }
	    c.children = nil
	    c.mu.Unlock()
	
	    if removeFromParent {            //正常情况下，需要将自己从parent删除
	        removeChild(c.Context, c)
	    }
	}
	
	实际上，WithCancel()返回的第二个用于cancel context的方法正是此cancel()。


>3,WithCancel()实现
	
	WithCancel()方法作了三件事：

    初始化一个cancelCtx实例
    将cancelCtx实例添加到其父节点的children中(如果父节点也可以被cancel的话)
    返回cancelCtx实例和cancel()方法
    
	type cancelCtx struct {
	Context

	mu       sync.Mutex            // protects following fields
	done     chan struct{}         // created lazily, closed by first cancel call
	children map[canceler]struct{} // set to nil by the first cancel call
	err      error                 // set to non-nil by the first cancel call
	}
	
	func WithCancel(parent Context) (ctx Context, cancel CancelFunc) {
	c := newCancelCtx(parent)
	propagateCancel(parent, &c)   //将自身添加到父节点
	return &c, func() { c.cancel(true, Canceled) }
	}
	
	这里将自身添加到父节点的过程有必要简单说明一下：

    如果父节点也支持cancel，也就是说其父节点肯定有children成员，那么把新context添加到children里即可；
    如果父节点不支持cancel，就继续向上查询，直到找到一个支持cancel的节点，把新context添加到children里；
    如果所有的父节点均不支持cancel，则启动一个协程等待父节点结束，然后再把当前context结束。


>4,WithTimeout()实现
	
	WithTimeout()实际调用了WithDeadline，二者实现原理一致。
	
	
	func WithTimeout(parent Context, timeout time.Duration) (Context, CancelFunc) {
		return WithDeadline(parent, time.Now().Add(timeout))
	}	
	
	
	
>5,WithValue实现
	
	

	由valueCtx数据结构定义可见，valueCtx.key和valueCtx.val分别代表其key和value值。 实现也很简单：
	
	func (c *valueCtx) Value(key interface{}) interface{} {
		if c.key == key {
			return c.val
		}
		return c.Context.Value(key)
	}
	
	这里有个细节需要关注一下，即当前context查找不到key时，会向父节点查找，如果查询不到则最终返回interface{}。也就是说，可以通过子context查询到父的value值。
	
		WithValue()实现也是非常的简单, 伪代码如下：

		func WithValue(parent Context, key, val interface{}) Context {
			if key == nil {
				panic("nil key")
			}
			return &valueCtx{parent, key, val}
		}
		
6,总结
	
	Context的withValue是并发安全的
    Context仅仅是一个接口定义，跟据实现的不同，可以衍生出不同的context类型；
    cancelCtx实现了Context接口，通过WithCancel()创建cancelCtx实例；
    timerCtx实现了Context接口，通过WithDeadline()和WithTimeout()创建timerCtx实例；
    valueCtx实现了Context接口，通过WithValue()创建valueCtx实例；
    三种context实例可互为父节点，从而可以组合成不同的应用形式；
		
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 

#十八,Timer和Ticker 定时器


>1,timer的数据结构
	
	源码包src/time/sleep.go:Timer定义了其数据结构：
	type Timer struct {
	    C <-chan Time
	    r runtimeTimer
	}
	
	Timer只有两个成员：
	C: 管道，上层应用跟据此管道接收事件；
	r: runtime定时器，该定时器即系统管理的定时器，对上层应用不可见；
	这里应该按照层次来理解Timer数据结构，Timer.C即面向Timer用户的，Timer.r是面向底层的定时器实现。
	
	
	前面我们说过，创建一个Timer实质上是把一个定时任务交给专门的协程进行监控，这个任务的载体便是runtimeTimer，简单的讲，每创建一个Timer意味着创建一个runtimeTimer变量，然后把它交给系统进行监控。我们通过设置runtimeTimer过期后的行为来达到定时的目的。
	源码包src/time/sleep.go:runtimeTimer定义了其数据结构：	
	type runtimeTimer struct {
	    tb uintptr                          // 存储当前定时器的数组地址
	    i  int                              // 存储当前定时器的数组下标
	
	    when   int64                        // 当前定时器触发时间
	    period int64                        // 当前定时器周期触发间隔
	    f      func(interface{}, uintptr)   // 定时器触发时执行的函数
	    arg    interface{}                  // 定时器触发时执行函数传递的参数一
	    seq    uintptr                      // 定时器触发时执行函数传递的参数二(该参数只在网络收发场景下使用)
	}	
	
	
	
	其成员如下：
		tb: 系统底层存储runtimeTimer的数组地址；
		i: 当前runtimeTimer在tb数组中的下标；
		when: 定时器触发事件的时间；
		period: 定时器周期性触发间隔（对于Timer来说，此值恒为0）；
		f: 定时器触发时执行的回调函数，回调函数接收两个参数；
		arg: 定时器触发时执行回调函数的参数一；
		seq: 定时器触发时执行回调函数的参数二（Timer并不使用该参数）；
		

>2,timer实现原理 --timer的三阶段 创建Timer（runtimer托管到startTImer）-->停止Timer（协程中移除）-->重置Timer（先协程中移除后修改后添加）
	
	一个进程中的多个Timer都由底层的一个协程来管理，为了描述方便我们把这个协程称为系统协程。
	我们想在后面的章节中单独介绍系统协程工作机制，本节，我们先简单介绍其工作过程。
	系统协程把runtimeTimer存放在数组中，并按照when字段对所有的runtimeTimer进行堆排序，定时器触发时执行runtimeTimer中的预定义函数f，即完成了一次定时任务。
	

>3,创建Timer

	我们来看创建Timer的实现，非常简单：
	
	func NewTimer(d Duration) *Timer {
	    c := make(chan Time, 1)  // 创建一个管道
	    t := &Timer{ // 构造Timer数据结构
	        C: c,               // 新创建的管道
	        r: runtimeTimer{
	            when: when(d),  // 触发时间
	            f:    sendTime, // 触发后执行函数sendTime
	            arg:  c,        // 触发后执行函数sendTime时附带的参数
	        },
	    }
	    startTimer(&t.r) // 此处启动定时器，只是把runtimeTimer放到系统协程的堆中，由系统协程维护
	    return t
	}
	
	NewTimer()只是构造了一个Timer，然后把Timer.r通过startTimer()交给系统协程维护。
	其中when()方法是计算下一次定时器触发的绝对时间，即当前时间+NewTimer()参数d。
	
	其中sendTime()方法便是定时器触发时的动作：
	func sendTime(c interface{}, seq uintptr) {
	    select {
	    case c.(chan Time) <- Now():
	    default:
	    }
	}
	
	sendTime接收一个管道作为参数，其主要任务是向管道中写入当前时间。
	创建Timer时生成的管道含有一个缓冲区（make(chan Time, 1)），所以Timer触发时向管道写入时间永远不会阻塞，sendTime写完即退出。
	之所以sendTime()使用select并搭配一个空的default分支，是因为后面所要讲的Ticker也复用sendTime()，Ticker触发时也会向管道中写入时间，但无法保证之前的数据已被取走，所以使用select并搭配一个空的default分支，确保sendTime()不会阻塞，Ticker触发时，如果管道中还有值，则本次不再向管道中写入时间，本次触发的事件直接丢弃。
	startTimer(&t.r)的具体实现在runtime包，其主要作用是把runtimeTimer写入到系统协程的数组中，并启动系统协程（如果系统协程还未开始运行的话）。更详细的内容，待后面讲解系统协程时再介绍。
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-Lat85FATVT40BgO76_T%2F-Lat86IaVPAkBT1wu0o2%2FTimer-01-New.png?generation=1553589369059605&alt=media)	
	
>4,停止Timer
	
	停止Timer，只是简单的把Timer从系统协程中移除。函数主要实现如下：

	func (t *Timer) Stop() bool {
	    return stopTimer(&t.r)
	}
	
	stopTimer()即通知系统协程把该Timer移除，即不再监控。系统协程只是移除Timer并不会关闭管道，以避免用户协程读取错误。
	系统协程监控Timer是否需要触发，Timer触发后，系统协程会删除该Timer。所以在Stop()执行时有两种情况：
	
	Timer还未触发，系统协程已经删除该Timer，Stop()返回false；
	Timer已经触发，系统协程还未删除该Timer，Stop()返回true;
	
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-Lat85FATVT40BgO76_T%2F-Lat86IcK2oL1YyZPnrp%2FTimer-02-Stop.png?generation=1553589369106368&alt=media)	
	
>5,重置Timer
	
	重置Timer时会先timer先从系统协程中删除，修改新的时间后重新添加到系统协程中。
	
	重置函数主要实现如下所示：
	
	func (t *Timer) Reset(d Duration) bool {
	    w := when(d)
	    active := stopTimer(&t.r)
	    t.r.when = w
	    startTimer(&t.r)
	    return active
	}
	
	其返回值与Stop()保持一致，即如果Timer成功停止，则返回true，如果Timer已经触发，则返回false。
	
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-Lat85FATVT40BgO76_T%2F-Lat86IeTBCRMh51FMEj%2FTimer-03-Reset.png?generation=1553589369060464&alt=media)
	
	由于新加的Timer时间很可能变化，所以其在系统协程的位置也会发生变化。

	需要注意的是，按照官方说明，Reset()应该作用于已经停掉的Timer或者已经触发的Timer，按照这个约定其返回值将总是返回false，之所以仍然保留是为了保持向前兼容，使用老版本Go编写的应用不需要因为Go升级而修改代码。

	如果不按照此约定使用Reset()，有可能遇到Reset()和Timer触发同时执行的情况，此时有可能会收到两个事件，从而对应用程序造成一些负面影响，使用时一定要注意。
	
	
>6,Ticker数据结构

	Ticker数据结构与Timer除名字不同外完全一样。
	type Ticker struct {
	    C <-chan Time // The channel on which the ticks are delivered.
	    r runtimeTimer
	}
	
	Ticker只有两个成员：
	C: 管道，上层应用跟据此管道接收事件；
	r: runtime定时器，该定时器即系统管理的定时器，对上层应用不可见；
	这里应该按照层次来理解Ticker数据结构，Ticker.C即面向Ticker用户的，Ticker.r是面向底层的定时器实现。
	
	runtimeTimer底层协程管理，和timer一致

>7,Ticker原理分析
	
	创建Ticker（runtimer托管到startTImer） -->停止停止(从runtime协程中删除)


>8,创建Ticker
	
    我们来看创建Ticker的实现，非常简单：
		
		func NewTicker(d Duration) *Ticker {
		    if d <= 0 {
		        panic(errors.New("non-positive interval for NewTicker"))
		    }
		    // Give the channel a 1-element time buffer.
		    // If the client falls behind while reading, we drop ticks
		    // on the floor until the client catches up.
		    c := make(chan Time, 1)
		    t := &Ticker{
		        C: c,
		        r: runtimeTimer{
		            when:   when(d),
		            period: int64(d), // Ticker跟Timer的重要区就是提供了period这个参数，据此决定timer是一次性的，还是周期性的
		            f:      sendTime,
		            arg:    c,
		        },
		    }
		    startTimer(&t.r)
		    return t
		}
			
			
	NewTicker()只是构造了一个Ticker，然后把Ticker.r通过startTimer()交给系统协程维护。
	其中period为事件触发的周期。
	
	其中sendTime()方法便是定时器触发时的动作：
	func sendTime(c interface{}, seq uintptr) {
	    select {
	    case c.(chan Time) <- Now():
	    default:
	    }
	}	
	
	sendTime接收一个管道作为参数，其主要任务是向管道中写入当前时间。
	创建Ticker时生成的管道含有一个缓冲区（make(chan Time, 1)），但是Ticker触发的事件确是周期性的，如果管道中的数据没有被取走，那么sendTime()也不会阻塞，而是直接退出，带来的后果是本次事件会丢失。
	
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-Lca1MRjsDT5E4Ag3hTc%2F-Lca1Q58I-DXzdUCnFXj%2FTicker-01-New.png?generation=1555416342481077&alt=media)

	
	
>9,	停止Ticker
	
	停止Ticker，只是简单的把Ticker从系统协程中移除。函数主要实现如下：
	func (t *Ticker) Stop() {
	    stopTimer(&t.r)
	}
	
	stopTicker()即通知系统协程把该Ticker移除，即不再监控。系统协程只是移除Ticker并不会关闭管道，以避免用户协程读取错误。
	与Timer不同的是，Ticker停止时没有返回值，即不需要关注返回值，实际上返回值也没啥用途。
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-Lca1MRjsDT5E4Ag3hTc%2F-Lca1Q5AjUFXDa6KR1fh%2FTicker-02-Stop.png?generation=1555416342556979&alt=media)	
	
	Ticker没有重置接口，也即Ticker创建后不能通过重置修改周期。
	需要格外注意的是Ticker用完后必须主动停止，否则会产生资源泄露，会持续消耗CPU资源。
	
	
>10,一次性定时器Timer和周期性定时器Ticker系统协程是如何管理这些定器
	
	前面我们介绍了一次性定时器Timer和周期性定时器Ticker，这两种定时器内部实现机制完全相同。创建定时器的协程并不负责计时，而是把任务交给系统协程，系统协程统一处理所有的定时器。
	本节，我们重点关注系统协程是如何管理这些定器的，包括以下问题：
	定时器使用什么数据结构存储？
	定时器如何触发事件？
	定时器如何添加进系统协程？
	定时器如何从系统协程中删除？
	

>11,timer定时器存储结构
	
	Timer和Ticker数据结构除名字外完全一样，二者都含有一个runtimeTimer类型的成员，这个就是系统协程所维护的对象。 runtimeTimer类型是time包的名称，在runtime包中，这个类型叫做timer。
(1),timer数据结构
	
	runtimer的结构为timer
	type timer struct {
	    tb *timersBucket // the bucket the timer lives in   // 当前定时器寄存于系统timer堆的地址
	    i  int           // heap index                      // 当前定时器寄存于系统timer堆的下标
	
	    when   int64                                        // 当前定时器下次触发时间
	    period int64                                        // 当前定时器周期触发间隔（如果是Timer，间隔为0，表示不重复触发）
	    f      func(interface{}, uintptr)                 // 定时器触发时执行的函数
	    arg    interface{}                                // 定时器触发时执行函数传递的参数一
	    seq    uintptr                                     // 定时器触发时执行函数传递的参数二(该参数只在网络收发场景下使用)
	}	
	
	其中timersBucket便是系统协程存储timer的容器，里面有个切片来存储timer，而i便是timer所在切片的下标。
	
(2),timersBucket数据结构
	
	type timersBucket struct {
	    lock         mutex
	    gp           *g          // 处理堆中事件的协程
	    created      bool        // 事件处理协程是否已创建，默认为false，添加首个定时器时置为true
	    sleeping     bool        // 事件处理协程（gp）是否在睡眠(如果t中有定时器，还未到触发的时间，那么gp会投入睡眠)
	    rescheduling bool        // 事件处理协程（gp）是否已暂停（如果t中定时器均已删除，那么gp会暂停）
	    sleepUntil   int64       // 事件处理协程睡眠时间
	    waitnote     note        // 事件处理协程睡眠事件（据此唤醒协程）
	    t            []*timer    // 定时器切片
	}
	
	timersBucket为存储time的结构
	lock: 互斥锁，在timer增加和删除时需要使用；
	gp: 事件处理协程，就是我们所说的系统协程，这个协程在首次创建Timer或Ticker时生成；
	create： 状态值，表示系统协程是否创建；
	sleeping: 系统协程是否在睡眠；
	rescheduling: 系统协程是否已暂停；
	sleepUntil: 系统协程睡眠到指定的时间（如果有新的定时任务可能会提前唤醒）；
	waitnote: 提前唤醒时使用的通知；
	t: 保存timer的切片，当调用NewTimer()或NewTicker()时便会有新的timer存到此切片中；
	看到这里应该能明白，系统协程在首次创建定时器时创建，定时器存储在切片中，系统协程负责计时并维护这个切片。
	
（3）,	存储拓扑

	以Ticker为例，我们回顾一下Ticker、timer和timersBucket关系，假设我们已经创建了3个Ticker，那么它们之间的关系如下：
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-Lgg6levA56pXSpK8AKu%2F-Lgg6nY4FZdXEYiKHyOp%2Ftimerproc-01-timersBucket.png?generation=1559813373709483&alt=media)	

	用户创建Ticker时会生成一个timer，这个timer指向timersBucket，timersBucket记录timer的指针。
	
	
（4），timersBucket数组
	
	通过timersBucket数据结构可以看到，系统协程负责计时并维护其中的多个timer，一个timersBucket包含一个系统协程。	
	当系统中定时器非常多时，一个系统协程可能处理能力跟不上，所以Go在实现时实际上提供了多个timersBucket，也就有多个系统协程来处理定时器。
	最理想的情况，应该预留GOMAXPROCS个timersBucket，以便充分使用CPU资源，但需要跟据实际环境动态分配。为了实现简单，Go在实现时预留了64个timersBucket，绝大部分场景下这些足够了。
	
	每当协程创建定时器时，使用协程所属的ProcessID%64来计算定时器存入的timersBucket
	
	const timersLen = 64

	func (t *timer) assignBucket() *timersBucket {
		id := uint8(getg().m.p.ptr().id) % timersLen
		t.tb = &timers[id].timersBucket
		return t.tb
	}

	
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-Lgg6levA56pXSpK8AKu%2F-Lgg6nY62FpIgh6J8_w1%2Ftimerproc-02-BucketArray.png?generation=1559813373866057&alt=media)

	为描述方便，上图中3个协程均分布于3个Process中。
	一般情况下，同一个Process的协程创建的定时器分布于同一个timersBucket中，只有当GOMAXPROCS大于64时才会出现多个Process分布于同一个timersBucket中。
	

>12,定时器运行机制
	
	看完上面的数据结构，了解了timer是如何存储的。现在开始探究定时器内部运作机制。

	回顾一下定时器创建过程，创建Timer或Ticker实际上分为两步： 1. 创建一个管道 2. 创建一个timer并启动（注意此timer不是Timer，而是系统协程所管理的timer。）
	首先，每个timer都必须要归属于某个timersBucket的，所以第一步是先选择一个timersBucket，选择的算法很简单，将当前协程所属的Processor ID 与timersBucket数组长度求模，结果就是timersBucket数组的下标。
	
	const timersLen = 64
	var timers [timersLen]struct { // timersBucket数组，长度为64
	    timersBucket
	}
	func (t *timer) assignBucket() *timersBucket {
	    id := uint8(getg().m.p.ptr().id) % timersLen // Processor ID 与数组长度求模，得到下标
	    t.tb = &timers[id].timersBucket
	    return t.tb
	}	
	
	至此，第一步，给当前的timer选择一个timersBucket已经完成。
	其次，每个timer都必须要加入到timersBucket中。前面我们知道，timersBucket中切片中保存着timer的指针，新加入的timer并不是按加入时间顺序存储的，而是把timer按照触发的时间排序的一个小头堆。那么timer加入timersBucket的过程实际上也是堆排序的过程，只不过这个排序是指的是新加元素后的堆调整过程。
	
	func (tb *timersBucket) addtimerLocked(t *timer) bool {
	    if t.when < 0 {
	        t.when = 1<<63 - 1
	    }
	    t.i = len(tb.t)                 // 先把定时器插入到堆尾
	    tb.t = append(tb.t, t)          // 保存定时器
	    if !siftupTimer(tb.t, t.i) {    // 堆中插入数据，触发堆重新排序
	        return false
	    }
	    if t.i == 0 { // 堆排序后，发现新插入的定时器跑到了栈顶，需要唤醒协程来处理
	        // siftup moved to top: new earliest deadline.
	        if tb.sleeping {                 // 协程在睡眠，唤醒协程来处理新加入的定时器
	            tb.sleeping = false
	            notewakeup(&tb.waitnote)
	        }
	        if tb.rescheduling {             // 协程已暂停，唤醒协程来处理新加入的定时器
	            tb.rescheduling = false
	            goready(tb.gp, 0)
	        }
	    }
	    if !tb.created {       // 如果是系统首个定时器，则启动协程处理堆中的定时器
	        tb.created = true
	        go timerproc(tb)
	    }
	    return true
	}
	
	下图展示一个小顶堆结构，图中每个圆圈代表一个timer，圆圈中的数字代表距离触发事件的秒数，圆圈外的数字代表其在切片中的下标。其中timer 15是新加入的，加入后它被最终调整到数组的1号下标。
	
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-Lgg6levA56pXSpK8AKu%2F-Lgg6nY9ZSXHHKoG_N-w%2Ftimerproc-03-heap.png?generation=1559813373790978&alt=media)	
	
	上图展示的是二叉堆，实际上Go实现时使用的是四叉堆，使用四叉堆的好处是堆的高度降低，堆调整时更快。
	
	
>13,删除定时器
	
	当Timer执行结束或Ticker调用Stop()时会触发定时器的删除。从timersBucket中删除定时器是添加定时器的逆过程，即堆中元素删除后，触发堆调整。在此不再细述。	
	
	
>14,timerproc系统协程也就是runtimer
	
	timerproc为系统协程的具体实现。它是在首次创建定时器创建并启动的，一旦启动永不销毁。 如果timersBucket中有定时器，取出堆顶定时器，计算睡眠时间，然后进入睡眠，醒来后触发事件。
	某个timer的事件触发后，跟据其是否是周期性定时器来决定将其删除还是修改时间后重新加入堆。
	
	如果堆中已没有事件需要触发，则系统协程将进入暂停态，也可认为是无限时睡眠，直到有新的timer加入才会被唤醒。	
>15,资源泄露问题

	前面介绍Ticker时格外提醒不使用的Ticker需要显式的Stop()，否则会产生资源泄露。研究过timer实现机制后，可以很好的解释这个问题了。首先，创建Ticker的协程并不负责计时，只负责从Ticker的管道中获取事件； 其次，系统协程只负责定时器计时，向管道中发送事件，并不关心上层协程如何处理事件；如果创建了Ticker，则系统协程将持续监控该Ticker的timer，定期触发事件。如果Ticker不再使用且没有Stop()，那么系统协程负担会越来越重，最终将消耗大量的CPU资源。	
	
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 

#十九，epoll原理详解 --多路复用IO 
>简介
	
	appche  --一请求一线程
	信号 ---sigio，udp


>1,epoll详解
	
	epoll是Linux内核为处理大批量文件描述符而作了改进的poll，是Linux下多路复用IO接口select/poll的增强版本，它能显著提高程序在大量并发连接中只有少量活跃的情况下的系统CPU利用率。另一点原因就是获取事件的时候，它无须遍历整个被侦听的描述符集，只要遍历那些被内核IO事件异步唤醒而加入Ready队列的描述符集合就行了。epoll除了提供select/poll那种IO事件的水平触发（Level Triggered）外，还提供了边缘触发（Edge Triggered），这就使得用户空间程序有可能缓存IO状态，减少epoll_wait/epoll_pwait的调用，提高应用程序效率。
	Level-triggered(LT) 水平触发 一直触发
	edge-triggered(ET) 边缘触发  一次触发   用户空间程序有可能缓存IO状态减少epoll_wait/epoll_pwait的调用
	

>2,	golang封装epoll
	
	（1）,创建
	
		func epollcreate(size int32) int32
		func epollcreate1(flags int32) int32
		
		TEXT runtime·epollcreate1(SB),NOSPLIT,$0
			MOVL    $329, AX
			MOVL	flags+0(FP), BX
			INVOKE_SYSCALL
			MOVL	AX, ret+4(FP)
			RET
		epollcreate() 可以创建一个epoll实例。在linux 内核版本大于2.6.8 后，这个size 参数就被弃用了，但是传入的值必须大于0。这里引用了互联网上的一句话
		
		在 epollcreate() 的最初实现版本时， size参数的作用是创建epoll实例时候告诉内核需要使用多少个文件描述符。内核会使用 size 的大小去申请对应的内存(如果在使用的时候超过了给定的size， 内核会申请更多的空间)。现在，这个size参数不再使用了（内核会动态的申请需要的内存）。但要注意的是，这个size必须要大于0，为了兼容旧版的linux 内核的代码。
		epollcreate1() 如果flags的值是0，epollcreate1()等同于epollcreate()除了过时的size被遗弃了。当然flasg可以使用_EPOLL_CLOEXEC = 0x80000。
	
	
	（2）,设置epoll事件
	
		func epollctl(epfd, op, fd int32, ev *epollevent) int32

		// sys_linux_386.s
		TEXT runtime·epollctl(SB),NOSPLIT,$0
			MOVL	$255, AX
			MOVL	epfd+0(FP), BX
			MOVL	op+4(FP), CX
			MOVL	fd+8(FP), DX
			MOVL	ev+12(FP), SI
			INVOKE_SYSCALL
			MOVL	AX, ret+16(FP)
			RET
		
		第一个参数epfd指向epoll的实例，op 添加事件的类型 fd是要注册的目标文件描述符，ev 是关联指定的描述符
		
		op 的枚举值:
		
		_EPOLL_CTL_ADD = 0x1 //在epfd中注册指定的fd文件描述符并能把event和fd关联起来。
		_EPOLL_CTL_MOD = 0x3 //改变 fd和evetn之间的联系。
		_EPOLL_CTL_DEL = 0x2 //从指定的epfd中删除fd文件描述符。在这种模式中event是被忽略的，并且为可以等于nil。
		event 结构
		
		type epollevent struct {
			events uint32
			data   [8]byte // to match amd64
	}
	
	
	(3),等待epoll事件

		func epollwait(epfd int32, ev *epollevent, nev, timeout int32) int32
		
		TEXT runtime·epollwait(SB),NOSPLIT,$0
			MOVL	$256, AX
			MOVL	epfd+0(FP), BX
			MOVL	ev+4(FP), CX
			MOVL	nev+8(FP), DX
			MOVL	timeout+12(FP), SI
			INVOKE_SYSCALL
			MOVL	AX, ret+16(FP)
			RET
		epollwait 这个系统调用是用来返回epfd中的就绪的G。events指向调用者可以使用的事件的内存区域。nev告知内核有多少个events，必须要大于0，timeout 指定超时时间。

>3,golang 网络轮循器的代码实现

	func netpoll(block bool) *g {
		if epfd == -1 {
			return nil
		}
		waitms := int32(-1)
		if !block {
			waitms = 0
		}
		var events [128]epollevent
	retry:
		n := epollwait(epfd, &events[0], int32(len(events)), waitms)
		if n < 0 {
			if n != -_EINTR {
				println("runtime: epollwait on fd", epfd, "failed with", -n)
				throw("epollwait failed")
			}
			goto retry
		}
		var gp guintptr
		for i := int32(0); i < n; i++ {
			ev := &events[i]
			if ev.events == 0 {
				continue
			}
			var mode int32
			if ev.events&(_EPOLLIN|_EPOLLRDHUP|_EPOLLHUP|_EPOLLERR) != 0 {
				mode += 'r'
			}
			if ev.events&(_EPOLLOUT|_EPOLLHUP|_EPOLLERR) != 0 {
				mode += 'w'
			}
			if mode != 0 {
				pd := *(**pollDesc)(unsafe.Pointer(&ev.data))
	
				netpollready(&gp, pd, mode)
			}
		}
		if block && gp == 0 {
			goto retry
		}
		return gp.ptr()
	}

>4,evio库分析
	
	比net/io快很多
	https://github.com/tidwall/evio
	https://blog.csdn.net/linux_Allen/article/details/99684013

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 

#二十，select原理详解	--多复用IO
	
>1,select简介
	
	Go 的select语句是一种仅能用于channl发送和接收消息的专用语句，此语句运行期间是阻塞的；当select中没有case语句的时候，会阻塞当前的groutine。所以，有人也会说select是用来阻塞监听goroutine的。	


>2,select的数据结构体：
	
	elect这个语句底层实现实际上主要由两部分组成：case语句和执行函数。
	
	type scase struct {
	    c           *hchan         // chan
	    elem        unsafe.Pointer // 读或者写的缓冲区地址
	    kind        uint16   //case语句的类型，是default、传值写数据(channel <-) 还是  取值读数据(<- channel)
	    pc          uintptr // race pc (for race detector / msan)
	    releasetime int64
	}
	
	scase.c为当前case语句所操作的channel指针，这也说明了一个case语句只能操作一个channel。
	scase.kind表示该case的类型，分为读channel、写channel和default，三种类型分别由常量定义：
	caseRecv：case语句中尝试读取scase.c中的数据；
	caseSend：case语句中尝试向scase.c中写入数据；
	caseDefault： default语句
	scase.elem表示缓冲区地址，跟据scase.kind不同，有不同的用途：
	scase.kind == caseRecv ： scase.elem表示读出channel的数据存放地址；
	scase.kind == caseSend ： scase.elem表示将要写入channel的数据存放地址；
	
	
![结构体](https://upload-images.jianshu.io/upload_images/6328562-6c62e61728f7be97.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/800)	

	
	selectgo函数的作用：
		（1),打乱数组中的scase顺序
		 (2),锁住其中所有饿channel
		（3）,遍历所有的channel，查看是否可读可写
		 (4),如果其中的channel可读或者可写，则解锁所有channel，并返回对应的channel数据
		 (5),假如没有channel可读或者可写，但是有default语句，则同上:返回default语句对应的scase并解锁所有的channel。
		 (6),假如既没有channel可读或者可写，也没有default语句，则将当前运行的groutine阻塞，并加入到当前所有channel的等待队列中去。
		(7),然后解锁所有channel，等待被唤醒。
		(8),此时如果有个channel可读或者可写ready了，则唤醒，并再次加锁所有channel，
		(9),遍历所有channel找到那个对应的channel和G，唤醒G，并将没有成功的G从所有channel的等待队列中移除。


>3,select逻辑实现
	
	hchan，它是channel的指针。在一个select中，所有的case语句会构成一个scase结构体的数组。	
	select语句实际上就是调用func selectgo(cas0 *scase, order0 *uint16, ncases int) (int, bool)函数。
		
    cas0 为上文提到的case语句抽象出的结构体scase数组的第一个元素地址
    order0为一个两倍cas0数组长度的buffer，保存scase随机序列pollorder和scase中channel地址序列lockorder。
    	pollorder：每次selectgo执行都会把scase序列打乱，以达到随机检测case的目的。
		lockorder：所有case语句中channel序列，以达到去重防止对channel加锁时重复加锁的目的。
    nncases表示scase数组的长度
		
		函数返回值： 1. int： 选中case的编号，这个case编号跟代码一致 2. bool: 是否成功从channle中读取了数据，如果选中的case是从channel中读数据，则该返回值表示是否读取成功。
	
		
		
		

	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 

#二十一,调度器之GMP模型

原理分析GMP
https://www.cnblogs.com/sunsky303/p/9705727.html
https://www.jianshu.com/p/790384768317

>1,并发并行和GMP代表的意思
	
	并发，逻辑上具有处理多个同时性任务的能力
	并行，物理上同一时刻执行多个并发任务
	M machine：是内核线程
	P processor: 是调度协调，用于协调M和G的执行，内核线程只有拿到了 P才能对goroutine继续调度执行，一般都是通过限定P的个数来控制golang的并发度
	G goroutine: 是待执行的goroutine，包含这个goroutine的栈空间
	
	G-P-M 的内存申请，并发发生在用户态，效率更高 G可以向P申请内存，G必须绑定P P管理G。G通过P最终在M执行
	

>2,Go调度器组成 -G 
	
	G是Goroutine的缩写，相当于操作系统中的进程控制块，在这里就是Goroutine的控制结构，是对Goroutine的抽象。其中包括执行的函数指令及参数；G保存的任务对象；线程上下文切换，现场保护和现场恢复需要的寄存器(SP、IP)等信息。
	
	Go不同版本Goroutine默认栈大小不同。

	// Go1.11版本默认stack大小为2KB
	
	_StackMin = 2048
	 
	// 创建一个g对象,然后放到g队列
	// 等待被执行
	func newproc1(fn *funcval, argp *uint8, narg int32, callergp *g, callerpc uintptr) {
	    _g_ := getg()
	
	    _g_.m.locks++
	    siz := narg
	    siz = (siz + 7) &^ 7
	
	    _p_ := _g_.m.p.ptr()
	    newg := gfget(_p_)    
	    if newg == nil {        
	       // 初始化g stack大小
	        newg = malg(_StackMin)
	        casgstatus(newg, _Gidle, _Gdead)
	        allgadd(newg)
	    }    
	    // 以下省略}
	
	

>3,Go调度器组成-M
		
	M是一个线程或称为Machine，所有M是有线程栈的。如果不对该线程栈提供内存的话，系统会给该线程栈提供内存(不同操作系统提供的线程栈大小不同)。当指定了线程栈，则M.stack→G.stack，M的PC寄存器指向G提供的函数，然后去执行。
		
		type m struct {    
    /*
        1.  所有调用栈的Goroutine,这是一个比较特殊的Goroutine。
        2.  普通的Goroutine栈是在Heap分配的可增长的stack,而g0的stack是M对应的线程栈。
        3.  所有调度相关代码,会先切换到该Goroutine的栈再执行。
    */
    g0       *g
    curg     *g         // M当前绑定的结构体G

    // SP、PC寄存器用于现场保护和现场恢复
    vdsoSP uintptr
    vdsoPC uintptr

    // 省略…}
	



>4,Go调度器组成-P

	P(Processor)是一个抽象的概念，并不是真正的物理CPU。所以当P有任务时需要创建或者唤醒一个系统线程来执行它队列里的任务。所以P/M需要进行绑定，构成一个执行单元。

	P决定了同时可以并发任务的数量，可通过GOMAXPROCS限制同时执行用户级任务的操作系统线程。可以通过runtime.GOMAXPROCS进行指定。在Go1.5之后GOMAXPROCS被默认设置可用的核数，而之前则默认为1。
		// 自定义设置GOMAXPROCS数量

	func GOMAXPROCS(n int) int {    
	    /*
	        1.  GOMAXPROCS设置可执行的CPU的最大数量,同时返回之前的设置。
	        2.  如果n < 1,则不更改当前的值。
	    */
	    ret := int(gomaxprocs)
	
	    stopTheWorld("GOMAXPROCS")    
	    // startTheWorld启动时,使用newprocs。
	    newprocs = int32(n)
	    startTheWorld()    
	    return ret
	}
	
	// 默认P被绑定到所有CPU核上
	// P == cpu.cores
	
	func getproccount() int32 {    
	    const maxCPUs = 64 * 1024
	    var buf [maxCPUs / 8]byte
	
	
	    // 获取CPU Core
	    r := sched_getaffinity(0, unsafe.Sizeof(buf), &buf[0])
	
	    n := int32(0)    
	    for _, v := range buf[:r] {        
	       for v != 0 {
	            n += int32(v & 1)
	            v >>= 1
	        }
	    }    
	    if n == 0 {
	       n = 1
	    }    
	    return n
	}
	// 一个进程默认被绑定在所有CPU核上,返回所有CPU core。
	// 获取进程的CPU亲和性掩码系统调用
	// rax 204                          ; 系统调用码
	// system_call sys_sched_getaffinity; 系统调用名称
	// rid  pid                         ; 进程号
	// rsi unsigned int len             
	// rdx unsigned long *user_mask_ptr
	sys_linux_amd64.s:
	TEXT runtime·sched_getaffinity(SB),NOSPLIT,$0
	    MOVQ    pid+0(FP), DI
	    MOVQ    len+8(FP), SI
	    MOVQ    buf+16(FP), DX
	    MOVL    $SYS_sched_getaffinity, AX
	    SYSCALL
	    MOVL    AX, ret+24(FP)
	    RET
		


>5,Go调度器调度过程
	
	首先创建一个G对象，G对象保存到P本地队列或者是全局队列。P此时去唤醒一个M。P继续执行它的执行序。M寻找是否有空闲的P，如果有则将该G对象移动到它本身。接下来M执行一个调度循环(调用G对象->执行->清理线程→继续找新的Goroutine执行)。

	M执行过程中，随时会发生上下文切换。当发生上线文切换时，需要对执行现场进行保护，以便下次被调度执行时进行现场恢复。Go调度器M的栈保存在G对象上，只需要将M所需要的寄存器(SP、PC等)保存到G对象上就可以实现现场保护。当这些寄存器数据被保护起来，就随时可以做上下文切换了，在中断之前把现场保存起来。如果此时G任务还没有执行完，M可以将任务重新丢到P的任务队列，等待下一次被调度执行。当再次被调度执行时，M通过访问G的vdsoSP、vdsoPC寄存器进行现场恢复(从上次中断位置继续执行)。


![go调度内部图](https://upload-images.jianshu.io/upload_images/5006907-1d97b4031894979b.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1000)
	
	（1）、P 队列
	通过上图可以发现，P有两种队列：本地队列和全局队列。

    本地队列： 当前P的队列，本地队列是Lock-Free，没有数据竞争问题，无需加锁处理，可以提升处理速度。

    全局队列：全局队列为了保证多个P之间任务的平衡。所有M共享P全局队列，为保证数据竞争问题，需要加锁处理。相比本地队列处理速度要低于全局队列。

	（2）,上线文切换

	简单理解为当时的环境即可，环境可以包括当时程序状态以及变量状态。例如线程切换的时候在内核会发生上下文切换，这里的上下文就包括了当时寄存器的值，把寄存器的值保存起来，等下次该线程又得到cpu时间的时候再恢复寄存器的值，这样线程才能正确运行。

	对于代码中某个值说，上下文是指这个值所在的局部(全局)作用域对象。相对于进程而言，上下文就是进程执行时的环境，具体来说就是各个变量和数据，包括所有的寄存器变量、进程打开的文件、内存(堆栈)信息等。
	
	(3),线程清理
	Goroutine被调度执行必须保证P/M进行绑定，所以线程清理只需要将P释放就可以实现线程的清理。什么时候P会释放，保证其它G可以被执行。P被释放主要有两种情况。

    主动释放：最典型的例子是，当执行G任务时有系统调用，当发生系统调用时M会处于Block状态。调度器会设置一个超时时间，当超时时会将P释放。

    被动释放：如果发生系统调用，有一个专门监控程序，进行扫描当前处于阻塞的P/M组合。当超过系统程序设置的超时时间，会自动将P资源抢走。去执行队列的其它G任务。


>6,goroutine数据结构 

	type g struct {
	  stack       stack   // 描述了真实的栈内存，包括上下界
	
	  m              *m     // 当前的m
	  sched          gobuf   // goroutine切换时，用于保存g的上下文      
	  param          unsafe.Pointer // 用于传递参数，睡眠时其他goroutine可以设置param，唤醒时该goroutine可以获取
	  atomicstatus   uint32
	  stackLock      uint32 
	  goid           int64  // goroutine的ID
	  waitsince      int64 // g被阻塞的大体时间
	  lockedm        *m     // G被锁定只在这个m上运行
	}
	
	其中最主要的当然是sched了，保存了goroutine的上下文。goroutine切换的时候不同于线程有OS来负责这部分数据，而是由一个gobuf对象来保存，这样能够更加轻量级，再来看看gobuf的结构：
	
	type gobuf struct {
	    sp   uintptr
	    pc   uintptr
	    g    guintptr
	    ctxt unsafe.Pointer
	    ret  sys.Uintreg
	    lr   uintptr
	    bp   uintptr // for GOEXPERIMENT=framepointer
	}

	其实就是保存了当前的栈指针，计数器，当然还有g自身，这里记录自身g的指针是为了能快速的访问到goroutine中的信息。
	
	
>7,M：代表一个线程，每次创建一个M的时候，都会有一个底层线程创建；所有的G任务，最终还是在M上执行
	
	其主要数据结构：
		
	type m struct {
	    g0      *g     // 带有调度栈的goroutine，goroutine实现线程栈
	
	    gsignal       *g         // 处理信号的goroutine
	    tls           [6]uintptr // thread-local storage
	    mstartfn      func()
	    curg          *g       // 当前运行的goroutine
	    caughtsig     guintptr 
	    p             puintptr // 关联p和执行的go代码
	    nextp         puintptr
	    id            int32
	    mallocing     int32 // 状态
	
	    spinning      bool // m是否out of work
	    blocked       bool // m是否被阻塞
	    inwb          bool // m是否在执行写屏蔽
	
	    printlock     int8
	    incgo         bool // m在执行cgo吗
	    fastrand      uint32
	    ncgocall      uint64      // cgo调用的总数
	    ncgo          int32       // 当前cgo调用的数目
	    park          note
	    alllink       *m // 用于链接allm
	    schedlink     muintptr
	    mcache        *mcache // 当前m的内存缓存
	    lockedg       *g // 锁定g在当前m上执行，而不会切换到其他m
	    createstack   [32]uintptr // thread创建的栈
	}
	
	结构体M中有两个G是需要关注一下的，一个是curg，代表结构体M当前绑定的结构体G。另一个是g0，是带有调度栈的goroutine，这是一个比较特殊的goroutine。普通的goroutine的栈是在堆上分配的可增长的栈，而g0的栈是M对应的线程的栈。所有调度相关的代码，会先切换到该goroutine的栈中再执行。也就是说线程的栈也是用的g实现，而不是使用的OS的。


>8,P：代表一个处理器
	
	每一个运行的M都必须绑定一个P，就像线程必须在么一个CPU核上执行一样，由P来调度G在M上的运行，P的个数就是GOMAXPROCS（最大256），启动时固定的，一般不修改；M的个数和P的个数不一定一样多（会有休眠的M或者不需要太多的M）（最大10000）；每一个P保存着本地G任务队列，也有一个全局G任务队列。P的数据结构：
	
	type p struct {
	    lock mutex
	
	    id          int32
	    status      uint32 // 状态，可以为pidle/prunning/...
	    link        puintptr
	    schedtick   uint32     // 每调度一次加1
	    syscalltick uint32     // 每一次系统调用加1
	    sysmontick  sysmontick 
	    m           muintptr   // 回链到关联的m
	    mcache      *mcache
	    racectx     uintptr
	
	    goidcache    uint64 // goroutine的ID的缓存
	    goidcacheend uint64
	
	    // 可运行的goroutine的队列
	    runqhead uint32
	    runqtail uint32
	    runq     [256]guintptr
	
	    runnext guintptr // 下一个运行的g
	
	    sudogcache []*sudog
	    sudogbuf   [128]*sudog
	
	    palloc persistentAlloc // per-P to avoid mutex
		
		pad [sys.CacheLineSize]byte
	 }
	 
	 
	 其中P的状态有Pidle, Prunning, Psyscall, Pgcstop, Pdead；在其内部队列runqhead里面有可运行的goroutine，P优先从内部获取执行的g，这样能够提高效率。

>>全局调度着就是schedt，可以看做是一个全局的调度者：

	type schedt struct {
	   goidgen  uint64
	    lastpoll uint64
	
	    lock mutex
	
	    midle        muintptr // idle状态的m
	    nmidle       int32    // idle状态的m个数
	    nmidlelocked int32    // lockde状态的m个数
	    mcount       int32    // 创建的m的总数
	    maxmcount    int32    // m允许的最大个数
	
	    ngsys uint32 // 系统中goroutine的数目，会自动更新
	
	    pidle      puintptr // idle的p
	    npidle     uint32
	    nmspinning uint32 
	
	    // 全局的可运行的g队列
	    runqhead guintptr
	    runqtail guintptr
	    runqsize int32
	
	    // dead的G的全局缓存
	    gflock       mutex
	    gfreeStack   *g
	    gfreeNoStack *g
	    ngfree       int32
	
	    // sudog的缓存中心
	    sudoglock  mutex
	    sudogcache *sudog
	}

	大多数需要的信息都已放在了结构体M、G和P中，schedt结构体只是一个壳。可以看到，其中有M的idle队列，P的idle队列，以及一个全局的就绪的G队列。schedt结构体中的Lock是非常必须的，如果M或P等做一些非局部的操作，它们一般需要先锁住调度器。
	
>9,go运行过程
	
	（1），newproc函数创建	goroutine结构
		func newproc1(fn *funcval, argp *uint8, narg int32, nret int32, callerpc uintptr) *g {
		    newg = malg(_StackMin)
		    casgstatus(newg, _Gidle, _Gdead)
		    allgadd(newg) 
		    newg.sched.sp = sp
		    newg.stktopsp = sp
		    newg.sched.pc = funcPC(goexit) + sys.PCQuantum 
		    newg.sched.g = guintptr(unsafe.Pointer(newg))
		    gostartcallfn(&newg.sched, fn)
		    newg.gopc = callerpc
		    newg.startpc = fn.fn
		    ......
		}
		
		分配一个g的结构体
		初始化这个结构体的一些域
		将g挂在就绪队列
		绑定g到一个m上
		
			
	 (2),M创建
	 		
	 		这个绑定只要m没有突破上限GOMAXPROCS,就拿一个m绑定一个g。如果m的waiting队列中有就从队列中拿,否则就要新建一个m,调用newm。
		func newm(fn func(), _p_ *p) {
		    mp := allocm(_p_, fn)
		    mp.nextp.set(_p_)
		    mp.sigmask = initSigmask
		    execLock.rlock()
		    newosproc(mp, unsafe.Pointer(mp.g0.stack.hi))
		    execLock.runlock()
		}
		该函数其实就是创建一个m，跟newproc有些相似，之前也说了m在底层就是一个线程的创建，也即是newosproc函数，在往下挖可以看到会根据不同的OS来执行不同的bsdthread_create函数，而底层就是调用的runtime.clone：
		
		m创建好之后，线程的入口是mstart，最后调用的即是mstart1：
			
			func mstart1() {
			    _g_ := getg()
			    gosave(&_g_.m.g0.sched)
			    _g_.m.g0.sched.pc = ^uintptr(0)
			    asminit()
			    minit()
			
			    if _g_.m == &m0 {
			        initsig(false)
			    }
			
			    if fn := _g_.m.mstartfn; fn != nil {
			        fn()
			    }
			    schedule()
			}
		
		里面最重要的就是schedule了，在schedule中的动作大体就是找到一个等待运行的g，然后然后搬到m上，设置其状态为Grunning,直接切换到g的上下文环境,恢复g的执行。		
		func schedule() {
		    _g_ := getg()
		
		    if _g_.m.lockedg != nil {
		        stoplockedm()
		        execute(_g_.m.lockedg, false) // Never returns.
		    }
		}
		
		chedule函数获取g => [必要时休眠] => [唤醒后继续获取] => execute函数执行g => 执行后返回到goexit => 重新执行schedule函数
			
			

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 

#二十二,channel原理详解

>1,chan作用
	
	channel是Golang在语言层面提供的goroutine间的通信方式，比Unix管道更易用也更轻便。channel主要用于进程内各goroutine间通信，如果需要跨进程通信，建议使用分布式系统的方法来解决。

>2,chan数据结构
	
	type hchan struct {
	    qcount   uint           // 当前队列中剩余元素个数
	    dataqsiz uint           // 环形队列长度，即可以存放的元素个数
	    buf      unsafe.Pointer // 环形队列指针
	    elemsize uint16         // 每个元素的大小
	    closed   uint32            // 标识关闭状态
	    elemtype *_type         // 元素类型
	    sendx    uint           // 队列下标，指示元素写入时存放到队列中的位置
	    recvx    uint           // 队列下标，指示元素从队列的该位置读出
	    recvq    waitq          // 等待读消息的goroutine队列
	    sendq    waitq          // 等待写消息的goroutine队列
	    lock mutex              // 互斥锁，chan不允许并发读写
	}
	
	从数据结构可以看出channel由队列、类型信息、goroutine等待队列组成，下面分别说明其原理。
	waitq存储的是第一次和最后一次的等待列表G

>3,chan实现原理
	
（1),环形队列

	chan内部实现了一个环形队列作为其缓冲区，队列的长度是创建chan时指定的。
	下图展示了一个可缓存6个元素的channel示意图：
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-LQrKzpm6n4khUvFEk_N%2F-LQrL-KVY4qBIFQpa1Wa%2Fchan-01-circle_queue.png?generation=1541748035003050&alt=media)

	dataqsiz指示了队列长度为6，即可缓存6个元素；
	buf指向队列的内存，队列中还剩余两个元素；
	qcount表示队列中还有两个元素；
	sendx指示后续写入的数据存储的位置，取值[0, 6)；
	recvx指示从该位置读取数据, 取值[0, 6)；	

(2),等待队列
		
	从channel读数据，如果channel缓冲区为空或者没有缓冲区，当前goroutine会被阻塞。 向channel写数据，如果channel缓冲区已满或者没有缓冲区，当前goroutine会被阻塞。
	被阻塞的goroutine将会挂在channel的等待队列中：
	因读阻塞的goroutine会被向channel写入数据的goroutine唤醒；
	因写阻塞的goroutine会被从channel读数据的goroutine唤醒；
	
	下图展示了一个没有缓冲区的channel，有几个goroutine阻塞等待读数据：
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-LQrKzpm6n4khUvFEk_N%2F-LQrL-KXrtSoygdJ28uD%2Fchan-02-wait_queue.png?generation=1541748034528380&alt=media)
	
	注意，一般情况下recvq和sendq至少有一个为空。只有一个例外，那就是同一个goroutine使用select语句向channel一边写数据，一边读数据。		
(3),类型信息
	
	一个channel只能传递一种类型的值，类型信息存储在hchan数据结构中。
	elemtype代表类型，用于数据传递过程中的赋值；
	elemsize代表类型大小，用于在buf中定位元素位置。
		
>4,chan创建
	
	创建channel的过程实际上是初始化hchan结构。其中类型信息和缓冲区长度由make语句传入，buf的大小则与元素大小和缓冲区长度共同决定。
	
	func makechan(t *chantype, size int) *hchan {
	    var c *hchan
	    c = new(hchan)
	    c.buf = malloc(元素类型大小*size)
	    c.elemsize = 元素类型大小
	    c.elemtype = 元素类型
	    c.dataqsiz = size
	
	    return c
	}
		

>5,向chan写数据
	
	向一个channel中写数据简单过程如下： 1. 如果等待接收队列recvq不为空，说明缓冲区中没有数据或者没有缓冲区，此时直接从recvq取出G,并把数据写入，最后把该G唤醒，结束发送过程； 2. 如果缓冲区中有空余位置，将数据写入缓冲区，结束发送过程； 3. 如果缓冲区中没有空余位置，将待发送数据写入G，将当前G加入sendq，进入睡眠，等待被读goroutine唤醒；
	
	
	
	

>6,从chan读取数据
	
	从一个channel读数据简单过程如下： 1. 如果等待发送队列sendq不为空，且没有缓冲区，直接从sendq中取出G，把G中数据读出，最后把G唤醒，结束读取过程； 2. 如果等待发送队列sendq不为空，此时说明缓冲区已满，从缓冲区中首部读出数据，把G中数据写入缓冲区尾部，把G唤醒，结束读取过程； 3. 如果缓冲区中有数据，则从缓冲区取出数据，结束读取过程； 4. 将当前goroutine加入recvq，进入睡眠，等待被写goroutine唤醒；
	

>7,关闭chan
	
	关闭channel时会把recvq中的G全部唤醒，本该写入G的数据位置为nil。把sendq中的G全部唤醒，但这些G会panic。
	除此之外，panic出现的常见场景还有： 1. 关闭值为nil的channel 2. 关闭已经被关闭的channel 3. 向已经关闭的channel写数据

>8,单向channel

	func readChan(chanName <-chan int)： 通过形参限定函数内部只能从channel中读取数据
	func writeChan(chanName chan<- int)： 通过形参限定函数内部只能向channel中写入数据
	func readChan(chanName <-chan int) {
		    <- chanName
		}
		
		func writeChan(chanName chan<- int) {
		    chanName <- 1
		}
		
		func main() {
		    var mychan = make(chan int, 10)
		
		    writeChan(mychan)
		    readChan(mychan)
	}
		
	
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 
	
#二十三,内存分配

>1,内存分配
	
	为了方便自主管理内存，做法便是先向系统申请一块内存，然后将内存切割成小块，通过一定的内存分配算法管理内存。 以64位系统为例，Golang程序启动时会向系统申请的内存如下图所示：
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-LR7-2F1Hhv-eZjCaJhL%2F-LR7-3-GIr-lVIWrhGe7%2Fmemory-01-init.png?generation=1542027495175387&alt=media)

	预申请的内存划分为spans、bitmap、arena三部分。其中arena即为所谓的堆区，应用中需要的内存从这里分配。其中spans和bitmap是为了管理arena区而存在的。
	arena的大小为512G，为了方便管理把arena区域划分成一个个的page，每个page为8KB,一共有512GB/8KB个页；
	spans区域存放span的指针，每个指针对应一个page，所以span区域的大小为(512GB/8KB)*指针大小8byte = 512M
	bitmap区域大小也是通过arena计算出来，不过主要用于GC。

>2,span数据结构
	
	span是内存管理的基本单位,每个span用于管理特定的class对象, 跟据对象大小，span将一个或多个页拆分成多个块进行管理。
	
	src/runtime/mheap.go:mspan定义了其数据结构：
	
	type mspan struct {
	    next *mspan            //链表向后指针，用于将span链接起来
	    prev *mspan            //链表向前指针，用于将span链接起来
	    startAddr uintptr // 起始地址，也即所管理页的地址
	    npages    uintptr // 管理的页数
	
	    nelems uintptr // 块个数，也即有多少个块可供分配
	
	    allocBits  *gcBits //分配位图，每一位代表一个块是否已分配
	
	    allocCount  uint16     // 已分配块的个数
	    spanclass   spanClass  // class表中的class ID
	
	    elemsize    uintptr    // class表中的对象大小，也即块大小
	}
		
	next和prev用于将多个span链接起来，这有利于管理多个span，接下来会进行说明。
	
	
>3,cache	

	有了管理内存的基本单位span，还要有个数据结构来管理span，这个数据结构叫mcentral，各线程需要内存时从mcentral管理的span中申请内存，为了避免多线程申请内存时不断的加锁，Golang为每个线程分配了span的缓存，这个缓存即是cache。
	
	type mcache struct {
	    alloc [67*2]*mspan // 按class分组的mspan列表
	}

	alloc为mspan的指针数组，数组大小为class总数的2倍。数组中每个元素代表了一种class类型的span列表，每种class类型都有两组span列表，第一组列表中所表示的对象中包含了指针，第二组列表中所表示的对象不含有指针，这么做是为了提高GC扫描性能，对于不包含指针的span列表，没必要去扫描。
	根据对象是否包含指针，将对象分为noscan和scan两类，其中noscan代表没有指针，而scan则代表有指针，需要GC进行扫描。
	mcache和span的对应关系如下图所示：
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-LR7-2F1Hhv-eZjCaJhL%2F-LR7-3-RZLPGxE4Sz2R2%2Fmemory-03-mcache.png?generation=1542027495254805&alt=media)

	mchache在初始化时是没有任何span的，在使用过程中会动态的从central中获取并缓存下来，跟据使用情况，每种class的span个数也不相同。上图所示，class 0的span数比class1的要多，说明本线程中分配的小对象要多一些。
	
	
>4,central
	
	cache作为线程的私有资源为单个线程服务，而central则是全局资源，为多个线程服务，当某个线程内存不足时会向central申请，当某个线程释放内存时又会回收进central。
	
	type mcentral struct {
	    lock      mutex     //互斥锁
	    spanclass spanClass // span class ID
	    nonempty  mSpanList // non-empty 指还有空闲块的span列表
	    empty     mSpanList // 指没有空闲块的span列表
	
	    nmalloc uint64      // 已累计分配的对象个数
	}
	
	lock: 线程间互斥锁，防止多线程读写冲突
	spanclass : 每个mcentral管理着一组有相同class的span列表
	nonempty: 指还有内存可用的span列表
	empty: 指没有内存可用的span列表
	nmalloc: 指累计分配的对象个数
		
	线程从central获取span步骤如下： 1. 加锁 2. 从nonempty列表获取一个可用span，并将其从链表中删除 3. 将取出的span放入empty链表 4. 将span返回给线程 5. 解锁 6. 线程将该span缓存进cache
	线程将span归还步骤如下： 1. 加锁 2. 将span从empty列表删除 3. 将span加入noneempty列表 4. 解锁上述线程从central中获取span和归还span只是简单流程，为简单起见，并未对具体细节展开。
	
	
		
	
	
	
>5,heap
	
	从mcentral数据结构可见，每个mcentral对象只管理特定的class规格的span。事实上每种class都会对应一个mcentral,这个mcentral的集合存放于mheap数据结构中。
	
	type mheap struct {
	    lock      mutex
	
	    spans []*mspan
	
	    bitmap        uintptr     //指向bitmap首地址，bitmap是从高地址向低地址增长的
	
	    arena_start uintptr        //指示arena区首地址
	    arena_used  uintptr        //指示arena区已使用地址位置
	
	    central [67*2]struct {
	        mcentral mcentral
	        pad      [sys.CacheLineSize - unsafe.Sizeof(mcentral{})%sys.CacheLineSize]byte
	    }
	}
	
	lock： 互斥锁
	spans: 指向spans区域，用于映射span和page的关系
	bitmap：bitmap的起始地址
	arena_start: arena区域首地址
	arena_used: 当前arena已使用区域的最大地址
	central: 每种class对应的两个mcentral
	
	从数据结构可见，mheap管理着全部的内存，事实上Golang就是通过一个mheap类型的全局变量进行内存管理的。
	mheap内存管理示意图如下：
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-LR7-2F1Hhv-eZjCaJhL%2F-LR7-3-TPIKYOnMaj2jy%2Fmemory-04-mheap.png?generation=1542027495283803&alt=media)	
	
	系统预分配的内存分为spans、bitmap、arean三个区域，通过mheap管理起来。接下来看内存分配过程。



>6,内存分配过程
		
	针对待分配对象的大小不同有不同的分配逻辑：
	(0, 16B) 且不包含指针的对象： Tiny分配
	(0, 16B) 包含指针的对象：正常分配
	[16B, 32KB] : 正常分配
	(32KB, -) : 大对象分配
	其中Tiny分配和大对象分配都属于内存管理的优化范畴，这里暂时仅关注一般的分配方法。
	以申请size为n的内存为例，分配步骤如下： 1. 获取当前线程的私有缓存mcache 2. 跟据size计算出适合的class的ID 3. 从mcache的alloc[class]链表中查询可用的span 4. 如果mcache没有可用的span则从mcentral申请一个新的span加入mcache中 5. 如果mcentral中也没有可用的span则从mheap中申请一个新的span加入mcentral 6. 从该span中获取到空闲对象地址并返回
	
	
	

>7,总结
	
	Golang内存分配是个相当复杂的过程，其中还掺杂了GC的处理，这里仅仅对其关键数据结构进行了说明，了解其原理而又不至于深陷实现细节。
	Golang程序启动时申请一大块内存，并划分成spans、bitmap、arena区域
	arena区域按页划分成一个个小块
	span管理一个或多个页
	mcentral管理多个span供线程申请使用
	mcache作为线程私有资源，资源来源于mcentral






***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
*** 

#二十四,垃圾回收

>1,垃圾回收算法
	
	业界常见的垃圾回收算法有以下几种：
引用计数：对每个对象维护一个引用计数，当引用该对象的对象被销毁时，引用计数减1，当引用计数器为0是回收该对象。

	优点：对象可以很快的被回收，不会出现内存耗尽或达到某个阀值时才回收。
	缺点：不能很好的处理循环引用，而且实时维护引用计数，有也一定的代价。
	代表语言：Python、PHP、Swift
	
标记-清除：从根变量开始遍历所有引用的对象，引用的对象标记为"被引用"，没有被标记的进行回收。

	优点：解决了引用计数的缺点。
	缺点：需要STW，即要暂时停掉程序运行。
	代表语言：Golang(其采用三色标记法)
分代收集：按照对象生命周期长短划分不同的代空间，生命周期长的放入老年代，而短的放入新生代，不同代有不能的回收算法和回收频率。

	优点：回收性能好
	缺点：算法复杂
	代表语言： JAVA

>2,GC垃圾回收原理
	
	简单的说，垃圾回收的核心就是标记出哪些内存还在使用中(即被引用到)，哪些内存不再使用了（即未被引用），把未被引用的内存回收掉，以供后续内存分配时使用。
	下图展示了一段内存，内存中即有已分配掉的内存，也有未分配的内存，垃圾回收的目标就是把那些已经分配的但没有对象引用的内存找出来并回收掉：
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-LR71-KFLXUgbqZUcmUK%2F-LR710W84QiYAMD8hfEP%2Fgc-01-overview.png?generation=1542028008618434&alt=media)
	
	上图中，内存块1、2、4号位上的内存块已被分配(数字1代表已被分配，0 未分配)。变量a, b为一指针，指向内存的1、2号位。内存块的4号位曾经被使用过，但现在没有任何对象引用了，就需要被回收掉。
	垃圾回收开始时从root对象开始扫描，把root对象引用的内存标记为"被引用"，考虑到内存块中存放的可能是指针，所以还需要递归的进行标记，全部标记完成后，只保留被标记的内存，未被标记的全部标识为未分配即完成了回收。


>3,内存标记(Mark)
	
	前面介绍内存分配时，介绍过span数据结构，span中维护了一个个内存块，并由一个位图allocBits表示每个内存块的分配情况。在span数据结构中还有另一个位图gcmarkBits用于标记内存块被引用情况。
	
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-LR71-KFLXUgbqZUcmUK%2F-LR710WAXZP5kZav-gDN%2Fgc-02-span_mark.png?generation=1542028008633282&alt=media)

	如上图所示，allocBits记录了每块内存分配情况，而gcmarkBits记录了每块内存标记情况。标记阶段对每块内存进行标记，有对象引用的的内存标记为1(如图中灰色所示)，没有引用到的保持默认为0.
	allocBits和gcmarkBits数据结构是完全一样的，标记结束就是内存回收，回收时将allocBits指向gcmarkBits，则代表标记过的才是存活的，gcmarkBits则会在下次标记时重新分配内存，非常的巧妙。	

>4, 三色标记法
	
	前面介绍了对象标记状态的存储方式，还需要有一个标记队列来存放待标记的对象，可以简单想象成把对象从标记队列中取出，将对象的引用状态标记在span的gcmarkBits，把对象引用到的其他对象再放入队列中。
	三色只是为了叙述上方便抽象出来的一种说法，实际上对象并没有颜色之分。这里的三色，对应了垃圾回收过程中对象的三种状态：
	灰色：对象还在标记队列中等待
	黑色：对象已被标记，gcmarkBits对应的位为1（该对象不会在本次GC中被清理）
	白色：对象未被标记，gcmarkBits对应的位为0（该对象将会在本次GC中被清理）

例如，当前内存中有A~F一共6个对象，根对象a,b本身为栈上分配的局部变量，根对象a、b分别引用了对象A、B, 而B对象又引用了对象D，则GC开始前各对象的状态如下图所示:
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-LR71-KFLXUgbqZUcmUK%2F-LR710WCPxTWeFWOafCh%2Fgc-03-root_scan.png?generation=1542028009051848&alt=media)
	
	初始状态下所有对象都是白色的。
	接着开始扫描根对象a、b:
	
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-LR71-KFLXUgbqZUcmUK%2F-LR710WE37agIaq6zqwu%2Fgc-04-root_scan_end.png?generation=1542028008628654&alt=media)
	
	由于根对象引用了对象A、B,那么A、B变为灰色对象，接下来就开始分析灰色对象，分析A时，A没有引用其他对象很快就转入黑色，B引用了D，则B转入黑色的同时还需要将D转为灰色，进行接下来的分析。如下图所示：
	
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-LR71-KFLXUgbqZUcmUK%2F-LR710WGClsrriSqcdt_%2Fgc-05-mark_phase2.png?generation=1542028008615003&alt=media)

	上图中灰色对象只有D，由于D没有引用其他对象，所以D转入黑色。标记过程结束：
		
![](https://blobscdn.gitbook.com/v0/b/gitbook-28427.appspot.com/o/assets%2F-LQm0KQP9eyG1B9ntPkR%2F-LR71-KFLXUgbqZUcmUK%2F-LR710WIImHV_CbAx-PM%2Fgc-06-mark_phase3.png?generation=1542028008608987&alt=media)
	
	最终，黑色的对象会被保留下来，白色对象会被回收掉。	
	
>5,Stop The World


	对于垃圾回收来说，回收过程中也需要控制住内存的变化，否则回收过程中指针传递会引起内存引用关系变化，如果错误的回收了还在使用的内存，结果将是灾难性的。
	
	Golang中的STW（Stop The World）就是停掉所有的goroutine，专心做垃圾回收，待垃圾回收结束后再恢复goroutine。
	
	STW时间的长短直接影响了应用的执行，时间过长对于一些web应用来说是不可接受的，这也是广受诟病的原因之一。
	
	为了缩短STW的时间，Golang不断优化垃圾回收算法，这种情况得到了很大的改善。	
	

>6,垃圾回收优化
 写屏障(Write Barrier)

	前面说过STW目的是防止GC扫描时内存变化而停掉goroutine，而写屏障就是让goroutine与GC同时运行的手段。虽然写屏障不能完全消除STW，但是可以大大减少STW的时间。
	
	写屏障类似一种开关，在GC的特定时机开启，开启后指针传递时会把指针标记，即本轮不回收，下次GC时再确定。
	
	GC过程中新分配的内存会被立即标记，用的并不是写屏障技术，也即GC过程中分配的内存不会在本轮GC中回收。

辅助GC(Mutator Assist)

	为了防止内存分配过快，在GC执行过程中，如果goroutine需要分配内存，那么这个goroutine会参与一部分GC的工作，即帮助GC做一部分工作，这个机制叫作Mutator Assist。	
	
>7,垃圾回收触发时机
	
 (1), 内存分配量达到阀值触发GC

	每次内存分配时都会检查当前内存分配量是否已达到阀值，如果达到阀值则立即启动GC。
	
	阀值 = 上次GC内存分配量 * 内存增长率
	
	内存增长率由环境变量GOGC控制，默认为100，即每当内存扩大一倍时启动GC。
	
(2), 定期触发GC

	默认情况下，最长2分钟触发一次GC，这个间隔在src/runtime/proc.go:forcegcperiod变量中被声明：
	
	// forcegcperiod is the maximum time in nanoseconds between garbage
	// collections. If we go this long without a garbage collection, one
	// is forced to run.
	//
	// This is a variable for testing purposes. It normally doesn't change.
	var forcegcperiod int64 = 2 * 60 * 1e9
	
(3), 手动触发

	程序代码中也可以使用runtime.GC()来手动触发GC。这主要用于GC性能测试和统计。	
	

>8,GC性能优化
	
	GC性能与对象数量负相关，对象越多GC性能越差，对程序影响越大。
	所以GC性能优化的思路之一就是减少对象分配个数，比如对象复用或使用大对象组合多个小对象等等。
	另外，由于内存逃逸现象，有些隐式的内存分配也会产生，也有可能成为GC的负担。
	关于GC性能优化的具体方法，后面单独介绍。




***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***

#二十五,tcmalloc内存分配

>1，tcmalloc分配策略

	tcmalloc分配的内存主要来自两个地方：全局缓存堆和进程的私有缓存。对于一些小容量的内存申请试用进程的私有缓存，私有缓存不足的时候可以再从全局缓存申请一部分作为私有缓存。对于大容量的内存申请则需要从全局缓存中进行申请。而大小容量的边界就是32k。缓存的组织方式是一个单链表数组，数组的每个元素是一个单链表，链表中的每个元素具有相同的大小。

>2,小对象分配策略
	
	小对象内存分配默认会分配86个不同大小的块，而这些块的大小并没有明确说明，需要查一下源码。每种大小的块的数组的长度都采用使用了才初始化，有点类似于lazy-initialize。
![](http://legendtkl.com/img/uploads/local.png)	

>3,大对象分配
	
	对于大于32k的内存申请，使用全局内存来分配。全局内存的组织也是单链表数组，数组长度为256，分别对用1 page大小, 2 page大小（1 page=4k）.
![](http://legendtkl.com/img/uploads/global.png)	

>4,span
	
	tcmalloc使用span来管理内存分页，一个span可以包含几个连续分页。span的状态只有未分配、作为大对象分配、作为小对象分配。
	
![](http://legendtkl.com/img/uploads/span.png)

>5,go的内存分配
	
	go语言的内存分配并不是和tcmalloc一模一样。

    局部缓存并不是分配给进程或者线程，而是分配给P（这个还需要说一下go的goroutine实现）
    go的GC是stop the world，并不是每个进程单独进行GC。
    span的管理更有效率
	
	





	
	

广告系统资料https://blog.csdn.net/hemin1003/article/category/7949792
	
	
	
	
	
	
	
	

	
	
	
	
	