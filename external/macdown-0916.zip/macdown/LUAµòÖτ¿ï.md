# LUA安装启动
	
	brew install lua
	brew install luarocks -v
	
# lua教程看ide的代码详情





# shell详情

## shell中给变量设置默认值

通常shell中我们需要给变量设置默认值，可能会写出如下代码

	#!/bin/bash  
	if [ ! $1 ]; then  
	       $1='default'  
	fi  
	显然这种方式在变量少的时候没啥问题，一旦变量多起来，我们可能就有大量的重复劳动(if判断)
	
	有没有比较优雅的方式，不用写一大堆if判断，显然答案是有的
	
	变量为null时


	#当变量a为null时则var=b  
	var=${a-b}  
	变量为null且为空字符串的时候
	
	#当变量a为null或为空字符串时则var=b  
	var=${a:-b}  
	
	#当变量a不为null或不为空字符串时则var=b  
	var=${a:+b}  
	