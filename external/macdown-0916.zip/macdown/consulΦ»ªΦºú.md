#一，consul基础

	Agent： Consul集群中长时间运行的守护进程，以consul agent 命令开始启动. 在客户端和服务端模式下都可以运行，可以运行DNS或者HTTP接口， 它的主要作用是运行时检查和保持服务同步。  
	Client： 客户端, 无状态, 以一个极小的消耗将接口请求转发给局域网内的服务端集群.  
	Server： 服务端, 保存配置信息, 高可用集群, 在局域网内与本地客户端通讯, 通过广域网与其他数据中心通讯. 每个数据中心的 server 数量推荐为 3 个或是 5 个.
	Datacenter： 数据中心，多数据中心联合工作保证数据存储安全快捷
	sConsensus： 一致性协议使用的是Raft Protocol
	
	
#二，consul健康检查

	https://www.cnblogs.com/duanxz/p/9662862.html
	

#三，配置中心

	https://github.com/uoko-J-Go/UOKOConsul	


#四,consul详解

	http://www.voidcn.com/relative/p-xpitohil-bee.html
	

#五，conusl可靠性分析