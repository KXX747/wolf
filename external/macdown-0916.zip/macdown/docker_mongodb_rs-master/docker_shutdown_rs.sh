docker stop mongos0
docker rm -f  mongos0
docker stop configsvr0
docker rm -f configsvr0
docker stop configsvr1
docker rm -f configsvr1
docker stop configsvr2
docker rm -f configsvr2
docker stop shardsvr00
docker rm -f shardsvr00
docker stop shardsvr01
docker rm -f shardsvr01
docker stop shardsvr02
docker rm -f shardsvr02
docker stop shardsvr10
docker rm -f shardsvr10
docker stop shardsvr11
docker rm -f shardsvr11
docker stop shardsvr12
docker rm -f shardsvr12

