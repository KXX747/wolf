docker start shardsvr00
docker start shardsvr01
docker start shardsvr02
docker start shardsvr10
docker start shardsvr11
docker start shardsvr12
docker start shardsvr20
docker start shardsvr21
docker start shardsvr22

