#一,结构化检索应用

>1,创建数据_bulk批量添加
	
	//批量添加
	POST /forum/article/_bulk
	{"index":{"_id":1}}
	{"articleId":10000001,"userId":1,"hidden":false,"postDate":"2017-01-01"}
	{"index":{"_id":2}}
	{"articleId":10000002,"userId":1,"hidden":false,"postDate":"2017-01-02"}
	{"index":{"_id":3}}
	{"articleId":10000003,"userId":2,"hidden":false,"postDate":"2017-01-01"}
	{"index":{"_id":4}}
	{"articleId":10000004,"userId":2,"hidden":false,"postDate":"2017-01-02"}
	
	//批量更新
	POST /forum/article/_bulk
	{"update":{"_id":1}}
	{"doc":{"tag":["java","hadoop"]}}
	{"update":{"_id":2}}
	{"doc":{"tag":["oc"]}}
	{"update":{"_id":3}}
	{"doc":{"tag":["java","golang"]}}
	{"update":{"_id":4}}
	{"doc":{"tag":["shell","python"]}}
	
>2,查询用户所有文章
	
	GET /forum/article/_search
	{
	  "query": {
	    "match": {
	      "userId": 1
	    }
	    
	  }
	}
	
	//term不分词
	GET /forum/article/_search
	{
	  "query": {
	    "constant_score": {
	      "filter": {
	        "term": {
	          "userId": 2
	        }
	      }
	    }
	  }
	}
	
>3,查看article的_mappings
	
	GET /forum/_mapping/article
	
	{
	  "forum" : {
	    "mappings" : {
	      "article" : {
	        "properties" : {
	          "articleId" : {
	            "type" : "text",
	            "fields" : {
	              "keyword" : {
	                "type" : "keyword",
	                "ignore_above" : 256
	              }
	            }
	          },
	          "hidden" : {
	            "type" : "boolean"
	          },
	          "postDate" : {
	            "type" : "date"
	          },
	          "userId" : {
	            "type" : "long"
	          }
	        }
	      }
	    }
	  }
	}

>3,_filter执行原理（bitset机制和caching机制）

	bitset是在检索的时候对检索次数多的进行排序等操作
	caching是缓存bitset结果
	filter会在query之前执行，query查询会倒排索引等，filter只是条件检索


4,bool组合多个filter条件检索
	
	must,bool,not_must,should,filter
	bool可以嵌套
	
	
	//filter拦截检索,只是条件检索
	GET /forum/article/_search
	{
	  "query": {
	      
	      "constant_score": {
	        "filter": {
	          "bool": {
	            "should":[
	              {"term":{"postDate":"2017-01-01"}},
	              {"term":{"articleId":"10000003"}}
	              ],
	              "must_not":{
	                "term":{
	                  "postDate":"2017-01-02"
	                }
	                
	              }
	          }
	        }
	      }
	  }
	}
	
	//query查询，会倒排等
		GET /forum/article/_search
		{
		  "query": {
		    
		    "bool": {
		      "must": [
		        {"term":{"postDate":"2017-01-01"}}
		      ],
		      "must_not": [ 
		        { "term":{"postDate":"2017-01-02"}}
		      ]
		    }
		    
		  }
		}



>5,使用terms检索多个值值哟啊匹配其中一个就可以，term必须全部匹配
	
	
	GET /forum/article/_search
	{
	  "query": {
	    "constant_score": {
	      "filter": {
	        "terms": {
	          "tag": [
	            "python",
	            "golang"
	          ]
	        }
	        
	      }
	    }
	  }
	}
	
	控制检索结果精准度 minimun_should_match

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***	
#二,搜索技术

>1,dis_max实现多个feild按照分数高低返回
	
	GET /forum/article/_search
	{
	  "query": {
	    "dis_max": {
	      "queries": [
	        {
	          "match": {
	            "tag": "java"
	          }
	        },{
	          "match": {
	            "hidden": false
	          }
	        }
	        ]
	    }
	    
	  }
	}
	
	返回结果：
		
		{
		  "took" : 4,
		  "timed_out" : false,
		  "_shards" : {
		    "total" : 5,
		    "successful" : 5,
		    "skipped" : 0,
		    "failed" : 0
		  },
		  "hits" : {
		    "total" : 4,
		    "max_score" : 0.2876821,
		    "hits" : [
		      {
		        "_index" : "forum",
		        "_type" : "article",
		        "_id" : "1",
		        "_score" : 0.2876821,
		        "_source" : {
		          "articleId" : "10000001",
		          "userId" : 1,
		          "hidden" : false,
		          "postDate" : "2017-01-01",
		          "tag" : [
		            "java",
		            "hadoop"
		          ]
		        }
		      },
		      {
		        "_index" : "forum",
		        "_type" : "article",
		        "_id" : "3",
		        "_score" : 0.2876821,
		        "_source" : {
		          "articleId" : "10000003",
		          "userId" : 2,
		          "hidden" : false,
		          "postDate" : "2017-01-01",
		          "tag" : [
		            "java",
		            "golang"
		          ]
		        }
		      },
		      {
		        "_index" : "forum",
		        "_type" : "article",
		        "_id" : "2",
		        "_score" : 0.18232156,
		        "_source" : {
		          "articleId" : "10000002",
		          "userId" : 1,
		          "hidden" : false,
		          "postDate" : "2017-01-02",
		          "tag" : [
		            "oc"
		          ]
		        }
		      },
		      {
		        "_index" : "forum",
		        "_type" : "article",
		        "_id" : "4",
		        "_score" : 0.18232156,
		        "_source" : {
		          "articleId" : "10000004",
		          "userId" : 2,
		          "hidden" : false,
		          "postDate" : "2017-01-02",
		          "tag" : [
		            "shell",
		            "python"
		          ]
		        }
		      }
		    ]
		  }
		}
			
		
>2,multi_match实现dis_max和tie_breaker使用

	dis_max取最高分
	tie_breaker将其他的query也考虑进去
	

#三,IK分词器

>1,ik两种analyzer:
	
	ik_max_word 分的最多
	ik_smart 分的最少

>2,创建ik_max_word分词器
	
	//创建分词表
	PUT /my_index
	{
	    "mappings":{
	      "my_type":{
	        "properties": {
	            "title": {
	                "type": "text",
	                "analyzer": "ik_max_word",
	                "search_analyzer": "ik_max_word"
	            }
	             "content": {
	                "type": "text",
	                "analyzer": "ik_max_word",
	                "search_analyzer": "ik_max_word"
	            }
	            
	            
	        }
	      }
	      
	    }
	}
	
	//添加数据
	POST /my_index/my_type/_bulk
	{"index":{"_id":1}}
	{"title":"神奇秘方（皮肤科，外科，内科。）","content":"1、皮肤瘙痒：鲜韭菜与淘米水，按一比10重量配好，先泡两小时再一起烧开，去韭菜用水洗痒处或洗澡，一次见效，洗后勿用清水过身，一日一次，连洗3天可愈。 ­2、牛皮癣、头癣、顽癣：猪胆一个，刺破，将胆汁放在小碗内，加入明矾（如黄豆大），待溶化后用胆汁搽患处，每日2次，连用7天。此方治疗多年皮癣、顽癣效果神奇。"}
	{"index":{"_id":2}}
	{"title":"遇到什么样的男人可以恋爱？遇到什么样的男人可以结婚？","content":"你好！ 恋爱是对爱的向往，结婚是对家和归宿的向往。这两者之间因为年龄和目的不一样而不一样。 恋爱时尽显浪漫 恋爱的时候，男女之间的吸引更多是建立... "}
	{"index":{"_id":3}}
	{"title":"商业数据分析，3个月轻松入门","content":"提前报名，立减千元学费"}
	{"index":{"_id":4}}
	{"title":"一个中年男人的大实话：女人身上没这两样东西，婚姻很难持久下去","content":"文/墨然 都说，最开始喜欢一个人的时候，都是始于颜值，陷于才华，终于人品。是的，两个人最开始的相互吸引，离不开颜值的成分。但是长期交往在一起还是... "}
	{"index":{"_id":5}}
	{"title":"一个女人好不好追，对她说这“三个字”，就心里有数了","content":"都说“男追女隔座山，女追男隔层纱”，在感情问题里，女人追求男人似乎更容易的多，只要女人开口和男人表白，男人基本上都会同意。 但男人追求女人就没有..."}
	{"index":{"_id":6}}
	{"title":"姚晨崩溃大哭上热搜：我终于活成了我妈害怕的样子","content":"最近，“原生家庭”这个话题又引起热议。 自《都挺好》播出以来，就获得人们的广泛关注，豆瓣评分高达8.5。 这部剧不同于以往的家庭伦理..."}
	{"index":{"_id":7}}
	{"title":"真正心里有你的人","content":"真正心里有你的人： 看的不是微信，而是你的世界。 读的不是文字，而是你的心情。 点赞是对你的关注， 评论是对你的在乎。 好感情交的是心，连的是情... "}
	{"index":{"_id":8}}
	{"title":"魔道祖师","content":"“魏婴！你可知错！”蓝忘机。 “我何错之有？”魏无羡问。 “你看看你都干了什么！” 魏无羡看着周围围着的姑苏子第以及满地的尸体。他终于明白了。 ... "}
	{"index":{"_id":9}}
	{"title":"八小时之外，如何自我提高？","content":"焦虑和迷茫是年轻人的常态。但大部分人的焦虑只是徒增烦恼，渴望向上又好逸恶劳，焦虑万分但碌碌无为。正如所谓的“间接性踌躇满志，持续性混吃等死”。"}
	{"index":{"_id":10}}
	{"title":"6个月从0学会英语——开口说英语的万能钥匙","content":"学英语初期阶段的三个原则 1、不需要分解成单词。 2、只需要掌握一句话的整体含义。 3、马上就去用。 一些简单的开口说英语的万能钥匙、小工具 1... "}
	{"index":{"_id":11}}
	{"title":"最佛系的星座？12星座佛系指数排行榜，双鱼座最能领悟人生的真谛","content":"第12名天蝎座 天蝎座如果想要“成佛”，那真的是要下一番苦功夫，至少他们得要把心里的那个“魔”给摆平了。天蝎座的这个“魔”，就是他们的贪嗔痴。天... "}
	{"index":{"_id":12}}
	{"title":"鸡蛋跟“它”吃，固精强肾，头发乌黑，睡眠也好起来，早吃早受益","content":"鸡蛋跟“它”吃，固精强肾，头发乌黑，睡眠也好起来，早吃早受益。鸡蛋是我们家家户户都必备的一种食材，我们家常吃的炒鸡蛋就是由它为主要食材做成的，它... "}

	
	//搜索
	GET /my_index/_search
	{
	  "query": {
	    
	    "match": {
	      "title": "结婚"
	    }
	  }
	}


>3,ik配置文件 IKAnalyzer.cfg.xml
	
	<properties>
		<comment>IK Analyzer 扩展配置</comment>
		<!--用户可以在这里配置自己的扩展字典 -->
		<entry key="ext_dict"></entry>
		 <!--用户可以在这里配置自己的扩展停止词字典-->
		<entry key="ext_stopwords"></entry>
		<!--用户可以在这里配置远程扩展字典 -->
		<!-- <entry key="remote_ext_dict">words_location</entry> -->
		<!--用户可以在这里配置远程扩展停止词字典-->
		<!-- <entry key="remote_ext_stopwords">words_location</entry> -->
	</properties>
	
	
	
>4,自定义建立词库
	
	vi mydict.dic
	
	网红
	刘建行

	<!--用户可以在这里配置自己的扩展字典 -->
	<entry key="ext_dict">mydict.dic</entry>
	
	
	重启es
	
	查看配置的分词
		GET _analyze
		{
		  "text":"刘建行",
		  "analyzer": "ik_max_word"
		}
		
	

>5,修改ik分析器热更新
	
	修改ik支持动态加载词库	
		
	
	
#四,聚合数据分析--家电卖场为背景
	
	aggs分析 bucket metric
	
	
	
	
	
	
	
	
	
