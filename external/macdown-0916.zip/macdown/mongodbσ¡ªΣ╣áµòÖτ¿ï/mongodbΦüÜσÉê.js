use pipe_col
db.orders.insert([
   { "_id" : 1, "item" : "almonds", "price" : 12, "quantity" : 2 },
   { "_id" : 2, "item" : "pecans", "price" : 20, "quantity" : 1 },
   { "_id" : 3  }
])
   
 
db.inventory.insert([
   { "_id" : 1, "sku" : "almonds", description: "product 1", "instock" : 120 },
   { "_id" : 2, "sku" : "bread", description: "product 2", "instock" : 80 },
   { "_id" : 3, "sku" : "cashews", description: "product 3", "instock" : 60 },
   { "_id" : 4, "sku" : "pecans", description: "product 4", "instock" : 70 },
   { "_id" : 5, "sku": null, description: "Incomplete" },
   { "_id" : 6 }
])
   

   
 
 db.orders.find({})  
 db.inventory.find({})  
 
 
#lokkup关联查询
db.orders.aggregate([
   {
     $lookup:
       {
         from: "inventory",
         localField: "item",
         foreignField: "sku",
         as: "inventory_docs"
       }
  },{
      $out:"myaggregate_out_col"
      }
])

db.orders.aggregate([{
    $lookup:{
        from:"inventory",
        localField:"item",
        foreignField:"sku",
        as:"inventory_docs"
        }
 },{
     $match:{
        "price":{$gt:0}
         }
},{
    
        $project:{
           "_id":1,
            "item":1,
        }
    }
])
 

db.orders.aggregate([{
    $lookup:{
        from:"inventory",
        localField:"item",
        foreignField:"sku",
        as:"inventory_docs"
        }
 },{
     $match:{
        "price":{$gt:0}
         }
},{
      $group:{
           _id:"$id",
          totalPrice:{$sum: { $multiply: [ "$price", "$quantity" ] } },
          averageQuantity: { $avg: "$quantity" },
          count: { $sum: 1 }
          }
}
],{"allowDiskUse":true})





db.runCommand(
   { group:
       {
         ns: 'orders',
         key: { ord_dt: 1, 'item.sku': 1 },
         cond: { ord_dt: { $gt: new Date( '01/01/2012' ) } },
         $reduce: function ( curr, result ) {
                     result.total += curr.item.qty;
                  },
         initial: { total : 0 }
       }
    }
)






 
 



   
 
   
