use test
db.col.update({"title":"mongodb学习"},{$min:{"score":9}})

db.col.find()




db.col.update({"title":"mongodb学习"},{$max:{"score":99}})

db.col.update({"title":"mongodb学习"},{$mul:{a:NumberLong(100),score:2}})

db.col.update({"title":"mongodb学习"},{$set:{"score":159}})


db.col.update({ "title" : "apple", "likes" : 100 },{})

db.col.update(
  { "_id" : ObjectId("5d4ce8475cae39aab458c0c7")},
  {
     $set: { title: "apple" },
     $setOnInsert: { likes: 100 }
  },
  { upsert: true }
)

db.col.update({"title":"apple"},{$unset:{likes:0}})


db.students.insert([
   { "_id" : 1, "grades" : [ 85, 80, 80 ] },
   { "_id" : 2, "grades" : [ 88, 90, 92 ] },
   { "_id" : 3, "grades" : [ 85, 100, 90 ] }
])
   
   
db.students.find({ _id: 1, grades: 80})
   
   
db.studnets.update({ _id: 1.0, grades: 85 },{ $set: { "grades.$" : 1000 } })

db.students.updateOne(
   { _id: 1, grades: 80 },
   { $set: { "grades.$" : 82 } }
)
   
   
db.students.find({_id:1})
db.students.update({_id:1},{$addToSet:{grades:300}})
   
db.students.updateMany({},{$pullAll:{grades:[200,300]}})


db.students.update({_id:1},{$push:{grades:{$each:[400,500]}}})

db.students.find({})


db.students.update({_id:2},{$push:{
    
    grades:{
        $each:[5,6,7],
        $slice:-5
        }
 }})
 
 db.students.update({_id:2},{
     $push:{
         
        grades :{
            
            $each:[100,6000,700000],
            $sort:{grades:1}
            }
     }
})
 
 

db.singleindex_col.insert(arr);
db.singleindex_col.count() 

db.singleindex_col.find({name:"jack46000"}).explain()
db.singleindex_col.find({"age" : {$gte : 0}}).explain()

db.singleindex_col.createIndex({"age":1})

db.singleindex_col.createIndex({"age":1,"name":1})


db.singleindex_col.find({}).sort({age:-1,name:-1}).explain()

db.singleindex_col.createIndex({name:"hashed"})


#创建ttl索引
db.mydate.insert({
     "createAt":new Date(),
     "logEvent":2,
      "logMessage":"Succcess!",
    })

 db.mydate.find({})
 
 db.mydate.createIndex({"createAt":1},{expireAfterSeconds:5})
 

db.mydate.getIndexes()


