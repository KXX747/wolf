//数据库 启用 分片
	sh.enableSharding("test")
	//分片集合
	sh.shardCollection("test.order", {"_id": "hashed" })
	
	//插入数据
	use test
	for (i = 1; i <= 1001; i=i+1){
	db.order.insert({"price": 1})
	}
	
	//查看数据分布
	db.order.find().count()
        
        show tables
	


