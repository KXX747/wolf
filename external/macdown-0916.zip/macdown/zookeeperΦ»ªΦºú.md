
#一，节点类型和event

1、PERSISTENT--持久化目录节点

	客户端与zookeeper断开连接后，该节点依旧存在

2、PERSISTENT_SEQUENTIAL-持久化顺序编号目录节点

	客户端与zookeeper断开连接后，该节点依旧存在，只是Zookeeper给该节点名称进行顺序编号

3、EPHEMERAL-临时目录节点

	客户端与zookeeper断开连接后，该节点被删除

4、EPHEMERAL_SEQUENTIAL-临时顺序编号目录节点

	客户端与zookeeper断开连接后，该节点被删除，只是Zookeeper给该节点名称进行顺序编号

5,github.com/samuel/go-zookeeper/zk创建节点时flags对应的类型如下
	
	//0 持久节点（PERSISTENT）
	//1 临时节点（EPHEMERAL）
	//2 持久顺序节点（PERSISTENT_SEQUENTIAL） 带顺序编号 2_0000000007
	//3 临时顺序节点(EPHEMERAL_SEQUENTIAL)带顺序编号 33_0000000009
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***		
	
#二，zk分布式锁
	
	  在zookeeper指定节点（locks）下创建临时顺序节点node_n
    获取locks下所有子节点children
    对子节点按节点自增序号从小到大排序
    判断本节点是不是第一个子节点，若是，则获取锁；若不是，则监听比该节点小的那个节点的删除事件
    若监听事件生效，则回到第二步重新进行判断，直到获取到锁

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***		

#三，zookeeper理解

>1.Zookeeper工作原理

	Zookeeper 的核心是原子广播，这个机制保证了各个Server之间的同步。实现这个机制的协议叫做Zab协议。Zab协议有两种模式，它们分别是恢复模式（选主）和广播模式（同步）。当服务启动或者在领导者崩溃后，Zab就进入了恢复模式，当领导者被选举出来，且大多数Server完成了和 leader的状态同步以后，恢复模式就结束了。状态同步保证了leader和Server具有相同的系统状态。 

	为了保证事务的顺序一致性，zookeeper采用了递增的事务id号（zxid）来标识事务。所有的提议（proposal）都在被提出的时候加上了zxid。实现中zxid是一个64位的数字，它高32位是epoch用来标识leader关系是否改变，每次一个leader被选出来，它都会有一个新的epoch，标识当前属于那个leader的统治时期。低32位用于递增计数。

>2.Zookeeper 下 Server工作状态

	每个Server在工作过程中有三种状态： 
	
	LOOKING：当前Server不知道leader是谁，正在搜寻
	LEADING：当前Server即为选举出来的leader
	FOLLOWING：leader已经选举出来，当前Server与之同步

>3.Zookeeper选主流程(basic paxos)

	当leader崩溃或者leader失去大多数的follower，这时候zk进入恢复模式，恢复模式需要重新选举出一个新的leader，让所有的Server都恢复到一个正确的状态。Zk的选举算法有两种：一种是基于basic paxos实现的，另外一种是基于fast paxos算法实现的。系统默认的选举算法为fast paxos。

	1.选举线程由当前Server发起选举的线程担任，其主要功能是对投票结果进行统计，并选出推荐的Server； 
	
	2.选举线程首先向所有Server发起一次询问(包括自己)； 
	
	3.选举线程收到回复后，验证是否是自己发起的询问(验证zxid是否一致)，然后获取对方的id(myid)，并存储到当前询问对象列表中，最后获取对方提议的leader相关信息(id,zxid)，并将这些信息存储到当次选举的投票记录表中； 
	
	4.收到所有Server回复以后，就计算出zxid最大的那个Server，并将这个Server相关信息设置成下一次要投票的Server； 
	
	5.线程将当前zxid最大的Server设置为当前Server要推荐的Leader，如果此时获胜的Server获得n/2 + 1的Server票数，设置当前推荐的leader为获胜的Server，将根据获胜的Server相关信息设置自己的状态，否则，继续这个过程，直到leader被选举出来。 通过流程分析我们可以得出：要使Leader获得多数Server的支持，则Server总数必须是奇数2n+1，且存活的Server的数目不得少于n+1. 每个Server启动后都会重复以上流程。在恢复模式下，如果是刚从崩溃状态恢复的或者刚启动的server还会从磁盘快照中恢复数据和会话信息，zk会记录事务日志并定期进行快照，方便在恢复时进行状态恢复。选主的具体流程图所示： 
	
>4.Zookeeper选主流程（fast paxos）	
	
	fast paxos流程是在选举过程中，某Server首先向所有Server提议自己要成为leader，当其它Server收到提议以后，解决epoch和 zxid的冲突，并接受对方的提议，然后向对方发送接受提议完成的消息，重复这个流程，最后一定能选举出Leader。
	 
	
		
>5.zookeeper同步流程
	
	1. Leader等待server连接； 
	2 .Follower连接leader，将最大的zxid发送给leader； 
	3 .Leader根据follower的zxid确定同步点； 
	4 .完成同步后通知follower 已经成为uptodate状态； 
	5 .Follower收到uptodate消息后，又可以重新接受client的请求进行服务了。

>6,Zookeeper工作流程-Leader
	
	1 .恢复数据； 

	2 .维持与Learner的心跳，接收Learner请求并判断Learner的请求消息类型； 
	3 .Learner的消息类型主要有PING消息、REQUEST消息、ACK消息、REVALIDATE消息，根据不同的消息类型，进行不同的处理。 
	PING 消息是指Learner的心跳信息；
	REQUEST消息是Follower发送的提议信息，包括写请求及同步请求；
	ACK消息是 Follower的对提议的回复，超过半数的Follower通过，则commit该提议；
	REVALIDATE消息是用来延长SESSION有效时间。
	
	
>7,Zookeeper工作流程-Follower	
	
	1.向Leader发送请求（PING消息、REQUEST消息、ACK消息、REVALIDATE消息）； 
	2.接收Leader消息并进行处理； 
	3.接收Client的请求，如果为写请求，发送给Leader进行投票；
	4.返回Client结果。 
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***		

#4,Zookeeper写操作
		
>1,通过写Leader操作流程如下图所示	

![zk的写操作](http://www.jasongj.com/img/zookeeper/1_architecture/writeleader.png)
	
    客户端向Leader发起写请求
    Leader将写请求以Proposal的形式发给所有Follower并等待ACK
    Follower收到Leader的Proposal后返回ACK
    Leader得到过半数的ACK（Leader对自己默认有一个ACK）后向所有的Follower和Observer发送Commmit
    Leader将处理结果返回给客户端

这里要注意

    Leader并不需要得到Observer的ACK，即Observer无投票权
    Leader不需要得到所有Follower的ACK，只要收到过半的ACK即可，同时Leader本身对自己有一个ACK。上图中有4个Follower，只需其中两个返回ACK即可，因为(2+1) / (4+1) > 1/2
    Observer虽然无投票权，但仍须同步Leader的数据从而在处理读请求时可以返回尽可能新的数据

>2,写Follower/Observer
	
	通过Follower/Observer进行写操作流程如下图所示：
![](http://www.jasongj.com/img/zookeeper/1_architecture/writefollower.png)
	
	从上图可见
    Follower/Observer均可接受写请求，但不能直接处理，而需要将写请求转发给Leader处理
    除了多了一步请求转发，其它流程与直接写Leader无任何区别


***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***		

#5,Zookeeper读操作

	Leader/Follower/Observer都可直接处理读请求，从本地内存中读取数据并返回给客户端即可。
	如果需要读取最新的需要手动调用sync()
	
![](http://www.jasongj.com/img/zookeeper/1_architecture/read.png)
	
	由于处理读请求不需要服务器之间的交互，Follower/Observer越多，整体可处理的读请求量越大，也即读性能越好。
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***		

#6,保证数据不丢失

	一致性保证
	ZAB协议保证了在Leader选举的过程中，已经被Commit的数据不会丢失，未被Commit的数据对客户端不可见。
		
	
	
>1,Commit过的数据不丢失

	Failover前状态
	为更好演示Leader Failover过程，本例中共使用5个Zookeeper服务器。A作为Leader，共收到P1、P2、P3三条消息，并且Commit了1和2，且总体顺序为P1、P2、C1、P3、C2。根据顺序性原则，其它Follower收到的消息的顺序肯定与之相同。其中B与A完全同步，C收到P1、P2、C1，D收到P1、P2，E收到P1，如下图所示。
	
![](http://www.jasongj.com/img/zookeeper/1_architecture/recovery_1.png)

这里要注意

    由于A没有C3，意味着收到P3的服务器的总个数不会超过一半，也即包含A在内最多只有两台服务器收到P3。在这里A和B收到P3，其它服务器均未收到P3
    由于A已写入C1、C2，说明它已经Commit了P1、P2，因此整个集群有超过一半的服务器，即最少三个服务器收到P1、P2。在这里所有服务器都收到了P1，除E外其它服务器也都收到了P2


	选出新Leader
	旧Leader也即A宕机后，其它服务器根据上述FastLeaderElection算法选出B作为新的Leader。C、D和E成为Follower且以B为Leader后，会主动将自己最大的zxid发送给B，B会将Follower的zxid与自身zxid间的所有被Commit过的消息同步给Follower，如下图所示。
![](http://www.jasongj.com/img/zookeeper/1_architecture/recovery_2.png)

在上图中

    P1和P2都被A Commit，因此B会通过同步保证P1、P2、C1与C2都存在于C、D和E中
    P3由于未被A Commit，同时幸存的所有服务器中P3未存在于大多数据服务器中，因此它不会被同步到其它Follower

	通知Follower可对外服务
	同步完数据后，B会向D、C和E发送NEWLEADER命令并等待大多数服务器的ACK（下图中D和E已返回ACK，加上B自身，已经占集群的大多数），然后向所有服务器广播UPTODATE命令。收到该命令后的服务器即可对外提供服务。
![](http://www.jasongj.com/img/zookeeper/1_architecture/recovery_3.png)



>2,未Commit过的消息对客户端不可见		
	
	在上例中，P3未被A Commit过，同时因为没有过半的服务器收到P3，因此B也未Commit P3（如果有过半服务器收到P3，即使A未Commit P3，B会主动Commit P3，即C3），所以它不会将P3广播出去。

	具体做法是，B在成为Leader后，先判断自身未Commit的消息（本例中即P3）是否存在于大多数服务器中从而决定是否要将其Commit。然后B可得出自身所包含的被Commit过的消息中的最小zxid（记为min_zxid）与最大zxid（记为max_zxid）。C、D和E向B发送自身Commit过的最大消息zxid（记为max_zxid）以及未被Commit过的所有消息（记为zxid_set）。B根据这些信息作出如下操作

    如果Follower的max_zxid与Leader的max_zxid相等，说明该Follower与Leader完全同步，无须同步任何数据
    如果Follower的max_zxid在Leader的(min_zxid，max_zxid)范围内，Leader会通过TRUNC命令通知Follower将其zxid_set中大于Follower的max_zxid（如果有）的所有消息全部删除

	上述操作保证了未被Commit过的消息不会被Commit从而对外不可见。

	上述例子中Follower上并不存在未被Commit的消息。但可考虑这种情况，如果将上述例子中的服务器数量从五增加到七，服务器F包含P1、P2、C1、P3，服务器G包含P1、P2。此时服务器F、A和B都包含P3，但是因为票数未过半，因此B作为Leader不会Commit P3，而会通过TRUNC命令通知F删除P3。如下图所示。

![](http://www.jasongj.com/img/zookeeper/1_architecture/recovery_4.png)


http://www.jasongj.com/kafka/transaction/


#7,基于Zookeeper的分布式锁与领导选举 

	
	参考地址：http://www.jasongj.com/zookeeper/distributedlock/



