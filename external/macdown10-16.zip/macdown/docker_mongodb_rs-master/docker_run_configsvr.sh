
#configsvr0 部署在134
#configsvr1 部署在135
#configsvr2 部署在136

#保存镜像
#docker save 11111 > mongo.tar

#导入镜像
#docker load < mongo.tar

#tag重命名
#docker tag f7adfc4dbcf5 docker.io/mongo:latest

 mkdir -p /home/mongodb/data/cs/configsvr0
 mkdir -p /home/mongodb/data/cs/configsvr1
 mkdir -p /home/mongodb/data/cs/configsvr2

#docker run -d --name configsvr0  -v /home/mongodb/conf/mongod_config.conf:/data/configdb/mongod.conf -v /home/mongodb/testKeyFile.file:/data/configdb/testKeyFile.file -v /home/mongodb/log/cs/configsvr0:/var/log/mongodb -v /home/mongodb/data/cs/configsvr0:/data/configdb mongo --config /data/configdb/mongod.conf --configsvr --replSet "rs_configsvr"  --bind_ip_all
docker run --network host  -d --name configsvr0  -v /home/mongodb/conf/mongod_config.conf:/data/configdb/mongod.conf -v /home/mongodb/testKeyFile.file:/data/configdb/key.file -v /home/mongodb/log/cs/configsvr0/config.log:/data/configdb/log/config.log -v /home/mongodb/data/cs/configsvr0:/data/configdb mongo --config /data/configdb/mongod.conf --profile=1 --slowms=10
docker run --network host -d --name configsvr1  -v /home/mongodb/conf/mongod_config.conf:/data/configdb/mongod.conf -v /home/mongodb/testKeyFile.file:/data/configdb/key.file -v /home/mongodb/log/cs/configsvr1/config.log:/data/configdb/log/config.log -v /home/mongodb/data/cs/configsvr1:/data/configdb mongo --config /data/configdb/mongod.conf --profile=1 --slowms=10
docker run --network host -d --name configsvr2  -v /home/mongodb/conf/mongod_config.conf:/data/configdb/mongod.conf -v /home/mongodb/testKeyFile.file:/data/configdb/key.file -v /home/mongodb/log/cs/configsvr2/config.log:/data/configdb/log/config.log -v /home/mongodb/data/cs/configsvr2:/data/configdb mongo --config /data/configdb/mongod.conf --profile=1 --slowms=10
#docker run -d --name configsvr1  -v /home/mongodb/data/cs/configsvr1:/data/configdb mongo --configsvr --replSet "rs_configsvr"  --bind_ip_all
#docker run -d --name configsvr2  -v /home/mongodb/data/cs/configsvr2:/data/configdb mongo --configsvr --replSet "rs_configsvr"  --bind_ip_all
