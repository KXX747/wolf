docker start configsvr0
docker start configsvr1
docker start configsvr2
