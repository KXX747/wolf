docker stop mongos0
docker stop mongos1
docker stop mongos2
docker stop configsvr0
docker stop configsvr1
docker stop configsvr2
docker stop shardsvr00
docker stop shardsvr01
docker stop shardsvr02
docker stop shardsvr10
docker stop shardsvr11
docker stop shardsvr12

