docker run  --name mongodb_dump -d -v $PWD/../../mongodb_bak:/data/mongodb_bak mongo

