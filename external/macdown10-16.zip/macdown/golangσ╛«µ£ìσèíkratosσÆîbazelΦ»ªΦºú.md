#golang微服务kratos和bazel详解


#一，kratos-tool使用

###1，kratos生成工程


	kratos new是快速创建一个项目的命令，执行如下：

	kratos new kratos-demo

	即可快速在当前目录生成一个叫kratos-demo的项目。此外还支持指定owner和path，如下：
	
	kratos new kratos-demo -o YourName -d YourPath
	
	kratos new videopicture-getaway-servers -o liuhui -d /Users/a747/go/src/github.com/KXX747/


	注意，kratos new默认是不会生成通过 protobuf 定义的grpc和bm示例代码的，如需生成请加--proto，如下：
	
	kratos new kratos-demo -o YourName -d YourPath --proto
	
	kratos new user-account-server -o liuhui -d /Users/a747/go/src/github.com/KXX747 --proto

	
    特别注意，如果不是MacOS系统，需要自己进行手动安装protoc，用于生成的示例项目api目录下的proto文件并不会自动生成对应的.pb.go和.bm.go文件。

    也可以参考以下说明进行生成：protoc说明
   
   下载 protobuf之后无法找到插件，需要make install   
   go get github.com/gogo/protobuf
	
export KRATOS_HOME = "/Users/a747/go/src/github.com/bilibili/kratos"  
export KRATOS_DEMO = "/Users/a747/go/src/github.com/KXX747/wolf/public/user-acount-server/api"  

	#生成：api.pb.go  
protoc -I$GOPATH/src:$KRATOS_HOME/tool/protobuf/pkg/extensions:$KRATOS_DEMO/api --gogofast_out=plugins=grpc:$KRATOS_DEMO/api $KRATOS_DEMO/api/api.proto

	# 生成：api.bm.go
protoc -I$GOPATH/src:$KRATOS_HOME/tool/protobuf/pkg/extensions:$KRATOS_DEMO/api --bm_out=$KRATOS_DEMO/api $KRATOS_DEMO/api/api.proto

	# 生成：api.swagger.json
protoc -I$GOPATH/src:$KRATOS_HOME/tool/protobuf/pkg/extensions:$KRATOS_DEMO/api --bswagger_out=$KRATOS_DEMO/api $KRATOS_DEMO/api/api.proto


###2,kratos build & run

	kratos build和kratos run是go build和go run的封装，可以在当前项目任意目录进行快速运行进行调试，并无特别用途。
	

###3,kratos tool

	kratos tool是基于proto生成http&grpc代码，生成缓存回源代码，生成memcache执行代码，生成swagger文档等工具集，先看下的执行效果：
	
	kratos tool
	
	swagger(已安装): swagger api文档 Author(goswagger.io) [2019/05/05]
	protoc(已安装): 快速方便生成pb.go和bm.go的protoc封装，windows、Linux请先安装protoc工具 Author(kratos) [2019/05/04]
	kratos(已安装): Kratos工具集本体 Author(kratos) [2019/04/02]
	
	安装工具: kratos tool install demo
	执行工具: kratos tool demo
	安装全部工具: kratos tool install all

	详细文档： https://github.com/bilibili/kratos/blob/master/doc/wiki-cn/kratos-tool.md

    小小说明：如未安装工具，第一次运行也可自动安装，不需要特别执行install

目前已经集成的工具有：

    kratos 为本体工具，只用于安装更新使用；
    protoc 用于快速生成gRPC、HTTP、Swagger文件，该命令Windows，Linux用户需要手动安装 protobuf 工具；
    swagger 用于显示自动生成的HTTP API接口文档，通过 kratos tool swagger serve api/api.swagger.json 可以查看文档；
    genmc 用于自动生成memcached缓存代码；
    genbts 用于生成缓存回源代码生成，如果miss则调用回源函数从数据源获取，然后塞入缓存；

[文档目录树](https://github.com/bilibili/kratos/blob/master/doc/wiki-cn/summary.md)

kratos tool swagger serve api/api.swagger.json
###4,

生成后可直接运行如下

	cd kratos-demo/cmd
	go build 
	
	./cmd -conf ../configs
	
	打开浏览器访问：http://localhost:8000/kratos-demo/start，你会看到输出了Golang 大法好 ！！！
	
	
#二，go mod依赖
	
	替换不能下载的包
	golang.org/x/net v0.0.0-20190311183353-d8887717615a
	golang.org/x/sync v0.0.0-20190423024810-112230192c58
	golang.org/x/crypto v0.0.0-20190308221718-c2843e01d9a2
	golang.org/x/sys@v0.0.0-20190215142949-d0b11bdaac8a
	golang.org/x/text@v0.3.0
	
	
	4adf7a708c2de4c9ea24a1f351c2e1c9b82fbde8
		
	 go mod edit -replace=golang.org/x/net@v0.0.0-20190311183353-d8887717615a=github.com/golang/net@v0.0.0-20190311183353-d8887717615a
	 
	go mod edit -replace=golang.org/x/sync@v0.0.0-20190423024810-112230192c58=github.com/golang/sync@v0.0.0-20190423024810-112230192c58
	
	go mod edit -replace=golang.org/x/crypto@v0.0.0-20190308221718-c2843e01d9a2=github.com/golang/crypto@v0.0.0-20190308221718-c2843e01d9a2
	
	go mod edit -replace=golang.org/x/sys@v0.0.0-20190215142949-d0b11bdaac8a=github.com/golang/sys@v0.0.0-20190215142949-d0b11bdaac8a
	
	go mod edit -replace=golang.org/x/text@v0.0.0-4adf7a708c2de4c9ea24a1f351c2e1c9b82fbde8=github.com/golang/text@v0.0.0-4adf7a708c2de4c9ea24a1f351c2e1c9b82fbde8
	
		
	go mod edit -replace=golang.org/x/text@v0.3.0=github.com/golang/text@v0.3.0
	
	4adf7a708c2de4c9ea24a1f351c2e1c9b82fbde8
	
	
	 	download    download modules to local cache
        edit        edit go.mod from tools or scripts
        graph       print module requirement graph
        init        initialize new module in current directory
        tidy        add missing and remove unused modules
        vendor      make vendored copy of dependencies
        verify      verify dependencies have expected content
        why         explain why packages or modules are needed

	
	下载依赖
	go mod download
	
	
	

#三,bazel微服务构建

### 1,安装：
	centos安装
	
	yum install bazel
	
	mac安装
	brew tap bazelbuild/tap
	brew install bazelbuild/tap/bazel
	
	All set! You can confirm Bazel is installed successfully by running the following command:
	
	bazel version
	
	Once installed, you can upgrade to a newer version of Bazel using the following command:
	
	brew upgrade bazelbuild/tap/bazel


  https://github.com/bazelbuild/bazel
  
  
### 错误解决
	
  
  
### 2, bazel详解




###3，bazel构建kratos微服务

	
	https://github.com/bazelbuild/rules_go
	
	https://blog.didiyun.com/index.php/2019/03/27/bazel-golang/
	
	http://brendanjryan.com/golang/bazel/2018/05/12/building-go-applications-with-bazel.html

	https://www.cnblogs.com/zjutzz/p/10305301.html
	
  
	
