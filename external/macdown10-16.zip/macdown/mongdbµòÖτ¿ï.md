# 一，mongdb集群和分片概述

![分片集群搭建架构详解](https://images2018.cnblogs.com/blog/242916/201803/242916-20180313222747434-1293437958.png)

mongodb分片集群由下面几个组建组成: mongos->configure server -> shard-> 投票

    shard 官方建议采用副本集，提供数据冗余和高可用，主要存储业务数据
    mongos 是应用程序的接口，通过它，应用程序与整个集群是透明的，故一般每个应用服务器对应一个实例，可以跟应用部署到一台服务器上。它主要读取或缓存配置服务器中元数据，提供查询路由到每个分片的功能
    configure servers 官方建议采用副本集，存储集群的元数据。很重要，能够影响集群的使用
    详细见：https://docs.mongodb.com/manual/sharding/
    
    primary  secondary 主从模式
    
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***  


# 二,mongodb的简单的curd教程

####a,创建和删除数据库
	
	use test //test不存在是创建数据库
	db.createCollection("test")创建数据库
	
	
	db.test.drop()//删除数据库
	
	show collections //查看表
	
	db.collection.drop()
	如果成功删除选定集合，则 drop() 方法返回 true，否则返回 false。

####b,创建集合和capped
  
> 创建语法
  	
  	db.createCollection(name,options)
  	 //name表名称
  	 //options 可选参数，指定有关内存大小及索引的选项
  	 
  	options 可以是如下参数：
	字段 	类型 	描述
	capped 	布尔 	（可选）如果为 true，则创建固定集合。固定集合是指有着固定大小的集合，当达到最大值时，它会自动覆盖最早的文档。
	当该值为 true 时，必须指定 size 参数。
	autoIndexId 	布尔 	（可选）如为 true，自动在 _id 字段创建索引。默认为 false。
	size 	数值 	（可选）为固定集合指定一个最大值（以字节计）。
	如果 capped 为 true，也需要指定该字段。
	max 	数值 	（可选）指定固定集合中包含文档的最大数量。
	

> 固定集合 capped collection

 	 db.createCollection("mycol", { capped : true, autoIndexId : true, size : 
   6142800, max : 10000 } )


> 创建表
	insert插入数据时，表不存在会被自动创建
	
	db.col.insert({title: 'MongoDB 教程', 
    description: 'MongoDB 是一个 Nosql 数据库',
    by: '菜鸟教程',
    url: 'http://www.runoob.com',
    tags: ['mongodb', 'database', 'NoSQL'],
    likes: 100
	})

####c,删除集合

   remove() 方法的基本语法格式如下所示：

	db.collection.remove(
	   <query>,
	   {
	     justOne: <boolean>,
	     writeConcern: <document>
	   }
	)
		
	参数说明：
    query :（可选）删除的文档的条件。
    justOne : （可选）如果设为 true 或 1，则只删除一个文档，如果不设置该参数，或使用默认值 false，则删除所有匹配条件的文档。
    writeConcern :（可选）抛出异常的级别。
    
    >db.col.insert({title: 'MongoDB 教程', 
    description: 'MongoDB 是一个 Nosql 数据库',
    by: '菜鸟教程',
    url: 'http://www.runoob.com',
    tags: ['mongodb', 'database', 'NoSQL'],
    likes: 100
	})

	使用 find() 函数查询数据：

	> db.col.find()
	{ "_id" : ObjectId("56066169ade2f21f36b03137"), "title" : "MongoDB 教程", "description" : "MongoDB 是一个 Nosql 数据库", "by" : "菜鸟教程", "url" : "http://www.runoob.com", "tags" : [ "mongodb", "database", "NoSQL" ], "likes" : 100 }
	{ "_id" : ObjectId("5606616dade2f21f36b03138"), "title" : "MongoDB 教程", "description" : "MongoDB 是一个 Nosql 数据库", "by" : "菜鸟教程", "url" : "http://www.runoob.com", "tags" : [ "mongodb", "database", "NoSQL" ], "likes" : 100 }
	
	接下来我们移除 title 为 'MongoDB 教程' 的文档：
	
	>db.col.remove({'title':'MongoDB 教程'})
	WriteResult({ "nRemoved" : 2 })           # 删除了两条数据
	>db.col.find()
	
	db.col.remove({}) //移除所有数据
	db.col.find({}) //查询

####d,更新集合
	
> 更新操作 $set

	语法：
	db.collection.update(
		<query>,
		<update>,
		{
			upsert:<boolean>,
			multi:<boolean>,
			writeConcern:<document>
		}	
	)
	
	参数说明：
	query : update的查询条件，类似sql update查询内where后面的。
	update :update的对象和一些更新的操作符（如$,$inc）
	upsert :可选，如果不存在update的记录，是否插入，true为插入，默认false
	multi :可选，mongodb默认是false，只更新找到的第一条记录，如果这个参数为true，就按条件差出来更新多条记录全部更新
	writeConcern:可选，抛出异常的级别
	
	
> update的$set更新数据

    db.col.insert({
    title: 'MongoDB 教程', 
    description: 'MongoDB 是一个 Nosql 数据库',
    by: '菜鸟教程',
    url: 'http://www.runoob.com',
    tags: ['mongodb', 'database', 'NoSQL'],
    likes: 100
	})
	
	//更新
	db.col.update({title: 'MongoDB 教程'},{$set:{title: 'MongoDB'}})
	

> save替换数据
	
	语法：
		
	db.collection.save(<document>,{writeConcern:<document>})	
    db.col.save({
    "_id" : ObjectId("5d4c26213d66900b7361556b"),
    "title" : "MongoDB",
    "description" : "MongoDB 是一个 Nosql 数据库",
    "by" : "菜鸟教程",
    "url" : "http://www.runoob.com",
    "tags" : [ 
        "mongodb", 
        "database", 
        "NoSQL"
    ],
    "likes" : 110.0
	})
		

####e,查询集合
	
	db.collection.find({query,projection})

	query ：可选，使用查询操作符指定查询条件
	projection ：可选，使用投影操作符指定返回的键。查询时返回文档中所有键值， 只需省略该参数即可（默认省略）。
	
	 db.col.find({likes:{"$ne":100}})  //不等于100的
	
	
	

####f,插入集合
	
	所有存储在集合中的数据都是 BSON 格式。
	BSON 是一种类似 JSON 的二进制形式的存储格式，是 Binary JSON 的简称。
	
	MongoDB 使用 insert() 或 save() 方法向集合中插入文档，语法如下：
	
	db.collection.insert(document)
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***	
	
# 三,mongodb的运算符
	
>1，比较运算符号

   	(>) 大于 - gt
	(<) 小于 - lt
	(>=) 大于等于 - gte
	(<= ) 小于等于 - lte
	
	db.col.find({likes:{"ne":100}})  
		

>2，条件运算符号 or,and,nor,not,exites,type

	
>> or运算符号满足一个条件即可
 语法：
 
	{ or: [ { <expression1> }, { <expression2> }, ... , { <expressionN> } ] }
	
	使用：
	db.col.find( {or :[{"likes" : 110.0},{"likes":{lt:10}}]})
	
	
	
	
>> and运算符号两个都要满足

语法：
	Syntax: { and: [ { <expression1> }, { <expression2> } , ... , { <expressionN> } ] }
	
	//
	db.col.find( {and :[{"likes" : 110.0},{"likes":{gt:10}}]})




>> nor运算符号

语法：
	{ nor: [ { <expression1> }, { <expression2> }, ...  { <expressionN> } ] }
	db.col.find( {nor :[{"likes" : 120.0},{"likes":{lt:10}}]})	
	

>> not运算符号

语法：
	Syntax: { field: { not: { <operator-expression> } } }
	
	//查询不大于120的值
	db.col.find({"likes":{not:{gt:120}}})

	
>3,元素查询运算符 exists type	

>> exites运算符号 匹配具有指定字段的文档。
	
	语法： { field: { exists: <boolean> } }
	如果<boolean>为true，则exists匹配包含该字段的文档，包括字段值所在的文档 null。如果<boolean>为false，则查询仅返回不包含该字段的文档。
	
	db.col.find({"likes":{exists:true}}) //字段存在可以取出来
	db.col.find({"likes":{existss:true}}) //字段不存在无法取出
	

>>type运算符号 如果字段是指定类型，则选择文档。

	type操作符是基于BSON类型来检索集合中匹配的数据类型，并返回结果。
	
	类型 			数字 	备注
	Double 		1 	 
	String 		2 	 
	Object 		3 	 
	Array 			4 	 
	Binary data 	5 	 
	Undefined 	6 		已废弃。
	Object id 	7 	 
	Boolean 		8 	 
	Date 			9 	 
	Null 			10 	 
	Regular Expression 11 	 
	JavaScript 	13 	 
	Symbol 		14 	 
	JavaScript (with scope) 15 	 
	32-bit integer 	16 	 
	Timestamp 	17 	 
	64-bit integer 	18 	 
	Min key 		255 	Query with -1.
	Max key 		127 	 


	如果想获取 "col" 集合中 title 为 String 的数据，你可以使用以下命令：

	db.col.find({"title" : {type : 2}})
	或
	db.col.find({"title" : {type : 'string'}})
	


> 4,评估查询运算符 expr jsonSchema mod text where
	
	
>>	expr 允许在查询语言中使用聚合表达式。
	语法：
		{ $expr: { <expression> } }
	


>>	jsonSchema根据给定的JSON模式验证文档。

>>  mod 对字段的值执行模运算，并选择具有指定结果的文档。
	语法： divisor除数，remainder余数
	{  field ： {  $ mod ： [  divisor ， remainder  ]  }  }
	
	db.col.find("likes":{$ mod :[10,0]})


>> regex 选择值与指定正则表达式匹配的文档。
   	
   

>> text 执行文本搜索。（不支持中文分词）

>> where 匹配满足JavaScript表达式的文档。

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***

#4,mongodb的update的操作符

> 运算符一 

>>$currentDate	将字段的值设置为当前日期，可以是Date或Timestamp。

	

>>$inc	按指定的数量增加字段的值。
	语法：
	{ $inc: { <field1>: <amount1>, <field2>: <amount2>, ... } }
	
	//likes +（-2）
	db.col.update({"title":"golang学习"},{$inc:{"likes":-2}})
	

>>$min	仅当指定的值小于现有字段值时才更新字段。
	
	语法：
	{ $min: { <field1>: <value1>, ... } }
	//score为10，指定min的值为小于10才会更新
	db.col.update({"title":"mongodb学习"},{$min:{"score":9}})

	

>>$max	仅当指定的值大于现有字段值时才更新字段。
	语法：
	{ $max: { <field1>: <value1>, ... } }
		//score为9，指定max的值为大于9才会更新
	db.col.update({"title":"mongodb学习"},{$max:{"score":100}})


>>$mul	将字段的值乘以指定的量。
	
	语法：
	{ $mul: { <field1>: <number1>, ... } }
	
	db.col.update({"title":"mongodb学习"},{$mul:{a:NumberLong(100),score:2}})
	该操作导致以下文档，其中新值 a反映原始值10.99乘以1.25 和新值score反映原始值25 乘以2：


		

>>$rename	重命名字段。
	
	/将likes替换为score字段
	db.col.update({likes:{$gte:10}},{$rename:{"likes":"score"}})

>>$set	设置文档中字段的值。
	
	//更新数据
	db.col.update({"title":"mongodb学习"},{$set:{"score":159}})


>>$setOnInsert	如果更新导致文档插入，则设置字段的值。对修改现有文档的更新操作没有影响。
	
	语法：
	db.collection.update(
	   <query>,
	   { $setOnInsert: { <field1>: <value1>, ... } },
	   { upsert: true }
	)

	//数据不存在直接插入数据
	db.col.update(
	  { "_id" : ObjectId("5d4ce8475cae39aab458c0c7")},
	  {
	     $set: { title: "apple" },
	     $setOnInsert: { likes: 100 }
	  },
	  { upsert: true }
	)
	

>>$unset	从文档中删除指定的字段。

	语法：
	{ $unset: { <field1>: "", ... } }
	
	//删除likes字段
	db.col.update({"title":"apple"},{$unset:{likes:0}})
	
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***

#5,mongodb的update数组操作符和修饰符

>> 原始表

	db.students.insert([
	   { "_id" : 1, "grades" : [ 85, 80, 80 ] },
	   { "_id" : 2, "grades" : [ 88, 90, 92 ] },
	   { "_id" : 3, "grades" : [ 85, 100, 90 ] }
	])

>>$	充当占位符以更新与查询条件匹配的第一个元素。
	
	//$匹配第一个数据，修改的数据必须在query中存在
	db.students.updateOne(
	   { _id: 1, grades: 80 },
	   { $set: { "grades.$" : 82 } }
	)
  

>>$[]	充当占位符以更新数组中与查询条件匹配的文档中的所有元素。

	db.collection.update(
	   { myArray: [ 5, 8 ] },
	   { $set: { "myArray.$[]": 10 } },
	   { upsert: true }
	)


>>$[<identifier>]	充当占位符以更新与arrayFilters匹配查询条件的文档的条件匹配的所有元素。


	
>>$addToSet	仅当数组中尚不存在元素时才将元素添加到数组中，添加到末尾。
	
	语法：
	{ $addToSet: { <field1>: <value1>, ... } }
	
	db.students.update({_id:1},{$addToSet:{grades:200}})


>>$pop	删除数组的第一个或最后一个项目。
		
		//pop为-1 删除数据第一个数，1删除数据最后一个数
		db.students.update({_id:1},{$pop:{grades:-1}})

>>$pull删除与指定查询匹配的所有数组元素。
	
		//多条数据用updateMany,删除所有数组中包含200的
	 	db.students.updateMany({},{$pull:{grades:200}})
		

>>$push	将项添加到数组。
	
		/添加数据在末尾
		db.students.update({_id:1},{$push:{grades:200}})


>>$pullAll	从数组中删除所有匹配的值。

		语法：
		{ $pullAll: { <field1>: [ <value1>, <value2> ... ], ... } }
		
		//删除数组中包含200和300的数据
		db.students.updateMany({},{$pullAll:{grades:[200,300]}})



>>$each修改$push和$addToSet运算符以附加多个项目以进行阵列更新。each是添加数据
			
		语法：
		{ $push: { <field>: { $each: [ <value1>, <value2> ... ] } } }

		//下面两次都可以添加,对数组添加新的值
		db.students.update({_id:1},{$addToSet:{grades:{$each:[400,500]}}})
		db.students.update({_id:1},{$push:{grades:{$each:[400,500]}}})



>>$position修改$push运算符以指定数组中添加元素的位置。

	语法：
	{
	  $push: {
	    <field>: {
	       $each: [ <value1>, <value2>, ... ],
	       $position: <num>
	    }
	  }
	}	
	
	//each添加数据,position声明添加的位置
	db.students.update({_id:1},{$push:{
    grades:{
        $each:[50,60,7],
        $position:0
        }
    
    }})
	


>>$slice修改$push运算符以限制更新数组的大小。

	语法：	
	{
	  $push: {
	     <field>: {
	       $each: [ <value1>, <value2>, ... ],
	       $slice: <num>
	     }
	  }
	}
	
	该<num>可以是：
	 0：将数组更新为<field>空数组。
	 负数：	更新数组<field>以仅包含最后一个 <num>元素。
	 正数：	更新数组<field>只包含第一个<num> 元素。
	
	//slice为
	db.students.update({_id:2},{$push:{
    grades:{
        $each:[50,60,70],
        $slice:-5
        }
    
    }})
	


>>$sort修改$push运算符以重新排序存储在数组中的文档。

	语法：
	{
	  $push: {
	     <field>: {
	       $each: [ <value1>, <value2>, ... ],
	       $sort: <sort specification>
	     }
	  }
	}
	
	//添加数据并排序
	db.students.update({_id:2},{
	     $push:{
	         
	        grades :{
	            
	            $each:[100,6000,700000],
	            $sort:{grades:1}
	            }
	     }
	})
	

>> $bit执行按位AND，OR和XOR更新整数值

	
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***

#6,mongodb的索引-Indexes

>索引的创建使用

	参考官方文档和http://www.mongoing.com/archives/2797
	
>>单键索引 -- single field

	//创建数据：
	var arr = [];
		for(var i=0;i<100000;i++){
		    var name ="jack"+i;
		    var age = parseInt(Math.random()*100000000)%1000;
		    arr.push({"name":name,"age":age})
		    
	}
	
	db.singleindex_col.insert(arr);
	db.singleindex_col.count()
	
	
	//创建索引 1为
	db.singleindex_col.createIndex({"age":1})
	explain(）查看索引的使用



>>复合索引 -- compound index
	
	//创建复合索引
	db.singleindex_col.createIndex({"age":1,"name":1})
	
	explain(）查看索引的使用
	db.singleindex_col.find({}).sort({age:-1,name:-1}).explain()

>>多值索引 -- multikey indexs

	语法：
	db.coll.createIndex( { <field>: < 1 or -1 > } )
	
	创建数据：
		{ _id: 5, type: "food", item: "aaa", ratings: [ 5, 8, 9 ] }
		{ _id: 6, type: "food", item: "bbb", ratings: [ 5, 9 ] }
		{ _id: 7, type: "food", item: "ccc", ratings: [ 9, 5, 8 ] }
		{ _id: 8, type: "food", item: "ddd", ratings: [ 9, 5 ] }
		{ _id: 9, type: "food", item: "eee", ratings: [ 5, 9, 5 ] }
		
	创建多值索引
		db.multikeyindex_col.createIndex({ratings:1})
		
		db.getCollection('multikeyindex_col').find({"ratings":[5,8]}).explain()
	
>>地理空间索引 --geospatial index


>>文本索引 -- text index


>>hash索引 -- hashed index
	
	 针对属性的哈希值进行索引查询，当要使用Hashed index时，MongoDB能够自动的计算hash值，无需程序计算hash值。注：hash index仅支持等于查询，不支持范围查询 
	 
	  db.multikeyindex_col.createIndex({age:"hashed"})


>>局部索引 -- partialIndexes

	 对集合中指定的筛选器表达式筛选后的部分集合进行创建索引，优点：减少了存储空间，提高的查询效率
	 
	 db.multikeyindex_col.createIndex(
	   { item: 1,type: 1 },
	   { partialFilterExpression: { rating: { $gt: 5 } } }
	)
		
	 

>>唯一索引 -- Unique Indexes
	
	创建
	db.multikeyindex_col.createIndex( { age: 1 }, { unique: true } )
	

>>TTL索引 -- 过期索引

	创建：  expireAfterSeconds过期的秒数
		
	db.mydate.insert({
     "createAt":new Date(),
     "logEvent":2,
      "logMessage":"Succcess!",
    })

	 db.mydate.find({})
	  创建索引
	db.mydate.createIndex({"createAt":1},{expireAfterSeconds:5})
	
	ttl索引过期有延迟？background线程执行，60s执行一次，实时执行会有性能问题
		
	
> 索引的管理与优化
		
>>获取collection的索引

	db.mydate.getIndexes()

>>索取库的索引
	
	 db.getCollectionNames().forEach(function(collection) {
	   indexes = db[collection].getIndexes();
	   print("Indexes for " + collection + ":");
	   printjson(indexes);
	});

>>index优化建议
	
	参考地址：https://www.jianshu.com/p/2b09821a365d
	
	1，创建的索引最好能够覆盖大多数的查询
		{"category":1,"item":1}
	   可以用 categroy做前缀
	   也可以用 categroy+item
	   千万不能 item+category
	   
	2,sort的时候最好sort的键也要在索引上面
	
	3，index最好都能够存储在内存中
		db.collection.totalIndexSize()
	
	4,确保索引的高选择性
		比如有10个index，其中有1，2index基本上是不被选中的，那么这个索引基本上就没什么用。。。
		
	5,先查询后排序
	
	
	
	

> 索引的原理
		
	B-树索引
  	是MongoDB的默认索引结构。以下是B-树索引结构高等级的概述。
  	
  	参考地址：
  	https://www.jianshu.com/p/1ed61b4cca12
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***	
		
#7,GridFS分析和mongofiles工具

>> GridFS分布式文件存储 --大于16m的可以存储在里面，bson最大只能存储16m


>> GridFS和mongofiles可以做存储
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***

#8,Aggregation pipeline框架详细分析,聚合group详解 ,计算框架MapReduce详解



>Aggregation pipeline框架详细分析
	
	创建表：
	db.orders.insert([
	  { "_id" : 1, "item" : "almonds", "price" : 12, "quantity" : 2 },
	   { "_id" : 2, "item" : "pecans", "price" : 20, "quantity" : 1 },
	   { "_id" : 3  }
	])
	  
	db.inventory.insert([
	   { "_id" : 1, "sku" : "almonds", description: "product 1", "instock" : 120 },
	   { "_id" : 2, "sku" : "bread", description: "product 2", "instock" : 80 },
	   { "_id" : 3, "sku" : "cashews", description: "product 3", "instock" : 60 },
	   { "_id" : 4, "sku" : "pecans", description: "product 4", "instock" : 70 },
	   { "_id" : 5, "sku": null, description: "Incomplete" },
	   { "_id" : 6 }
	])

>>>Aggregation pipeline管道模型 --后面操作的数据来源前一个数据

>>>常用的pipeline

>>>>$project sql的select
	
	//project选择字段， project为1表示
	db.orders.aggregate([{
	    $lookup:{
	        from:"inventory",
	        localField:"item",
	        foreignField:"sku",
	        as:"inventory_docs"
	        }
	 },{
	     $match:{
	        "price":{$gt:0}
	         }
	},{
	    
	        $project:{
	            
	           "_id":1,
	            "item":1,
	        }
	    }
	])

>>>> $match  sql的where
	
	//先连表查询，在根据match过滤俄掉price价格小于等于0的
	db.orders.aggregate([{
	    $lookup:{
	        from:"inventory",
	        localField:"item",
	        foreignField:"sku",
	        as:"inventory_docs"
	        }
	 },{
	     $match:{
	        "price":{$gt:0}
	         }
	  }])

>>>> $limit  sql的limit

>>>> $skip   

>>>> $unwind  将数据拆分成每一个document

>>>> $group   分组计算 --有100m的内存限制,使用硬盘{"allowDiskUse":true}
	
	//对数据惊醒分组计算
	db.orders.aggregate([{
	    $lookup:{
	        from:"inventory",
	        localField:"item",
	        foreignField:"sku",
	        as:"inventory_docs"
	        }
	 },{
	     $match:{
	        "price":{$gt:0}
	         }
	},{
	      $group:{
	           _id:"$id",
	          totalPrice:{$sum: { $multiply: [ "$price", "$quantity" ] } },
	          
	          averageQuantity: { $avg: "$quantity" },
	          count: { $sum: 1 }
	          }
	    }
	],{"allowDiskUse":true})
	
	
	参数：
		 _id  一定要存在，可以为null或者其它值
		$multiply [ "$price", "$quantity" ]数据相乘
		$sum 相加

	
>>>> $sample  随机选择文档

>>>> $sort    sql中dedesc和asc --有100m的内存限制,使用硬盘

>>>> $geoNear  经纬度


>>>> $lookup   sql的join操作

 	//表关联查询，orders表关联inventory表
	db.orders.aggregate([
	   {
	     $lookup:
	       {
	         from: "inventory", // 关联inventory表
	         localField: "item", //orders表的item字段，值和sku的值相等
	         foreignField: "sku", //inventory表的sku字段，值和item相等
	         as: "inventory_docs" //关联到orders表中的字段名称
	       }
	  }
	])	 

>>>> $out.     将最后的结果输出到collection中去
	
	//将结果写到myaggregate_out_col表里面
	db.orders.aggregate([
	   {
	     $lookup:
	       {
	         from: "inventory",
	         localField: "item",
	         foreignField: "sku",
	         as: "inventory_docs"
	       }
	  },{
	      $out:"myaggregate_out_col"
	      }
	])

>>>> indexStats 查询中使用的索引情况


>>>> $redact    决定内嵌文档是否保留


>>>> $count   返回聚合管道此阶段的文档数量计数。





>聚合group详解
  

	 {
	  group:
	   {
	     ns: <namespace>,
	     key: <key>,
	     $reduce: <reduce function>,
	     $keyf: <key function>,
	     cond: <query>,
	     finalize: <finalize function>
	   }
	}

 
 	ns :collection 你的group的集合。。。。
 	key :我们group的键值
 	$keyf : 采用函数的定义我们的key,我们可以后更高的灵活性来定义。。。。去string的最后一个字母，或者中间，或者最后。。。
 	$reduce 刚好就是我们聚合进行中的每个操作。。。
 	$initial:聚合的初始文档，，，
 	cond : ($match where条件)
 	finalize 在某一个groupkey结束后插入点。。。。
   
	 //使用
	db.runCommand(
	   { group:
	       {
	         ns: 'orders',
	         key: { ord_dt: 1, 'item.sku': 1 },
	         cond: { ord_dt: { $gt: new Date( '01/01/2012' ) } },
	         $reduce: function ( curr, result ) {
	                     result.total += curr.item.qty;
	                  },
	         initial: { total : 0 }
	       }
	    }
	)




>计算框架MapReduce详解
		
		用做大数据计算	


***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***	
#9,Storage 存储引擎

	 nmap
	 wriedtiger事务引擎


#10,WT事务的实现-基于快照
		
>事物由的构造：

	 snapshot（事务快照） ， mvcc（多版本并发） ，redolog(重做日志)
	 
	 
	 事务对象和全局事务管理器。事务对象描述如下：
	 wt_transaction{

		transaction_id:    本次事务的全局唯一的ID，用于标示事务修改数据的版本号
		snapshot_object:   当前事务开始或者操作时刻其他正在执行且并未提交的事务集合,用于事务隔离
		operation_array:   本次事务中已执行的操作列表,用于事务回滚。
		redo_log_buf:      操作日志缓冲区。用于事务提交后的持久化
		State:             事务当前状态
	}

	 
>WT多版本并发mvcc

>>  WT中的MVCC是基于key/value中value值的链表，这个链表单元中存储有当先版本操作的事务ID和操作修改后的值。描述如下：

     wt_mvcc{

         transaction_id:    本次修改事务的ID

         value:             本次修改后的值

	}
	
    WT中的数据修改都是在这个链表中进行append操作，每次对值做修改都是append到链表头上，每次读取值的时候读是从链表头根据值对应的修改事务transaction_id和本次读事务的snapshot来判断是否可读，如果不可读，向链表尾方向移动，直到找到读事务能都的数据版本。样例如下：
    
![事务的mvcc](https://img-blog.csdn.net/20171025113153140?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQveXVhbnJ4ZHU=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/Center)
	
	上图中，事务T0发生的时刻最早，T5发生的时刻最晚。T1/T2/T4是对记录做了修改。那么在mvcc list当中就会增加3个版本的数据，分别是11/12/14。如果事务都是基于snapshot级别的隔离，T0只能看到T0之前提交的值10，读事务T3访问记录时它能看到的值是11，T5读事务在访问记录时，由于T4未提交，它也只能看到11这个版本的值。这就是WT 的MVCC基本原理。

	
	
>WT事务	snapshot
	
	参考地址：
	https://blog.csdn.net/yuanrxdu/article/details/78339295
	
	
		

#Replication
#Sharding





	https://docs.mongodb.com/manual/reference/operator/query/type/#op._S_type
	

