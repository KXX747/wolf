-- 缓存

-- 缓存的名字
local shared =ngx.shared["lua_shared_cache_key"];

local suc,err, farc;

for index=1,1000000,1 do
  suc ,err,farc = shared:set(tostring(index),string.rep('a',1));

  --ngx.say( "suc = " .. suc .. "\n" );
end

local keys = shared:get_keys();

ngx.say(#keys);
