
#一，Opentracing标准详解

###1，在单体应用中实现Tracing.

在编写代码之前还得理解下Jaeger中最基础的几个概念, 也是OpenTracing
的数据模型: Trace / Span

    Trace: 调用链, 其中包含了多个Span.
    Span: 跨度, 计量的最小单位, 每个跨度都有开始时间与截止时间. Span和Span之间可以存在References(关系): ChildOf 与 FollowsFrom

如下图 (来至开放分布式追踪（OpenTracing）入门与 Jaeger 实现)

单个 Trace 中，span 间的因果关系
        [Span A]  ←←←(the root span)
            |
     +------+------+
     |             |
 [Span B]      [Span C] ←←←(Span C 是 Span A 的孩子节点, ChildOf)
     |             |
 [Span D]      +---+-------+
               |           |
           [Span E]    [Span F] >>> [Span G] >>> [Span H]
                                       ↑
                                       ↑
                                       ↑
                         (Span G 在 Span F 后被调用, FollowsFrom)
                         
一个Trace中Span间的时间关系

––|–––––––|–––––––|–––––––|–––––––|–––––––|–––––––|–––––––|–> time

 [Span A···················································]
   [Span B··············································]
      [Span D··········································]
    [Span C········································]
         [Span E·······]        [Span F··] [Span G··] [Span H··]
                         

###2， 每个Span封装了如下状态:

    操作名称

    开始时间戳

    结束时间戳

    一组零或多个键:值结构的Span标签(Tags)。键必须是字符串。值可以是字符串，布尔或数值类型.

    一组零或多个Span日志(Logs)，其中每个都是一个键:值映射并与一个时间戳配对。键必须是字符串，值可以是任何类型。 并非所有的OpenTracing实现都必须支持每种值类型。

    一个SpanContext(见下文)

    零或多个因果相关的Span间的References (通过那些相关的Span的SpanContext)

每个SpanContext封装了如下状态:

    任何需要跟跨进程Span关联的，依赖于OpenTracing实现的状态(例如Trace和Span的id)

    键:值结构的跨进程的Baggage Items
                       
 
###3，Span间的Reference

一个Span可引用零或多个因果相关的SpanContext。OpenTracing目前定义了两种类型的Reference: ChildOf 和 FollowsFrom。这两种Reference类型都对父子Span间的因果关系进行了建模。未来，OpenTracing可能会为不具因果关系的Span提供不同类型的Reference (例如批量的Span，卡在队列中的Span等)。

ChildOf reference: 一个Span可以是另一个Span的子Span。在 ChildOf 引用中，父Span在某种程度上取决于子Span。下列情况会构成 ChildOf 关系:

    在一个RPC中，代表服务端的Span可作为 ChildOf 代表客户端的Span

    在一个持久化进程中，代表SQL插入的Span可作为 ChildOf 代表ORM save方法的Span

    多个并发(可能是分布式)执行任务的Span可能分别各自为 Childof 一个合并了多个子Span结果的父Span

下列这些都是有效的具有 ChildOf 关系的时序图

    [-Parent Span---------]
         [-Child Span----]

    [-Parent Span--------------]
         [-Child Span A----]
          [-Child Span B----]
        [-Child Span C----]
         [-Child Span D---------------]
         [-Child Span E----]

FollowsFrom reference: 有些父Span不依赖于任何子Span的结果。这种情况下，我们仅认为子Span在因果上 FollowsFrom 父Span。有许多不同的 FollowsFrom 引用子类别，在OpenTracing的未来版本中，它们可能会被更正式地区分。

下列这些都是有效的具有 FollowsFrom 关系的时序图

    [-Parent Span-]  [-Child Span-]


    [-Parent Span--]
     [-Child Span-]


    [-Parent Span-]
                [-Child Span-]
 
 
#二，Jaeger追踪使用

	参考：https://blog.csdn.net/liyunlong41/article/details/87932953
	


#三，tracer追踪使用