#sysbench对mycat性能测试

sysbench是一个模块化的、跨平台、多线程基准测试工具，主要用于评估测试各种不同系统参数下的数据库负载情况。关于这个项目的详细介绍请看：https://github.com/akopytov/sysbench 。
它主要包括以下几种方式的测试：

    cpu性能
    磁盘io性能
    调度程序性能
    内存分配及传输速度
    POSIX线程性能
    数据库性能(OLTP基准测试)
    
  
  
      * 产生数据
    sysbench --num-threads=128 --report-interval=3 --max-requests=0 --max-time=300 --test=/usr/local/Cellar/sysbench/1.0.17/share/sysbench/tests/include/oltp_legacy/select.lua --mysql-table-engine=innodb --oltp-table-size=50000000  --oltp-tables-count=2 --mysql-host=192.168.57.110 --mysql-port=3308 --mysql-user=root --mysql-password=rootfabric prepare
     
     
    * 执行
    sysbench --num-threads=128 --report-interval=3 --max-requests=0 --max-time=300 --test=/usr/local/Cellar/sysbench/1.0.17/share/sysbench/tests/include/oltp_legacy/select.lua --mysql-table-engine=innodb --oltp-table-size=50000000  --oltp-tables-count=2 --mysql-host=192.168.57.110 --mysql-port=3308 --mysql-user=root --mysql-password=rootfabric run

sysbench_mysql_select_56_57

    Point oltp

    * 产生数据
    sysbench --num-threads=128 --report-interval=3 --max-requests=0 --max-time=300 --test=/usr/local/Cellar/sysbench/1.0.17/share/sysbench/tests/include/oltp_legacy/oltp.lua --mysql-table-engine=innodb --oltp-table-size=50000000  --oltp-tables-count=2 --mysql-host=192.168.57.110 --mysql-port=3308 --mysql-user=root --mysql-password=rootfabric prepare
     
     
    * 执行
    sysbench --num-threads=128 --report-interval=3 --max-requests=0 --max-time=300 --test=/usr/local/Cellar/sysbench/1.0.17/share/sysbench/tests/include/oltp_legacy/oltp.lua --mysql-table-engine=innodb --oltp-table-size=50000000 --oltp-tables-count=2 --mysql-host=192.168.57.110 --mysql-port=3308 --mysql-user=root --mysql-password=rootfabric run

oltp_56_57_sysbench
