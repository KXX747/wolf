flutter配置

####一，安装flutter

git clone -b stable https://github.com/flutter/flutter.git

brew tap dart-lang/dart
brew install dart
brew info dart
./flutter --version

vi $HOME/.bash_profile
export PATH=${PATH}:/Users/a747/Apps/flutter/bin
source $HOME/.bash_profile

95169

6点

https://flutterchina.club/widgets-intro/#key



####二，Waiting for another flutter command to release the startup lock... 异常解决
	

	进入到你的flutter sdk目录中，然后找到bin/cache/lockfile文件，删除它即可。
	
	删除之后你再运行flutter doctor，你会发现错误已经解决了。
	
	
	
	
	
	