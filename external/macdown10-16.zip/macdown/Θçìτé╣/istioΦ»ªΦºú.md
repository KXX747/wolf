istio详解

	serverice ->proxy 网络代理访问
	
	pilot 服务注册发现
	Mixer 服务是否可访问
	Citadel 证书管理
	



#二,Piolt服务注册发现

>adapter适配不同的平台  

>服务配置管理-- 类似nginx的路由转发. 

>服务发现规则与kubernetes结合



#三,getaway流入流出

ingress  gateway  外网访问服务网格

egress gataway  网格内服务访问外部服务 


gateway与普通的sidecar均是使用Envoy作为proxy实行流量控制，Pilot为不同类型的proxy生成相应的配置，geteway的类型为router，sidecar的类型为sidecar。



#四,灰度发布概念
	
	蓝绿发布
		
		V1为原来的，V2为即将上线的,V2上线发布时为全量发布 V2有问题流量切换为V1，V2没有问题替换V1
		
		
	金丝雀（灰度发布）发布
		
		V1为原来的,V2为即将上线的,V2上线获取V1的部分流量 逐渐替换V1.
		
		
	A/B test发布
		侧重于软件的可用性，对不同版本进行决策
	
	
#五,Istio的灰度发布，piolt作为Istio的流量管理
	
	
>DestinationRule配置策略，决定了经过路由处理之后的流量的访问策略
	
	host - 目标服务的名称
	trafficPolicy --流量策略（负载均衡，连接池配置，熔断配置）
	subsets -- 一个或多个版本  可指定trafficPolicy
	
	


>Virtualservice定义了一系列针对指定服务的流量路由规则
	
	hosts -- 流量目标的主机
	gateway -- gateway名称列表
	http -- http流量规则（Httproute）的列表
	tcp -- tcp流量规则（tcproute）的列表
	tls -- tls和https（tlsroute）流量规则的列表
	

>智能灰度发布
	
	目标： 细粒度控制的自动化的持续交付
	
	特点：
		用户细分
		流量管理
		关键指标可观测
		步伐流程自动化	
	
	
	
	
#六，xDS详解

基本概念

协议分析

ADS理解

xDS的未来
	
	
#七,Mixer详解


 服务的治理部分。日志，认证，统计等等
	
	
	
	
	
			
	
		
		




