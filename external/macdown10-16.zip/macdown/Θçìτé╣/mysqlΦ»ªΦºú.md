mysql详解性能 https://www.jianshu.com/u/602a29dad7ba

https://www.jianshu.com/u/1d88ff841dfe pxc和tidb在k8s安装
https://github.com/percona/percona-xtradb-cluster-operator  pxc-k8s官方文档

#一，创建数据库和表 
 1，创建数据库
  
  	create database menagerie;

 2，明确使用menagerie数据库
  
  	USE menagerie

 3，查看menagerie数据库中的表
 
 	 SHOW TABLES

 4，创建pet表

		CREATE TABLE pet (name VARCHAR(20), owner VARCHAR(20), species VARCHAR(20), sex CHAR(1), birth DATE, death DATE);
	
		INSERT INTO pet VALUES ('Puffball','Diane','hamster','f','1999-03-30',NULL);
		INSERT INTO pet VALUES ('Fluffy','Harold','cat','f','1993-02-04',NULL);
		INSERT INTO pet VALUES ('Claws','Gwen','cat','m','1994-03-17',NULL);
		
		创建表
	     CREATE TABLE shop (
	    article INT(4) UNSIGNED ZEROFILL DEFAULT '0000' NOT NULL,
	    dealer  CHAR(20)                 DEFAULT ''     NOT NULL,
	    price   DOUBLE(16,2)             DEFAULT '0.00' NOT NULL,
	    PRIMARY KEY(article, dealer));
	INSERT INTO shop VALUES
	    (1,'A',3.45),(1,'B',3.99),(2,'A',10.99),(3,'B',1.45),
	    (3,'C',1.69),(3,'D',1.25),(4,'D',19.95);
		
 5，查看表的结构
 
 	DESCRIBE pet;
 	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***		
	
# 	二，数据库查询

  1，选择所有数据
  
   	SELECT * FROM pet;
   	
   	
  2,选择特定行
  
     SELECT * FROM pet WHERE name = 'Fluffy';
     
   3,选择特定列
   
	 SELECT name, birth FROM pet;
	 
	+----------+------------+
	| name     | birth      |
	+----------+------------+
	| Puffball | 1999-03-30 |
	| Fluffy   | 1993-02-04 |
	| Claws    | 1994-03-17 |
	+----------+------------+

	
	
	
   4,排序行 order by语句 ，按照birth字段排序
    
     a, select name,birth from pet order by birth;
     
		+----------+------------+
		| name     | birth      |
		+----------+------------+
		| Fluffy   | 1993-02-04 |
		| Claws    | 1994-03-17 |
		| Puffball | 1999-03-30 |
		+----------+------------+
		
	  b,order by 分组之后按照进行排序（desc，asc）
		
		select name,birth from pet order by birth ASC;
		+----------+------------+
		| name     | birth      |
		+----------+------------+
		| Fluffy   | 1993-02-04 |
		| Claws    | 1994-03-17 |
		| Puffball | 1999-03-30 |
		+----------+------------+
		
		select name,birth from pet order by birth desc;
		+----------+------------+
		| name     | birth      |
		+----------+------------+
		| Puffball | 1999-03-30 |
		| Claws    | 1994-03-17 |
		| Fluffy   | 1993-02-04 |
		+----------+------------+
	

  5,日期计算,其它日期等
  
  		select name,birth ,curdate() from pet;
		+----------+------------+------------+
		| name     | birth      | curdate()  |
		+----------+------------+------------+
		| Puffball | 1999-03-30 | 2018-12-01 |
		| Fluffy   | 1993-02-04 | 2018-12-01 |
		| Claws    | 1994-03-17 | 2018-12-01 |
		+----------+------------+------------+
		
		
   6，使用NULL值，is null
      
       select 1 is null,1 is not null;
		+-----------+---------------+
		| 1 is null | 1 is not null |
		+-----------+---------------+
		|         0 |             1 |
		+-----------+---------------+
		
   7,模式匹配（b%）模式匹配使您可以使用_ 匹配任何单个字符并%匹配任意数量的字符（包括零个字符）
   
    select * from pet where name like "p%";
		+----------+-------+---------+------+------------+-------+
		| name     | owner | species | sex  | birth      | death |
		+----------+-------+---------+------+------------+-------+
		| Puffball | Diane | hamster | f    | 1999-03-30 | NULL  |
		+----------+-------+---------+------+------------+-------+
		

   8,计数行count(*)
   
    select count(*) from pet;
		+----------+
		| count(*) |
		+----------+
		|        3 |
		+----------+

	 
   9，连接查询 内连接、外连接、左连接、右连接、全连接
   
   		完整查询
   		 select * from pet ,event ;
		+----------+--------+---------+------+------------+-------+--------+------------+--------+------------------------------+
		| name     | owner  | species | sex  | birth      | death | name   | date       | type   | remark                       |
		+----------+--------+---------+------+------------+-------+--------+------------+--------+------------------------------+
		| Puffball | Diane  | hamster | f    | 1999-03-30 | NULL  | Fluffy | 1995-05-15 | litter | 4 kittens, 3 female, 1 male  |
		| Puffball | Diane  | hamster | f    | 1999-03-30 | NULL  | Buffy  | 1993-06-23 | litter | 45 puppies, 2 female, 3 male |
		| Fluffy   | Harold | cat     | f    | 1993-02-04 | NULL  | Fluffy | 1995-05-15 | litter | 4 kittens, 3 female, 1 male  |
		| Fluffy   | Harold | cat     | f    | 1993-02-04 | NULL  | Buffy  | 1993-06-23 | litter | 45 puppies, 2 female, 3 male |
		| Claws    | Gwen   | cat     | m    | 1994-03-17 | NULL  | Fluffy | 1995-05-15 | litter | 4 kittens, 3 female, 1 male  |
		| Claws    | Gwen   | cat     | m    | 1994-03-17 | NULL  | Buffy  | 1993-06-23 | litter | 45 puppies, 2 female, 3 male |
		+----------+--------+---------+------+------------+-------+--------+------------+--------+------------------------------+

   
   	 a, 内连接
   	 	 select * from pet as p inner join event as e on p.name =e.name ;
		+--------+--------+---------+------+------------+-------+--------+------------+--------+-----------------------------+
		| name   | owner  | species | sex  | birth      | death | name   | date       | type   | remark                      |
		+--------+--------+---------+------+------------+-------+--------+------------+--------+-----------------------------+
		| Fluffy | Harold | cat     | f    | 1993-02-04 | NULL  | Fluffy | 1995-05-15 | litter | 4 kittens, 3 female, 1 male |
		+--------+--------+---------+------+------------+-------+--------+------------+--------+-----------------------------+
		
	 b,左连接（右表可以为空）
	 
	 select * from pet as p left join event as e on p.name =e.name ;
		+----------+--------+---------+------+------------+-------+--------+------------+--------+-----------------------------+
		| name     | owner  | species | sex  | birth      | death | name   | date       | type   | remark                      |
		+----------+--------+---------+------+------------+-------+--------+------------+--------+-----------------------------+
		| Fluffy   | Harold | cat     | f    | 1993-02-04 | NULL  | Fluffy | 1995-05-15 | litter | 4 kittens, 3 female, 1 male |
		| Puffball | Diane  | hamster | f    | 1999-03-30 | NULL  | NULL   | NULL       | NULL   | NULL                        |
		| Claws    | Gwen   | cat     | m    | 1994-03-17 | NULL  | NULL   | NULL       | NULL   | NULL                        |
		+----------+--------+---------+------+------------+-------+--------+------------+--------+-----------------------------+
		
		
		 
		c,右连接（左表可以为空）
		select * from pet as p right join event as e on p.name =e.name ;
		+--------+--------+---------+------+------------+-------+--------+------------+--------+------------------------------+
		| name   | owner  | species | sex  | birth      | death | name   | date       | type   | remark                       |
		+--------+--------+---------+------+------------+-------+--------+------------+--------+------------------------------+
		| Fluffy | Harold | cat     | f    | 1993-02-04 | NULL  | Fluffy | 1995-05-15 | litter | 4 kittens, 3 female, 1 male  |
		| NULL   | NULL   | NULL    | NULL | NULL       | NULL  | Buffy  | 1993-06-23 | litter | 45 puppies, 2 female, 3 male |
		+--------+--------+---------+------+------------+-------+--------+------------+--------+------------------------------+



   10，获取最大值和最小值
   		
   		select min(price),max(price) from shop;
		+------------+------------+
		| min(price) | max(price) |
		+------------+------------+
		|       1.25 |      19.95 |



  11,分组后获取最大的列(先分组再排序)
	
	   select article,max(price) from shop group by article  order by article;
		+---------+------------+
		| article | max(price) |
		+---------+------------+
		|    0001 |       3.99 |
		|    0002 |      10.99 |
		|    0003 |       1.69 |
		|    0004 |      19.95 |
		+---------+------------+
		
		
 	12，子查询保持某一列的分组最大值的行(效率低)
   	
   		select * from shop s1 where price=(select max(price) from shop s2 where s1.article = s2.article );
	+---------+--------+-------+
	| article | dealer | price |
	+---------+--------+-------+
	|    0001 | B      |  3.99 |
	|    0002 | A      | 10.99 |
	|    0003 | C      |  1.69 |
	|    0004 | D      | 19.95 |
	+---------+--------+-------+
	
  
  13，使用用户定义的变量
  	
  	   select @min_price :=min(price),@max_price:=max(price) from shop;
		+-------------------------+------------------------+
		| @min_price :=min(price) | @max_price:=max(price) |
		+-------------------------+------------------------+
		|                    1.25 |                  19.95 |
		+-------------------------+------------------------+
		
		 select * from shop where price = @max_price or price = @min_price;
		+---------+--------+-------+
		| article | dealer | price |
		+---------+--------+-------+
		|    0003 | D      |  1.25 |
		|    0004 | D      | 19.95 |
		+---------+--------+-------+
	
	
	
 14，使用外键 仅仅为了连接两个表，不需要外键约束。对于除以外的存储引擎 InnoDB，可以在定义列时使用 没有实际效果的子句，并且仅作为备忘录或注释，您当前定义的列旨在引用列中的列
 
 	 CREATE TABLE person (
    id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name CHAR(60) NOT NULL,
    PRIMARY KEY (id)
	);

	CREATE TABLE shirt (
    id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
    style ENUM('t-shirt', 'polo', 'dress') NOT NULL,
    color ENUM('red', 'blue', 'orange', 'white', 'black') NOT NULL,
    owner SMALLINT UNSIGNED NOT NULL REFERENCES person(id),
    PRIMARY KEY (id)
	);
	
	
	INSERT INTO person VALUES (NULL, 'Antonio Paz');

	SELECT @last := LAST_INSERT_ID();
	
	INSERT INTO shirt VALUES
	(NULL, 'polo', 'blue', @last),
	(NULL, 'dress', 'white', @last),
	(NULL, 't-shirt', 'blue', @last);
	
	INSERT INTO person VALUES (NULL, 'Lilliana Angelovska');
	
	SELECT @last := LAST_INSERT_ID();

	INSERT INTO shirt VALUES
	(NULL, 'dress', 'orange', @last),
	(NULL, 'polo', 'red', @last),
	(NULL, 'dress', 'blue', @last),
	(NULL, 't-shirt', 'white', @last);
	
	
	SELECT * FROM person;
	+----+---------------------+
	| id | name                |
	+----+---------------------+
	|  1 | Antonio Paz         |
	|  2 | Lilliana Angelovska |
	+----+---------------------+
	
	SELECT * FROM shirt;
	+----+---------+--------+-------+
	| id | style   | color  | owner |
	+----+---------+--------+-------+
	|  1 | polo    | blue   |     1 |
	|  2 | dress   | white  |     1 |
	|  3 | t-shirt | blue   |     1 |
	|  4 | dress   | orange |     2 |
	|  5 | polo    | red    |     2 |
	|  6 | dress   | blue   |     2 |
	|  7 | t-shirt | white  |     2 |
	+----+---------+--------+-------+
	
	
	SELECT s.* FROM person p INNER JOIN shirt s
	   ON s.owner = p.id
	 WHERE p.name LIKE 'Lilliana%'
	   AND s.color <> 'white';
	
	+----+-------+--------+-------+
	| id | style | color  | owner |
	+----+-------+--------+-------+
	|  4 | dress | orange |     2 |
	|  5 | polo  | red    |     2 |
	|  6 | dress | blue   |     2 |
	+----+-------+--------+-------+


***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***		

		
#三，mysql优化SQL语句
		
 1.WHERE子句优化
 	
  1.1,范围优化 range
	  range访问方法使用单个索引来检索包含一个或若干个索引值的时间间隔内表行的子集。它可用于单部分或多部分索引。以下部分描述了优化程序使用范围访问的条件。
	
	单部分索引的范围访问方法
	
	多部分索引的范围访问方法
	
	多值比较的等价范围优化
	
	跳过扫描范围访问方法
	
	行构造函数表达式的范围优化
	
	限制内存使用范围优化
	
	单部分索引的范围访问方法
	对于单部分索引，索引值间隔可以通过WHERE子句中的相应条件方便地表示 ，表示为 范围条件 而不是“ 间隔”。”
	
	单部分索引的范围条件的定义如下：
	
	对于这两种BTREE和 HASH索引，使用时具有恒定值的关键部分的比较是一个范围条件 =， <=>， IN()， IS NULL，或 IS NOT NULL运营商。
	
	另外，对于BTREE索引，使用时具有恒定值的关键部分的比较是一个范围条件 >， <， >=， <=， BETWEEN， !=，或 <> 运营商，或者LIKE 比较，如果该参数 LIKE是一个常数字符串不与通配符开始。
	
	对于所有索引类型，多个范围条件与范围条件组合OR或 AND形成范围条件。
	
	前面描述中的“ 常量值 ”表示以下之一：
	
	来自查询字符串的常量
	
	来自同一连接 的a const 或systemtable的 列
	
	不相关子查询的结果
	
	任何表达式完全由前面类型的子表达式组成
	
	以下是WHERE子句中具有范围条件的查询的一些示例：
	
	SELECT * FROM t1
	  WHERE key_col > 1
	  AND key_col < 10;
	
	SELECT * FROM t1
	  WHERE key_col = 1
	  OR key_col IN (15,18,20);
	
	SELECT * FROM t1
	  WHERE key_col LIKE 'ab%'
	  OR key_col BETWEEN 'bar' AND 'foo';
	在优化器常量传播阶段，一些非常量值可以转换为常量。
	
	MySQL尝试从WHERE每个可能索引的子句中提取范围条件 。在提取过程期间，丢弃不能用于构建范围条件的条件，组合产生重叠范围的条件，并且去除产生空范围的条件。
	
	请考虑以下语句，其中 key1是索引列 nonkey且未编入索引：
	
	SELECT * FROM t1 WHERE
	  (key1 < 'abc' AND (key1 LIKE 'abcde%' OR key1 LIKE '%b')) OR
	  (key1 < 'bar' AND nonkey = 4) OR
	  (key1 < 'uux' AND key1 > 'z');
	密钥的提取过程key1如下：
	
	从原始WHERE条款开始：
	
	(key1 < 'abc' AND (key1 LIKE 'abcde%' OR key1 LIKE '%b')) OR
	(key1 < 'bar' AND nonkey = 4) OR
	(key1 < 'uux' AND key1 > 'z')
	删除nonkey = 4，key1 LIKE '%b'因为它们不能用于范围扫描。删除它们的正确方法是用它们替换它们TRUE，这样我们在进行范围扫描时不会错过任何匹配的行。用TRUE收益率代替它们：
	
	(key1 < 'abc' AND (key1 LIKE 'abcde%' OR TRUE)) OR
	(key1 < 'bar' AND TRUE) OR
	(key1 < 'uux' AND key1 > 'z')
	崩溃条件总是真或假：
	
	(key1 LIKE 'abcde%' OR TRUE) 总是如此
	
	(key1 < 'uux' AND key1 > 'z') 总是假的
	
	用常数替换这些条件会产生：
	
	(key1 < 'abc' AND TRUE) OR (key1 < 'bar' AND TRUE) OR (FALSE)
	删除不必要的TRUE和 FALSE常量会产生：
	
	(key1 < 'abc') OR (key1 < 'bar')
	将重叠间隔组合成一个会产生用于范围扫描的最终条件：
	
	(key1 < 'bar')
	通常（并且如前面的示例所示），用于范围扫描的条件比该WHERE子句的限制性更小。MySQL执行额外的检查以过滤掉满足范围条件但不满足完整WHERE子句的行。
	
	范围条件提取算法可以处理 任意深度的嵌套 AND/ OR构造，并且其输出不依赖于条件在WHERE子句中出现的顺序 。
	
	MySQL不支持合并range空间索引的访问方法的多个范围 。要解决此限制，除了将每个空间谓词放在不同的语句中之外，您可以使用UNION具有相同 SELECT语句的语句 SELECT。
	
	多部分索引的范围访问方法
	多部分索引的范围条件是单部分索引的范围条件的扩展。多部分索引上的范围条件将索引行限制在一个或多个关键元组间隔内。使用索引中的排序，在一组关键元组上定义关键元组间隔。
	
	例如，考虑定义为的多部分索引 ，以及按键顺序列出的以下一组关键元组： key1(key_part1, key_part2, key_part3)
	
	key_part1  key_part2  key_part3
	  NULL       1          'abc'
	  NULL       1          'xyz'
	  NULL       2          'foo'
	   1         1          'abc'
	   1         1          'xyz'
	   1         2          'abc'
	   2         1          'aaa'
	条件key_part1 = 1定义了这个间隔：
	
	(1,-inf,-inf) <= (key_part1,key_part2,key_part3) < (1,+inf,+inf)
	间隔覆盖前面数据集中的第4，第5和第6个元组，并且可以由范围访问方法使用。
	
	相反，条件 key_part3 = 'abc'不定义单个间隔，并且不能由范围访问方法使用。
	
	以下描述更详细地说明了范围条件如何适用于多部分索引。
	
	对于HASH索引，可以使用包含相同值的每个间隔。这意味着只能为以下形式的条件生成间隔：
	
	    key_part1 cmp const1
	AND key_part2 cmp const2
	AND ...
	AND key_partN cmp constN;
	这里const1， const2...是常数，cmp是一个 =， <=>或者IS NULL比较运营商，以及条件覆盖所有指数部分。（也就是说，有一些N 条件，一个用于N-part索引的每个部分 。）例如，以下是三部分HASH索引的范围条件 ：
	
	key_part1 = 1 AND key_part2 IS NULL AND key_part3 = 'foo'
	有关被认为是常量的定义，请参阅 单部分索引的范围访问方法。
	
	对于一个BTREE索引，以一定间隔可能是条件组合可用 AND，其中每个条件使用的恒定值的关键部分进行比较 =， <=>， IS NULL， >， <， >=， <=， !=， <>， BETWEEN，或 （其中 LIKE 'pattern''pattern' 不以通配符开头）。可以使用间隔，只要可以确定包含与条件匹配的所有行的单个密钥元组（或者如果使用<> 或者!= 使用两个间隔 ）。
	
	只要比较运算符是，或=， 优化程序就会尝试使用其他关键部分来确定间隔 。如果操作是 ， ， ， ， ， ， ，或者 ，优化器使用它，但认为没有更多的关键部分。对于以下表达式，优化程序将使用 第一个比较。它也使用 <=>IS NULL><>=<=!=<>BETWEENLIKE=>= 从第二次比较，但没有考虑其他关键部分，并没有使用间隔构造的第三个比较：
	
	key_part1 = 'foo' AND key_part2 >= 10 AND key_part3 > 10
	单一间隔是：
	
	('foo',10,-inf) < (key_part1,key_part2,key_part3) < ('foo',+inf,+inf)
	创建的间隔可能包含的行数多于初始条件。例如，前一个间隔包括('foo', 11, 0)不满足原始条件的值。
	
	如果将包含区间内包含的行集的条件与其组合 OR，则它们形成一个条件，该条件覆盖其区间的并集中包含的一组行。如果条件与AND它们组合 ，则它们形成一个条件，该条件覆盖其间隔的交集中包含的一组行。例如，对于这个由两部分组成的索引：
	
	(key_part1 = 1 AND key_part2 < 2) OR (key_part1 > 5)
	间隔是：
	
	(1,-inf) < (key_part1,key_part2) < (1,2)
	(5,-inf) < (key_part1,key_part2)
	在此示例中，第一行上的间隔使用左边界的一个关键部分和右边界的两个关键部分。第二行的间隔仅使用一个关键部分。输出中的key_len列EXPLAIN指示使用的密钥前缀的最大长度。
	
	在某些情况下，key_len可能表示使用了关键部件，但这可能不是您所期望的。假设 key_part1并且 key_part2可以 NULL。然后该 key_len列显示以下条件的两个关键部分长度：
	
	key_part1 >= 1 AND key_part2 < 2
	但是，事实上，条件转换为：
	
	key_part1 >= 1 AND key_part2 IS NOT NULL
	有关如何执行优化以组合或消除单部分索引上的范围条件的间隔的说明，请参阅单部分索引的 范围访问方法。对多部分索引的范围条件执行类似步骤。
	
	多值比较的等价范围优化
	考虑这些表达式，其中 col_name是索引列：
	
	col_name IN(val1, ..., valN)
	col_name = val1 OR ... OR col_name = valN
	如果col_name等于多个值中的任何一个，则每个表达式都为真 。这些比较是等式范围比较（其中“ 范围 ”是单个值）。优化程序估计读取符合条件行的比较行的成本，如下所示：
	
	如果有唯一索引 col_name，则每个范围的行估计值为1，因为最多一行可以具有给定值。
	
	否则，任何索引 col_name都是非唯一的，并且优化器可以使用潜入索引或索引统计信息来估计每个范围的行数。
	
	使用索引潜水，优化程序会在范围的每一端进行潜水，并使用范围中的行数作为估计值。例如，表达式 col_name IN (10, 20, 30)具有三个相等范围，优化程序每个范围进行两次潜水以生成行估计。每对潜水产生具有给定值的行数的估计。
	
	索引潜水提供准确的行估计，但随着表达式中比较值的数量增加，优化程序需要更长的时间来生成行估计。索引统计的使用不如索引潜水准确，但允许对大值列表进行更快的行估计。
	
	该 eq_range_index_dive_limit 系统变量，可以配置在其优化从一个行估计策略到其他交换机值的数量。要允许使用索引潜水进行最多N 相等范围的比较，请设置 eq_range_index_dive_limit 为N+ 1.要禁用统计数据并始终使用索引潜水 N，请将其设置 eq_range_index_dive_limit 为0。
	
	要更新的最佳估计表索引统计信息，使用 ANALYZE TABLE。
	
	在MySQL 8.0之前，除了使用eq_range_index_dive_limit 系统变量之外，没有办法跳过使用索引潜水来估计索引的有用性 。在MySQL 8.0中，对于满足所有这些条件的查询，可以进行索引潜水跳过：
	
	查询用于单个表，而不是多个表的连接。
	
	存在单索引FORCE INDEX索引提示。我们的想法是，如果强制使用索引，那么从潜在的索引进行额外开销就无法获得任何好处。
	
	索引不是唯一的而不是 FULLTEXT索引。
	
	没有子查询。
	
	不DISTINCT，GROUP BY或ORDER BY条款存在。
	
	对于EXPLAIN FOR CONNECTION，如果跳过索引潜水，则输出更改如下：
	
	对于传统输出，rows和 filtered值是 NULL。
	
	对于JSON输出， rows_examined_per_scan并且 rows_produced_per_join不显示， skip_index_dive_due_to_force是 true，并且成本计算不准确。
	
	如果没有FOR CONNECTION， EXPLAIN则跳过索引潜水时输出不会改变。
	
	在执行跳过索引潜水的查询后，INFORMATION_SCHEMA.OPTIMIZER_TRACE 表中的相应行 包含 index_dives_for_range_access值 skipped_due_to_force_index。
	
	跳过扫描范围访问方法
	请考虑以下情形：
	
	CREATE TABLE t1 (f1 INT NOT NULL, f2 INT NOT NULL, PRIMARY KEY(f1, f2));
	INSERT INTO t1 VALUES
	  (1,1), (1,2), (1,3), (1,4), (1,5),
	  (2,1), (2,2), (2,3), (2,4), (2,5);
	INSERT INTO t1 SELECT f1, f2 + 5 FROM t1;
	INSERT INTO t1 SELECT f1, f2 + 10 FROM t1;
	INSERT INTO t1 SELECT f1, f2 + 20 FROM t1;
	INSERT INTO t1 SELECT f1, f2 + 40 FROM t1;
	ANALYZE TABLE t1;
	
	EXPLAIN SELECT f1, f2 FROM t1 WHERE f2 > 40;
	要执行此查询，MySQL可以选择索引扫描来获取所有行（索引包括要选择的所有列），然后应用子句中的f2 > 40 条件WHERE以生成最终结果集。
	
	范围扫描比完整索引扫描更有效，但在这种情况下不能使用，因为f1第一个索引列没有条件 。但是，从MySQL 8.0.13开始，优化器可以f1使用类似于松散索引扫描的称为Skip Scan的方法执行多个范围扫描，每个值对应一个值（参见第8.2.1.15节“GROUP BY优化”）：
	
	跳过第一个索引部分的不同值 f1（索引前缀）。
	
	f2 > 40对剩余索引部分上的条件的 每个不同前缀值执行子范围扫描。
	
	对于前面显示的数据集，算法的运行方式如下：
	
	获取第一个关键部分（f1 = 1）的第一个不同值。
	
	根据第一个和第二个关键部分构造范围（f1 = 1 AND f2 > 40）。
	
	执行范围扫描。
	
	获取第一个关键部分（f1 = 2）的下一个不同值。
	
	根据第一个和第二个关键部分构造范围（f1 = 2 AND f2 > 40）。
	
	执行范围扫描。
	
	使用此策略会减少访问行的数量，因为MySQL会跳过不符合每个构造范围的行。此Skip Scan访问方法适用于以下条件：
	
	表T具有至少一个具有形式的关键部分的复合索引（[A_1，...，A_ k，] B_1，...，B_ m，C [，D_1，...，D_ n]）。关键部分A和D可能是空的，但B和C必须是非空的。
	
	查询仅引用一个表。
	
	查询不使用GROUP BY或 DISTINCT。
	
	该查询仅引用索引中的列。
	
	A_1，...，A_的k谓词必须是等式谓词，它们必须是常量。这包括 IN()运营商。
	
	查询必须是连接查询; 即， AND的OR 条件： (cond1(key_part1) OR cond2(key_part1)) AND (cond1(key_part2) OR ...) AND ...
	
	C上必须有范围条件。
	
	允许D列条件。D上的条件必须与C上的范围条件一起使用。
	
	EXPLAIN 输出中 指示使用Skip Scan ，如下所示：
	
	Using index for skip scan在 Extra列中表示使用松散索引Skip Scan访问方法。
	
	如果索引可用于“跳过扫描”，则索引应在possible_keys 列中可见。
	
	在"skip scan"此格式的元素的优化程序跟踪输出中指示使用Skip Scan ：
	
	"skip_scan_range": {
	  "type": "skip_scan",
	  "index": index_used_for_skip_scan,
	  "key_parts_used_for_access": [key_parts_used_for_access],
	  "range": [range]
	}
	您可能还会看到一个 "best_skip_scan_summary"元素。如果选择“跳过扫描”作为最佳范围访问变体， "chosen_range_access_summary"则会写入a。如果选择“跳过扫描”作为总体最佳访问方法， "best_access_path"则存在元素。
	
	使用Skip Scan取决于 系统变量skip_scan标志的 optimizer_switch值。请参见第8.9.3节“可切换的优化”。默认情况下，此标志为on。要禁用它，请设置skip_scan为off。
	
	除了使用 optimizer_switch系统变量控制优化器在会话范围内使用Skip Scan之外，MySQL还支持优化器提示以基于每个语句影响优化器。请参见 第8.9.2节“优化程序提示”。
	
	行构造函数表达式的范围优化
	优化器能够将范围扫描访问方法应用于此表单的查询：
	
	SELECT ... FROM t1 WHERE ( col_1, col_2 ) IN (( 'a', 'b' ), ( 'c', 'd' ));
	以前，对于要使用的范围扫描，有必要将查询编写为：
	
	SELECT ... FROM t1 WHERE ( col_1 = 'a' AND col_2 = 'b' )
	OR ( col_1 = 'c' AND col_2 = 'd' );
	要使优化器使用范围扫描，查询必须满足以下条件：
	
	只使用IN()谓词，而不是NOT IN()。
	
	在IN()谓词的左侧 ，行构造函数仅包含列引用。
	
	在IN()谓词的右侧 ，行构造函数仅包含运行时常量，这些常量是在执行期间绑定到常量的文字或本地列引用。
	
	在IN()谓词的右侧 ，有多个行构造函数。
	
	有关优化程序和行构造函数的更多信息，请参见 第8.2.1.20节“行构造函数表达式优化”
	
	限制内存使用范围优化
	要控制范围优化程序可用的内存，请使用 range_optimizer_max_mem_size 系统变量：
	
	值为0表示“ 没有限制。”
	
	值大于0时，优化程序会在考虑范围访问方法时跟踪消耗的内存。如果要超过指定的限制，则放弃范围访问方法，并考虑其他方法，包括全表扫描。这可能不太理想。如果发生这种情况，则会出现以下警告（N当前 range_optimizer_max_mem_size 值在哪里 ）：
	
	Warning    3170    Memory capacity of N bytes for
	                   'range_optimizer_max_mem_size' exceeded. Range
	                   optimization was not done for this query.
	对于UPDATE和 DELETE语句，如果优化器回退到全表扫描并且sql_safe_updates启用了 系统变量，则会发生错误而不是警告，因为实际上没有使用任何键来确定要修改的行。有关更多信息，请参见 第4.5.1.6.4节“使用安全更新模式（--safe-updates）”。
	
	对于超出可用范围优化内存并且优化程序回退到不太理想的计划的单个查询，增加该 range_optimizer_max_mem_size 值可以提高性能。
	
	要估计处理范围表达式所需的内存量，请使用以下准则：
	
	对于一个简单的查询，如下所示，其中有一个候选键用于范围访问方法，每个谓词组合OR 使用大约230个字节：
	
	SELECT COUNT(*) FROM t
	WHERE a=1 OR a=2 OR a=3 OR .. . a=N;
	类似地，对于诸如以下的查询，每个谓词组合AND 使用大约125个字节：
	
	SELECT COUNT(*) FROM t
	WHERE a=1 AND b=1 AND c=1 ... N;
	对于带IN() 谓词的查询：
	
	SELECT COUNT(*) FROM t
	WHERE a IN (1,2, ..., M) AND b IN (1,2, ..., N);
	IN()列表 中的每个文字值都 计为与谓词组合的谓词OR。如果有两个IN() 列表，则组合的谓词 OR数是每个列表中文字值的数量的乘积。因此，与OR前一种情况相结合的谓词数 是 M× N。
 	 	
 1.2,索引合并优化
 	 
 	 	该指数合并访问方法检索与多行 range扫描和他们的结果合并到一个。此访问方法仅合并来自单个表的索引扫描，而不扫描多个表。合并可以生成其基础扫描的联合，交叉或交叉联合。
 	 	
 1.3,外连接优化	
 	  
 	 
 1.4，条件过滤
 	 
 	 1.5，is null优化
  	 1.6，order by优化
  	 1.7，group by优化
  	 1.8，distinct 优化
  	 1.9，limit查询优化
  	 1.10，避免全表扫描

	   
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***		
	
		
		
		
# 四，锁和事务
 
  mysql 通过主键索引检索数据，innodb才会使用行级锁，否则innodb将使用表锁
  
    行级锁：next-key-lock
    
    
    
    表锁：
    
		SET AUTOCOMMIT=0;
		LOCAK TABLES t1 WRITE, t2 READ, ...;
		[do something with tables t1 and here];
		COMMIT;
		UNLOCK TABLES;

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***	


#五，pxc


PXC的优点：

        ①实现mysql数据库集群架构的高可用性和数据的 强一致性。
        ②完成了真正的多节点读写的集群方案。
        ③改善了传统意义上的主从复制延迟问题，基本上达到了实时同步。
        ④新加入的节点可以自动部署，无须提供手动备份，维护起来很方便。
        ⑤由于是多节点写入，所以数据库故障切换很容易。

PXC的缺点：

        ①新加入的节点开销大，需要复制完整的数据。采用SST传输开销太大。
        ②任何更新事务都需要全局验证通过，才会在每个节点库上执行。集群性能受限于性能最差的节点，也就是经常说的短板效应。
        ③因为需要保证数据的一致性，所以在多节点并发写时，锁冲突问题比较严重。
        ④存在写扩大问题，所有的节点上都会发生些操作。
        ⑤只支持innodb存储引擎的表。
        ⑥没有表级别的锁定，执行DDL语句操作会把整个集群锁住，而且也 kill 不了（建议使用Osc操作，即在线DDL）
        ⑦所有的表必须含有主键，不然操作数据时会报错。

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***	


#六，主从同步流程

（1），主从同步流程
![](http://www.10tiao.com/img.do?url=http%3A//mmbiz.qpic.cn/mmbiz/nts52nHheTxrmMfcicYPvTRrvRYKuMkZqnqC9Bved6LrWmNBnNUXYcE3xcTdCO8DOHY5ATNl009H9AOCCsCRyNg/0)

	1，master数据写到binlog日志
	2，开启slave的IO线程监听binlog
	3，slave的IO线程数据写入中继日志relay log
	4，sql线程写入库

(2),binlog记录格式
	
	STATEMENT（记录操作的SQL语句）
    优点 减少了 binlog 日志量，节约IO，提高性能，易于理解
    缺点 不是所有的DML语句都能被复制，有些函数UUID() 、FOUND_ROWS()、USER() 也无法被复制

	ROW（记录操作的每一行数据的变化信息，RC 隔离级别，必须是 row 格式）

    优点 任何情况都可以被复制，ROW 模式是最安全可靠的
    缺点 产生大量的日志，特别是 copy data 的 DDL 会让日志暴涨
    建议表一定要有主键

	MIXED （混合模式）
    先使用 STATEMENT 模式记录 binlog ，对于 STATEMENT 模式无法复制的操作使用 ROW 模式保存 binlog，MySQL 会根据执行的 SQL 语句选择日志记录方式。Bug 较多，不建议使用。

(3),复制最优的参数配置

	 MySQL Replication 的最可靠的参数配置。
	master：
	
	binlog_format = ROW 
	transaction-isolation = READ-COMMITTE
	Dexpire_logs_days = 30 
	server-id = 327 
	sync_binlog = 1 
	innodb_flush_log_at_trx_commit = 1 
	innodb_support_xa = 1
	
	slave：
	
	log_slave_updates=1 
	server-id = 328 
	relay_log_recover = 1 
	relay_log_info_repository = TABLE 
	master_info_repository = TABLE
	read_only = 1
	
	
(4),如何提高复制效率？
	
	(4-1),	并行复制（MySQL 5.6提供）
		
		 基于database，如果是基于单database的依然无法做到真正的并行回放，这个阶段很多DBA将数据库进行垂直拆分，将一个database拆分成几个database，通过设置slave_parallel_workers=n，可以进行database级别的并行复制，但对于热点业务复制延迟依然无法解决。

![并行复制](http://www.10tiao.com/img.do?url=http%3A//mmbiz.qpic.cn/mmbiz_png/nts52nHheTxMDfHMKkLcEmGlKyJA3hYAEyHbqicFh3dfZWWZiatsW9GyIXfKW3p5iclHFZmicDVhElTNzVj1bJ1nLw/0%3Fwx_fmt%3Dpng)		 
		
		
		MySQL 5.6版本中还引入了GTID，不但降低了主从failover时，寻找filename，position的难度，更是加入到了组提交中，这也造就了MySQL 5.7版本中的Multi-Threaded Slave的出现。如下图，一组中的事务，可以并行回放。
![](http://www.10tiao.com/img.do?url=http%3A//mmbiz.qpic.cn/mmbiz_png/nts52nHheTxMDfHMKkLcEmGlKyJA3hYA4rwtnCHlw8A0TVfQT7eeq7jyBmVRh5SgUPk0yUWel6iajRa69NbdBibQ/0%3Fwx_fmt%3Dpng)		
		
		Multi-Threaded Slave 相关参数

		slave-parallel-type= DATABASE /LOGICAL_CLOCK
		-- DATABASE -- 基于库级别的并行复制 与5.6相同
		-- LOGICAL_CLOCK -- 逻辑时钟，主上怎么并行执行，从上怎么回放。
		
		slave-parallel-workers=16  
		-- 并行复制的线程数
		
		slave_preserve_commit_order=1 
		--commit的顺序保持一致
		 
		
	(4-2),	半同步
		
		我们都知道，默认的 MySQL Replication 复制为异步模式，异步也就说明会有丢失数据的可能性，MySQL在5.5版本中提供了 semi-sync replication，也就是半同步，但半同步只能说减少数据丢失的风险，所以在 MySQL 5.7版本中，MySQL 提供了 lossless semi-sync replication，也就是无损复制，可最低限度的减少数据丢失（无损复制会和半同步一样在出问题时会切换为异步复制）。
		
![](http://www.10tiao.com/img.do?url=http%3A//mmbiz.qpic.cn/mmbiz_png/nts52nHheTxMDfHMKkLcEmGlKyJA3hYAXRGXrvk7FMljJjCiaTrnG63XaCiaWkECerdicl5lVjUbibVsKgBGbHyTSA/0%3Fwx_fmt%3Dpng)	

	在半同步中，至少有一个Slave节点收到binlog后再返回，不能完全避免数据丢失，超时后，切回异步复制。在事物提交的过程中，在InnoDB层的 commit log 阶段后，Master 节点需要收到至少一个Slave节点回复的ACK后，才能继续下一个事物。	
	
	
	半同步相关参数
	rpl_semi_sync_master_enabled=1
	rpl_semi_sync_slave_enabled=1
	rpl_semi_sync_master_timeout=1000
	rpl_semi_sync_master_wait_for_slave_count=1
	rpl_semi_sync_master_wait_point=AFTER_SYNC
	rpl_semi_sync_master_wait_for_slave_count=1
	
	半同步相关事件统计
	Rpl_semi_sync_master_tx_avg_wait_time
	--开启Semi_sync，平均需要额外等待的时间
	Rpl_semi_sync_master_net_avg_wait_time
	--事务进入等待队列后，到网络平均等待时间Semi-sync的网络消耗有多大。
	Rpl_semi_sync_master_status
	-- 则表示当前Semi-sync是否正常工作
	Rpl_semi_sync_master_no_times
	--可以知道一段时间内，Semi-sync是否有超时失败过，记录了失败次数。
	
		
	(4-3),	无损复制
	
![](http://www.10tiao.com/img.do?url=http%3A//mmbiz.qpic.cn/mmbiz_png/nts52nHheTxMDfHMKkLcEmGlKyJA3hYAsE2xhF2INofPS0q9A3h1sewMWCw03kZziaqxticOCAZlpKY7hXx6SsQg/0%3Fwx_fmt%3Dpng)

	在无损复制中，master把binlog发送给slave，只有在slave把binlog写到本地的relay-log里，master才会将事务提交到存储引擎层，然后把请求返回给客户端，客户端才可以看见刚才提交的事务。在一个事物提交的过程中，在MySQL Server 层的 binlog阶段后，Master节点需要收到至少一个Slave节点回复的ACK后，才能继续下一个事物。
	
	半同步复制与无损复制的对比

ACK的时间点不同

    半同步复制在InnoDB层的Commit Log后，等待ACK。

    无损复制在MySQL Server层的Write binlog后，等待ACK。

主从数据一致性

    半同步复制意味着在Master节点上，这个刚刚提交的事物对数据库的修改，对其他事物是可见的。

    无损复制在write binlog完成后，就传输binlog，但还没有去写commit log，意味着当前这个事物对数据库的修改，其他事物也是不可见的。

	
	
	
	
	(4-4),	多源复制(MySQL 5.7版本提供)

	提供了多源复制，多源复制的出现对于分库分表的业务提供了极大的便利，目前我们已经部署了多套多源复制供统计使用。
	
![](http://www.10tiao.com/img.do?url=http%3A//mmbiz.qpic.cn/mmbiz_png/nts52nHheTxMDfHMKkLcEmGlKyJA3hYAKxFTLiaYXsE0R6c2xgxw1iaJ9dLAfRb9SzBpciaU8J4I9JlU0LKHHFeZA/0%3Fwx_fmt%3Dpng)
	
	如上图，多源复制采用多通道的模式，和普通的复制相比，就是使用FOR CHANNEL进行了分离。

	CHANGE MASTER TO .... FOR CHANNEL ‘m1';
	CHANGE MASTER TO .... FOR CHANNEL ‘m2';

	上面我们也说到，为了提高复制效率，很多DBA会根据业务进行DB拆分，但拆分后又面临一个新的问题，就是join，join绝对是关系型数据库中最常用一个特性，然而在分布式的环境中，join是最难解决的一个问题，使用多源复制就能很好的解决这个问题。
	
![](http://www.10tiao.com/img.do?url=http%3A//mmbiz.qpic.cn/mmbiz_png/nts52nHheTxMDfHMKkLcEmGlKyJA3hYA4BtzNGEcO5r42ztD2GVLSb3kTTtw5MpRj2WVB7EECFnPgZBy62hxSw/0%3Fwx_fmt%3Dpng)	

	如上图的分库分表架构，可以使用以下参数实现奇偶插入的方式去解决。
	
	auto_increment_offset=1…n
	auto_increment_increment=n
			
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***	 
    	
#7,MySQL Explain详解

	-- 实际SQL，查找用户名为Jefabc的员工
	select * from emp where name = 'Jefabc';
	-- 查看SQL是否使用索引，前面加上explain即可
	explain select * from emp where name = 'Jefabc';
	
![mysql的explain](https://images2018.cnblogs.com/blog/512541/201808/512541-20180803142201303-545775900.png)		
	expain出来的信息有10列，分别是id、select_type、table、type、possible_keys、key、key_len、ref、rows、Extra
	
	(1),id 选择表示符号，执行的顺序 
		id相同表示加载表的顺序是从上到下。id不同id值越大，优先级越高，越先被执行。id有相同，也有不同，同时存在。id相同的可以认为是一组，从上往下顺序执行；在所有的组中，id的值越大，优先级越高，越先执行。
	
	(2)select _type 表示查询中每个select子句的类型
		(2-1) SIMPLE(简单SELECT，不使用UNION或子查询等
		(2-2) PRIMARY(子查询中最外层查询，查询中若包含任何复杂的子部分，最外层的select被标记为PRIMARY)
		(2-3) UNION(UNION中的第二个或后面的SELECT语句)
		(2-4) DEPENDENT UNION(UNION中的第二个或后面的SELECT语句，取决于外面的查询)
		(2-5) UNION RESULT(UNION的结果，union语句中第二个select开始后面所有select)
		(2-6) SUBQUERY(子查询中的第一个SELECT，结果不依赖于外部查询)
		(2-7) DEPENDENT SUBQUERY(子查询中的第一个SELECT，依赖于外部查询)
		(2-8) DERIVED(派生表的SELECT, FROM子句的子查询)
		(2-9) UNCACHEABLE SUBQUERY(一个子查询的结果不能被缓存，必须重新评估外链接的第一行)
		
	(3),table显示这一步所访问数据库中表名称（显示这一行的数据是关于哪张表的），有时不是真实的表名字，可能是简称，例如上面的e，d，也可能是第几步执行的结果的简称
	
	
   （4),type 表示MySQL在表中找到所需行的方式，又称“访问类型”。
   			
   			all,index,range ,ref,eq_ref,const,system,NULL 从左到右，性能从差到好
			
			all:全表扫描
			index：只遍历索引树
			range: 检查给定范围，使用一个索引来选择行
			ref: 表示有列或者常量被用于查找索引列上的值
			eq_ref:类似ref,区别就在使用的索引是唯一索引,对于每个索引键值，表中只有一条记录匹配,只有primary key或者 unique key作为关联条件
			const,system:当MySQL对查询某部分进行优化，并转换为一个常量时，使用这些类型访问。如将主键置于where列表中，MySQL就能将该查询转换为一个常量，system是const类型的特例，当查询的表只有一行的情况下，使用system	
			NULL:对mysql在优化过程中分解语句，执行时，甚至不用访问表或索引
   
	（5）,possible_key指出MySQL能使用哪个索引在表中找到记录，查询涉及到的字段上若存在索引，则该索引将被列出，但不一定被查询使用（该查询可以利用的索引，如果没有任何索引显示 null）
		
		该列完全独立于EXPLAIN输出所示的表的次序。这意味着在possible_keys中的某些键实际上不能按生成的表次序使用。
		如果该列是NULL，则没有相关的索引。在这种情况下，可以通过检查WHERE子句看是否它引用某些列或适合索引的列来提高你的查询性能。如果是这样，创造一个适当的索引并且再次用EXPLAIN检查查询
	
	
	(6),key列显示MySQL实际决定使用的键（索引），必然包含在possible_keys中
 	
 	如果没有选择索引，键是NULL。要想强制MySQL使用或忽视possible_keys列中的索引，在查询中使用FORCE INDEX、USE INDEX或者IGNORE INDEX。
 	
	
	（7）,key_len
		表示索引中使用的字节数，可通过该列计算查询中使用的索引的长度（key_len显示的值为索引字段的最大可能长度，并非实际使用长度，即key_len是根据表定义计算而得，不是通过表内检索出的）

		不损失精确性的情况下，长度越短越好 
	
	(8),ref
		列与索引的比较，表示上述表的连接匹配条件，即哪些列或常量被用于查找索引列上的值
		
  （9）,rows
   	
		 估算出结果集行数，表示MySQL根据表统计信息及索引选用情况，估算的找到所需的记录所需要读取的行数
		
  （10）,	Extra该列包含MySQL解决查询的详细信息,
  		
	Using where:不用读取表中所有信息，仅通过索引就可以获取所需数据，这发生在对表的全部的请求列都是同一个索引的部分的时候，表示mysql服务器将在存储引擎检索行后再进行过滤
	Using temporary：表示MySQL需要使用临时表来存储结果集，常见于排序和分组查询，常见 group by ; order by
	Using filesort：当Query中包含 order by 操作，而且无法利用索引完成的排序操作称为“文件排序”
	-- 测试Extra的filesort
	explain select * from emp order by name;
	Using join buffer：改值强调了在获取连接条件时没有使用索引，并且需要连接缓冲区来存储中间结果。如果出现了这个值，那应该注意，根据查询的具体情况可能需要添加索引来改进能。
	Impossible where：这个值强调了where语句会导致没有符合条件的行（通过收集统计信息不可能存在结果）
	Select tables optimized away：这个值意味着仅通过使用索引，优化器可能仅从聚合函数结果中返回一行
	No tables used：Query语句中使用from dual 或不含任何from子句
	-- explain select now() from dual;

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***	

  		
#8,mysql的锁

>1,innerdb和myisam是什么锁
	
	InnoDB预设是Row-Level Lock，所以只有「明确」的指定主键，MySQL才会执行Row lock (只锁住被选取的资料例) ，否则MySQL将会执行Table Lock (将整个资料表单给锁住)。--会出现死锁 当查询主键索引会锁住主键,查询非主键索引会先锁住非主键索引再锁住主键索引
	
	myisam 是表锁， -不会出现死锁
	
	避免死锁：
		a、如果不同程序会并发存取多个表，尽量约定以相同的顺序访问表，可以大大降低死锁机会。
		b、在同一个事务中，尽可能做到一次锁定所需要的所有资源，减少死锁产生概率；
		c、对于非常容易产生死锁的业务部分，可以尝试使用升级锁定颗粒度，通过表级锁定来减少死锁产生的概率；
	
	S锁(共享锁)：又称读锁，若事务T对数据对象A加上S锁，则事务T可以读A但不能修改A，其他事务只能再对A加S锁，而不能加X锁，直到T释放A上的S锁。这保证了其他事务可以读A，但在T释放A上的S锁之前不能对A做任何修改，除非先获取A的X锁。
	
	X锁(排他锁)：又称写锁，若事务T对数据对象A加上X锁，事务T可以读A也可以修改A，其他事务不能再对A加任何锁，直到T释放A上的锁。这保证了其他事务在T释放A上的锁之前不能再读取和修改A。
			

>2,MyIsam引擎的锁机制
	
 (1),myisam读取写入都加锁
 	
 	MyISAM只支持表锁，锁的是整张表，读取数据的时候会加S锁，增删改的时候会加X锁。
 	
	.frm文件：与表相关的元数据信息都存放在frm文件，包括表结构的定义信息等。
	.myd文件：myisam存储引擎专用，用于存储myisam表的数据
	.myi文件：myisam存储引擎专用，用于存储myisam表的索引相关信息
	
 
>3,innerdb引擎的锁机制
	
（1）,innerdb写入数据加锁，读取不加锁
	
	innoDB既支持表锁也支持行锁，可以锁行级别的数据，增删改的时候会对数据对象（可能是一行或者多行或者一张表）加X锁，读取的时候一般不加锁，因为innoDB实现MVCC（Multi-Version Concurrency Control 多版本并发控制）
	
	.frm文件：表结构
	.ibd文件:表数据

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***	

#9，mysql的innerdb隔离级别

>1,事务的隔离级别

 	(1),RAED UNCOMMITED：使用查询语句不会加锁，可能会读到未提交的行（Dirty Read)   
 	(2),READ COMMITED：只对记录加记录锁，而不会在记录之间加间隙锁，所以允许新的记录插入到被锁定记录的附近，所以再多次使用查询语句时，可能得到不同的结果（Non-Repeatable Read   
	(3),REPEATABLE READ：多次读取同一范围的数据会返回第一次查询的快照，不会返回不同的数据行，但是可能发生幻读（Phantom Read）   
	(4),SERIALIZABLE：InnoDB 隐式地将全部的查询语句加上共享锁，解决了幻读的问题   
	
	

	脏读是指一个事务正在访问数据，并对数据进行了修改，而且没有提交，这时，另一个事务也访问了这个数据，然后使用了这个数据(读出的是脏数据)；
	
	不可重复读：指在一个事务内多次读同一数据，在这个事务还没有结束时，另一个事务也访问了该数据。在第一个事务的两次读数据之间，第二个事务也修改了数据，所以第一个事务两次读到的数据是不一样的，称为不可重复读(读不到相同的数据)；
	
	幻读：是指当事务不是独立执行时发生的一种现象，例如第一个事务对一个表中的数据进行了修改，并涉及到表中的全部数据行，同时，第二个事务也修改了这个表中的数据，这种修改是向表中插入一行新数据，此时第一个事务的操作者就会发现表中还有没有修改的数据行（产生了幻觉）


>2,隔离级别的实现--锁，时间戳，mvcc
	
	（1）锁
		锁是一种最为常见的并发控制机制，在一个事务中，我们并不会将整个数据库都加锁，而是只会锁住那些需要访问的数据项， MySQL 和常见数据库中的锁都分为两种，共享锁（Shared）和互斥锁（Exclusive），前者也叫读锁，后者叫写锁。
		
		读锁保证了读操作可以并发执行，相互不会影响，而写锁保证了在更新数据库数据时不会有其他的事务访问或者更改同一条记录造成不可预知的问题。
		
	（2）时间戳
		除了锁，另一种实现事务的隔离性的方式就是通过时间戳，使用这种方式实现事务的数据库，例如 PostgreSQL 会为每一条记录保留两个字段；读时间戳中报错了所有访问该记录的事务中的最大时间戳，而记录行的写时间戳中保存了将记录改到当前值的事务的时间戳。
		使用时间戳实现事务的隔离性时，往往都会使用乐观锁，先对数据进行修改，在写回时再去判断当前值，也就是时间戳是否改变过，如果没有改变过，就写入，否则，生成一个新的时间戳并再次更新数据，乐观锁其实并不是真正的锁机制，它只是一种思想，在这里并不会对它进行展开介绍。
	
	（3）mvcc版本快照
		
		通过维护多个版本的数据，数据库可以允许事务在数据被其他事务更新时对旧版本的数据进行读取，很多数据库都对这一机制进行了实现；因为所有的读操作不再需要等待写锁的释放，所以能够显著地提升读的性能，MySQL 和 PostgreSQL 都对这一机制进行自己的实现，也就是 MVCC，虽然各自实现的方式有所不同，MySQL 就通过文章中提到的回滚日志实现了 MVCC，保证事务并行执行时能够不等待互斥锁的释放直接获取数据。


>3,Next-key间隙锁的实现 --行锁
	
  (1),Record lock-对操作的行加锁:
  
  		单个行记录上的锁，我们通常讲的行锁，它的实质是通过对索引的加锁实现；只有通过索引条件检索数据，InnoDB才使用行级锁，否则，InnoDB将使用表锁。在事务隔离级别为读已提交下，仅采用Record Lock。
	
 （2）,Gap lock --间隙锁
 
	生活中排队的场景，小明，小红，小花三个人依次站成一排，此时，如何让新来的小刚不能站在小红旁边，这时候只要将小红和她前面的小明之间的空隙封锁，将小红和她后面的小花之间的空隙封锁，那么小刚就不能站到小红的旁边。这里的小红，小明，小花，小刚就是数据库的一条条记录。
	他们之间的空隙也就是间隙，而封锁他们之间距离的锁，叫做间隙锁。

  （3）,Next-lock锁，行级间隙锁
  		
		Next-Key Lock是结合Record Lock与Gap Lock的一种锁定方法，它锁定了包括记录本身的一个范围。
		
		例子 分析gap-lock和next-key lock的区别
		id 		name 
		10 		a
		20 		b
		50 		c

	如果索引为 10，20，50，那么：

	Record Lock：select * from tab where id = 10 for update; //对id=10单行进行加锁 
	Gap Lock锁范围：（- ∞，10）（10，20）（20，50）（50，+∞） 
	Next-Key Lock锁范围：（- ∞，10）[10，20）[20，50）[50，+∞）
	
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***	


#10,mysql日志类型

>1,redolog --重做日志
	
	(1),防止在发生故障的时间点，尚有脏页未写入磁盘，在重启mysql服务的时候，根据redo log进行重做，从而达到事务的持久性这一特性。
 	
 	(2),日志开始：
	事务开始之后就产生redo log，redo log的落盘并不是随着事务的提交才写入的，而是在事务的执行过程中，便开始写入redo log文件中。
	(3),日志删除
	 当对应事务的脏页写入到磁盘之后，redo log的使命也就完成了，重做日志占用的空间就可以重用（被覆盖）。
	 
	 (4),配置
	 innodb_log_group_home_dir 指定日志文件组所在的路径，默认./ ，表示在数据库的数据目录下。
　　innodb_log_files_in_group 指定重做日志文件组中文件的数量，默认2
　　关于文件的大小和数量，由一下两个参数配置
　　innodb_log_file_size 重做日志文件的大小。
　　innodb_mirrored_log_groups 指定了日志镜像文件组的数量，默认1
　　
　　（5）,redo log将日志刷新到磁盘详解：
　　	a,Master Thread 每秒一次执行刷新Innodb_log_buffer到重做日志文件。
　　	b,每个事务提交时会将重做日志刷新到重做日志文件。
　　	c,当重做日志缓存可用空间 少于一半时，重做日志缓存被刷新到重做日志文件
　　	
　
>2,undolog --回滚日志
	
  （1）,作用
  
	保存了事务发生之前的数据的一个版本，可以用于回滚，同时可以提供多版本并发控制下的读（MVCC），也即非锁定读
	
	(2),日志开始
	  事务开始之前，将当前版本生成的undo log，undo 也会产生 redo 来保证undo log的可靠性
	 
   (3),日志删除
   	 	当事务提交后，undo log不能立即删除，等待清理的链表，由purge线程判断是由其他事务在使用undo中保存上一个事务之前的版本信息，决定是否可以清理undo log日志
   	 	
   	(4),配置
	   	MySQL5.6之前，undo表空间位于共享表空间的回滚段中，共享表空间的默认的名称是ibdata，位于数据文件目录中。
	　　MySQL5.6之后，undo表空间可以配置成独立的文件，但是提前需要在配置文件中配置，完成数据库初始化后生效且不可改变undo log文件的个数
	　　如果初始化数据库之前没有进行相关配置，那么就无法配置成独立的表空间了。
	　　关于MySQL5.7之后的独立undo 表空间配置参数如下
	　　innodb_undo_directory = /data/undospace/ --undo独立表空间的存放目录
	　　innodb_undo_logs = 128 --回滚段为128KB
	　　innodb_undo_tablespaces = 4 --指定有4个undo log文件
   	 
   	 	 	
   		

>3,binglog --数据日志
	
 （1）,作用
 
	a，用于复制，在主从复制中，从库利用主库上的binlog进行重播，实现主从同步。
　　b，用于数据库的基于时间点的还原。
	
  (2),日志产生
  	
	  	事务提交的时候，一次性将事务中的sql语句（一个事物可能对应多个sql语句）按照一定的格式记录到binlog中。
	　　这里与redo log很明显的差异就是redo log并不一定是在事务提交的时候刷新到磁盘，redo log是在事务开始之后就开始逐步写入磁盘。
	　　因此对于事务的提交，即便是较大的事务，提交（commit）都是很快的，但是在开启了bin_log的情况下，对于较大事务的提交，可能会变得比较慢一些。
	　　这是因为binlog是在事务提交的时候一次性写入的造成的，这些可以通过测试验证。	
 （3）,日志删除
 	
	配置自动删除	
	binlog的默认是保持时间由参数expire_logs_days配置，也就是说对于非活动的日志文件，在生成时间超过expire_logs_days配置的天数之后，会被自动删除。
  	
  	

	
>4,errorlog --错误日志
	
	错误日志记录了MySQL Server每次启动和关闭的详细信息以及运行过程中所有较为严重的警告和错误信息。
	可以用--log-error[=file_name]选项来开启mysql错误日志，该选项指定mysqld保存错误日志文件的位置。
	对于指定--log-error[=file_name]选项而未给定file_name值，mysqld使用错误日志名host_name.err 并在数据目录中写入日志文件。
	
	
>5，slow query log - 慢日志
		
	slow_query_log是记录SQL执行超过一定时间的参数。
	
	a、命令行参数：

    --log-slow-queries

    指定日志文件存放位置，可以为空，系统会给一个缺省的文件host_name-slow.log

	b、系统变量

    log_slow_queries
    指定日志文件存放位置，可以为空，系统会给一个缺省的文件host_name-slow.log

    slow_query_log
    slow quere log的开关，当值为1的时候说明开启慢查询。
    
    slow_query_log_file
    指定日志文件存放位置，可以为空，系统会给一个缺省的文件host_name-slow.log
    
    long_query_time
    记录超过的时间，默认为10s
    log_queries_not_using_indexes
    log下来没有使用索引的query，可以根据情况决定是否开启
	发现执行时间过长的SQL，有效的改善数据库的性能时，非常有用的参数。

	
>6,general log --一般日志
		
	开启 general log 将所有到达MySQL Server的SQL语句记录下来。
	一般不会开启开功能，因为log的量会非常庞大。但个别情况下可能会临时的开一会儿general log以供排障使用。 
	相关参数一共有3：general_log、log_output、general_log_file

    show variables like 'general_log';  -- 查看日志是否开启
    set global general_log=on; -- 开启日志功能
    
    show variables like 'general_log_file';  -- 看看日志文件保存位置
    set global general_log_file='tmp/general.lg'; -- 设置日志文件保存位置
	
	 show variables like 'log_output';  -- 看看日志输出类型  table或file
    set global log_output='table'; -- 设置输出类型为 table
    set global log_output='file';   -- 设置输出类型为file

>7,relay log --中继日志
	
	relay log和binlog类似
	relaylog用户从库接收到主库的binglog日志，从库通过写入relaylog然后由IO线程写入binlog
	
	从服务器I/O线程将主服务器的二进制日志读取过来记录到从服务器本地文件，然后SQL线程会读取relay-log日志的内容并应用到从服务器，从而使从服务器和主服务器的数据保持一致
	



***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***	

#11,innerdb事务日志


>1,事务日志的组成
	
	RedoLog ,UndoLog,CHeckPoint三者组成，UndoLog存储了checkpoint的日志序列号

>2,Log日志写入机制
		
		LSN，日志序列号，Innodb的日志序列号是一个64位的整型。
	
	（1），日志写入位置：
		
		根据日志的位置来写入，旧的日志序列号+写入的日志大小 = checkpoint日志写入的位置
		
	（2）,checkpoint写入机制详解
	 
	 解决的问题：
		 1、缩短数据库的恢复时间；2、缓冲池不够用时，将脏页刷新到磁盘；3、重做日志不可用时，刷新脏页。
		 
	 Checkpoint分类：Sharpcheckpoint ,fuzzyCheckpoint
	 
	 Sharp Checkpoint 发生在数据库关闭时将所有的脏页都刷新回磁盘，这是默认的工作方式，即参数innodb_fast_shutdown=1。但是若数据库在运行时也使用Sharp Checkpoint，那么数据库的可用性就会受到很大的影响。故在InnoDB存储引擎内部使用Fuzzy Checkpoint进行页的刷新，即只刷新一部分脏页，而不是刷新所有的脏页回磁盘。
	 
	 
	 
	 (3),Fuzzy checkpoint日志检查
	 
	  Fuzzy Checkpoint，Innodb每次取最老的modified page(last checkpoint)对应的LSN，再将此脏页的LSN作为Checkpoint点记录到日志文件，意思就是“此LSN之前的LSN对应的日志和数据都已经flush到redo log
	
	 当mysql crash的时候，Innodb扫描redo log，从last checkpoint开始apply redo log到buffer pool，直到last checkpoint对应的LSN等于Log flushed up to对应的LSN，则恢复完成	
	 	
![恢复过程](https://images2015.cnblogs.com/blog/268981/201601/268981-20160108210013918-92051279.png)
	
	如上图所示，Innodb的一条事务日志共经历4个阶段：

    创建阶段：事务创建一条日志；
    日志刷盘：日志写入到磁盘上的日志文件；
    数据刷盘：日志对应的脏页数据写入到磁盘上的数据文件；
    写CKP：日志被当作Checkpoint写入日志文件；
    
	对应这4个阶段，系统记录了4个日志相关的信息，用于其它各种处理使用：

    Log sequence number（LSN1）：当前系统LSN最大值，新的事务日志LSN将在此基础上生成（LSN1+新日志的大小）；
    Log flushed up to（LSN2）：当前已经写入日志文件的LSN；
    Oldest modified data log（LSN3）：当前最旧的脏页数据对应的LSN，写Checkpoint的时候直接将此LSN写入到日志文件；
    Last checkpoint at（LSN4）：当前已经写入Checkpoint的LSN；
	对于系统来说，以上4个LSN是递减的，即： LSN1>=LSN2>=LSN3>=LSN4.

	
	（4）,Log日志保护机制
	
	  Innodb的数据并不是实时写盘的，为了避免宕机时数据丢失，保证数据的ACID属性，Innodb至少要保证数据对应的日志不能丢失。对于不同的情况，Innodb采取不同的对策：
		
		1）宕机导致日志丢失
		Innodb有日志刷盘机制，可以通过innodb_flush_log_at_trx_commit参数进行控制（具体含义请查看mysql配置文件详解）；
			 
		2）日志覆盖导致日志丢失
		Innodb日志文件大小是固定的，写入的时候通过取余来计算偏移量，这样存在两个LSN写入到同一位置的可能，后面写的把前面写得就覆盖了，以“写入机 制”章节的样例为例，LSN＝100000000和LSN＝1600000000两个日志的偏移量是相同的了。这种情况下，为了保证数据一致性，必须要求LSN=1000000000对应的脏页数据都已经刷到磁盘中，也就是要求Last checkpoint对应的LSN一定要大于1000000000， 否则覆盖后日志也没有了，数据也没有刷盘，一旦宕机，数据就丢失了。
	
	   3), innodb_flush_log_at_trx_commit日志提交
	 
	 	当取值为 0 的时候，log buffer 会 每秒写入到日志文件并刷写（flush）到磁盘。但每次事务提交不会有任何影响，也就是 log buffer 的刷写操作和事务提交操作没有关系。在这种情况下，MySQL性能最好，但如果 mysqld 进程崩溃，通常会导致最后 1s 的日志丢失。
	 当取值为 1 时，每次事务提交时，log buffer 会被写入到日志文件并刷写到磁盘。这也是默认值。这是最安全的配置，但由于每次事务都需要进行磁盘I/O，所以也最慢。
	 
	 当取值为 2 时，每次事务提交会写入日志文件，但并不会立即刷写到磁盘，日志文件会每秒刷写一次到磁盘。这时如果 mysqld 进程崩溃，由于日志已经写入到系统缓存，所以并不会丢失数据；在操作系统崩溃的情况下，通常会导致最后 1s 的日志丢失。
	 
	   4）,sync_binlog 同步到磁盘的频率
	   
	   	如果 autocommit 开启，每个语句都写一次 binary log，否则每次事务写一次。默认值是 0，不主动同步，而依赖操作系统本身不定期把文件内容 flush 到磁盘。设为 1 最安全，在每个语句或事务后同步一次 binary log，即使在崩溃时也最多丢失一个语句或事务的日志，但因此也最慢。
		大多数情况下，对数据的一致性并没有很严格的要求，所以并不会把 sync_binlog 配置成 1. 为了追求高并发，提升性能，可以设置为 100 或直接用 0. 而和 innodb_flush_log_at_trx_commit 一样，对于支付服务这样的应用，还是比较推荐 sync_binlog = 1.
	 	

***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***
***		
	
#12,innerdb的读数据mvcc并发
	
>1,产生的背景
		
		myisam读取数据S共享锁，innerdb采用的是mvcc并发
		
>2,mvcc原理

	(1）,innodb MVCC主要是为Repeatable-Read事务隔离级别做的。在此隔离级别下，A、B客户端所示的数据相互隔离，互相更新不可见，了解innodb的行结构、Read-View的结构对于理解innodb mvcc的实现由重要意义
	
	(2),innodb存储的最基本row中包含一些额外的存储信息 DATA_TRX_ID，DATA_ROLL_PTR，DB_ROW_ID，DELETE BIT
    6字节的DATA_TRX_ID 标记了最新更新这条行记录的transaction id，每处理一个事务，其值自动+1
    7字节的DATA_ROLL_PTR 指向当前记录项的rollback segment的undo log记录，找之前版本的数据就是通过这个指针
    6字节的DB_ROW_ID，当由innodb自动产生聚集索引时，聚集索引包括这个DB_ROW_ID的值，否则聚集索引中不包括这个值.，这个用于索引当中
    DELETE BIT位用于标识该记录是否被删除，这里的不是真正的删除数据，而是标志出来的删除。真正意义的删除是在commit的时候

![mvcc](https://images2015.cnblogs.com/blog/268981/201512/268981-20151221230743968-739828690.png)	
具体的执行过程:
begin->用排他锁锁定该行->记录redo log->记录undo log->修改当前行的值，写事务编号，回滚指针指向undo log中的修改前的行

上述过程确切地说是描述了UPDATE的事务过程，其实undo log分insert和update undo log，因为insert时，原始的数据并不存在，所以回滚时把insert undo log丢弃即可，而update undo log则必须遵守上述过程
	
	
	
	
	
	
#13,表分区

（1）,分区的概念	

	 	将一张表从逻辑上分成多张表，实际只有一张表

（2）,分区的优劣势
	
	 优：
	 存储更多数据，优化查询
	 
	 劣：
	 一张表最多1024分区
	

（3),分区的类型
	
	range分区:按照范围分区
	
	list分区:根据具体数值分区，每个分区数值不重叠
	
	hash分区: Hash分区主要用来确保数据在预先确定数目的分区中平均分布，Hash括号内只能是整数列或返回确定整数的函数，实际上就是使用返回的整数对分区数取模。
	
	key分区	:Key分区与Hash分区很相似，只是Hash函数不同，定义时把Hash关键字替换成Key即可，同样Key分区也有对应与线性Hash的线性Key分区方法。
	

(4),range分区 PARTITION BY RANGE, VALUES LESS THAN

>4.1,根据数值范围
	
	创建表和分区，partition by range(分区的key)
	
	drop table if exists employees;
	create table employees(
	    id int not null,
	    fname varchar(30),
	    lname varchar(30),
	    hired date not null default '1970-01-01',
	    separated date not null default '9999-12-31',
	    job_code int not null default 0,
	    store_id int not null default 0
	)engine=myisam default charset=utf8
	partition by range(store_id)(
	    partition p0 values less than (6),
	    partition p1 values less than (11),
	    partition p2 values less than (16),
	    partition p3 values less than (21),
	    partition p4 values less than MAXVALUE  
	);
	
	// partition p4 values less than MAXVALUE 超过21范围的就写在p4
	
	插入数据
	insert into employees (id,fname,lname,hired,store_id) values(1,'张三','张','2015-05-04',1);
	insert into employees (id,fname,lname,hired,store_id) values(2,'李四','李','2016-10-01',5);
	insert into employees (id,fname,lname,hired,store_id) values(3,'王五','王','2016-11-14',10);
	insert into employees (id,fname,lname,hired,store_id) values(4,'赵六','赵','2017-08-24',15);
	insert into employees (id,fname,lname,hired,store_id) values(5,'田七','田','2018-05-20',20);
		
	按照这种分区方案，在商店1到5工作的雇员相对应的所有行被保存在分区P0中，商店6到10的雇员保存在P1中，依次类推。注意，每个分区都是按顺序进行定义，从最低到最高。这是PARTITION BY RANGE 语法的要求。
	
	
>4.2、根据TIMESTAMP范围	
	
	 drop table if exists quarterly_report_status;
	create table quarterly_report_status(
	  report_id int not null,
	  report_status varchar(20) not null,
	  report_updated timestamp not null default current_timestamp on update current_timestamp
	)
	partition by range(unix_timestamp(report_updated))(
	  partition p0 values less than (unix_timestamp('2008-01-01 00:00:00')),
	  partition p1 values less than (unix_timestamp('2008-04-01 00:00:00')),
	  partition p2 values less than (unix_timestamp('2008-07-01 00:00:00')),
	  partition p3 values less than (unix_timestamp('2008-10-01 00:00:00')),
	  partition p4 values less than (unix_timestamp('2009-01-01 00:00:00')),
	  partition p5 values less than (unix_timestamp('2009-04-01 00:00:00')),
	  partition p6 values less than (unix_timestamp('2009-07-01 00:00:00')),
	  partition p7 values less than (unix_timestamp('2009-10-01 00:00:00')),
	  partition p8 values less than (unix_timestamp('2010-01-01 00:00:00')),
	  partition p9 values less than maxvalue
	);
	
	
	
(5),List分区

	根据具体数值分区，每个分区数值不重叠，使用PARTITION BY LIST、VALUES IN关键字。跟Range分区类似，不使用COLUMNS关键字时List括号内必须为整数字段名或返回确定整数的函数。
	
	假定有20个音像店，分布在4个有经销权的地区，如下表所示：

	====================
	
	地区      商店ID 号
	
	北区      3, 5, 6, 9, 17
	
	东区      1, 2, 10, 11, 19, 20
	
	西区      4, 12, 13, 14, 18
	
	中心区   7, 8, 15, 16
	
	drop table if exists staff;
	create table staff(
	  id int not null,
	  fname varchar(30),
	  lname varchar(30),
	  hired date not null default '1970-01-01',
	  separated date not null default '9999-12-31',
	  job_code int not null default 0,
	  store_id int not null default 0
	)
	partition by list(store_id)(
	  partition pNorth values in (3,5,6,9,17),
	  partition pEast values in (1,2,10,11,19,20),
	  partition pWest values in (4,12,13,14,18),
	  partition pCentral values in (7,8,15,16)
	);
	
	
6、HASH分区	
	
	Hash分区主要用来确保数据在预先确定数目的分区中平均分布，Hash括号内只能是整数列或返回确定整数的函数，实际上就是使用返回的整数对分区数取模。 partition by hash(counlom) partition 4;
	
	drop table if exists staff;
	create table staff(
	  id int not null,
	  fname varchar(30),
	  lname varchar(30),
	  hired date not null default '1970-01-01',
	  separated date not null default '9999-12-31',
	  job_code int not null default 0,
	  store_id int not null default 0
	)
	partition by hash(year(hired))
	partitions 4;
	
	
7,KEY分区
	
	Key分区与Hash分区很相似，只是Hash函数不同，定义时把Hash关键字替换成Key即可，同样Key分区也有对应与线性Hash的线性Key分区方法。
	
	drop table if exists staff;
	create table staff(
	  id int not null,
	  fname varchar(30),
	  lname varchar(30),
	  hired date not null default '1970-01-01',
	  separated date not null default '9999-12-31',
	  job_code int not null default 0,
	  store_id int not null default 0
	)
	partition by key(store_id)
	partitions 4;
	
	在KEY分区中使用关键字LINEAR和在HASH分区中使用具有同样的作用，分区的编号是通过2的幂（powers-of-two）算法得到，而不是通过模数算法。
	
	
#14,Mysql面试题在这里！

>1,备份计划，mysqldump以及xtranbackup的实现原理

    (1)、备份计划；这里每个公司都不一样，您别说那种1小时1全备什么的就行(2)、备份恢复时间；这里跟机器，尤其是硬盘的速率有关系，以下列举几个仅供参考20G的2分钟（mysqldump）80G的30分钟(mysqldump)111G的30分钟（mysqldump)288G的3小时（xtra)3T的4小时（xtra)逻辑导入时间一般是备份时间的5倍以上(3)、xtrabackup实现原理在InnoDB内部会维护一个redo日志文件，我们也可以叫做事务日志文件。事务日志会存储每一个InnoDB表数据的记录修改。当InnoDB启动时，InnoDB会检查数据文件和事务日志，并执行两个步骤：它应用（前滚）已经提交的事务日志到数据文件，并将修改过但没有提交的数据进行回滚操作。 
    
>2,500台db，在最快时间之内重启

	puppet，dsh（同网段批量启动）    

>3,innodb的读写参数优化

    (1)、读取参数global buffer pool以及 local buffer；
    (2)、写入参数；innodb_flush_log_at_trx_commit innodb_buffer_pool_size
    (3)、与IO相关的参数；innodb_write_io_threads = 8innodb_read_io_threads = 8innodb_thread_concurrency = 0
    (4)、缓存参数以及缓存的适用场景。query cache/query_cache_type并不是所有表都适合使用query cache。造成query cache失效的原因主要是相应的table发生了变更 第一个：读操作多的话看看比例，简单来说，如果是用户清单表，或者说是数据比例比较固定，比如说商品列表，是可以打开的，前提是这些库比较集中，数据库中的实务比较小。 第二个：我们“行骗”的时候，比如说我们竞标的时候压测，把query cache打开，还是能收到qps激增的效果，当然前提示前端的连接池什么的都配置一样。大部分情况下如果写入的居多，访问量并不多，那么就不要打开，例如社交网站的，10%的人产生内容，其余的90%都在消费，打开还是效果很好的，但是你如果是qq消息，或者聊天，那就很要命。 第三个：小网站或者没有高并发的无所谓，高并发下，会看到 很多 qcache 锁 等待，所以一般高并发下，不建议打开query cache 
    
    
>5,你是如何监控你们的数据库的？你们的慢日志都是怎么查询的？

    监控的工具有很多，例如zabbix，lepus，我这里用的是lepus    

>6,你是否做过主从一致性校验，如果有，怎么做的，如果没有，你打算怎么做？

    pt-table-checksum 检查
    pt-table-sync		修复	


>7,你们数据库是否支持emoji表情，如果不支持，如何操作？

    如果是utf8字符集的话，需要升级至utf8_mb4方可支持 

>8,MySQL中InnoDB引擎的行锁是通过加在什么上完成(或称实现)的？为什么是这样子的？

    InnoDB是基于索引来完成行锁例: select * from tab_with_index where id = 1 for update;for update 可以根据条件来完成行锁锁定,并且 id 是有索引键的列,如果 id 不是索引键那么InnoDB将完成表锁,,并发将无从谈起 

>9,开放性问题：据说是腾讯的
	
	一个6亿的表a，一个3亿的表b，通过外间tid关联，你如何最快的查询出满足条件的第50000到第50200中的这200条数据记录。
	
	1、如果A表TID是自增长,并且是连续的,B表的ID为索引
	
	select * from a,b where a.tid = b.id and a.tid>500000 limit 200;
	
	2、如果A表的TID不是连续的,那么就需要使用覆盖索引.TID要么是主键,要么是辅助索引,B表ID也需要有索引。
	
	select * from b , (select tid from a limit 50000,200) a where b.id = a .tid;


>10,数据库的乐观锁和悲观锁是什么？

	数据库管理系统（DBMS）中的并发控制的任务是确保在多个事务同时存取数据库中同一数据时不破坏事务的隔离性和统一性以及数据库的统一性。乐观并发控制(乐观锁)和悲观并发控制（悲观锁）是并发控制主要采用的技术手段。

    悲观锁：假定会发生并发冲突，屏蔽一切可能违反数据完整性的操作，不能读
    乐观锁：假设不会发生并发冲突，只在提交操作时检查是否违反数据完整性。 可以读不能写

>11,简单说一说drop、delete与truncate的区

	SQL中的drop、delete、truncate都表示删除，但是三者有一些差别
    1、delete和truncate只删除表的数据不删除表的结构2、速度,一般来说: drop> truncate >delete3、delete语句是dml,这个操作会放到rollback segement中,事务提交之后才生效;4、如果有相应的trigger,执行的时候将被触发. truncate,drop是ddl, 操作立即生效,原数据不放到rollback segment中,不能回滚. 操作不触发trigger. 

	drop、delete与truncate分别在什么场景之下使用？
    1、不再需要一张表的时候，用drop2、想删除部分数据行时候，用delete，并且带上where子句	 3、保留表而删除所有数据的时候用truncate 	


>12,说一说三个范式。

    第一范式（1NF）：数据库表中的字段都是单一属性的，不可再分。这个单一属性由基本类型构成，包括整型、实数、字符型、逻辑型、日期型等。 第二范式（2NF）：数据库表中不存在非关键字段对任一候选关键字段的部分函数依赖（部分函数依赖指的是存在组合关键字中的某些字段决定非关键字段的情况），也即所有非关键字段都完全依赖于任意一组候选关键字。 第三范式（3NF）：在第二范式的基础上，数据表中如果不存在非关键字段对任一候选关键字段的传递函数依赖则符合第三范式。所谓传递函数依赖，指的是如 果存在"A → B → C"的决定关系，则C传递函数依赖于A。因此，满足第三范式的数据库表应该不存在如下依赖关系： 关键字段 → 非关键字段 x → 非关键字段y 


#查看mycat分库分表
	
	
	
#mysql主从同步出现中断

 1. 一般的异常只需要跳过一步即可恢复


	>slave stop;
	
	>SET GLOBAL sql_slave_skip_counter = 1;
	
	>slave start;
	
 

2.断电导致主从不能同步时，通主库的最后一个bin-log日志进行恢复

	在主库服务器上，mysqlbinlog mysql-bin.xxxx > binxxxx.txt
	
	tail -n 100000  binxxxx.txt > tail-binxxxx.txt
	
	vim tail-binxxxx.txt 打开tail-binxxxx.txt文件找到最后一个postion值
	
	然后在从库上，change host to 相应正确的值
	
	>slave stop;
	
	>change master to master_host='ip', master_user='username', master_password='password', master_log_file='mysql-bin.xxxx', master_log_pos=xxxx;
	
	>slave start;
	
	>show slave status\G;

 

 

3.主键冲突、表已存在等错误代码如1062,1032,1060等，可以在mysql主配置文件指定

	略过此类异常并继续下条sql同步，这样也可以避免很多主从同步的异常中断
	
	[mysqld]
	
	slave-skip-errors = 1062,1032,1060	
	

			