
#视频表
create table tb_video (
id INT (20) primary key auto_increment COMMENT '表id',
id_no varchar(255) DEFAULT '' COMMENT '关联唯一idno',
filename varchar(255) DEFAULT '' COMMENT '文件名称',
vid varchar(255) DEFAULT '' COMMENT '视频唯一编号',
dir varchar(255) DEFAULT '/SFTP/vedio' COMMENT '用户地址',
create_at varchar(255) DEFAULT '' COMMENT '创建时间',
create_ip varchar(255) DEFAULT '127.0.0.1' COMMENT '创建ip',
tag varchar(255) DEFAULT '' COMMENT '视频类型标记',
INDEX(id_no,vid,filename)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;


select * from tb_video;
INSERT into tb_video(id,id_no,filename,vid,dir,create_at,create_ip,tag)
  VALUES(0,"KX","001","1320000000","","2019-09-09","127.0.0.1","system");

#视频评价表
create table tb_evaluation (
id int(20) primary key auto_increment COMMENT '表id',
id_no varchar(255)  DEFAULT '' COMMENT '视频发布人',
vid varchar(255)  DEFAULT '' COMMENT '视频唯一编号',
e_idno varchar(255) DEFAULT '' COMMENT '评价视频人的idno',
e_name varchar(255) DEFAULT '' COMMENT '评价人的name',
eid varchar(255) DEFAULT '' COMMENT '评价的唯一id',
e_content varchar(255) DEFAULT '' COMMENT '评价内容',
create_at varchar(255) DEFAULT '' COMMENT '创建时间',
create_ip varchar(255) DEFAULT '127.0.0.1' COMMENT '创建ip',
n_eid varchar(255) DEFAULT '' COMMENT '用户评价的子评价',
INDEX(id_no,vid,eid)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;


INSERT into tb_evaluation(id,id_no,vid,e_idno,e_name,eid,e_content,create_at,create_ip,n_eid)
  VALUES(0,"KX","001","1320000000",0);

#
alter table tb_video change url hash varchar(255) DEFAULT '' COMMENT '视频md5';