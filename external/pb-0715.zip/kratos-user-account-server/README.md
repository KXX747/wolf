# user-account-server

## 项目简介
1.用户信息

 redis实现分布式锁
 