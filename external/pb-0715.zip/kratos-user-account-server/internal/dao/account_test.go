package dao_test

import (
	"testing"
	"time"
	"context"
	"github.com/bilibili/kratos/pkg/log"
	"github.com/bilibili/kratos/pkg/container/pool"
	xtime "github.com/bilibili/kratos/pkg/time"
	"github.com/bilibili/kratos/pkg/cache/redis"
	"fmt"
)

var p *redis.Pool
var config *redis.Config

func init() {
	config = getConfig()
	//p =redis.NewPool(config)
	p=redis.NewPool(config)

}

func TestDao_FindUserDao(t *testing.T) {


}


func getConfig() (c *redis.Config) {
	c = &redis.Config{
		Name:         "test",
		Proto:        "tcp",
		Addr:         "192.168.57.135:19000",
		DialTimeout:  xtime.Duration(time.Second),
		ReadTimeout:  xtime.Duration(time.Second),
		WriteTimeout: xtime.Duration(time.Second),
	}
	c.Config = &pool.Config{
		Active:      20,
		Idle:        2,
		IdleTimeout: xtime.Duration(90 * time.Second),
	}
	return
}

func TestRedis(t *testing.T) {
	//testSet(t, p)
	//testSend(t, p)
	//testGet(t, p)
	//testErr(t, p)
	//RedisDecrExist(t,p)
	//redislock(t,p)
	if err := p.Close(); err != nil {
		t.Errorf("redis: close error(%v)", err)
	}
	conn, err := redis.NewConn(config)
	if err != nil {
		t.Errorf("redis: new conn error(%v)", err)
	}
	if err := conn.Close(); err != nil {
		t.Errorf("redis: close error(%v)", err)
	}
}

//redis锁
func TestRedislock(t *testing.T)  {
	lock("woshi1")
	//lock("woshi2")
}

func lock(name string)  {
	ctx:=context.TODO()
	rml,_:=redis.NewMutex(ctx,name,p)
	err:=rml.Lock()
	fmt.Println("rml.Lock()",err)
	time.Sleep(10*time.Second)

	err=rml.Unlock()
	fmt.Println("rml.Unlock()",err)

}

//lua 添加数据
func TestRadisAdd(t *testing.T)  {

	conn := p.Get(context.TODO())
	defer conn.Close()
	luaAdd:=`if redis.call("set", KEYS[1], ARGV[1], "nx", "px", ARGV[2]) then  return "OK"  else return "ERR" end`

	reply, err := conn.Do("EVAL",luaAdd,1,"key1","v1",int( 8 * time.Second/time.Millisecond))

	fmt.Println(string(reply.([]byte)),"<><><><>",err)

}


// RedisDecrExist 当 key 存在时 给 key 减去指定数值 key 不存在时不做操作
func  RedisDecrExist( t *testing.T,p *redis.Pool)  {
	key :="shanghai:nihao"
	num :=100
	var err error

	conn := p.Get(context.TODO())
	defer conn.Close()

	//lua := `if redis.call("EXISTS",KEYS[1])==1 then return redis.call("%s",KEYS[1]%s);else return nil;end`
	//if num == 1 {
	//	log.Info(fmt.Sprintf(fmt.Sprintf(lua, "DECR", "")+"%d %s", 1, key))
	//	_, err = conn.Do("EVAL", fmt.Sprintf(lua, "DECR", ""), 1, key)
	//} else {
	//	log.Info(fmt.Sprintf(fmt.Sprintf(lua, "DECRBY", ",ARGV[1]")+"%d %s %d"), 1, key, num)
	//	_, err = conn.Do("EVAL", fmt.Sprintf(lua, "DECRBY", ",ARGV[1]"), 1, key, num)
	//}

	//ARGV[1]
	lua :=`if redis.call("get", KEYS[1])== ARGV[1]  then  return redis.call("del", KEYS[1]) else return ARGV[1] end`
	reply, err := conn.Do("EVAL", lua, 1, key,num)
	if err != nil {
		log.Error("d.RedisDecrExist(%s, %d) error(%v)", key, num, err)
	}else {
		fmt.Println(" KEYS[1]) == ARGV[1] ",string(reply.([]byte)))
	}

	return
}


func testSets(t *testing.T, p *redis.Pool) {
	var (
		key   = "test"
		value = "test"
		conn  = p.Get(context.TODO())
	)
	defer conn.Close()

	if reply, err := conn.Do("l", key, value); err != nil {
		t.Errorf("redis: conn.Do(SET, %s, %s) error(%v)", key, value, err)
	} else {
		t.Logf("redis: set status: %s", reply)
	}

}




func testSet(t *testing.T, p *redis.Pool) {
	var (
		key   = "test"
		value = "test"
		conn  = p.Get(context.TODO())
	)
	defer conn.Close()
	if reply, err := conn.Do("set", key, value); err != nil {
		t.Errorf("redis: conn.Do(SET, %s, %s) error(%v)", key, value, err)
	} else {
		t.Logf("redis: set status: %s", reply)
	}
}

func testSend(t *testing.T, p *redis.Pool) {
	var (
		key    = "test"
		value  = "test"
		expire = 1000
		conn   = p.Get(context.TODO())
	)
	defer conn.Close()
	if err := conn.Send("SET", key, value); err != nil {
		t.Errorf("redis: conn.Send(SET, %s, %s) error(%v)", key, value, err)
	}
	if err := conn.Send("EXPIRE", key, expire); err != nil {
		t.Errorf("redis: conn.Send(EXPIRE key(%s) expire(%d)) error(%v)", key, expire, err)
	}
	if err := conn.Flush(); err != nil {
		t.Errorf("redis: conn.Flush error(%v)", err)
	}
	for i := 0; i < 2; i++ {
		if _, err := conn.Receive(); err != nil {
			t.Errorf("redis: conn.Receive error(%v)", err)
			return
		}
	}
	t.Logf("redis: set value: %s", value)
}

func testGet(t *testing.T, p *redis.Pool) {
	var (
		key  = "test"
		conn = p.Get(context.TODO())
	)
	defer conn.Close()
	if reply, err := conn.Do("GET", key); err != nil {
		t.Errorf("redis: conn.Do(GET, %s) error(%v)", key, err)
	} else {
		t.Logf("redis: get value: %s", reply)
	}
}

func testErr(t *testing.T, p *redis.Pool) {
	conn := p.Get(context.TODO())
	if err := conn.Close(); err != nil {
		t.Errorf("memcache: close error(%v)", err)
	}
	if err := conn.Err(); err == nil {
		t.Errorf("redis: err not nil")
	} else {
		t.Logf("redis: err: %v", err)
	}
}

func BenchmarkMemcache(b *testing.B) {
	b.ResetTimer()
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			conn := p.Get(context.TODO())
			if err := conn.Close(); err != nil {
				b.Errorf("memcache: close error(%v)", err)
			}
		}
	})
	if err := p.Close(); err != nil {
		b.Errorf("memcache: close error(%v)", err)
	}
}
