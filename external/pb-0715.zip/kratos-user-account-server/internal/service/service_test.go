package service

import (
	"kratos-user-account-server/internal/model/user"
	"github.com/bilibili/kratos/pkg/net/http/blademaster"
	"github.com/bilibili/kratos/pkg/net/netutil/breaker"
	xtime "github.com/bilibili/kratos/pkg/time"
	"time"
	http "net/http"
	"fmt"
	"testing"
	"context"
	"net/url"
)

var (
	uri = "http://127.0.0.1:38888/account.service.Users/AddUser"

	req    *http.Request //请求
	client *blademaster.Client //连接
	err    error
)

func init() {
	client = blademaster.NewClient(
		&blademaster.ClientConfig{

			Dial:      xtime.Duration(time.Second),
			Timeout:   xtime.Duration(time.Second),
			KeepAlive: xtime.Duration(time.Second),
			Breaker: &breaker.Config{
				Window:  10 * xtime.Duration(time.Second),
				Sleep:   50 * xtime.Duration(time.Millisecond),
				Bucket:  10,
				Ratio:   0.5,
				Request: 100,
			},
		},
	)
}

//test rpc adduser
func TestService_AddUser(t *testing.T) {

	params := url.Values{}
	params.Set("Name", "kxx747")
	params.Set("Mobile", "13800000000")

	if req,err = client.NewRequest(http.MethodGet,uri,"",params);err!=nil {
		t.Errorf("client.NewRequest: get error(%v)", err)
		return
	}

	rep:=&account_service.UserReply{}
	if err=client.PB(context.TODO(),req,rep);err!=nil{
		t.Errorf("Do: client.Do get error(%v) ", err,"添加失败 idno=")
		return
	}

	r,_:=rep.Marshal()
	fmt.Println(string(r))

}






func TestService_AddUser2(t *testing.T) {

	//初始化user的service


}



//test rpc updateuser
func TestService_UpdateUser(t *testing.T) {


}


//test rpc deleteuser
func TestService_DeleteUser(t *testing.T) {


}

