package main

import (
	"fmt"

	"crypto/md5"
	"io/ioutil"
	"strings"
)

func main() {
	fmt.Println(32 << 10)

	fmt.Println((12+2+12-2*2));


	result,err:=Md5SumFile("/Users/a747/go/src/kratos-stream-server/README1.md")
	fmt.Println(err)
	fmt.Println(result)
	var s string
	for _, v := range result {
		s += fmt.Sprintf("%x", v)
	}

	fmt.Println(s)

	//[87 140 62 201 203 193 105 144 113 148 51 19 197 117 41 9]
	// 578c3ec9cbc1699071943313c575299

	str:="1jdfhfjdhfjiw.mp4"
	vid :=strings.Split(str,".")
	fmt.Println(vid[0])

}



/**
获取文件的md5
 */
func Md5SumFile(file string) (value [md5.Size]byte, err error) {
	var data []byte
	data, err = ioutil.ReadFile(file)
	if err != nil {
		return
	}
	value = md5.Sum(data)
	return
}