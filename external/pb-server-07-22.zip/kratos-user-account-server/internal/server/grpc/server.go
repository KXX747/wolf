package grpc

import (

	pb "kratos-user-account-server/api"
	"kratos-user-account-server/internal/service"
	"github.com/bilibili/kratos/pkg/net/rpc/warden"
	"kratos-user-account-server/internal/model/user"

)


// New new a grpc server.
func New(svc *service.Service) *warden.Server {
	//var rc struct {
	//	Server *warden.ServerConfig
	//}
	//if err := paladin.Get("grpc.toml").UnmarshalTOML(&rc); err != nil {
	//	if err != paladin.ErrNotExist {
	//		panic(err)
	//	}
	//}
	ws := warden.NewServer(svc.AppConfig.Grpc)
	//注册demo的rpc
	pb.RegisterDemoServer(ws.Server(), svc)
	//注册rpc
	account_service.RegisterUsersServer(ws.Server(), svc)

	account_service.RegisterUserDetailCommonServer(ws.Server(), svc)

	ws, err := ws.Start()
	if err != nil {
		panic(err)
	}
	return ws
}







