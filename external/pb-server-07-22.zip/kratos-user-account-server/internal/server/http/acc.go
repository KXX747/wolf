package http

import (
	"github.com/satori/go.uuid"
	"github.com/bilibili/kratos/pkg/ecode"
	"github.com/bilibili/kratos/pkg/net/http/blademaster"
	"io"
	"os"
	"path"
	"fmt"
	"kratos-user-account-server/internal/model"
	"kratos-user-account-server/internal/model/user"
	"github.com/bilibili/kratos/pkg/database/sftp"
	"encoding/json"
	"github.com/bilibili/kratos/pkg/log"
)

const(
	filePathKey      = "search"
	LOGIN_EXR =2*60*60 //两个小时过期
)

// example for http request handler.
func howToStart(c *blademaster.Context) {
	k := &model.Kratos{
		Hello: "/user-account-server Golang 大法好 !!!",
	}
	log.Info("user-account-server  Golang 大法好 !!! ip=%s",c.Request.RemoteAddr)

	c.JSON(k, nil)
}

/**
用户登录
 */
func LoginSys(c *blademaster.Context)  {

	loginInParams:=new(model.LoginInSystem)
	if err := c.Bind(loginInParams); err != nil {
		c.JSON(nil, ecode.ReqParamErr)
		return
	}
	//
	reply,err:=svc.FindUserIsExistDao(c.Context,loginInParams.Mobile,loginInParams.Name)
	if err!=nil {
		c.JSON(nil, ecode.BatchUserTooLong)
		return
	}

	//判断用户是否存在
	if reply.IdNo=="" {
		c.JSON(nil,ecode.MobileNoVerfiy)
		return
	}

	token:=uuid.Must(uuid.NewV4())
	loginInfo:=model.LoginResponse{}
	loginInfo.Token =token.String()
	loginInfo.Mobile = reply.Mobile
	loginInfo.Name  = reply.Name
	loginInfo.Address = reply.Address
	loginInfo.IdNo = reply.IdNo

	//保存redis数据
	redisKey:=svc.GetLoginToRedisKey(c,loginInfo.Token)
	fmt.Println("GetLoginToRedisKey  = ",redisKey)
	redisSaveData,err:=json.Marshal(loginInfo)
	if err!=nil {
		c.JSON(nil, ecode.BatchUserTooLong)
		return
	}
	err=svc.AddRedisAndExrString(c.Context,redisKey,string(redisSaveData),LOGIN_EXR)
	if err!=nil {
		c.JSON(nil, ecode.BatchUserTooLong)
		return
	}
	c.JSON(loginInfo, nil)

}

/**
退出用户
 */
func LoginOut(c *blademaster.Context)  {
	loginOutParams:=new(model.LoginOutSystem)
	if err := c.Bind(loginOutParams); err != nil {
		c.JSON(nil, ecode.ReqParamErr)
		return
	}
	//删除redis数据
	redisKey:=svc.GetLoginToRedisKey(c,loginOutParams.Token)
	err:=svc.DelRedisString(c.Context,redisKey)
	if err!=nil {
		c.JSON(nil, ecode.BatchUserTooLong)
		return
	}
	//p:=new(account_service.UserReply)
	c.JSON("数据已删除", nil)
}



/**
一是 Request Body 就是整个文件内容，通过请求头（即 Header ）中的 Content-Type 字段来指定文件类型。
二是用 multipart 表单方式来上传
*/
//上传信息照片
func updatecard(c *blademaster.Context) {
	p := new(model.ParamUpload)
	if err := c.Bind(p); err != nil {
		c.JSON(nil, ecode.ReqParamErr)
		return
	}

	//return
	c.Request.ParseMultipartForm(32 << 10)
	//将本地图片保存并上传sftp服务器，上传sftp服务器后删除图片
	newFileOne, err := getUploadFile(model.CRAD_ONE, c)
	newFileTwo, err := getUploadFile(model.CRAD_TWO, c)
	if err != nil {
		c.JSON(nil, err)
		return
	}

	uploadSftp :=[]string{newFileOne,newFileTwo}
	//sftp上传图片
	err=sftp.NewUploadListSftpFile(svc.Kftp,sftp.REMOTE_SFTP_IMAGE,uploadSftp)
	if err!=nil {
		c.JSON(nil, err)
	}else {
		//删除本地的图片，只保留sftp图片
		for _, value := range uploadSftp {
			os.Remove(value)
		}
	}

	//关联用户详细信息
	userCommon := &account_service.UserCommon{}
	userCommon.IdNo = p.IdNo
	userCommon.Sex = p.Sex
	userCommon.Age = p.Age
	userCommon.CradIdFristImg = newFileOne
	userCommon.CradIdSecodeImg = newFileTwo
	userCommon.UserRealName = p.UserRealName
	userCommon.CradId = p.CradId
	reply, err := svc.UpdateUserCommon(c, userCommon)
	if err != nil {
		c.JSON(nil, err)
		return
	}
	c.JSON(reply, err)
}

//获取上传的文件
func getUploadFile(key string, c *blademaster.Context) (string, error) {

	//获取key获取文件名称
	file, handler, err := c.Request.FormFile(key)
	defer file.Close()
	if err != nil {
		return "", err
	}
	//创建文件
	newFile, err := os.Create(handler.Filename)
	defer newFile.Close()
	if err != nil {
		return "", err
	}

	//将获取到的文件到村到本地
	_, err = io.Copy(newFile, file)
	if err != nil {
		return "", err
	}

	//获取文件名后追
	fileExt:= path.Ext(handler.Filename)
	//修改文件名
	newFileName := uuid.Must(uuid.NewV4())
	newFileNameFormat:=fmt.Sprintf("%s%s",newFileName.String(),fileExt)
	os.Rename(handler.Filename,newFileNameFormat)

	return newFileNameFormat, nil
}

/**
检查用过户登录
 */
func checkLogin(c *blademaster.Context) {

	loginKey:=c.Request.Header.Get("x-seesion-token")
	if loginKey ==""{
		c.JSON(nil,ecode.NoLogin)
		c.Abort()
		return
	}
	//组合redis 的key，获取redis的登录token数据
	redisKey:=svc.GetLoginToRedisKey(c,loginKey)
	reply,err:=svc.CheckRedisIsLoginString(c.Context,redisKey)
	if err!=nil||reply==nil {
		c.JSON(nil,ecode.NoLogin)
		c.Abort()
		return
	}


}

