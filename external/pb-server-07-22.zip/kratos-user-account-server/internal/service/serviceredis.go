package service

import (
	"context"
)

/**
查询数据
 */
func (s *Service)FindRedisString(ctx context.Context, key string) (reply []byte,err error){

	reply,err=s.dao.FindRedisString(ctx,key)
	return
}


//添加数据
func(s *Service)AddRedisAndExrString(ctx context.Context, key ,value string,exr int64) (err error) {
	 err=s.dao.AddRedisAndExrString(ctx,key,value,exr)
	return
}

//检查是否登录
func (s *Service)CheckRedisIsLoginString(ctx context.Context, key string) (reply []byte,err error){
	reply,err=s.dao.CheckRedisIsLoginString(ctx,key)
	return

}


/**
删除数据
 */
func (s *Service)DelRedisString(ctx context.Context, key string) (err error){
	err=s.dao.DelRedisString(ctx,key)
	return
}

/**
用户login的key
 */
func (s *Service)GetLoginToRedisKey(ctx context.Context, token string) (loginKey string){
	loginKey=s.dao.GetLoginToRedisKey(ctx,token)
	return
}

