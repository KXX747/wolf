#!/usr/bin/env bash

echo "启动中"

#生成proto
cd $GOPATH/kratos-user-account-server
cd internal/model/user
./pd-st.sh
echo "proto 完成"


#启动服务
cd ../../../cmd
go build -o cmd main.go
#启动服务 修改pref的端口
./cmd -conf /Users/a747/go/src/kratos-user-account-server/configs/ -http.perf=tcp://0.0.0.0:38887
