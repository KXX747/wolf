package http

import (
	"github.com/bilibili/kratos/pkg/ecode"
	"github.com/bilibili/kratos/pkg/net/http/blademaster"
	"io"
	"os"
	"user-account-server/internal/model"
	"user-account-server/internal/model/user"
)

// example for http request handler.
func howToStart(c *blademaster.Context) {
	k := &model.Kratos{
		Hello: "Golang 大法好 !!!",
	}

	c.JSON(k, nil)

}

//上传信息照片
func updatecard(c *blademaster.Context) {
	p := new(model.ParamUpload)
	if err := c.Bind(p); err != nil {
		c.JSON(nil, ecode.ReqParamErr)
		return
	}
	c.Request.ParseMultipartForm(32 << 10)
	filefrist, handlerfrist, err := c.Request.FormFile("crad_id_frist_img")
	filesecond, handlersecond, err := c.Request.FormFile("crad_id_secode_img")
	if err != nil {
		c.JSON(nil, err)
		return
	}
	defer filefrist.Close()
	defer filesecond.Close()

	outfrist, err := os.Create(handlerfrist.Filename)
	outseconde, err := os.Create(handlersecond.Filename)
	if err != nil {
		c.JSON(nil, err)
		return
	}

	defer outfrist.Close()
	defer outseconde.Close()

	_, err = io.Copy(outfrist, filefrist)
	_, err = io.Copy(outseconde, filesecond)
	if err != nil {
		c.JSON(nil, err)
		return
	}

	//关联用户详细信息
	userCommon := &account_service.UserCommon{}
	userCommon.IdNo = p.IdNo
	userCommon.Sex = p.Sex
	userCommon.Age = p.Age
	userCommon.CradIdFristImg = outfrist.Name()
	userCommon.CradIdSecodeImg = outseconde.Name()
	userCommon.UserRealName = p.UserRealName
	userCommon.CradId = p.CradId

	reply, err := svc.UpdateUserCommon(c.Context, userCommon)
	if err != nil {
		c.JSON(nil, err)
		return
	}

	respJson, _ := reply.Marshal()
	c.JSON(string(respJson), err)
	c.JSON(p, nil)

}
