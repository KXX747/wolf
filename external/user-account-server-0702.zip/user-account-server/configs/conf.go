package configs

import (
	xtime "github.com/bilibili/kratos/pkg/time"

)



// FTP FTP.
type FtpConfigs struct {
	Addr       string
	User       string
	Password   string
	RemotePath map[string]string
	Timeout    xtime.Duration
	LocalPath  map[string]string
}

