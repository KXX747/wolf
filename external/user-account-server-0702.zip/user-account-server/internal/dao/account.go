package dao

import (
	"fmt"
	"context"
	"github.com/satori/go.uuid"
	"time"
	"encoding/json"
	"user-account-server/internal/model/user"
	"errors"
	xsql "github.com/bilibili/kratos/pkg/database/sql"
	"database/sql"
	"github.com/bilibili/kratos/pkg/ecode"
)

const (
	//标记用户渠道来源
	CREATBYSYSTEM ="system"
	LOCALIP       ="127.0.0.1"
	CREATEADDRESS ="CHINA"

	/**
		_userAchieveSQL        = "select id,aid,sid,mid,award from act_like_user_achievements where id = ?"
	_userAchieveUpSQL      = "update act_like_user_achievements set award = ? where id = ? and  award = 0"
	_userAchievementAddSQL = "insert into act_like_user_achievements (`aid`,`mid`,`sid`,`award`) values(?,?,?,?)"
	_userAchievementSQL    = "select id,aid,sid,mid,award from act_like_user_achievements where sid = ? and mid = ? and del = 0"
	 */

	_userNewAddSQL="INSERT into user(id,name,id_no,mobile,address,create_at,create_ip,create_by)  VALUES(0,?,?,?,?,?,?,?);"
	_userAchieveSQL="select id,name,id_no,mobile,address,create_at,create_ip,create_by from user where id_no=? limit 1"
	_userAchieveSELECTMOBILESQL="select id,name,id_no,mobile,address,create_at,create_ip,create_by from user where mobile=? or name=? limit 1"

	//%s
	_userAchievenUpdateSQL="update user set mobile=?,address=? where id_no=?"
	_userAchievenDeleteSQL="delete from user where id_no=?"

	_userCommonAchievenUpDateSQL="update user_common set mobile=?,address=? where id_no=?"
	_userCommonAchievenUpCARDIDDateSQL="update user_common set user_real_name=?,crad_id=?,crad_id_frist_img=?,crad_id_secode_img=?,age=?,sex=? where id_no=?"
	_userCommonAchievenSelectIdNoSQL="select id,id_no,name,user_real_name,crad_id,crad_id_frist_img,crad_id_secode_img,age,sex,mobile,address,parent_id from user_common where id_no=? limit 1"
	_userCommonAchievenSelectMobileSQL="select id,id_no,name,user_real_name,crad_id,crad_id_frist_img,crad_id_secode_img,age,sex,mobile,address,parent_id from user_common where mobile=? limit 1"
	_userCommonAchievenSelectCradIdSQL="select id,id_no,name,user_real_name,crad_id,crad_id_frist_img,crad_id_secode_img,age,sex,mobile,address,parent_id from user_common where crad_id=? and user_real_name=? limit 1"
	//_userCommonAchievenInsertSQL="INSERT into user_common(id,id_no,name,user_real_name,crad_id,crad_id_frist_img,crad_id_secode_img,age,sex,mobile,address,parent_id) VALUES(0,?,?,?,?,?,?,?,?,?,?,?);"
	_userCommonAchievenInsertSQL="INSERT into user_common(id,name,id_no,mobile,address,parent_id) VALUES(0,?,?,?,?,?);"


	//用户详细信息查询条件
	SLTIDNO   ="1"
	SLTMOBILE ="2"
	SLTCARDID ="3"
)




//dao层
func (d *dao) AddUserDao(ctx context.Context,name string ,mobile string)(reply *account_service.UserReply,err error){

	//检查用户是否已经注册
	_,err=d.FindUserIsExistDao(ctx,name,mobile)
	if err!=nil {
		return
	}

	//用户不存在添加用户
	reply =&account_service.UserReply{}
	idNo := uuid.Must(uuid.NewV4())
	reply.IdNo = idNo.String()
	reply.Name =name
	reply.Mobile = mobile
	reply.CreateAt = time.Now().String()
	reply.CreatBy = CREATBYSYSTEM
	reply.CreateIp = LOCALIP
	reply.Address= CREATEADDRESS

	var result sql.Result;
	result ,err=d.db.Exec(ctx,_userNewAddSQL,reply.Name,reply.IdNo,reply.Mobile,reply.Address,reply.CreateAt,reply.CreateIp,reply.CreatBy)
	if err!=nil {
		err = errors.New(err.Error()+"  d.db.Exec("+_userNewAddSQL+")")
		return
	}

	//获取id保存到user_common表的parent_id
	lastInsertId,_:=result.LastInsertId()

	//数据保存到实名认证中
	userCommon:=&account_service.UserCommon{}
	userCommon.IdNo =reply.IdNo
	userCommon.Mobile = reply.Mobile
	userCommon.Name = reply.Name
	userCommon.ParentId =lastInsertId
	userCommon.Address = reply.Address
	if _ ,err=d.InsertUserCommonDao(ctx,userCommon);err!=nil {
		err = errors.New(err.Error()+"  InsertUserCommonDao  d.db.Exec("+_userCommonAchievenInsertSQL+")")
		return
	}
	//保存到redis
	err=d.saveUserToRedis(ctx,reply,err,0)
	//
	return
}

//删除用户
func(d *dao)DeleteUserDao(ctx context.Context, idNo string,content string) (reply *account_service.UserReply,err error) {
	var result sql.Result;
	result,err=d.db.Exec(ctx,_userAchievenDeleteSQL, idNo)
	if err!=nil {
		err = errors.New(err.Error()+"   d.db.Exec("+_userAchievenDeleteSQL+")" +" id_no="+ idNo)
		return
	}
	result.RowsAffected()
	//删除redis数据
	err=d.del(ctx,d.getUserSaveToRedisKey(idNo))

	return
}


//update user dao层
func(d *dao) UpdateUserDao(ctx context.Context, idNo,mobile,address string) (reply *account_service.UserReply,err error) {

	fmt.Println("<><>UpdateUserDao<><> ", idNo,mobile,address)
	var result sql.Result;
	result,err=d.db.Exec(ctx,_userAchievenUpdateSQL,mobile,address, idNo)
	if err!=nil {
		err = errors.New(err.Error()+"   d.db.Exec("+_userAchievenUpdateSQL+")")
		return
	}
	result.RowsAffected()

	//修改user表保存到redis的数据
	//删除redis数据
	err = d.del(ctx,d.getUserCommonSaveToRedisKey(idNo))
	if err!=nil {
		err=errors.New(err.Error() +" d.del("+ idNo +")")
		return
	}
	//将查询到的重新添加到redis
	reply,err=d.FindUserDao(ctx, idNo)
	if err!=nil {
		err=errors.New(err.Error() +" d.db.redis("+ idNo +")")
		return
	}
	//修改user_common表和redis的数据
	mUserCommon:=&account_service.UserCommon{}
	mUserCommon.IdNo= idNo
	mUserCommon.Address =address
	//mUserCommon.Name =name
	mUserCommon.Mobile =mobile
	_,err=d.UpdateUserCommonDao(ctx,mUserCommon);
	if err!=nil {
		return
	}
	return
}


func (d *dao) FindUserDao(ctx context.Context, idNo string)(reply *account_service.UserReply,err error){

	//查询redis中是否存在数据
	v,err:=d.FindRedis(ctx,d.getUserSaveToRedisKey(idNo))
	if err!=nil || v ==""{
		//redis不存在 select id,name,id_no,mobile,address,create_at,create_ip,create_by
		reply =&account_service.UserReply{}
		rows :=d.db.QueryRow(ctx,_userAchieveSQL, idNo)
		err =rows.Scan(&reply.Id,&reply.Name,&reply.IdNo,&reply.Mobile,&reply.Address,&reply.CreateAt,&reply.CreateIp,&reply.CreatBy)
		if err!=nil {
			if err == xsql.ErrNoRows {
				//未查询到数据，数据不存在redis写入空数据设置过期时间
				reply.IdNo = idNo
				err=d.saveUserToRedis(ctx,reply,err,10)
			} else{
				err = errors.New(err.Error() +"FindUserDao()  d.db.QueryRow( "+_userAchieveSQL+" )"+"id_no = "+ idNo)
			}
		}else {
			//查询成功，返回数据并将数据写入redis
			err=d.saveUserToRedis(ctx,reply,err,0)
		}
		return
	}
	//解析保存的数据
	err = json.Unmarshal([]byte(v), reply)
	return
}

/**
检查用户是否存在
  实现了查询数据库
 */
func (d *dao) FindUserIsExistDao(ctx context.Context,name string ,mobile string )(reply *account_service.UserReply,err error){
	reply =&account_service.UserReply{}
	rows :=d.db.QueryRow(ctx,_userAchieveSELECTMOBILESQL,mobile,name)
	err=rows.Scan(&reply.Id,&reply.Name,&reply.IdNo,&reply.Mobile,&reply.Address,&reply.CreateAt,&reply.CreateIp,&reply.CreateIp)

	//检查用户信息存在抛出异常
	if reply.IdNo !="" {
		//用户存在
		err=ecode.UserDuplicate
		return
	}else if err == xsql.ErrNoRows {
		err =nil
	}

	return
}

//查询用户 for id_no
func(d *dao) FindUserListDao(ctx context.Context, idNo []string)(reply *account_service.UserListReply,err error) {

	reply =&account_service.UserListReply{}
	//遍历数据
	for i:=0;i<len(idNo);i++ {
		var mUserReply *account_service.UserReply
		mUserReply,err =d.FindUserDao(ctx, idNo[i])
		if err!=nil {
			err = errors.New(err.Error()+" FindUserListDao  ("+ idNo[i]+")")
			return
		}
		reply.UserListReply = append(reply.UserListReply,mUserReply)
	}
	return
}



//创建用户时需要添加添加用户详细信息
func(d *dao)InsertUserCommonDao(ctx context.Context, in *account_service.UserCommon) (*account_service.UserCommon, error) {

	var result sql.Result;
	result,err:=d.db.Exec(ctx,_userCommonAchievenInsertSQL,in.Name,in.IdNo,in.Mobile,in.Address,in.ParentId)
	if err !=nil{
		err = errors.New(err.Error()+"  d.db.Exec("+_userCommonAchievenInsertSQL+")")
		return nil,err
	}
	result.LastInsertId()
	//存储到redis
	redisKey:=d.getUserCommonSaveToRedisKey(in.IdNo)
	err=d.saveUserCommonToRedis(ctx,in,err,redisKey,0)
	if err !=nil{
		err = errors.New(err.Error()+"  d.redis save  ("+redisKey+") = ")
		return nil,err
	}
	return in,nil
}


//修改用户详细信息 user表修改了user_common表也修改
func(d *dao)UpdateUserCommonDao(ctx context.Context, in *account_service.UserCommon) (reply *account_service.UserCommon,err error) {

	var result sql.Result;
	//name=?,user_real_name=?,crad_id=?,crad_id_frist_img=?,crad_id_secode_img=?,age=?,sex=?,mobile=?,address=? where id_no=?
	result ,err=d.db.Exec(ctx,_userCommonAchievenUpDateSQL,in.Mobile,in.Address,in.IdNo)
	if err!=nil {
		err = errors.New(err.Error()+"   d.db.Exec("+_userCommonAchievenUpDateSQL+")" +" id_no="+in.IdNo)
		return
	}
	result.RowsAffected()

	//删除redis数据
	err = d.del(ctx,d.getUserCommonSaveToRedisKey(in.IdNo))
	if err!=nil {
		err = errors.New(err.Error()+"d.del("+in.IdNo+")")
		return
	}
	//重新拉取数据到redis
	_,err=d.FindIdNoUserCommonDao(ctx,in.IdNo)
	if err!=nil {
		err = errors.New(err.Error()+"d.find("+in.IdNo+")")
		return
	}
	return
}

/**
	查询用户详细数据
 */
func(d *dao)FindIdNoUserCommonDao(ctx context.Context, idNo string) (reply *account_service.UserCommon,err error) {

	mUserCommonReq:=&account_service.UserCommonReq{}
	mUserCommonReq.IdNo = idNo
	mUserCommonReq.Querytype = SLTIDNO
	reply,err=d.FindUserCommonDao(ctx,mUserCommonReq)
	return
}


//查询用户详细信息
func(d *dao)FindUserCommonDao(ctx context.Context, in *account_service.UserCommonReq) (reply *account_service.UserCommon,err error) {

	reply =&account_service.UserCommon{}
	//默认采用第一种
	if ""==in.Querytype || SLTIDNO == in.Querytype {
		//用户id查询
		//id,id_no,name,user_real_name,crad_id,crad_id_frist_img,crad_id_secode_img,age,sex,mobile,address
		errs :=d.db.QueryRow(ctx,_userCommonAchievenSelectIdNoSQL,in.IdNo).Scan(&reply.Id,&reply.IdNo,&reply.Name,&reply.UserRealName,&reply.CradId,&reply.CradIdFristImg,&reply.CradIdSecodeImg,&reply.Age,&reply.Sex,&reply.Mobile,&reply.Address,&reply.ParentId)
		redisKeyIdNo :=d.getUserCommonSaveToRedisKey(in.IdNo)
		if errs!=nil {
			if errs ==xsql.ErrNoRows {
				//未查询到数据，会报错，需要捕获数据
				err=d.saveUserCommonToRedis(ctx,reply,err, redisKeyIdNo,10)
				return
			}else if errs!=nil&&errs !=xsql.ErrNoRows {
				//抛出错误
				err =errs
			}
		}else {
			//正常获取到数据
			err=d.saveUserCommonToRedis(ctx,reply,err, redisKeyIdNo,0)
		}

	}else if SLTMOBILE == in.Querytype {
		//手机号查询
		errs :=d.db.QueryRow(ctx,_userCommonAchievenSelectMobileSQL,in.Mobile).Scan(reply.Id,reply.IdNo,reply.Name,reply.UserRealName,reply.CradId,reply.CradIdFristImg,reply.CradIdSecodeImg,reply.Age,reply.Sex,reply.Mobile,reply.Address,reply.ParentId)
		redisKeyMobile :=fmt.Sprintf(_REDIS_USERCOMMON_DATA_MOBILE,reply.Mobile)
		if errs!=nil {
			if errs ==xsql.ErrNoRows {
				//未查询到数据
				err=d.saveUserCommonToRedis(ctx,reply,err, redisKeyMobile,10)
				return
			}else if errs!=nil&&errs !=xsql.ErrNoRows {
				//抛出错误
				err =errs
			}
		}else {
			err=d.saveUserCommonToRedis(ctx,reply,err, redisKeyMobile,0)
		}

	}else if SLTCARDID == in.Querytype  {
		//证件查询
		errs :=d.db.QueryRow(ctx,_userCommonAchievenSelectCradIdSQL,in.IdNo,in.UserRealName).Scan(reply.Id,reply.IdNo,reply.Name,reply.UserRealName,reply.CradId,reply.CradIdFristImg,reply.CradIdSecodeImg,reply.Age,reply.Sex,reply.Mobile,reply.Address,reply.ParentId)
		redisKeyCradid :=fmt.Sprintf(_REDIS_USERCOMMON_DATA_CRADID,reply.CradId)
		if errs!=nil {
			if err ==xsql.ErrNoRows {
				//未查询到数据
				err=d.saveUserCommonToRedis(ctx,reply,err, redisKeyCradid,10)
				return
			}else if errs!=nil&&errs !=xsql.ErrNoRows {
				//抛出错误
				err =errs
			}
		} else {
			err=d.saveUserCommonToRedis(ctx,reply,err, redisKeyCradid,0)
		}
	}

	return
}


/**
	实名认证用户详情信息
 */
func(d *dao)VerifiedIdNoUser(ctx context.Context, in *account_service.UserCommon) (reply *account_service.UserCommon,err error) {

	var result sql.Result;
	//user_real_name=?,crad_id=?,crad_id_frist_img=?,crad_id_secode_img=?,age=?,sex=?
	result ,err=d.db.Exec(ctx,_userCommonAchievenUpCARDIDDateSQL,in.UserRealName,in.CradId,in.CradIdFristImg,in.CradIdSecodeImg,in.Age,in.Sex,in.IdNo)
	if err!=nil {
		err = errors.New(err.Error()+"   d.db.Exec("+_userCommonAchievenUpCARDIDDateSQL+")" +" id_no="+in.IdNo)
		return
	}
	result.RowsAffected()

	//删除redis数据
	err = d.del(ctx,d.getUserCommonSaveToRedisKey(in.IdNo))
	if err!=nil {
		err = errors.New(err.Error()+"d.del("+in.IdNo+")")
		return
	}
	//重新拉取数据到redis
	reply,err=d.FindIdNoUserCommonDao(ctx,in.IdNo)
	if err!=nil {
		err = errors.New(err.Error()+"d.find("+in.IdNo+")")
		return
	}

	return
}


