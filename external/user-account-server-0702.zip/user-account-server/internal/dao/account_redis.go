package dao

import	(
	"user-account-server/internal/model/user"
	"context"
	"github.com/bilibili/kratos/pkg/log"
	"encoding/json"
	"fmt"

)

const (
	//redis存储用户信息
	_REDIS_USER_DATA = "account:user:%s"
	_REDIS_USERCOMMON_DATA_IDNO = "account:uc:idno:%s"
	_REDIS_USERCOMMON_DATA_MOBILE = "account:uc:mobile:%s"
	_REDIS_USERCOMMON_DATA_CRADID = "account:uc:creaid:%s"
)

//用户数据保存到redis
//isExr 是否设置过期时间 >0 设置时间
func(d *dao)saveUserToRedis(ctx context.Context,reply *account_service.UserReply,err error,isExr int64)(e error) {
	redisValue,err := json.Marshal(reply)
	redisKey:=d.getUserSaveToRedisKey(reply.IdNo)
	if isExr>0 {
		e = d.AddRedisAndExr(ctx, redisKey, string(redisValue),isExr)
	}else {
		e = d.AddRedis(ctx, redisKey, string(redisValue))
	}
	return
}


//用户认证数据保存到redis
//isExr 是否设置过期时间 >0 设置时间
func(d *dao)saveUserCommonToRedis(ctx context.Context,reply *account_service.UserCommon,err error,redisKey string,isExr int64)(e error) {
	redisValue,err := json.Marshal(reply)
	if isExr>0 {
		e = d.AddRedisAndExr(ctx, redisKey, string(redisValue),isExr)
	}else {
		e = d.AddRedis(ctx, redisKey, string(redisValue))
	}

	return
}


//redis string del key
func(d *dao)del(ctx context.Context,delkey string)(e error) {

	conn :=d.redis.Get(ctx)
	defer conn.Close()
	if _,err:=conn.Do("DEL",delkey);err!=nil {
		log.Error("conn.DEL(PING) error(%v)", err)
	}
	return
}

//redis string set  exr
func (d *dao) AddRedisAndExr(ctx context.Context, key string,value string,exr int64) (err error) {
	conn := d.redis.Get(ctx)
	defer conn.Close()

	if _, err = conn.Do("SET", key, value,"EX",exr); err != nil {
		log.Error("conn.Set(PING) error(%v)", err)
	}
	return
}

//redis string set
func (d *dao) AddRedis(ctx context.Context, key string,value string) (err error) {
	conn := d.redis.Get(ctx)
	defer conn.Close()

	if _, err = conn.Do("SET", key, value); err != nil {
		log.Error("conn.Set(PING) error(%v)", err)
	}
	return
}


//redis string get
func (d *dao) FindRedis(ctx context.Context, key string) (reply string,err error) {
	conn := d.redis.Get(ctx)
	defer conn.Close()
	if reply, err := conn.Do("GET", key); err != nil {
		log.Error("redis: conn.Do(GET, %s) error(%v)", key, err)
	} else {
		log.Error("redis: get value: %s", reply)
	}
	return
}

/**
 用户表存储到rediskey
 */
func(d *dao)getUserSaveToRedisKey(id_no string)(rediskey string){
	rediskey =fmt.Sprintf(_REDIS_USER_DATA,id_no)
	return rediskey
}

/**
 用户认证表存储到rediskey
 */
func(d *dao)getUserCommonSaveToRedisKey(id_no string)(rediskey string){
	rediskey =fmt.Sprintf(_REDIS_USERCOMMON_DATA_IDNO,id_no)
	return rediskey
}
