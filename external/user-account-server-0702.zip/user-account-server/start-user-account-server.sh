#!/usr/bin/env bash

echo "启动中"

#生成proto
cd $GOPATH/user-account-server
cd internal/model/user
./pd-st.sh
echo "proto 完成"


#启动服务
cd ../../../cmd
go build
#启动服务 修改pref的端口
./cmd -conf ../configs/ -http.perf=tcp://0.0.0.0:38887
