# CentOS 调优（内核参数）

系统默认参数一般都是比较保守的，我们可以通过调整系统参数来提高系统内存、CPU、内核资源的占用，通过禁用不必要的服务、端口，来提高系统的安全性，更好的发挥系统的可用性。

yum 常用源
常用 yum 源整理；

sshd 优化
ssh 密钥登录、ssh 安全加固；

文件描述符
ulimit 资源限制

### 用户限制
--- /etc/security/limits.conf ---
root soft nofile 102400
root hard nofile 102400

### 内核限制
--- /etc/sysctl.conf ---
fs.file-max = 10240000

sysctl -p   # 立即生效

### 重新登录 shell
ulimit -n                   # 查看当前shell的最大文件描述符数
sysctl -a | grep file-max   # 查看当前内核的最大文件描述符数
cat /proc/sys/fs/file-nr    # 分别表示：已分配的句柄数、已分配未使用的句柄数、file-max 值
BashCopy
关闭三键重启
仅针对 CentOS 6.x

--- /etc/init/control-alt-delete.conf ---
#exec /sbin/shutdown -r now "Control-Alt-Deletepressed"
BashCopy
隐藏系统信息
echo "Welcome to Server" > /etc/issue
echo "Welcome to Server" > /etc/centos-release
BashCopy
命令历史记录
--- /etc/profile ---
export HISTSIZE=10000
export HISTCONTROL=ignoredups   # 忽略重复记录
BashCopy
ntp 时间同步
ntp 时间同步（CentOS 6.x）、chrony 时间同步（CentOS 7.x）

## 常用公共ntp服务器
time.windows.com
cn.pool.ntp.org
tw.pool.ntp.org

## 手动更新时间
yum -y install ntp

ntpdate -u time.windows.com

## 设置时区为上海:
CentOS 6.x：ln -sf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
CentOS 7.x：timedatectl set-timezone Asia/Shanghai
BashCopy
内核参数优化
### VPS 服务器配置（1G 内存）
--- /etc/sysctl.conf ---
fs.nr_open = 10000000
fs.file-max = 500000000
net.ipv4.ip_forward = 1
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_tw_reuse = 0
net.ipv4.tcp_fin_timeout = 15
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.tcp_max_tw_buckets = 5000
net.ipv4.tcp_max_syn_backlog = 10240
net.core.netdev_max_backlog = 10240
net.core.somaxconn = 10240
net.ipv4.tcp_retries1 = 1
net.ipv4.tcp_retries2 = 3
net.ipv4.tcp_syn_retries = 2
net.ipv4.tcp_synack_retries = 2
net.ipv4.tcp_max_orphans = 3276800
net.ipv4.tcp_keepalive_time = 30
net.ipv4.tcp_keepalive_intvl = 2
net.ipv4.tcp_keepalive_probes = 3
net.core.rmem_default = 8388608
net.core.wmem_default = 8388608
net.core.rmem_max = 16777216
net.core.wmem_max = 16777216
net.core.optmem_max = 204800
net.ipv4.tcp_mem = 177945 216076 254208
net.ipv4.tcp_rmem = 65536 1048576 8388608
net.ipv4.tcp_wmem = 65536 1048576 8388608
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_no_metrics_save = 0
net.ipv4.tcp_slow_start_after_idle = 0

### 内核参数解释
fs.nr_open = 10000000                       # 单个进程允许的最大 fd 数量. 
fs.file-max = 500000000                     # linux 内核允许的最大 fd 数量
net.ipv4.ip_forward = 1                     # 允许网卡之间的数据包转发
net.ipv4.tcp_syncookies = 1                 # 启用syncookies, 可防范少量syn攻击
net.ipv4.tcp_tw_reuse = 0                   # 重用time_wait的tcp端口(建议禁用)
net.ipv4.tcp_fin_timeout = 15               # fin_wait_2超时时间
net.ipv4.ip_local_port_range = 1024 65535   # 动态分配端口的范围
net.ipv4.tcp_max_tw_buckets = 5000          # time_wait套接字最大数量，高于该值系统会立即清理并打印警告信息
net.ipv4.tcp_max_syn_backlog = 10240        # syn队列长度
net.core.netdev_max_backlog = 10240         # 最大设备队列长度
net.core.somaxconn = 10240                  # listen()的默认参数, 等待请求的最大数量
net.ipv4.tcp_retries1 = 1                   # tcp 连接丢包重传次数，达到此值将刷新路由缓存
net.ipv4.tcp_retries2 = 3                   # tcp 连接丢包重传次数，达到此值将断开 TCP 连接
net.ipv4.tcp_syn_retries = 2                # 放弃建立连接前内核发送syn包的数量
net.ipv4.tcp_synack_retries = 2             # 放弃连接前内核发送syn+ack包的数量
net.ipv4.tcp_max_orphans = 3276800          # 设定最多有多少个套接字不被关联到任何一个用户文件句柄上
net.ipv4.tcp_keepalive_time = 30            # keepalive idle空闲时间
net.ipv4.tcp_keepalive_intvl = 2            # keepalive intvl间隔时间
net.ipv4.tcp_keepalive_probes = 3           # keepalive probes最大探测次数
net.core.rmem_default = 8388608             # socket默认读buffer大小
net.core.wmem_default = 8388608             # socket默认写buffer大小
net.core.rmem_max = 16777216                # socket最大读buffer大小
net.core.wmem_max = 16777216                # socket最大写buffer大小
net.ipv4.tcp_rmem = 65536 1048576 8388608   # tcp_socket读buffer大小
net.ipv4.tcp_wmem = 65536 1048576 8388608   # tcp_socket写buffer大小
net.ipv4.tcp_mem = 177945 216076 254208     # 确定tcp栈应该如何反映内存使用
net.ipv4.tcp_fastopen = 3                   # 开启tcp_fastopen（内核 3.7 +）
net.ipv4.tcp_no_metrics_save = 0            # 在路由中缓存 TCP 连接的各项指标
net.ipv4.tcp_slow_start_after_idle = 0      # 在连接空闲期间保持拥塞窗口的大小

## net/ipv4/tcp_mem 解释
net.ipv4.tcp_mem = 94500000 915000000 927000000
net.ipv4.tcp_mem[0]: 低于此值，TCP 没有内存压力     # 80% of Memory
net.ipv4.tcp_mem[1]: 在此值下，进入内存压力阶段     # 90% of Memory
net.ipv4.tcp_mem[2]: 高于此值，TCP 拒绝分配socket   # 100% of Memory
# 内存单位是页（1页=4kb），可根据物理内存大小进行调整，如果内存足够大的话，可适当往上调
BashCopy
虚拟机问题
如果你的 Linux 安装在 VMware、VirtualBox 虚拟机上，那么每次开机的时候都会出现这个错误信息：
piix4_smbus 0000:00:007.3: Host SMBus controller not enabled，是不是很烦？关键我强迫症，忍不了！
但是，系统启动运行后，并没有任何问题，所有功能都正常，于是我开始 Google，发现原来不止我一个强迫症！

解决办法
将i2c_piix4模块加入黑名单即可，编辑/etc/modprobe.d/blacklist.conf黑名单文件，添加blacklist i2c_piix4。