# Istio微服务控制


使用Go语言操作Istio和其他Kubernetes CRD
http://www.servicemesher.com/blog/manipulating-istio-and-other-custom-kubernetes-resources-in-golang/