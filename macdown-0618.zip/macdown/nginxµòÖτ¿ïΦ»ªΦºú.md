# 一，安装启动

	
	 mac安装 brew install nginx 
	 docker安装  docker pull nginx
	 
	 启动： nginx -c /usr/local/etc/nginx/nginx.conf
	 重启： nginx -s reload
	 启动: nginx -s start;
	 
	 重新启动，热启动，修改配置重启不影响线上  nginx -s reload;
	 关闭  nginx -s stop;
	 修改配置后，可以通过下面的命令测试是否有语法错误  nginx -t;
 
 
#  二，nginx信号量
信号量控制nginx服务器的启动停止和重启的： 
	
	格式：kill int（信号控制）进程号
	
	
信号控制参数：
	 
	     HUP：配置重新
        QUIT：等待所有的请求完成再关闭
        INT/TERM：从容关闭

        USER1：切换日志文件
            -- kill -USER1 进程号

        USER2：平滑升级可执行进程
            -- kill -USER2 进程号
        WINCH：从容关闭工作进程
            -- kill -WINCH 主进程号

Nginx 平滑升级：

		低版本————>高版本
        强制升级 ，原来的进程关闭，会影响服务提供
        不会停止原来的进程，原来的请求不会关闭，不接受新的的请求。

        老进程：处理原来请求，不接受新请求。
        新进程：接收新的请求


平滑升级实战：
		
		1 查看版本
		./nginx -V #查看nginx的版本
		注意：记录configure arguments: 信息
		
		2备份老版本，替换新版本
		进入之前安装nginx可执行文件目录，进行备份。使用cp命令
		cp nginx nginx.old
		
		3下载高版本，上传解压
		下载更高的版本，上传解压（解压命令 tar -zxvf nginx-x-x.tar.gz）
		./configure
		make 
		注意 ： 解压到之前安装的目标下，不需要输入make install ,因为我们这里是升级。
		
		4 发送指令
		（1）Kill -USR2 旧版本的Nginx主进程号
		执行完之后，这时候在查看进程，会发现多了一个nginx新的主进程！
		（2）执行kill -WINCH 旧版本的Nginx主进程号 
		发现旧版本worker process进程没有了
		（3）执行 kill -QUIT 旧版本的Nginx主进程号 ，平滑升级成功。
		老的nginx 主进程已经不存在。
		
		5最后处理
		  平滑升级完成！删除刚才上传和解压的文件。

# 三，nginx虚拟主机配置
	
		mac 查看nginx的文件配置路径
		cd /usr/local/Cellar/nginx/1.15.10/share/nginx/src
		cat configure_args.txt
		
		--prefix=/usr/local/Cellar/nginx/1.15.10
		--sbin-path=/usr/local/Cellar/nginx/1.15.10/bin/nginx
		--with-cc-opt=-I/usr/local/opt/pcre/include -I/usr/local/opt/openssl/include
		--with-ld-opt=-L/usr/local/opt/pcre/lib -L/usr/local/opt/openssl/lib
		--conf-path=/usr/local/etc/nginx/nginx.conf
		--pid-path=/usr/local/var/run/nginx.pid
		--lock-path=/usr/local/var/run/nginx.lock
		--http-client-body-temp-path=/usr/local/var/run/nginx/client_body_temp
		--http-proxy-temp-path=/usr/local/var/run/nginx/proxy_temp
		--http-fastcgi-temp-path=/usr/local/var/run/nginx/fastcgi_temp
		--http-uwsgi-temp-path=/usr/local/var/run/nginx/uwsgi_temp
		--http-scgi-temp-path=/usr/local/var/run/nginx/scgi_temp
		--http-log-path=/usr/local/var/log/nginx/access.log
		--error-log-path=/usr/local/var/log/nginx/error.log
		--with-debug
		--with-http_addition_module
		--with-http_auth_request_module
		--with-http_dav_module
		--with-http_degradation_module
		--with-http_flv_module
		--with-http_gunzip_module
		--with-http_gzip_static_module
		--with-http_mp4_module
		--with-http_random_index_module
		--with-http_realip_module
		--with-http_secure_link_module
		--with-http_slice_module
		--with-http_ssl_module
		--with-http_stub_status_module
		--with-http_sub_module
		--with-http_v2_module
		--with-ipv6
		--with-mail
		--with-mail_ssl_module
		--with-pcre
		--with-pcre-jit
		--with-stream
		--with-stream_realip_module
		--with-stream_ssl_module
		--with-stream_ssl_preread_module
		 
		 
####  nginx.conf配置分析，大致分为以下几个部分
		
		main                                # 全局配置
		events {                            # nginx工作模式配置
		}
		
		http {                                # http设置
		    ....
		
		    server {                        # 服务器主机配置
		        ....
		        location {                    # 路由配置
		            ....
		        }
		
		        location path {
		            ....
		        }
		
		        location otherpath {
		            ....
		        }
		    }
		
		    server {
		        ....
		        location {
		            ....
		        }
		    }
		
		    upstream name {                    # 负载均衡配置
		        ....
		    }
	}

	
如上述配置文件所示，主要由6个部分组成：

	main：用于进行nginx全局信息的配置
	events：用于nginx工作模式的配置
	http：用于进行http协议信息的一些配置
	server：用于进行服务器访问信息的配置
	location：用于进行访问路由的配置
	upstream：用于进行负载均衡的配置
 		
 		
##### main模块

		观察下面的配置代码
		
		user nobody nobody;
		worker_processes 2;
		error_log logs/error.log
		error_log logs/error.log notice
		error_log logs/error.log info
		pid logs/nginx.pid
		worker_rlimit_nofile 1024;

		上述配置都是存放在main全局配置模块中的配置项
		
		user用来指定nginx worker进程运行用户以及用户组，默认nobody账号运行
		worker_processes指定nginx要开启的子进程数量，运行过程中监控每个进程消耗内存(一般几M~几十M不等)根据实际情况进行调整，通常数量是CPU内核数量的整数倍
		error_log定义错误日志文件的位置及输出级别【debug / info / notice / warn / error / crit】
		pid用来指定进程id的存储文件的位置
		worker_rlimit_nofile用于指定一个进程可以打开最多文件数量的描述


##### event 模块


		event {
		    worker_connections 1024;
		    multi_accept on;
		    use epoll;
		}
		上述配置是针对nginx服务器的工作模式的一些操作配置
		
		worker_connections 指定最大可以同时接收的连接数量，这里一定要注意，最大连接数量是和worker processes共同决定的。
		multi_accept 配置指定nginx在收到一个新连接通知后尽可能多的接受更多的连接
		use epoll 配置指定了线程轮询的方法，如果是linux2.6+，使用epoll，如果是BSD如Mac请使用Kqueue


##### http模块
		
		作为web服务器，http模块是nginx最核心的一个模块，配置项也是比较多的，项目中会设置到很多的实际业务场景，需要根据硬件信息进行适当的配置，常规情况下，使用默认配置即可！


		http {
		    ##
		    # 基础配置
		    ##
		
		    sendfile on;
		    tcp_nopush on;
		    tcp_nodelay on;
		    keepalive_timeout 65;
		    types_hash_max_size 2048;
		    # server_tokens off;
		
		    # server_names_hash_bucket_size 64;
		    # server_name_in_redirect off;
		
		    include /etc/nginx/mime.types;
		    default_type application/octet-stream;
		
		    ##
		    # SSL证书配置
		    ##
		
		    ssl_protocols TLSv1 TLSv1.1 TLSv1.2; # Dropping SSLv3, ref: POODLE
		    ssl_prefer_server_ciphers on;
		
		    ##
		    # 日志配置
		    ##
		
		    access_log /var/log/nginx/access.log;
		    error_log /var/log/nginx/error.log;
		
		    ##
		    # Gzip 压缩配置
		    ##
		
		    gzip on;
		    gzip_disable "msie6";
		
		    # gzip_vary on;
		    # gzip_proxied any;
		    # gzip_comp_level 6;
		    # gzip_buffers 16 8k;
		    # gzip_http_version 1.1;
		    # gzip_types text/plain text/css application/json application/javascript
		 text/xml application/xml application/xml+rss text/javascript;
		
		    ##
		    # 虚拟主机配置
		    ##
		
		    include /etc/nginx/conf.d/*.conf;
		    include /etc/nginx/sites-enabled/*;
		 
		
		1) 基础配置
		
		sendfile on：配置on让sendfile发挥作用，将文件的回写过程交给数据缓冲去去完成，而不是放在应用中完成，这样的话在性能提升有有好处
		tc_nopush on：让nginx在一个数据包中发送所有的头文件，而不是一个一个单独发
		tcp_nodelay on：让nginx不要缓存数据，而是一段一段发送，如果数据的传输有实时性的要求的话可以配置它，发送完一小段数据就立刻能得到返回值，但是不要滥用哦
		
		keepalive_timeout 10：给客户端分配连接超时时间，服务器会在这个时间过后关闭连接。一般设置时间较短，可以让nginx工作持续性更好
		client_header_timeout 10：设置请求头的超时时间
		client_body_timeout 10:设置请求体的超时时间
		send_timeout 10：指定客户端响应超时时间，如果客户端两次操作间隔超过这个时间，服务器就会关闭这个链接
		
		limit_conn_zone $binary_remote_addr zone=addr:5m ：设置用于保存各种key的共享内存的参数，
		limit_conn addr 100: 给定的key设置最大连接数
		
		server_tokens：虽然不会让nginx执行速度更快，但是可以在错误页面关闭nginx版本提示，对于网站安全性的提升有好处哦
		include /etc/nginx/mime.types：指定在当前文件中包含另一个文件的指令
		default_type application/octet-stream：指定默认处理的文件类型可以是二进制
		type_hash_max_size 2048：混淆数据，影响三列冲突率，值越大消耗内存越多，散列key冲突率会降低，检索速度更快；值越小key，占用内存较少，冲突率越高，检索速度变慢

		2) 日志配置
		
		access_log logs/access.log：设置存储访问记录的日志
		error_log logs/error.log：设置存储记录错误发生的日志
		3) SSL证书加密
		
		ssl_protocols：指令用于启动特定的加密协议，nginx在1.1.13和1.0.12版本后默认是ssl_protocols SSLv3 TLSv1 TLSv1.1 TLSv1.2，TLSv1.1与TLSv1.2要确保OpenSSL >= 1.0.1 ，SSLv3 现在还有很多地方在用但有不少被攻击的漏洞。
		ssl prefer server ciphers：设置协商加密算法时，优先使用我们服务端的加密套件，而不是客户端浏览器的加密套件
		4) 压缩配置
		
		gzip 是告诉nginx采用gzip压缩的形式发送数据。这将会减少我们发送的数据量。
		gzip_disable 为指定的客户端禁用gzip功能。我们设置成IE6或者更低版本以使我们的方案能够广泛兼容。
		gzip_static 告诉nginx在压缩资源之前，先查找是否有预先gzip处理过的资源。这要求你预先压缩你的文件（在这个例子中被注释掉了），从而允许你使用最高压缩比，这样nginx就不用再压缩这些文件了（想要更详尽的gzip_static的信息，请点击这里）。
		gzip_proxied 允许或者禁止压缩基于请求和响应的响应流。我们设置为any，意味着将会压缩所有的请求。
		gzip_min_length 设置对数据启用压缩的最少字节数。如果一个请求小于1000字节，我们最好不要压缩它，因为压缩这些小的数据会降低处理此请求的所有进程的速度。
		gzip_comp_level 设置数据的压缩等级。这个等级可以是1-9之间的任意数值，9是最慢但是压缩比最大的。我们设置为4，这是一个比较折中的设置。
		gzip_type 设置需要压缩的数据格式。上面例子中已经有一些了，你也可以再添加更多的格式。

		5) 文件缓存配置
		
		open_file_cache 打开缓存的同时也指定了缓存最大数目，以及缓存的时间。我们可以设置一个相对高的最大时间，这样我们可以在它们不活动超过20秒后清除掉。
		open_file_cache_valid 在open_file_cache中指定检测正确信息的间隔时间。
		open_file_cache_min_uses 定义了open_file_cache中指令参数不活动时间期间里最小的文件数。
		open_file_cache_errors 指定了当搜索一个文件时是否缓存错误信息，也包括再次给配置中添加文件。我们也包括了服务器模块，这些是在不同文件中定义的。如果你的服务器模块不在这些位置，你就得修改这一行来指定正确的位置。




##### server模块

		srever模块配置是http模块中的一个子模块，用来定义一个虚拟访问主机，也就是一个虚拟服务器的配置信息
		
		server {
		    listen        80;
		    server_name localhost    192.168.1.100;
		    root        /nginx/www;
		    index        index.php index.html index.html;
		    charset        utf-8;
		    access_log    logs/access.log;
		    error_log    logs/error.log;
		    ......
		}
	
		核心配置信息如下：
		
		server：一个虚拟主机的配置，一个http中可以配置多个server
		
		server_name：用力啊指定ip地址或者域名，多个配置之间用空格分隔
		
		root：表示整个server虚拟主机内的根目录，所有当前主机中web项目的根目录
		
		index：用户访问web网站时的全局首页
		
		charset：用于设置www/路径中配置的网页的默认编码格式
		
		access_log：用于指定该虚拟主机服务器中的访问记录日志存放路径
		
		error_log：用于指定该虚拟主机服务器中访问错误日志的存放路径


##### location模块

		location模块是nginx配置中出现最多的一个配置，主要用于配置路由访问信息
		
		在路由访问信息配置中关联到反向代理、负载均衡等等各项功能，所以location模块也是一个非常重要的配置模块
		
		基本配置
		
		location / {
		    root    /nginx/www;
		    index    index.php index.html index.htm;
		}
		location /：表示匹配访问根目录
		
		root：用于指定访问根目录时，访问虚拟主机的web目录
		
		index：在不指定访问具体资源时，默认展示的资源文件列表
		
		反向代理配置方式
		
		通过反向代理代理服务器访问模式，通过proxy_set配置让客户端访问透明化
		
		location / {
		    proxy_pass http://localhost:8888;
		    proxy_set_header X-real-ip $remote_addr;
		    proxy_set_header Host $http_host;
		}
		uwsgi配置
		
		wsgi模式下的服务器配置访问方式
		
		location / {
		    include uwsgi_params;
		    uwsgi_pass localhost:8888
	}
	
	
##### upstream模块

			upstream模块主要负责负载均衡的配置，通过默认的轮询调度方式来分发请求到后端服务器
			
			简单的配置方式如下
		
			upstream name {
			    ip_hash;
			    server 192.168.1.100:8000;
			    server 192.168.1.100:8001 down;
			    server 192.168.1.100:8002 max_fails=3;
			    server 192.168.1.100:8003 fail_timeout=20s;
			    server 192.168.1.100:8004 max_fails=3 fail_timeout=20s;
			}
		
			核心配置信息如下
			
			ip_hash：指定请求调度算法，默认是weight权重轮询调度，可以指定
			
			server host:port：分发服务器的列表配置
			
			-- down：表示该主机暂停服务
			
			-- max_fails：表示失败最大次数，超过失败最大次数暂停服务
			
			-- fail_timeout：表示如果请求受理失败，暂停指定的时间之后重新发起请求	
		 
		
			
		
#四，nginx日志管理
		
		
#### 	定义日志收集的格式
		log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                      '$status $body_bytes_sent "$http_referer" '
                      '"$http_user_agent" "$http_x_forwarded_for"';
	
	
####  定义日志写入的文件

		 access_log  logs/access.log  main;
		 
		
		
#五，nginx 定时任务完成日志分割

		
		对logs/access.log做日志分割，每天生成新的日志文件，备份
		

#六，nginx-location详解匹配
			
### 		精准匹配  
				
			location = /user{
				
			}
			
### 		一般匹配
			location /user{
			
			}

			
### 		正则匹配

			location /[正则表达式]{
				
			}
			

### 	Location的正则表达式详解
			
			•location [ = | ~ | ~* | ^~ ] uri { … }
			•location @name { … }
			
#### 注1：规则不能混合使用
			
			
####  “=”精确匹配
	
		location = / {
		  .....
		}
		# 只匹配http://abc.com
		# http://abc.com [匹配成功]
		# http://abc.com/index [匹配失败]

####  “～”大小写敏感
		location ~ /Example/ {
		  .....
		}
		#http://abc.com/Example/ [匹配成功]
		#http://abc.com/example/ [匹配失败]
		
####  “～*”大小写忽略	
	
		location ~* /Example/ {
		  .....
		}
		#http://abc.com/Example/ [匹配成功]
		#http://abc.com/example/ [匹配成功]
		
####  “^~”，只匹配以 uri 开头	

		location ^~ /index/ {
			.....
		}
			
		#http://abc.com/index/index.html [匹配成功]
		#http://abc.com/error/index.html [匹配失败]

####  “@”，nginx的内部跳转
	
		location /index/ {
			
			error_page 404 @index_error;
			
		}
		
		location @index_error{
			............
		}
		
		#以 /index/ 开头的请求，如果链接的状态为 404。则会匹配到 @index_error 这条规则上。
	
	

###  location不加任何规则	
	
	   不加任何规则则时，默认是大小写敏感，前缀匹配，相当于加了“~”与“^~”
	   只有 / 表示匹配所有uri

		location /index/{
			........
		}
		#http://abc.com/index  [匹配成功]
		#http://abc.com/index/index.page  [匹配成功]
		#http://abc.com/test/index  [匹配失败]
		#http://abc.com/Index  [匹配失败]
		
		# 匹配到所有uri
		location / {
		  ......
		}
	
			
#七，nginx location匹配符优先级

		
		= > 空匹配符，满足精确匹配时 > ^~ > ~或~* > 空匹配符，满足以指定模式开始时的匹配时
			
		* 先判断精准命中，如果命中，立即返回结果并结束解析过程。
		* 判断普通命中，如果有多个命中，“记录”下来“最长”的命中结果（记录但不结束，最长的为准）。
		* 继续判断正则表达式的解析结果，按配置里的正则表达式顺序为准，由上至下开始匹配，一旦匹配成功1个，立即返回结果，并结束解析过程。
		* 普通命中顺序无所谓，是因为按命中的长短来确定。正则命中，顺序有所谓，因为是从前入往后命中的。
		
		
		
#  nginx Rewrite语法详解
		
	Nginx提供的全局变量或自己设置的变量，结合正则表达式和标志位实现url重写以及重定向。
	rewrite只能放在server{},location{},if{}中，
	并且只能对域名后边的除去传递的参数外的字符串起作用。
	Rewrite主要的功能就是实现URL的重写，Nginx的Rewrite规则采用Pcre，perl兼容正则表达式的语法规则匹配，如果需要Nginx的Rewrite功能，在编译Nginx之前，需要编译安装PCRE库。
	通过Rewrite规则，可以实现规范的URL、根据变量来做URL转向及选择配置。
	
	


### Rewrite的相关指令
		
		break
		if ( condition ){ ... }
		
		return
		
		rewrite regex replacement flag
		
		uninitialized_variable_warn on|off
		
		set  variable  value



	
	
### Rewrite全局变量

			变量								含义

		$args					这个变量等于请求行中的参数，同$query_string
		$content length		请求头中的Content-length字段。
		$content_type			请求头中的Content-Type字段。
		$document_root		当前请求在root指令中指定的值。
		
		$host					请求主机头字段，否则为服务器名称。
		$http_user_agent		客户端agent信息
		$http_cookie			客户端cookie信息
		$limit_rate			这个变量可以限制连接速率。
		
		$request_method		客户端请求的动作，通常为GET或POST。
		$remote_addr			客户端的IP地址。
		$remote_port			客户端的端口。
		$remote_user			已经经过Auth Basic Module验证的用户名。
		
		$request_filename	当前请求的文件路径，由root或alias指令与URI请求生成。
		$scheme				HTTP方法（如http，https）。
		$server_protocol		请求使用的协议，通常是HTTP/1.0或HTTP/1.1。
		$server_addr			服务器地址，在完成一次系统调用后可以确定这个值。
		
		$server_name			服务器名称。
		$server_port			请求到达服务器的端口号。
		$request_uri			包含请求参数的原始URI，不包含主机名，如”/foo/bar.php?arg=baz”。
		$uri					不带请求参数的当前URI，$uri不包含主机名，如”/foo/bar.html”。
		$document_uri 		与$uri相同。



### Rewrite语法规则


		
		操作符				含义

		= ,!=				比较的一个变量和字符串。
		
		~， ~*				与正则表达式匹配的变量，如果这个正则表达式中包含}，;则整个表达式需要用"或'包围。
		
		-f，!-f			检查一个文件是否存在。
		
		-d, !-d			检查一个目录是否存在。
		
		-e，!-e			检查一个文件、目录、符号链接是否存在。
		
		-x， !-x			检查一个文件是否可执行。

	

### if指令	

	  if  语法格式
     if 空格 (条件) {
        重写模式
     }	
		
		
	 # 限制浏览器访问
    if ($http_user_agent ~ Firefox) { 
      rewrite ^(.*)$ /firefox/$1 break; 
    }      

    if ($http_user_agent ~ MSIE) { 
        rewrite ^(.*)$ /msie/$1 break; 
    }      

    if ($http_user_agent ~ Chrome) { 
        rewrite ^(.*)$ /chrome/$1 break; 
    }
		
		
### return，break指令	

	 # 限制IP访问
    if  ($remote_addr = 192.168.197.142) {
       return 403;
    }	
    
    if  ($remote_addr = 192.168.197.142) {
       break;
    }	
    1.首先从日志查出ip

	修改conf配置文件

	重启配置文件访问发现
	
	
	
### rewrite指令

	#判断目录是否存在
	#服务器内部的rewrite和302跳转不一样.跳转的话URL都变了,变成重新http请求index.html,而内部rewrite,上下文没变。
	#  nginx zip压缩提示网站速度
	
	
	  if (!-e $document_root$fastcgi_script_name) {
        rewrite ^.*$ /index.html break;
    }


### set指令

	变量申明
	



#  nginx之 expires缓存提升网站负载
		
		

#  nginx 反向代理实现apache动静分离

		
		

#  nginx zip压缩提示网站速度


#  nginx 实现负载均衡
#  nginx 连接redis
#  nginx 第三方模块编译及一致性哈希应用
#  nginx 大量访问优化整体思路
	

#  nginx ab压力测试及nginx性能统计模块
#  nginx 单机1万并发优化
	
	1,socket的优化

		增加max open files。先查看一下:
		$ sysctl -a | grep files
		kern.maxfiles = 12288
		kern.maxfilesperproc = 10240
		修改为
		
		$ sudo sysctl -w kern.maxfiles=12288
		$ sudo sysctl -w kern.maxfilesperproc=10240
		增加 max sockets
		$ sysctl -a | grep somax
		kern.ipc.somaxconn: 2048
		$ sudo sysctl -w kern.ipc.somaxconn=2048
		最后用ulimit -n看一下。跟linux语法类似


#  nginx 服务器集群搭建
#  nginx 集群性能测试




#  初识nginx

###	静态资源，反向代理，API服务
	
	静态资源：本地的文件系统提供的服务
	反向代理：Nginx性能，缓存，负载均衡
	API服务：OpenResty
	
	Ngnix模块配置详解官方解释  https://nginx.org/en/docs/
		
	Nginx日志分析  goaccess nginx
			
	
	goaccess安装使用
		brew install goaccess
		yum -y install goaccess
		
	使用：
	
		修改/usr/local/Cellar/goaccess/1.2/etc/goaccess.conf 
		
		Fatal error has occurred
		Error occured at: src/parser.c - parse_log - 2705
		No time format was found on your conf file.
		提示没有 time format， 即我们需要配置日志的时间格式，
		
		打开默认的配置文件 goaccess.conf, 开启下面配置：
		
		time-format %H:%M:%S
		date-format %d/%b/%Y	
		log-format COMBINED
			
		
		启动 goaccess  -f  access.log -o  result.html
			
#  nginx架构基础

![nginx架构图](https://img-my.csdn.net/uploads/201212/26/1356522086_4076.png)

* nginx热升级，worker进程优雅关闭，配置重载，信号管理子进程。

* nginx的worker共享内存-Slab
	* Bestfit分配内存，最多两倍消耗内存 
	* Bestfit 适合小对象，避免碎片化，避免重复初始化
* 哈希表的max_siae和bucket_size配置
* 红黑树 定时器的实现	


理论上可以使用ngx_lua开发各种复杂的web应用，不过Lua是一种脚本/动态语言，不适合业务逻辑比较重的场景，适合小巧的应用场景，代码行数保持在几十行到几千行。目前见到的一些应用场景：

web应用：会进行一些业务逻辑处理，甚至进行耗CPU的模板渲染，一般流程：mysql/redis/http获取数据、业务处理、产生JSON/XML/模板渲染内容，比如京东的列表页/商品详情页；

接入网关：实现如数据校验前置、缓存前置、数据过滤、API请求聚合、AB测试、灰度发布、降级、监控等功能，比如京东的交易大Nginx节点、无线部门正在开发的无线网关、单品页统一服务、实时价格、动态服务；

Web防火墙：可以进行IP/URL/UserAgent/Referer黑名单、限流等功能；

缓存服务器：可以对响应内容进行缓存，减少到后端的请求，从而提升性能；

其他：如静态资源服务器、消息推送服务、缩略图裁剪等。



#  详解HTTp模块
#  nginx的系统层性能优化
#  从源码视角深入使用Nginx与OpenResty


# Openresty安装使用

	安装目录 /usr/local/opt/openresty/nginx/sbin
	
	启动：	
	/usr/local/opt/openresty/nginx/sbin/nginx -c /usr/local/opt/openresty/nginx/conf/nginx.conf  -p /usr/local/opt/openresty/nginx  
	
	
ffi的使用：

	local ffi = require "ffi"
	ffi.cdef[[
	  int printf(const char *fmt, ...);
	]]
	
	ffi.C.printf("hello world");
	使用luajit启动lua程序
	启动：/usr/local/opt/openresty/luajit/bin/luajit-2.1.0-beta3  /usr/local/opt/openresty/nginx/lua/lua_ffi.lua
	
	
	nginx.conf + lua 开发
	
	
	lua-resty-lock 解决缓存失效风暴
	set-by-lua  变量
	rewrite-by-lua 路由转发
	access-by-lua 鉴权
	content-by-lua lua脚本
	header-filter-by-lua header的拦截器
	body_filter_by_lua body的拦截器
	log_by_lua 日志记录（本地或远端的服务器）
	
	
	nginx-lua检测脚本库
	https://github.com/openresty/openresty-devel-utils
	

# Openresty灰度发布
 
 ![灰度发布流程图](https://images2015.cnblogs.com/blog/611088/201704/611088-20170427154049240-2097568032.jpg)
 
 
 
 一、安装OpenResty
Linux官方建议直接通过官方提供的预编译包安装：http://openresty.org/cn/linux-packages.html

# 确保yum周边工具已经安装
	yum install yum-utils -y
	 ###添加仓库
	yum-config-manager --add-repo https://openresty.org/package/centos/openresty.repo
	### 安装openresty
	yum install openresty -y
	openresty默认安装在/usr/local/openresty，其中已自带nginx。
	
	 
	
	二、使用安全规则ngx_lua_waf
	2.1 ngx_lua_waf介绍
	
	我不明白为什么很多软件不提供默认配置，比较很多暴力破解软件不提供弱口令文件snort有段时间也不提供默认规则，openresty也不提供默认规则。
	
	不过还好有人自己写了规则分享出来：https://github.com/loveshell/ngx_lua_waf
	
	 
	
	2.2 ngx_lua_waf加载到nginx
	
	下载规则文件：
	
	git clone https://github.com/loveshell/ngx_lua_waf.git
	mv ngx_lua_waf/ /usr/local/openresty/nginx/conf/waf
	纠正nginx位置。因为规则默认nginx安装在/usr/local/nginx，我们需要编缉config.lua纠正nginx位置，主要是RulePath和logdir两项：
	
	RulePath = "/usr/local/openresty/nginx/conf/waf/wafconf/"
	logdir = "/usr/local/openresty/nginx/logs/hack/"
	创建拦截日志文件目录。上面我们设置拦截日志文件目录为/usr/local/openresty/nginx/logs/hack/但该目录尚未存在需要事先创建，且需要赋权给nobody不然没法写：
	
	mkdir /usr/local/openresty/nginx/logs/hack/
	chown -R nobody:nobody hack/
	加载规则。编缉/usr/local/openresty/nginx/conf/nginx.conf，在http{}内server{}前加入：
	
	lua_shared_dict limit 10m;
	lua_package_path "/usr/local/openresty/nginx/conf/waf/?.lua";
	init_by_lua_file  /usr/local/openresty/nginx/conf/waf/init.lua; 
	access_by_lua_file /usr/local/openresty/nginx/conf/waf/waf.lua;
	
![waf配置](ttps://img2018.cnblogs.com/blog/1116722/201811/1116722-20181123180142156-402546488.png)
	


	 
	三、拦截效果测试
	默认只对.php和.jsp文件进行规则检测，但因为进行规则检测后进行文件是否存在查询，所以虽然当前nginx没有反向代理php和jsp也没有php和jsp文件但这两个都不用管。
	
	但要注意默认对来自本机的请求是不进行规则过滤的，所以不要在安装OpenResty的机器上curl http://127.0.0.1/test.php?id=../etc/passwd半天，然后说规则怎么没生效。
	
	启动nginx后在另外一台机器上访问（192.168.220.133是我安装OpenResty的机器的ip），效果如下：
	
	
	
	进入拦截日志目录检看拦截记录如下：


#挂载本地目录

docker可以支持把一个宿主机上的目录挂载到镜像里

	docker run -it -v /home/dock/Downloads:/usr/Downloads ubuntu64 /bin/bash  
	通过-v参数，冒号前为宿主机目录，必须为绝对路径，冒号后为镜像内挂载的路径。
	现在镜像内就可以共享宿主机里的文件了。

默认挂载的路径权限为读写。如果指定为只读可以用：ro

	docker run -it -v /home/dock/Downloads:/usr/Downloads:ro ubuntu64 /bin/bash


docker还提供了一种高级的用法。叫数据卷。

	数据卷：“其实就是一个正常的容器，专门用来提供数据卷供其它容器挂载的”。感觉像是由一个容器定义的一个数据挂载信息。其他的容器启动可以直接挂载数据卷容器中定义的挂载信息。
	
	看示例：
	docker run -v /home/dock/Downloads:/usr/Downloads  --name dataVol ubuntu64 /bin/bash
	
	创建一个普通的容器。用--name给他指定了一个名（不指定的话会生成一个随机的名子）。
	再创建一个新的容器，来使用这个数据卷。

	docker run -it --volumes-from dataVol ubuntu64 /bin/bash
	
	--volumes-from用来指定要从哪个数据卷来挂载数据。


如果你在用数据容器，那做备份是相当容易的：

	docker run --rm --volumes-from dataVol -v $(pwd):/backup debian tar cvf /backup/backup.tar /var/lib/postgresql/data


	该示例应该会将Volume里所有的东西压缩为一个tar包（官方的postgres Dockerfile在/var/lib/postgresql/data目录下定义了一个Volume）
	
 权限与许可
 
	通常你需要设置Volume的权限或者为Volume初始化一些默认数据或者配置文件。要注意的关键点是，在Dockerfile的VOLUME指令后的任何东西都不能改变该Volume，比如：
	FROM debian:wheezy
	RUN useradd foo
	VOLUME /data
	RUN touch /data/x
	RUN chown -R foo:foo /data
	
	该Docker file不能按预期那样运行，我们本来希望touch命令在镜像的文件系统上运行，但是实际上它是在一个临时容器的Volume上运行。如下所示：
	FROM debian:wheezy
	RUN useradd foo
	RUN mkdir /data && touch /data/x
	RUN chown -R foo:foo /data
	VOLUME /data
	
	Docker可以将镜像中Volume下的文件挂载到Volume下，并设置正确的权限。如果你指定Volume的主机目录将不会出现这种情况。
	
	如果你没有通过RUN指令设置权限，那么你就需要在容器启动时使用CMD或ENTRYPOINT指令来执行（译者注：CMD指令用于指定一个容器启动时要运行的命令，与RUN类似，只是RUN是镜像在构建时要运行的命令）。

删除Volumes

	这个功能可能会更加重要，如果你已经使用docker rm来删除你的容器，那可能有很多的孤立的Volume仍在占用着空间。

Volume只有在下列情况下才能被删除：

	该容器是用docker rm －v命令来删除的（-v是必不可少的）。
	docker run中使用了--rm参数
	
	即使用以上两种命令，也只能删除没有容器连接的Volume。连接到用户指定主机目录的Volume永远不会被docker删除。



#docker发布Openresty

执行以下docker命令

  docker pull openresty/openresty:alpine-fat
  
根据Openresty文档进行测试

首先，在/usr/local/openresrty-docker 创建 conf 和 logs 两个文件夹
在conf中创建nginx.conf

	worker_processes  1;
	error_log logs/error.log;
	events {
	    worker_connections 1024;
	}
	http {
	    server {
	        listen 18080;
	        location / {
	            default_type text/html;
	            content_by_lua '
	                ngx.say("<p>hello, world</p>")
	            ';
	        }
	    }
	}
检查本地端口占用


  docker run -v /usr/local/openresty:/usr/local/openresty  --name openresty-volumes ubuntu64 /bin/bash
  
  docker run -it --volumes-from openresty-volumes ubuntu64 /bin/bash


	netstat -tlunp | grep 80
	
启动Docker

   运行openresty
   
	docker run  --name="pc-openresty-keepalived" -p 80:80 -v /usr/local/openresty/nginx/conf/nginx.conf:/usr/local/openresty/nginx/conf/nginx.conf -v /usr/local/openresty/nginx/logs/:/usr/local/openresrty/logs/ -v /usr/local/openresty/nginx/lua/:/usr/local/openresty/nginx/lua/ -v /usr/local/openresty/nginx/html/:/usr/local/openresty/nginx/html/ -d openresty/openresty

	
	 openresty/openresty
	
终止Docker

	docker kill pc-openresty-keepalived && docker rm pc-openresty-keepalived

	//copy到其它机器指定位置
	scp -r openresrty-docker/ root@192.168.57.111:/usr/local/
	//进入nginx容器
	docker exec -it pc-openresty-keepalived  /bin/sh
	//重启nginx
	nginx -s reload
	//查看日志
	docker logs pc-openresty-keepalived
	
	
	<h1>Welcome to OpenResty-01!</h1>
	<p>hello openresty-01!!!!!!!!!!!!!!!!!</p>  
	

#docker: Error response from daemon: driver failed programming external connectivity on endpoint
错误现象 =>

启动 rancher server 时出现网络故障，如下：

docker: Error response from daemon: driver failed programming external connectivity on endpoint peaceful_sammet (0ffcb446e5de6905d872c4e20080243fce8f9928d68b857f6b4a23eadc38f2f3): iptables failed: iptables --wait -t nat -A DOCKER -p tcp -d 0/0 --dport 8080 -j DNAT --to-destination 172.17.0.2:8080 ! -i docker0: iptables: No chain/target/match by that name.


pkill docker                         #终止进程
iptables -t nat -F                 #清空nat表的所有链
ifconfig docker0 down        #停止docker默认网桥
brctl delbr docker0             #删除网桥
systemctl restart docker       #重启docker

 	