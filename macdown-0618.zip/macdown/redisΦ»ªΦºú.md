# redis详解

# 一，codis裸机安装依赖编译

  安装编译依赖：
  
	yum install autoconf automake libtool -y
	yum install -y gcc glibc gcc-c++ make git
	
	 make
	 
	 make gotest
	 
	
 修改配置文件：config下的配置文件修改
 
 	目录配置
 		
 		mkdir -p /usr/local/codis/{bin,logs,data}/
  		cp -rf /root/go/src/github.com/CodisLabs/codis/bin/* /usr/local/codis/bin
  		cp -rf /root/go/src/github.com/CodisLabs/codis/config /usr/local/codis/config
  
  		
  （1）Codis Dashboard （192.168.57.134 主机）
  

		dashboard是仪表盘，可以把其他服务绑定到监控仪表盘来进行服务管理及监控。
		
		编辑配置文件/usr/local/codis/config/dashboard.toml
		
		#coordinator_name = "filesystem"
		#coordinator_addr = "/tmp/codis"
		coordinator_name = "zookeeper"
		coordinator_addr = "192.168.57.134:2181,192.168.57.135:2181,192.168.57.136:2181"
		#coordinator_auth = ""
		
		# Set Codis Product Name/Auth.
		product_name = "codis-mysql-proxy"
		product_auth = ""
		
		# Set bind address for admin(rpc), tcp only.
		admin_addr = "0.0.0.0:18080"
		
		启动dashboard
		
	
		nohup /usr/local/codis/bin/codis-dashboard --ncpu=4 --config=/usr/local/codis/config/dashboard.toml --log=/usr/local/codis/logs/dashboard.log --log-level=WARN &		
		停止dashboard
		必须使用命令来停止dashboard，不然会报错。原因是已经在zk中注册了，但是没有正常关闭的话，zk中的信息就不能删除，再次启动会报错。
		
		/usr/local/codis/bin/codis-admin --dashboard=192.168.57.134:18080 --shutdown
	
	
	
(2）Codis Proxy

	   proxy是对外提供redis服务的入口。
		
		编辑配置文件/usr/local/codis/config/proxy.toml
	
 #主机192.168.57.134
		
		product_name = "codis-mysql-proxy"
		
		product_auth = ""
		
		session_auth = ""
		
		admin_addr = "0.0.0.0:11080"
		
		proto_type = "tcp4"
		
		proxy_addr = "0.0.0.0:19000"
		
		jodis_name = "zookeeper"
		
		jodis_addr = "192.168.57.134:2181,192.168.57.135:2181,192.168.57.136:2181"
		
		jodis_auth = ""
		
		jodis_timeout = "20s"
		
		jodis_compatible = true
		
		
 #主机192.168.57.135
 
		product_name = "codis-mysql-proxy"
		
		product_auth = ""
		
		session_auth = ""
		
		admin_addr = "0.0.0.0:11080"
		
		proto_type = "tcp4"
		
		proxy_addr = "0.0.0.0:19000"
		
		jodis_name = "zookeeper"
		
		jodis_addr = "192.168.57.134:2181,192.168.57.135:2181,192.168.57.136:2181"
		
		jodis_auth = ""
		
		jodis_timeout = "20s"
		
		jodis_compatible = true
	

 #主机192.168.57.136

		product_name = "codis-mysql-proxy"
		
		product_auth = ""
		
		session_auth = ""
		
		admin_addr = "0.0.0.0:11080"
		
		proto_type = "tcp4"
		
		proxy_addr = "0.0.0.0:19000"
		
		jodis_name = "zookeeper"
		
		jodis_addr = "192.168.57.134:2181,192.168.57.135:2181,192.168.57.136:2181"
		
		jodis_auth = ""
		
		jodis_timeout = "20s"
		
		jodis_compatible = true



启动codis-proxy
		
	nohup /usr/local/codis/bin/codis-proxy --ncpu=4 --config=/usr/local/codis/config/proxy.toml --log=/usr/local/codis/logs/proxy.log --log-level=WARN &
	
	
（3）Codis-admin

	关联proxy到dashboard
	
	#主机192.168.209.131
	
	/usr/local/codis/bin/codis-admin --dashboard=192.168.57.134:18080 --create-proxy -x 192.168.57.134:11080
	
	
	
（4）Codis-Server

	即创建redis实例,每台主机都创建2个redis实例

	mkdir -p /usr/local/codis/redis/6379
	mkdir -p /usr/local/codis/redis/6380
	
	
cp /root/go/src/github.com/CodisLabs/codis/config/redis.conf /usr/local/codis/redis/6379
cp /root/go/src/github.com/CodisLabs/codis/config/redis.conf /usr/local/codis/redis/6380

	
	
	修改/usr/local/codis/redis/6379/redis.conf配置文件

（maxmemory一定要设置最大内存，否则后面的codis无法使用）


	pidfile "/usr/local/codis/redis/6379/redis.pid"
	
	daemonize no
	
	protected-mode yes
	
	port 6379
	
	dbfilename "dump_6379.rdb"
	
	dir "/usr/local/codis/redis/6379/"
	
	logfile "/usr/local/codis/redis/6379/redis.log"
	
	requirepass ""
	
	maxmemory 1gb

 

修改/usr/local/codis/redis/6380/redis.conf配置文件

（maxmemory一定要设置最大内存，否则后面的codis无法使用）


	pidfile "/usr/local/codis/redis/6380/redis.pid"
	
	daemonize no
	
	protected-mode yes
	
	port 6380
	
	dbfilename "dump_6380.rdb"
	
	dir "/usr/local/codis/redis/6380/"
	
	logfile "/usr/local/codis/redis/6380/redis.log"
	
	requirepass ""
	
	maxmemory 1gb
	
	
	启动codis-server
	
	后面需要使用 Codis-fe或者Codis-admin 添加到集群
	
	nohup /usr/local/codis/bin/codis-server /usr/local/codis/redis/6379/redis.conf &
	nohup /usr/local/codis/bin/codis-server /usr/local/codis/redis/6380/redis.conf &

	
（5）Codis-FE

	# 启动 codis-fe
	nohup /usr/local/codis/bin/codis-fe --ncpu=4 --log=/usr/local/codis/logs/fe.log --log-level=WARN --zookeeper=192.168.57.134:2181 --listen=192.168.57.134:8888 &

	
（6）修复异常退出的 Codis-dashboard和修复异常退出的 Codis-proxy

dashboard 非正常退出，或者 kill -9 时使用

    需要正确连接到zookeeper集群
	/usr/local/codis/bin/codis-admin --remove-lock --product=codis-shanghai --zookeeper=192.168.57.134:2181

修复异常退出的 Codis-proxy

	proxy 非正常退出，或者 kill -9 时使用
	/usr/local/codis/bin/codis-admin --dashboard=192.168.57.134:18080 --remove-proxy --addr=192.168.57.134:11080 -force

（7）codis集群启动

  主机暂停codis-dashboard
  
   /usr/local/codis/bin/codis-admin --dashboard=192.168.57.134:18080 --shutdown

	a,主机启动codis-dashboard 134节点启动
	nohup /usr/local/codis/bin/codis-dashboard --ncpu=4 --config=/usr/local/codis/config/dashboard.toml --log=/usr/local/codis/logs/dashboard.log --log-level=WARN &
			
	b,创建proxy
	nohup /usr/local/codis/bin/codis-proxy --ncpu=4 --config=/usr/local/codis/config/proxy.toml --log=/usr/local/codis/logs/proxy.log --log-level=WARN &
	
	c,主机proxy和dashboard关联
	/usr/local/codis/bin/codis-admin --dashboard=192.168.57.134:18080 --create-proxy -x 192.168.57.134:11080
	
	d,启动redis
	nohup /usr/local/codis/bin/codis-server /usr/local/codis/redis/6379/redis.conf &
	nohup /usr/local/codis/bin/codis-server /usr/local/codis/redis/6380/redis.conf &
	
	//e,主机机器启动fe
	nohup /usr/local/codis/bin/codis-fe --ncpu=4 --log=/usr/local/codis/logs/fe.log --log-level=WARN --zookeeper=192.168.57.134:2181,192.168.57.135:2181,192.168.57.136:2181 --listen=192.168.57.134:8888 &
	
	f,codis集群启动成功 无法提供服务，需要redis进行分组和slots
		


 (8),在fe界面查看、添加proxy代理服务，在添加的时候proxy需要启动
 
 	proxy启动默认会自动注册到dashboard中，也可以在fe中手动添加,

	“Proxy Admin Address”选项中分别填写如下内容，然后点击“New Proxy”按钮添加
	
	192.168.57.134:11080
	
	192.168.57.135:11080
	
	192.168.57.136:11080
	
	备注：主机的codis-proxy服务需要启动，11080端口是互通的，才能添加成功，结果如下：
	
![codis-proxy启动成功](https://img-blog.csdnimg.cn/20190318170625919.png)


(9),部署codis-server加入集群
	
添加group

	Group栏为空，因为我们启动的codis-server并未加入到集群，启动所有主机codis-server服务，
	
	“NEW GROUP”选项分别输入输入1，2，3，点击NEW GROUP添加3个Group。

添加实例（按照部署规划，添加redis服务）

	“Data Center” 选项填 空
	
	“Codis Server Address” 选项填192.168.57.134:6379
	
	“Group”选项填1
	
	“Data Center” 选项填 空
	
	“Codis Server Address” 选项填192.168.57.134:6380
	
	“Group”选项填1

 

	“Data Center” 选项填 空
	
	“Codis Server Address” 选项填192.168.57.135:6379
	
	“Group”选项填2
	
	“Data Center” 选项填 空
	
	“Codis Server Address” 选项填192.168.57.135:6380
	
	“Group”选项填2

 

	“Data Center” 选项填 空
	
	“Codis Server Address” 选项填192.168.57.136:6379
	
	“Group”选项填3
	
	“Data Center” 选项填 空
	
	“Codis Server Address” 选项填192.168.57.136:6380
	
	“Group”选项填3

 
 配置结果如下，图中按钮误乱操作，否则会导致服务切换，若要删除Group，需要先删除Group对应的slots
 	
 ![配置结果](https://img-blog.csdnimg.cn/20190318170625958.png)


(10),对slots进行分组
	
Migrate Range选项中，输入所要分组的slots的起和止的范围，然后输入组ID，点击后面按钮即可。也可以直接点击按钮“Rebalance All Slots”，让系统自动分配slots。

	
	


(11),codis集群并发测试

	
10000请求，200并发

	/usr/local/codis/bin/redis-benchmark -h 192.168.57.134 -p 19000 -n 10000 -c 200 -q
	
	/usr/local/codis/bin/redis-benchmark -h 192.168.57.135 -p 19000 -n 10000 -c 200 -q
	
	/usr/local/codis/bin/redis-benchmark -h 192.168.57.136 -p 19000 -n 10000 -c 200 –q


redis单机性能测试：

10000请求，200并发

	/usr/local/codis/bin/redis-benchmark -h 192.168.57.134 -p 6379 -n 10000 -c 200 –q
	
	/usr/local/codis/bin/redis-benchmark -h 192.168.57.134 -p 6380 -n 10000 -c 200 -q

 

设置10万随机key连续SET 100万次测试：

	/usr/local/codis/bin/redis-benchmark -h 192.168.57.134 -p 19000 -t set -r 100000 -n 1000000
	
	/usr/local/codis/bin/redis-benchmark -h 192.168.57.135 -p 19000 -t set -r 100000 -n 1000000
	
	/usr/local/codis/bin/redis-benchmark -h 192.168.57.136 -p 19000 -t set -r 100000 -n 1000000
	
	
	
安装教程

	https://blog.csdn.net/guoyanliang1985/article/details/88578226
	
	
	

	
#二，持久化	和数据恢复

###1,持久化分类详解：
	
RDB持久化配置

	Redis会将数据集的快照dump到dump.rdb文件中。此外，我们也可以通过配置文件来修改Redis服务器dump快照的频率，在打开6379.conf文件之后，我们搜索save，可以看到下面的配置信息：
	
	save 900 1              #在900秒(15分钟)之后，如果至少有1个key发生变化，则dump内存快照。
	
	save 300 10            #在300秒(5分钟)之后，如果至少有10个key发生变化，则dump内存快照。
	
	save 60 10000        #在60秒(1分钟)之后，如果至少有10000个key发生变化，则dump内存快照。

AOF持久化配置，redis启动会优化AOF配置，RDB和AOF可以同时存在

	开启AOF功能需要设置配置：appendonly yes，默认不开启。AOF文件名通过appendfilename配置设置，默认文件名是appendonly.aof

	在Redis的配置文件中存在三种同步方式，它们分别是：
	
	appendfsync always     #每次有数据修改发生时都会写入AOF文件。
	
	appendfsync everysec  #每秒钟同步一次，该策略为AOF的缺省策略。
	
	appendfsync no          #从不同步。高效但是数据不会被持久化。
	


###2,RDB恢复


###3,AOF恢复



###4,redis 持久化详解,RDB和AOF是什么？他们优缺点是什么？运行流程是什么？

http://www.chenxm.cc/article/38.html

####4.1 RDB触发机制 手动触发分别对应save和bgsave命令:

	  save命令：阻塞当前Redis服务器，知道RDB过程完成为止，对于内存比较大的实例会造成长时间阻塞，先上环境不建议使用。运行save命令对应Redis日志如下：
	  
	  DB saved on disk
	  
	  bgsave命令：Redis进程执行fork操作创建子进程，RDB持久化过程由子进程负责，完成后自动结束。阻塞只发生在fork阶段，一段时间很短。运行bgsave名字对应的Redis日志如下：
	  Background saving started by pid 3152
	  DB saved on disk
	  RDB: 0MB of memory userd by copy-on-write
	  Background saving terminated with success


	 bgsave命令是针对save阻塞问题做的优化。因此Redis内部所有涉及到RDB操作都采用bgsave的方式，而save命令可以废弃。
	 
	 Redis内部还存在自动触发RDB的持久化机制，例如一下场景:

    1) 使用save相关配置，如‘save m n’表示m秒之内数据集存在n次修改时，自动触发bgsave。

    2）如果从节点执行全量复制操作，主节点自动执行bgsave生成RDB文件并发送给从节点。

    3）执行debug reload命令重新加载Redis时，也会自动触发save操作。

    4）默认情况下执行shutdown命令时，如果没有开启AOF持久化功能则自动执行bgsave。
    
    

####4.2 bgsave流程说明

	1) 执行bgsave命令，Redis父进程判断当前是否存在正在执行的子进程，如只RDB/AOF子进程，如果存在bgsave命令直接返回。

	2) 父进程执行fork操作创建子进程，fork操作过程中父进程会阻塞，通过info stats命令查看latest_fork_usec选项，可以获取最近一个fork以操作的耗时，单位为微秒。
	
	3) 父进程仍fork完成后，bgsave命令返回“Background saving started”信息并不再阻塞父进程，可以继续响应其他命令。
	
	4) 子进程创建RDB文件，根据父进程内存生成临时快照文件，完成后对原有文件进行原子替换。执行lastsave命令可以获取最后一次生成尺RDB的时间，对应info统计的rdb_last_save_time选项。
	
	5) 进程发送信号给父进程衣示完成，父进程更新统计信息，具体见info Persistence下的rdb_*相关选项。


####4.3 RDB文件处理
	
	
    保存：RDB文件保存在dir配置指定的目录下，文件名通过dbfilename配置指定。可以通过执行config set dir {newDir} 和 config set dbfilename {newFileName}运行期动态执行，当下次运行时RDB文件会保存到新目录。

    压缩：Redis默认采用LZF算法对生成的RDB文件做压缩处理，压缩后的文件远远小于内存大小，默认开启，可以通过参数config set rdbcompression {yes|no}动态修改。

    校验：如果Redis加载损坏的RDB文件时拒绝启动，并打印如下日志：

    Short read or OOM loading DB. Unrecoverable error , aborting now.

    这时可以使用Redis提供的redis-check-dump工具检测RDB文件并获取对应的错误报告

RDB的优缺点

RDB的优点:

    RDB是一个紧凑压缩的二进制文件，代表Redis在某一个时间点上的数据快照。非常适合用于备份，全量复制等场景。比如每6小时执行bgsave备份，并把RDB文件拷贝到远程机器或者文件系统中（如hdfs），用于灾难恢复。

    Redis加载RDB恢复数据远远快于AOF方式。

RDB的缺点

    RDB方式数据没办法做到实时持久化/秒级持久化。因为bgsave每次运行都要执行fork操作创建子进程，属于重量级操作，频繁执行成本过高。

    RDB文件使用特定二进制格式保存，Redis版本演进过程中有多个格式的RDB笨笨，存在老版本Redis服务无法兼容新版RDB格式的问题。

    针对RDB不适合实时持久化的问题，Redis提供了AOF持久化方式来解决



###4.4 AOF
	
	AOF持久化，以独立日志的方式记录每条命令，重启时再重新执行AO文件中命令达到恢复数据的目的。AOF主要解决的就是数据持久化的实时性，目前已经是redis持久化的主流方式。
	

####4.4.1 使用AOF

	    开启AOF功能需要设置配置：appendonly yes,默认不开启。AOF文件通过appendfilename 配置设置，默认文件名是appendonly.aof。保存路径同RDB持久化方式一致。通过dir配置指定。AOF的工作流程操作：命令写入（append）、文件同步（sync）、文件重写（rewrite）、重启加载（load）,工作流程如下：

	命令写入————>文件同步----->文件重写------>重启加载
	
	1),所有的命令会追加到aof_buf缓冲区中。
	2),AOF 缓冲区根据对应的策略像硬盘做同步操作。
	3),随着AOF文件越来越大，需要定期对AOF文件进行重写，达到压缩的目的。
	4） 当Redis服务重启时，可以加载AOF文件进行数据恢复。了解AOF工作流程之后，下面针对每个步骤做详细介绍。
	

####4.4.2 AOF命令追加到aof_buf缓冲区中。写入的内容是文本协议-文件协议油很好的兼容性无需协议转换

AOF命令写入的内容直接是文本协议格式。例如set hello world 这条命令，在AOF缓冲区会追加如下文本：

	\r\n$3\r\nset\r\n$5\r\nhello\r\n$5\r\nworld\r\n
	
	   介绍关于AOF的连个疑惑：

    1） AOF为什么直接采用文本协议格式？可能的理由如下：

        文本协议具有很好的兼容性。

        开启AOF后，所有写入命令都包含追加操作，直接采用协议格式，避免二次处理开销。

        文本协议具有可读性，方便直接修改和处理。
        
        2） AOF为什么把命令追加到aof_buf中？Redis使用单线程响应命令，如果每次写AOF文件命令都直接追加到硬盘，那么性能完全取决于当前硬盘负载。且写入缓冲区aof_buf中，还有另一个好处，Redis可以提供多种缓冲区同步硬盘的策略，在性能和安全性方面做出平衡。
        
  

####4.4.3  AOF文件同步-缓冲区同步文件策略


1, 系统调用writ和fsync说明

	write操作会处罚延迟写（delayed write）机制，Linux在内核提供页缓冲区用来提高硬盘IO性能。write操作在写入系统缓冲区后直接返回。同步硬盘操作依赖于系统调度机制，列如：缓冲区页空间写满或达到特定时间周期。同步文件之前，如果此时系统故障宕机，缓冲区内数据将丢失
	
	fsync针对单个文件操作（比如AOF文件），做强制硬盘同步，fsync将阻塞通道写入硬盘完成后返回，保证了数据持久化。

	
2,aof同步策略appendfsync

	Redis提供了多种AOF缓冲区同步文件策略，由参数appendfsync控制。可取三种值：always、everysec和no。

	 配置为always时，每次写入都要同步AOF文件，在一般的STAT硬盘上，Redis只能支持大约几百TPS写入，显然跟Redis高性能特性背道而驰，不建议配置。

    配置为no,由于操作系统每次同步AOF文件的周期不可控，而且会极大每次同步硬盘的数据量，虽然提升了性能，但数据安全性无法保证。

    配置为everysec,是建议的同步策略，也是默认配置，做到兼顾性能和数据安全性，理论上只有在系统突然宕机的情况下丢失1s的数据。（严格来说最多丢失1s数据是不准确）
	
	
  
	
###4.5 AOF的重写机制

随着命令不断写入AOF，文件会越来越大，为了解决这个问题，Redis引入了AOF重写机制压缩文件体积。AOF文件重写是吧Redis进程内的数据转化为写命令同步到新AOF文件的过程。
	

####4.5.1 重写后的AOF文件为什么可以变小？有如下原因：

    1） 进程内已经超时的数据不再写文件。

    2）旧的AOF文件含有无效命令，如del key1、 hdel key2、srem keys、set a 111、set a 222等。重写使用进程内数据直接生成，这样新的AOF文件只保留最终数据的写入命令。

    3) 多条写命令可以合并为一个，如lpush list a、lpush list b、 lpush list c 可以转化为：lpush list a b c。为了防止但挑明了过大造成客户端缓冲区溢出，对于list、set、hash、zset等类型曹组，以64个元素为界拆分为多条。
    
    
####4.5.2,AOF重写过程可以手动触发和自动触发：

    手动触发：直接调用bgrewriteaof命令

    自动触发：更具auto-aof-rewrite-min-size和auto-aof-rewrite-percentage参数确定自动触发时机

        auto-aof-rewrite-min-size:表示运行AOF重写时文件最小体积，默认为64MB

        auto-aof-rewrite-percentage:代表当前AOF文件空间（aof_current_size）和上一次重写后AOF文件空间（aof_base_size）的值
    
   
   
####4.5.3 AOF重写加载流程


1）执行AOF重写请求。   
	 
	如果当前进程正在执行AOF重写，请求不执行并返回如下响应:
	     
	如果当前进程正在执行bgsave操作，重写命令延迟到bgsave完成后再执行，返回如下响应：
	
2) 父进程执行fork创建子进程，开销等同于bgsave过程。

3.1） 主进程fork操作完成后，继续响应其他命令。所有修改命令依然写入AOF缓冲区并更具appendfsync策略同步到硬盘，保证原有AOF机制正确性。

3.2） 由于fork操作运用写时复制技术，子进程只能共享fork操作时的内存数据。由于父进程依然响应命令，Redis使用"AOF重写缓冲区"保存这部分新数据，防止新AOF文件生成期间丢失这部分数据。


4）子进程根据内存快照，按照命令合并规则写入到新的AOF文件。每次批量写入硬盘数据量由配置aof-rewrite-incremental-fsync控制，默认为32MB，防止单次刷盘数据过多造成硬盘阻塞。

5.1）新AOF文件写入完成后，子进程发送信号给父进程，父进程更新统计信息，具体见info persistence下的aof_*相关统计。

5.2）父进程把AOF重写缓冲区的数据写入到新的AOF文件。

5.3）使用新AOF文件替换老文件，完成AOF重写。
   
	
	
   
####4.6 AOF的重启加载 


AOF和RDB文件都可以用于服务器重启时的数据恢复


    流程说明：

    1） AOF持久化开启且存在AOF文件时，优先加载AOF文件，打印如下日志：

		DB loaded from append only file: 5.841 seconds

    2） AOF关闭或者AOF文件不存在时，加载RDB文件，打印如下日志：

		DB loaded from disk:5.586 seconds

    3） 加载AOF/RDB文件城后，Redis启动成功。

    4） AOF/RDB文件存在错误时，Redis启动失败并打印错误信息  	
	
#三 keys和scan扫描

		keys *  会使redis挂掉
		
		scan 0 match * count 1000000  
		
		
		
#四，数据类型

	redis官方命令详解
		https://www.redis.net.cn/order/

		
#主从同步和切换		

	

	


#HyperLogLog与布隆过滤器

	https://www.cnblogs.com/chianquan/p/9505694.html
	
	
#redis 管道pipelining



#分布式锁和lua脚本



#缓存穿透,雪崩,限流，降级








	